# 2026-11-08 changes

- Set keep_with_next on all 35 table captions (4 main + 31 supplement).
- Fixes 3 caption/table page splits (Table 1, Table S8, Table S22).
- A first partial fix (3 captions only) introduced 2 new splits (S18, S24); the uniform fix eliminates the whole class. Supplement is now 32 pages.
- Two independent rendered validations + three independent manuscript rechecks passed.
- No text, numbers, references or figures changed.
- Added Supplementary_Data_Files.zip (21 harmonized CSVs + Table S30 302-row export)
  so the Supplement's data-availability statement resolves to a real archive file.
  MANIFEST.csv recomputed. No manuscript text changed.
- Graphical abstract v59 -> v60: uniform connector arrows (4.0 units, mutation_scale 10),
  subtitle repositioned to remove overlap with the EXPOSURES frame; all wording,
  colours, font sizes and canvas size unchanged. MANIFEST recomputed.
- Figure 1 v56 -> v57: two in-figure spellings changed to US English
  (harmonisation->harmonization, harmonised->harmonized), matching the manuscript
  Figure 1 caption and the 2026-11-07 language unification. Source added as
  code/current/_build_fig1_v57.py. A v56 baseline re-render matched the old PNG
  pixel-for-pixel; body 8.6 pt / titles 9.6 pt, band heights, gap, colours and
  canvas (17.40 x 18.03 cm @600 dpi) are unchanged. MANIFEST recomputed.
- Corrected the release README: the concept DOI resolves to the latest version,
  so the Cover Letter does not need a version-DOI edit after upload.
- Added code/current/_gabs_v60.py, the source that generates the current v60
  graphical abstract. The 2026-11-09 v60 layout fix changed the figure but did
  not archive its script, so the 'analysis code ... publicly archived' statement
  could not be reproduced for that figure. README.md now maps all five current
  figures to their source scripts. MANIFEST recomputed; no submission file changed.
- Verified by re-running build_figs1_v53.py / build_figs2_v53.py: both reproduce
  the current 600-dpi supplemental figures pixel-for-pixel (their *_300dpi.png
  output filenames are historical). README mapping updated accordingly.
- 2026-11-11 post-mock-review revision: Table S31 caption 29 -> 33; four SNP counts
  given thousands separators; abstract / Clinical Perspective / limitations / sample-size
  wording calibrated; graphical abstract v61 with figure wording aligned to the text.
  submission/, nmr text exports, verification PDFs, README, MANIFEST regenerated.
- 2026-11-11: synchronized core_properties.title of Cover_Letter.docx and
  Highlights.docx with the current FTO-locus title (hidden metadata carriers).
- Legacy verifier retirement: moved verification/_verify_release.py (v52-era
  stale assertions) to code/history/; it must not be run against the current build.
- 2026-11-12 figure-accuracy revision (see README section of the same date):
  Figure S1 v54 right-margin fix for the clipped 2.5 tick; Figure 1 v58 and
  Graphical Abstract v62 case-count units and R13 qualifier; Figure S2 v54
  legend wording and three-decimal control rows; Manuscript Figure S2 caption
  clarified. Four new source scripts added to code/current/. Baseline re-renders
  of all four old scripts matched the previous PNGs pixel-for-pixel. submission/,
  verification PDFs, README and MANIFEST regenerated.
- 2026-11-14 second-round mock-review revision (text only, no figures or
  estimates changed): STROBE-MR checklist quoted fragments corrected to the
  current three-way null classification; reference 30 title restored to the
  published form (PMID 29686387); Multiplicity family rationale linked to
  Table S28; Table S31 caption totals scoped and seven-row sums given;
  Highlights items 1 and 4 disambiguated; Figure S2 caption distinguishes
  its filled-marker threshold from Figure 2. Body 9,601 -> 9,669 words.
  submission/, verification PDFs, README and MANIFEST regenerated.

## 2026-11-15
- Corrected Yuan shared-SNP allocation and reran all seven exposures with fixed RNG seed 20261027. Updated Tables 2, S26, S27 and S30; Figure 2 v57, Figure S1 v55, Figure S2 v55 and Graphical Abstract v63. Added ref 58 (Yuan Author Correction) and corrected ref 9 title.
- Rebuilt Supplementary_Data_Files.zip and added complete Yuan harmonized data and FTO regional inputs/prior outputs.

- Editorial-focused revision on 2026-11-15: abstract reframed around conflicting genetic evidence and shortened to 230 words; Discussion reduced by 849 words without deleting core limitations; PubMed updated to 2026-11-15 and refs 59-61 appended (PMID 42252494, 42985412, 41733040); Cover Letter now reports the non-significant Yuan coffee estimate. Figure 1 v59 and Graphical Abstract v64 are presentation-only revisions. Body 9,676 -> 8,851 words; no estimate, table value or significance decision changed. submission, verification PDFs, current figure sources, README and MANIFEST regenerated.

- Final detail sweep on 2026-11-17: 215 language/notation/format replacements; all 61 references audited and renumbered by first appearance; 37 references expanded to the AHA first-10-author format; Ann Statist. abbreviation and Yuan Author Correction issue fixed. Added MD degrees, 38-character short title, total word count and correct title-page/page-number behavior; moved Figure legends and Tables after References; completed repeated table headers. Abstract 240 words, CP 207 words, main text 8,103 words, total 12,442 words. No estimate or significance decision changed. submission, verification PDFs, README and MANIFEST regenerated.


## 2026-11-17 S27 and wording closure

- Corrected the stale Table S27 note to the corrected Yuan outputs: 1.26-1.58 before exclusion and 3.85% of 2,000 random deletions.
- Synchronized the main text to 3.85% and calibrated 'determine' to 'interrogate' in the objective and STROBE-MR quotation.
- Added Graphical Abstract v65 and its source; updated placebo script display precision only. Isolated placebo output is byte-identical to the archived corrected distribution.


## 2026-11-22 Supplement pagination repair

- Added `w:cantSplit` to all 24 STROBE-MR rows and all 405 Table S30 rows (629 rows total), eliminating six confirmed cross-page row splits. Supplement remains 36 pages.
- Three post-fix verification passes passed: all 8,352 text nodes are unchanged; only the two intended tables gained row properties; fresh-render page text and 110-dpi pixels match the inspected post-fix PDF; all affected page boundaries passed enlarged visual review.
- Updated the submission README to Graphical Abstract v65 and to the actual visual-check/public-release status. Regenerated `verification/Supplement_rendered.pdf`, synchronized `submission/` and recomputed MANIFEST.csv.
- No manuscript or supplement text, scientific estimate, reference, significance decision or figure changed. Public Zenodo v6.0.0 remains the pre-repair Supplement until a new release is published.
