# 2026-11-07 changes

- 9 UK spellings normalized (analysed/behavior/modelled) in the manuscript.
- Conclusions now name the FTO locus: "pleiotropy at the FTO locus - most plausibly adiposity-linked".
- README word count 9,508 -> 9,516.
- P2-2 (single-locus / eQTL caveat) NOT added: Discussion P103/P104 already state both caveats.
- submission/, nmr text exports, verification PDFs and MANIFEST regenerated.
