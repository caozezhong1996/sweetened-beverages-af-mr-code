import io
import shutil
import sys
from pathlib import Path
from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
PKG = Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")
ARC = Path(r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版\JAHA_v525_改稿留档\审读意见_20261028")


def paragraphs(doc):
    for p in doc.paragraphs:
        yield p
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    yield p


def set_run_text_preserve(paragraph, start, end, replacement):
    runs = paragraph.runs
    full = "".join(run.text for run in runs)
    assert full == paragraph.text, "run/text mismatch"
    assert 0 <= start < end <= len(full)
    cursor = 0
    inserted = False
    for run in runs:
        text = run.text
        left, right = cursor, cursor + len(text)
        cursor = right
        if right <= start or left >= end:
            continue
        prefix = text[: max(0, start - left)] if left <= start < right else ""
        suffix = text[max(0, end - left) :] if left < end <= right else ""
        if not inserted:
            run.text = prefix + replacement + suffix
            inserted = True
        else:
            run.text = suffix
    assert inserted


class Editor:
    def __init__(self, path):
        self.path = path
        self.doc = Document(str(path))
        self.count = 0

    def replace(self, old, new, expected=1):
        hits = 0
        for p in paragraphs(self.doc):
            full = p.text
            start = 0
            while True:
                idx = full.find(old, start)
                if idx < 0:
                    break
                set_run_text_preserve(p, idx, idx + len(old), new)
                hits += 1
                full = p.text
                start = idx + len(new)
        assert hits == expected, f"replace count {hits} != {expected}: {old[:90]}"
        self.count += hits
        print(f"PASS replace x{hits}: {old[:72]}")

    def paragraph(self, prefix, new_text, expected=1):
        matches = [p for p in paragraphs(self.doc) if p.text.startswith(prefix)]
        assert len(matches) == expected, f"paragraph count {len(matches)} != {expected}: {prefix}"
        for p in matches:
            set_run_text_preserve(p, 0, len(p.text), new_text)
        self.count += len(matches)
        print(f"PASS paragraph x{len(matches)}: {prefix[:72]}")

    def span(self, start_marker, end_marker, new_text, expected=1):
        hits = 0
        for p in paragraphs(self.doc):
            full = p.text
            a = full.find(start_marker)
            if a < 0:
                continue
            b = len(full) if end_marker == "" else full.find(end_marker, a)
            assert b >= 0, f"end marker not found: {end_marker}"
            set_run_text_preserve(p, a, b, new_text)
            hits += 1
        assert hits == expected, f"span count {hits} != {expected}: {start_marker}"
        self.count += hits
        print(f"PASS span x{hits}: {start_marker[:72]}")

    def save(self):
        self.doc.save(str(self.path))
        print(f"SAVED {self.path} ({self.count} edits)")


for name in ("Manuscript.docx", "Cover_Letter.docx"):
    backup = ARC / f"修改前备份_{name}"
    shutil.copy2(PKG / name, backup)
    print("BACKUP", backup)

m = Editor(PKG / "Manuscript.docx")
m.paragraph(
    "Background: Milk tea",
    "Background: Our literature search identified no prospective study of milk tea consumption and atrial fibrillation (AF), and milk tea is not instrumented in genome-wide association studies (GWAS). We tested whether genetically proxied intake of its sweetened-beverage components is causally associated with AF.",
)
m.replace("two overlap-free replication sources", "two replication sources")
m.paragraph(
    "• In the first unified",
    "• In a unified Mendelian randomization framework of five sweetened-beverage phenotypes and their caffeinated counterparts against large public atrial fibrillation genome-wide association studies, genetically proxied sweetened-beverage intake showed no evidence of a causal association across four European-ancestry outcome sources, including a UK Biobank-free panel of 192,851 cases, and an East Asian contextual analysis.",
)
m.paragraph(
    "• The only recurring signal",
    "• The recurring coffee signal was not attributable to caffeine-handling pathways: adiposity-locus exclusion collapsed between-source spread to 1.39–1.48 but left a residual association (pooled OR 1.41; P = 0.0007); colocalization occurred at FTO, not at caffeine-metabolism loci.",
)
m.paragraph(
    "• The modest observational association",
    "• The source of the modest observational associations remains unresolved; these data do not test whether weight management should take precedence over beverage-specific advice.",
)
m.replace(
    "To our knowledge, no prospective cohort has measured milk tea consumption directly, and no GWAS instruments it;",
    "Our literature search identified no prospective cohort that directly measured milk tea consumption in relation to AF, and no GWAS currently instruments it;",
)
m.replace(
    "Milk tea itself has never been studied as an exposure;",
    "Milk tea itself was not directly evaluated in this study, and our literature search identified no prior AF-specific study of milk tea as an exposure;",
)
m.replace("Two overlap-free replication outcomes", "Two replication outcomes")
m.replace(
    "these analyses verify that the pipeline detects a known causal effect.",
    "these analyses provide directionally calibrated positive controls rather than proof of analytical sensitivity.",
)
m.replace(
    "The same index variants were used across outcome sources; for BioBank Japan, four proxy variants were substituted where the index variant was unavailable, giving 36 variants.",
    "The same index variants were used across outcome sources where available; for BioBank Japan, unavailable index variants were replaced by proxies, with exposure-specific retained counts reported in Table S1.",
)
m.replace("both overlap-free replication outcomes", "both replication outcomes", expected=2)
m.replace(
    "indicated that the coffee estimate was carried by adiposity variants",
    "suggested a contribution from adiposity-linked variants",
)
m.replace("Outcome: AF (replication, overlap-free)", "Outcome: AF (replication)")
m.replace(
    "The MRlap overlap-corrected estimate did not differ from the observed estimate (difference P = 0.07; Table S17), excluding material overlap bias.",
    "The MRlap overlap-corrected estimate did not differ measurably from the observed estimate (difference P = 0.07; Table S17), but this comparison does not exclude residual overlap or other bias.",
)
m.replace(
    "An independent coffee GWAS (Neale lab field 1498; 24 instruments) gave a concordant, non-significant estimate (OR 1.18, 0.93–1.50; P = 0.166); cross-GWAS fixed-effect meta-analysis gave OR 1.23 (1.04–1.44; P = 0.013; Table S19).",
    "A second coffee GWAS derived from the same UK Biobank resource (Neale lab field 1498; 24 instruments) gave a concordant, non-significant estimate (OR 1.18, 0.93–1.50; P = 0.166; Table S19). Because the exposure sources and instruments overlap with the main analysis, this is a phenotype-definition sensitivity analysis rather than independent replication; the cross-GWAS fixed-effect estimate is not interpreted as independent evidence or used to increase precision.",
)
m.replace(
    "The null findings therefore exclude moderate-to-large causal effects but cannot exclude effects of the magnitude reported by observational cohorts.",
    "The null findings therefore exclude only effects above the exposure-specific 95% confidence upper bounds (approximately 1.01–1.17 in the European meta-analyses); effects of the magnitude reported by observational cohorts cannot be excluded.",
)
m.replace(
    "At FTO, the larger outcome GWAS yielded strong evidence of a shared causal variant (PP.H4 = 0.894; FinnGen R13 0.906), directly implicating adiposity-linked pleiotropy—consistent with the attenuation of the coffee estimate after BMI adjustment.",
    "At FTO, the larger outcome GWAS yielded strong evidence of a shared causal variant (PP.H4 = 0.894; FinnGen R13 0.906), providing locus-level evidence compatible with adiposity-linked pleiotropy; because BMI was not included in the colocalization model, this does not establish mediation through adiposity.",
)
m.replace(
    "The FTO shared-variant conclusion was robust to the colocalization prior (PP.H4 > 0.8 for p12 ≥ 5 × 10⁻⁶ in both sources; Table S13).",
    "The FTO result was prior-sensitive (PP.H4 > 0.8 for p12 ≥ 5 × 10⁻⁶, but 0.457 at p12 = 10⁻⁶; Table S13) and is therefore treated as locus-level rather than pathway-proof evidence.",
)
m.paragraph(
    "As a positive control, the identical pipeline",
    "As a positive control, the identical pipeline was applied to alcohol consumption (Table S5). Genetically instrumented alcoholic drinks per week (GSCAN; 33 SNPs) were directionally associated with higher AF odds in all four cohorts (ORs 1.12–2.25), with a nominally significant European meta-analysis (OR 1.19, 1.01–1.40; P = 0.035), consistent with the established causal contribution of alcohol to AF. Individual outcome estimates were not all significant, so this provides qualified rather than definitive support for analytical sensitivity. Alcohol intake frequency (UK Biobank; 97 SNPs) was not associated with AF in any cohort (all P ≥ 0.12); the contrast with drinks per week is compatible with different exposure definitions but does not by itself identify a quantity-versus-frequency mechanism.",
)
m.paragraph(
    "Against atrioventricular block",
    "Against atrioventricular block (Table S18), six of nine exposure tests were null (P ≥ 0.53); nominal associations for alcohol intake frequency (P = 0.043) and coffee intake (P = 0.042) did not survive Bonferroni correction, whereas the inverse association for sugar added to tea (P = 0.001) did. The negative control therefore failed for sugar added to tea and cannot validate instrument specificity. Shared adiposity or another correlated pathway is a possible explanation, but the present analysis does not identify it; accordingly, the beverage null estimates should not be interpreted as proof of no effect.",
)
m.replace("two overlap-free replication outcomes", "two replication outcomes", expected=2)
m.paragraph(
    "In this two-sample and multivariable Mendelian randomization study using four",
    "In this two-sample and multivariable Mendelian randomization study using four European-ancestry AF sources, including the largest public one (192,851 cases), genetically proxied consumption of sweetened beverages showed no evidence of a causal association with atrial fibrillation. The null estimates exclude effects above their 95% confidence upper bounds (about 17% in the European meta-analysis), but not effects of the magnitude reported observationally (10–20%). Three nominal IVW signals emerged, but none met the robustness criteria: the inverse association for sugar added to coffee failed to replicate; the inverse association for sugar added to tea in FinnGen R13 was absent from the other sources and attenuated in the meta-analysis; and the recurring coffee association was partly linked to adiposity-locus instruments. Removing those instruments collapsed the between-source spread from 1.26–1.79 to 1.39–1.48 but left a residual association (pooled OR 1.41, 1.16–1.72; P = 0.0007), so adiposity explains heterogeneity rather than the whole signal. East Asian estimates were imprecise and contextual. The positive lifestyle control was directionally associated with AF but individually underpowered, offering qualified support for analytical sensitivity.",
)
m.paragraph(
    "Beyond previous single-beverage",
    "Beyond previous single-beverage and dietary-exposure MR analyses [4,5,6,34], the present study contributes a unified multi-exposure framework with adiposity modelling, locus-level colocalization and an East Asian contextual arm. Our findings diverge from two UK Biobank cohort analyses that reported 10–20% higher incident AF risk among high consumers of SSBs or ASBs [2,3]. A previous smaller MR study reported a positive causal association between SSBs and AF (OR 1.023, 1.007–1.038; P = 0.0039) [5], using an AF outcome with 3,818 cases, a relaxed instrument threshold and no adiposity modelling. Direct numerical comparison of effect sizes is inappropriate because exposure definitions and scales differ; our sensitivity analyses nevertheless do not support a robust causal interpretation. Three considerations help reconcile the divergence. First, the observational hazard ratios were modest and residual confounding remains possible, but our data cannot quantify how much is explained by adiposity. Second, MR estimates reflect lifelong average exposure, whereas cohorts capture mid-life intake over about a decade. Third, the exposure-specific confidence bounds limit larger effects on the per-category scale, but they do not exclude observational-magnitude effects and cannot be converted into gram- or serving-based thresholds.",
)
m.paragraph(
    "Genetic instruments for self-reported beverage intake are not molecule-specific:",
    "Genetic instruments for self-reported beverage intake are not molecule-specific: they index intake behavior together with adiposity, dietary-quality and socioeconomic correlates [35,36]. Horizontal pleiotropy can bias estimates in either direction, so the present null findings do not establish absence of effect, particularly given limited power for observational-magnitude effects. Source-dependent outlier sensitivity, attenuation after BMI modelling, colocalization and locus exclusion help localize potential pleiotropy but do not fully identify its pathway. Complementary estimators provide partly concordant but not uniform results. We therefore interpret these estimates as effects of the behavior cluster the instruments index, not of a molecularly isolated exposure, and do not equate null estimates with safety.",
)
m.paragraph(
    "The BMI positive control",
    "The BMI positive control (OR 1.47 per SD) reaffirms adiposity as an established causal determinant of AF and a plausible source of confounding or pleiotropy, but the present design does not test how much of the observational SSB–AF association it explains. Two-step mediation MR was consistent with an adiposity pathway but cannot resolve direction at these loci. The difference-method direct estimate (OR 0.955, 0.705–1.292) is compatible with a substantial residual effect, and the mediated fraction cannot be separated from adiposity liability. FTO colocalization provides locus-level corroboration rather than proof of an adiposity-mediated pathway. The collapse of between-source spread after adiposity-locus exclusion (1.26–1.79 to 1.39–1.48), together with the placebo test (only 0.9% of 2,000 random exclusions achieved an equally small spread), argues against simple random-deletion regression to the mean. The residual pooled estimate (1.41) nevertheless indicates that adiposity does not fully explain the association. Positive genetic correlations of SSB and ASB intake with AF alongside null MR estimates are compatible with shared heritable architecture; they do not establish that weight management should take precedence over beverage-specific advice [1].",
)
m.replace(
    "For young East Asian consumers—where global estimates place a rising SSB-attributable cardiovascular burden [44]—the AF-prevention message remains the established one: healthy weight, limited alcohol, cardiometabolic risk control [1].",
    "For East Asian consumers, the AF-prevention message remains the established one: healthy weight, limited alcohol and cardiometabolic risk control [1].",
)
m.replace(
    "Here it is bounded by cross-estimator concordance, participant-disjoint replication and null metabolite-instrument estimates.",
    "Here it is bounded, but not eliminated, by cross-estimator concordance, replication in the UK Biobank-free Yuan outcome and null metabolite-instrument estimates.",
)
m.paragraph(
    "Genetically proxied consumption of sweetened beverages—including",
    "Genetically proxied consumption of sweetened beverages—including the sugar component of tea- and coffee-based drinks, the closest available proxy for milk-tea-type beverages—showed no evidence of a causal association with atrial fibrillation in European or East Asian populations. Effects above the exposure-specific 95% confidence upper bounds are excluded, but observational-magnitude effects and milk-tea exposure itself remain untested. The source of the modest observational associations is unresolved, and these data do not establish a choice between beverage-specific advice and established cardiometabolic risk management. The recurring coffee signal was attenuated but not eliminated by adiposity-locus exclusion, leaving an unexplained residual association; direct investigation of milk tea consumption in prospective East Asian cohorts remains needed.",
)
m.replace(
    "Circulation. 2026. doi:10.1161/CIR.0000000000001454.",
    "Circulation. 2026;154(9):e345-e355. doi:10.1161/CIR.0000000000001454.",
)
m.replace("Mazza A, Montagnana D, et al.", "Mazza A, Montagnana M, et al.")
m.save()

c = Editor(PKG / "Cover_Letter.docx")
c.replace("Date: 13 October 2026", "Date: 28 October 2026")
c.replace("the last two serving as overlap-free replication outcomes", "the last two serving as replication outcomes")
c.span(
    "The single recurring signal",
    " Biomarker-level MR",
    "The single recurring signal—for coffee intake (European meta-analytic OR 1.34, 1.11–1.62; P = 0.002; UK Biobank-free OR 1.79, 1.23–2.60)—failed every pre-specified robustness criterion. Multivariable estimates were attenuated but relied on weak conditional instruments and are therefore exploratory; locus-level colocalization was observed at FTO rather than caffeine-metabolism loci, and genome-wide CAUSE was compatible with correlated pleiotropy. Removing variants within 500 kb of body-mass-index loci collapsed between-source spread from 1.26–1.79 to 1.39–1.48 but left a residual association (pooled OR 1.41, 1.16–1.72; P = 0.0007), indicating that adiposity explains heterogeneity rather than the whole signal.",
)
c.paragraph(
    "To our knowledge this is the first study",
    "This study brings the full sweetened-beverage spectrum into a single, uniformly analyzed Mendelian randomization framework and combines a UK Biobank-free outcome replication with locus-level colocalization, biomarker-level MR and explicit instrument-strength diagnostics. Its principal contribution is not the number of analyses, but a calibrated assessment of which reported beverage–AF associations remain robust and which do not. The archived code, harmonized datasets and result tables are provided for reuse.",
)
c.span(
    "In accordance with journal policy on generative AI",
    "",
    "In accordance with journal policy on generative AI, we disclose that an artificial-intelligence assistant (Kimi, Moonshot AI) was used for language editing and code assistance. All analyses, interpretations and conclusions are the authors' own; all content was independently verified and approved by the authors, who take full responsibility for the integrity of the work.",
)
c.save()
