import io
import sys
from pathlib import Path
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
path = Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\Supplement.docx")
doc = Document(str(path))
for table in doc.tables:
    for i, row in enumerate(table.rows):
        trPr = row._tr.get_or_add_trPr()
        if trPr.find(qn("w:cantSplit")) is None:
            trPr.append(OxmlElement("w:cantSplit"))
        if i == 0 and trPr.find(qn("w:tblHeader")) is None:
            trPr.append(OxmlElement("w:tblHeader"))
doc.save(str(path))
print("table pagination properties updated", len(doc.tables))
