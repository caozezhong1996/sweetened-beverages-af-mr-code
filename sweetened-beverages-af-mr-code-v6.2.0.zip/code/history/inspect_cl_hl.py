# -*- coding: utf-8 -*-
import io, os, re, sys
from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
P = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013"

for f in ["Cover_Letter", "Highlights"]:
    d = Document(os.path.join(P, f + ".docx"))
    print("=" * 22, f)
    for p in d.paragraphs:
        t = p.text.strip()
        if t and re.search(r"co-primary|FinnGen|Nielsen|GWAS|largest|Yuan|outcome source|adiposity", t):
            print("  ", t[:340])
