# -*- coding: utf-8 -*-
"""Verify every reference against CrossRef (v2: robust title extraction)."""
import io
import json
import os
import re
import sys
import time
import urllib.parse
import urllib.request

from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
PKG = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013"
OUT = r"C:\Users\64915\WorkBuddy\2026-10-06-13-49-21\ref_check.json"
MAILTO = "caozezhong1996@163.com"

man = Document(os.path.join(PKG, "Manuscript.docx"))
full = "\n".join(p.text.strip() for p in man.paragraphs if p.text.strip())
refs = [(int(n), t) for n, t in re.findall(r"(?m)^(\d+)\.\s(.+)$", full)]
print("references:", len(refs), flush=True)

INITIAL = re.compile(r"\b[A-Z]{1,3}\b")


def guess_title(s):
    segs = [x.strip(" .") for x in re.split(r"\.\s+", s)]
    cands = []
    for seg in segs:
        words = seg.split()
        if len(words) < 4:
            continue
        if "et al" in seg or ";" in seg:
            continue
        if re.search(r"\b(19|20)\d{2};\d", seg):
            continue
        if len(INITIAL.findall(seg)) > 1:       # author list has several initials
            continue
        if seg.count(",") > 4:
            continue
        cands.append(seg)
    return max(cands, key=len) if cands else max(segs, key=len)


def norm(s):
    return set(re.findall(r"[a-z0-9]+", s.lower()))


def sim(a, b):
    A, B = norm(a), norm(b)
    if not A or not B:
        return 0.0
    return len(A & B) / len(A | B)


def query(title):
    url = ("https://api.crossref.org/works?" + urllib.parse.urlencode(
        {"query.bibliographic": title, "rows": 5, "mailto": MAILTO}))
    req = urllib.request.Request(url, headers={"User-Agent": f"refcheck/2.0 (mailto:{MAILTO})"})
    with urllib.request.urlopen(req, timeout=45) as r:
        return json.load(r)["message"]["items"]


results = []
for n, txt in refs:
    title = guess_title(txt)
    rec = {"n": n, "ref": txt, "title": title, "best": None, "score": 0.0, "doi": None}
    for attempt in range(3):
        try:
            items = query(title)
            scored = []
            for it in items:
                t = (it.get("title") or [""])[0]
                scored.append((sim(title, t), t, it.get("DOI")))
            if scored:
                rec["score"], rec["best"], rec["doi"] = max(scored)
                rec["score"] = round(rec["score"], 3)
            break
        except Exception as e:
            rec["error"] = f"{type(e).__name__}"
            time.sleep(2 + 2 * attempt)
    results.append(rec)
    flag = "OK  " if rec["score"] >= 0.70 else ("??  " if rec["score"] >= 0.50 else "BAD ")
    print(f"{flag}[{n:>2}] {rec['score']:.2f}  {title[:66]}", flush=True)
    time.sleep(0.3)

with open(OUT, "w", encoding="utf-8") as f:
    json.dump(results, f, ensure_ascii=False, indent=1)

low = [r for r in results if r["score"] < 0.70]
print(f"\nchecked {len(results)}; >=0.70: {len(results)-len(low)}; <0.70: {len(low)}", flush=True)
for r in low:
    print(f"\n[{r['n']}] {r['score']}\n  cited: {r['title'][:130]}\n  found: {(r['best'] or '-')[:130]}\n  doi  : {r['doi']}", flush=True)
