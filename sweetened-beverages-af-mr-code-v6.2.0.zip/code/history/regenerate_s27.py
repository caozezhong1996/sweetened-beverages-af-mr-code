# -*- coding: utf-8 -*-
"""Regenerate Table S27 (adiposity-locus sensitivity) from the per-SNP data with
one reproducible implementation, and diff against the printed table."""
import csv
import io
import math
import os
import sys

import numpy as np

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
D = r"C:\a3work"
PKG = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013"

TAGS = [("Sugar_added_to_tea", "Sugar added to tea"),
        ("Sugar_added_to_coffee", "Sugar added to coffee"),
        ("Fizzy_drink_intake_SSB", "Fizzy drink intake (SSB)"),
        ("Low_calorie_drink_intake_ASB", "Low-calorie drink intake (ASB)"),
        ("Artificial_sweetener_added_to_tea", "Artificial sweetener added to tea"),
        ("Coffee_intake", "Coffee intake"),
        ("Tea_intake", "Tea intake")]
YUAN_LABEL = {"Sugar_added_to_tea": "Sugar added to tea",
              "Sugar_added_to_coffee": "Sugar added to coffee",
              "Fizzy_drink_intake_SSB": "Fizzy drinks (SSB)",
              "Low_calorie_drink_intake_ASB": "Low-calorie drinks (ASB)",
              "Artificial_sweetener_added_to_tea": "Sweetener added to tea",
              "Coffee_intake": "Coffee intake", "Tea_intake": "Tea intake"}

LOCI = np.array([(int(x["chr"]), int(x["pos"]))
                 for x in csv.DictReader(open(os.path.join(D, "tmp_bmi_instruments_v46.csv"), encoding="utf-8"))])


def near(c, p):
    return ((LOCI[:, 0] == c) & (np.abs(LOCI[:, 1] - p) <= 500000)).any()


def ivw(rows):
    if len(rows) < 3:
        return float("nan"), float("nan"), float("nan")
    a = np.array([[r[3], r[4], r[5]] for r in rows])
    bx, by, se = a[:, 0], a[:, 1], a[:, 2]
    w = 1 / se ** 2
    den = (w * bx ** 2).sum()
    b = (w * bx * by).sum() / den
    se_fe = math.sqrt(1 / den)
    q = float((w * (by - b * bx) ** 2).sum())
    df = len(rows) - 1
    infl = max(1.0, math.sqrt(q / df)) if df > 0 else 1.0
    se = se_fe * infl
    p = math.erfc(abs(b / se) / math.sqrt(2))
    return b, se, p


def load(tag, src):
    rows = []
    if src == "yuan":
        # Yuan outcome positions are GRCh38; the BMI locus list is GRCh37.
        # Use exposure-side GRCh37 coordinates and align complementary alleles.
        exp = {r["SNP"]: r for r in csv.DictReader(
            open(os.path.join(D, f"dat_{tag}_ebi_a_GCST006414.csv"), encoding="utf-8"))}
        comp = lambda a: a.translate(str.maketrans("ACGT", "TGCA"))
        for r in csv.DictReader(open(os.path.join(D, "yuan2025_instruments.tsv"), encoding="utf-8"), delimiter="\t"):
            if r["exposure"] != tag or r["SNP"] not in exp:
                continue
            e = exp[r["SNP"]]
            bx = float(e["beta.exposure"])
            ea, oa = e["effect_allele.exposure"], e["other_allele.exposure"]
            if r["ea.out"] == ea and r["oa.out"] == oa:
                by = float(r["beta.out"])
            elif r["ea.out"] == oa and r["oa.out"] == ea:
                by = -float(r["beta.out"])
            elif r["ea.out"] == comp(ea) and r["oa.out"] == comp(oa):
                by = float(r["beta.out"])
            elif r["ea.out"] == comp(oa) and r["oa.out"] == comp(ea):
                by = -float(r["beta.out"])
            else:
                continue
            rows.append((r["SNP"], int(e["chr"]), int(e["pos"]), bx, by, float(r["se.out"])))
    else:
        coord = {r["SNP"]: (int(r["chr"]), int(r["pos"]))
                 for r in csv.DictReader(open(os.path.join(D, f"dat_{tag}_ebi_a_GCST006414.csv"), encoding="utf-8"))}
        for r in csv.DictReader(open(os.path.join(D, f"dat_{tag}_{src}.csv"), encoding="utf-8")):
            if str(r.get("mr_keep", "TRUE")).upper() == "FALSE":
                continue
            c, p = coord[r["SNP"]]
            rows.append((r["SNP"], c, p, float(r["beta.exposure"]),
                         float(r["beta.outcome"]), float(r["se.outcome"])))
    return rows


records = []
for tag, label in TAGS:
    for src, out in [("ebi_a_GCST006414", "Nielsen"), ("finngen_R13", "FinnGen R13"), ("yuan", "Yuan 2025")]:
        rows = load(tag, src)
        keep = [r for r in rows if not near(r[1], r[2])]
        b0, s0, p0 = ivw(rows)
        b1, s1, p1 = ivw(keep)
        records.append(dict(outcome=out, exposure=label, n=len(rows),
                            OR=math.exp(b0), lo=math.exp(b0 - 1.96 * s0), hi=math.exp(b0 + 1.96 * s0), p=p0,
                            n_clean=len(keep), OR_clean=math.exp(b1),
                            lo_clean=math.exp(b1 - 1.96 * s1), hi_clean=math.exp(b1 + 1.96 * s1), p_clean=p1))

# diff vs printed S27
from docx import Document
sup = Document(os.path.join(PKG, "Supplement.docx"))
t27 = next(t for t in sup.tables if "SNPs (kept)" in " ".join(c.text for c in t.rows[0].cells))
printed = {}
for r in t27.rows[1:]:
    c = [x.text.strip() for x in r.cells]
    printed[(c[0], c[1])] = (c[3], c[6], c[7])

print(f"{'outcome':<12}{'exposure':<32}{'printed OR':<12}{'new OR':<10}{'printed clean':<16}{'new clean':<10}")
diffs = 0
for rec in records:
    key = (rec["outcome"], rec["exposure"])
    old = printed.get(key, ("-", "-", "-"))
    new_all = f"{rec['OR']:.2f}"
    new_cl = f"{rec['OR_clean']:.2f}"
    flag = ""
    if old[1] != "-" and not old[1].startswith(new_cl):
        flag = "  <-- DIFF"
        diffs += 1
    if flag or rec["exposure"] == "Coffee intake":
        print(f"{rec['outcome']:<12}{rec['exposure']:<32}{old[0]:<12}{new_all:<10}{old[1]:<16}{new_cl:<10}{flag}")

with open(os.path.join(D, "S27_regenerated.csv"), "w", encoding="utf-8", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(records[0].keys()))
    w.writeheader()
    for rec in records:
        w.writerow({k: (f"{v:.6g}" if isinstance(v, float) else v) for k, v in rec.items()})
print(f"\n{len(records)} rows written; {diffs} rows differ from printed table")
