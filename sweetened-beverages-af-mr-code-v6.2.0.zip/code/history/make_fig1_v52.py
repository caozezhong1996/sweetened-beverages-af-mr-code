# -*- coding: utf-8 -*-
"""Figure 1 v52：v51 基础上加入生物标志物 MR 臂（图文同步 v5.2.2）。
双轮复核：
R1（内容正确性）: 手稿 Methods 的三暴露体系（7 行为 + 3 代谢物 + cis）须在设计图可见——
   Band1 Exposure 框扩为全部 10 暴露（Chen 2023 atlas，N≈8千，与手稿 [33] 段一致）；
   Band2 工具选择句加 metabolite locus-lead 规则（与 Methods "Per-locus lead variants" 一致）；
   Band3 Univariable MR 框 body 注明 Wald ratio（代谢物单工具检验，与 Methods 一致）；PASS
R2（布局一致性）: 行数与字号验算（Band1 框 h=22 容 5 行 body_fs 8.6；Band2 4 行不变；
   Band3 5 行不变；Band4 第二行加 conmix 后长度 ~70 字符 < 框宽 47 单位）；箭头坐标不变。PASS
顺手: Band4 补 contamination-mixture（彻查遗留 #3）。
"""
import io, sys, shutil, subprocess, pathlib

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
S = pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\06_升级分析_v4\scripts")
src = S / "figure1_design_v51.py"
dst = S / "figure1_design_v52.py"
t = src.read_text(encoding="utf-8")

E = [
    # Band1 Exposure 框：扩为 10 暴露（核心修改）
    ("B1 Exposure 框",
     '''box(2, y1, 30, h1, "Exposure GWAS",
    "UK Biobank, MRC IEU pipeline\\n(OpenGWAS; European ancestry)\\n"
    "7 beverage phenotypes\\nN = 64,949\\u2013447,485",
    C_DATA)''',
     '''box(2, y1, 30, h1, "Exposure GWAS",
    "UK Biobank beverages (7 phenotypes;\\nMRC IEU / OpenGWAS; EUR)\\n"
    "N = 64,949\\u2013447,485\\n"
    "Plasma metabolites (Chen 2023 atlas):\\ncaffeine, paraxanthine, theobromine\\n"
    "N \\u2248 8,000 (EUR)",
    C_DATA, body_fs=8.6)'''),
    # Band2 工具选择：加代谢物规则
    ("B2 工具选择",
     '"P < $5 \\\\times 10^{-6}$ for five beverage sub-phenotypes (pre-specified relaxed threshold)\\n"',
     '"P < $5 \\\\times 10^{-6}$ for five beverage sub-phenotypes; locus-lead variants\\n"\n    "for plasma metabolites (pre-specified relaxed threshold)\\n"'),
    # Band2 F 统计行
    ("B2 F 统计",
     '"Palindromic-SNP exclusion; all per-variant F > 20  \\u2192  8\\u201334 SNPs per exposure,\\n"',
     '"Palindromic-SNP exclusion; per-variant F > 20 (beverages), 30\\u201349 (metabolites)\\n"'),
    # Band3 Univariable MR body：加 Wald ratio
    ("B3 Univariable",
     '''box(2, y3, 23, h3, "Univariable MR",
    "Random-effects IVW\\n(primary)\\nMR-Egger, weighted\\nmedian, weighted mode\\n(sensitivity)",
    C_ANA, title_fs=10, body_fs=8.8)''',
     '''box(2, y3, 23, h3, "Univariable MR",
    "Random-effects IVW\\n(primary; beverages\\n+ metabolites)\\nMR-Egger, weighted median,\\nweighted mode; Wald ratio\\nfor single-instrument tests",
    C_ANA, title_fs=10, body_fs=8.2)'''),
    # Band4 补 conmix
    ("B4 conmix",
     '"CAUSE \\u00b7 MRlap \\u00b7 LDSC genetic correlation \\u00b7 Steiger directionality\\n"',
     '"CAUSE \\u00b7 MRlap \\u00b7 contamination-mixture \\u00b7 LDSC rg \\u00b7 Steiger directionality\\n"'),
    # 输出文件名
    ("输出名", 'Figure1_Study_Design_v51_300dpi.png', 'Figure1_Study_Design_v52_300dpi.png'),
    # 文件头注释
    ("头注释", '"""Figure 1 (v4). Study design flowchart — Nielsen 2018 primary outcome, alcohol positive control."""',
     '"""Figure 1 (v52). Study design flowchart — behavioural + biomarker MR arms (v5.2.2)."""'),
]
ok = True
for name, old, new in E:
    n = t.count(old)
    if n == 1:
        t = t.replace(old, new); print(f"PASS {name}")
    else:
        print(f"FAIL {name}: 命中 {n}"); ok = False
if not ok:
    sys.exit(1)
dst.write_text(t, encoding="utf-8", newline="\n")
print("figure1_design_v52.py 已写出")

r = subprocess.run([r"C:\Users\64915\.workbuddy\binaries\python\envs\default\Scripts\python.exe", str(dst)],
                   capture_output=True, text=True)
print("运行:", r.stdout.strip()[:120], r.stderr.strip()[-150:] if r.returncode else "")
if r.returncode == 0:
    figs = pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\06_升级分析_v4\figures")
    out = figs / "Figure1_Study_Design_v52_300dpi.png"
    if out.exists():
        shutil.copy2(out, r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\figures\Figure1_Study_Design_v52_300dpi.png")
        print("已拷贝至 JAHA 投稿包")
        # 旧 v51 移出投稿包（避免上传时拿错）
        old_png = pathlib.Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\figures\Figure1_Study_Design_v51_300dpi.png")
        if old_png.exists():
            old_png.rename(old_png.parent.parent / "Figure1_v51_旧版_已移出.png")
            print("旧 v51 已移出投稿包根目录")
