# -*- coding: utf-8 -*-
"""Figure 2 v52 + Graphical Abstract v52：加入生物标志物臂与三阶段收敛。
双轮复核：
R1（图文一致）: 代谢物 meta 值取自 biomarker_meta_summary.csv（与手稿 [69] 段逐位一致：
  caffeine 0.99(0.92-1.07) P=0.85 / paraxanthine 0.98(0.93-1.02) P=0.31 / theobromine 0.84(0.72-0.98) P=0.029）；
  GA 收敛行对应摘要"Null genetic estimates converge with randomized trial evidence"。PASS
R2（布局验算）: F2 图高 9.0→12.0（10 暴露 vs 7），底部代谢物小节分隔线；GA 三处小改均为增量行/框加高，
  箭头起点同步下移，不改动既有文字块。PASS
"""
import io, sys, shutil, subprocess, pathlib

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
S = pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\06_升级分析_v4\scripts")
FIGS = pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\06_升级分析_v4\figures")
OUT = pathlib.Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\figures")
PY = r"C:\Users\64915\.workbuddy\binaries\python\envs\default\Scripts\python.exe"

# ============ Figure 2：复制 v41 并注入代谢物小节 ============
t = (S / "forest_figure2_v4.py").read_text(encoding="utf-8")
edits = [
    ("去 daimon 依赖",
     'sys.path.insert(0, str(Path(sys.executable).parent.parent.parent))\nfrom daimon_runtime import setup_plot\n',
     ''),
    ("去 setup_plot 调用", 'setup_plot()\n', ''),
    ("exposures 列表加代谢物（reversed 后位于图底部）",
     'exposures = [\n    "Sugar added to tea", "Sugar added to coffee", "Fizzy drink intake SSB",\n    "Low-calorie drink intake ASB", "Artificial sweetener added to tea",\n    "Coffee intake", "Tea intake",\n]',
     'exposures = [\n    "Plasma caffeine", "Plasma paraxanthine", "Plasma theobromine",\n    "Sugar added to tea", "Sugar added to coffee", "Fizzy drink intake SSB",\n    "Low-calorie drink intake ASB", "Artificial sweetener added to tea",\n    "Coffee intake", "Tea intake",\n]'),
    ("代谢物记录注入",
     'df = pd.DataFrame(records)',
     '''# v52: plasma metabolite arm (European meta-analytic OR; biomarker_meta_summary.csv)
meta = pd.read_csv(NEW / "biomarker_meta_summary.csv")
name_map = {"caffeine": "Plasma caffeine", "paraxanthine": "Plasma paraxanthine", "theobromine": "Plasma theobromine"}
for _, r in meta.iterrows():
    records.append({"exposure": name_map[r["exposure"]], "source": "EUR meta (Nielsen + FinnGen R13)",
                    "OR": r["or"], "lo": r["lo"], "hi": r["hi"], "p": r["p"], "nsnp": 0,
                    "color": "#1A5276"})
df = pd.DataFrame(records)'''),
    ("图高 9.0→12.0", 'fig, ax = plt.subplots(figsize=(11.0, 9.0))', 'fig, ax = plt.subplots(figsize=(11.0, 12.0))'),
    ("代谢物小节分隔线",
     'ax.axvline(1.0, color="#666666", lw=1, ls="--")',
     '''# v52: separator between beverage block and metabolite block
ax.axhline(2 * 1.75 - 0.88, color="#bbbbbb", lw=0.8, ls=":")
ax.text(0.155, 2 * 1.75 - 0.88, "Plasma metabolites (Chen 2023 atlas)",
        fontsize=8.2, color="#666666", va="center", style="italic")
ax.axvline(1.0, color="#666666", lw=1, ls="--")'''),
    ("标题含代谢物",
     'ax.set_title("Mendelian randomization: beverage exposures and atrial fibrillation\\n"\n             "Primary outcome Nielsen 2018 (N = 1.03 M); FinnGen release R13; * P < 0.05 (nominal)", fontsize=11)',
     'ax.set_title("Mendelian randomization: beverage and plasma-metabolite exposures and atrial fibrillation\\n"\n             "Primary outcome Nielsen 2018 (N = 1.03 M); FinnGen R13 (co-primary); * P < 0.05 (nominal)", fontsize=11)'),
    ("输出名", 'Figure2_Forest_v41_300dpi.png', 'Figure2_Forest_v52_300dpi.png'),
]
ok = True
for name, old, new in edits:
    n = t.count(old)
    if n == 1:
        t = t.replace(old, new); print(f"PASS {name}")
    else:
        print(f"FAIL {name}: 命中 {n}"); ok = False
if ok:
    (S / "forest_figure2_v52.py").write_text(t, encoding="utf-8", newline="\n")
    r = subprocess.run([PY, str(S / "forest_figure2_v52.py")], capture_output=True, text=True)
    print("F2 运行:", r.stdout.strip()[-120:], r.stderr.strip()[-250:] if r.returncode else "")
    out = FIGS / "Figure2_Forest_v52_300dpi.png"
    if out.exists():
        shutil.copy2(out, OUT / out.name); print("已拷贝 F2 v52 到投稿包")
        old = OUT / "Figure2_Forest_v41_300dpi.png"
        if old.exists():
            old.rename(old.parent.parent / "Figure2_v41_旧版_已移出.png"); print("旧 F2 已移出")

# ============ Graphical Abstract：三处增量修改 ============
g = (S / "graphical_abstract_v50.py").read_text(encoding="utf-8")
ge = [
    ("EXPOSURES 标题含代谢物",
     'txt(50, 128.8, "EXPOSURES — 7 beverage phenotypes", size=7.8, weight="bold", color=BLUE)',
     'txt(50, 128.8, "EXPOSURES — 7 beverages + 3 plasma metabolites", size=7.8, weight="bold", color=BLUE)'),
    ("EXPOSURES 框加高+代谢物行",
     'box(4, 116, 92, 15, LBLUE, BLUE)',
     'box(4, 113.5, 92, 17.5, LBLUE, BLUE)\ntxt(50, 116.4, "Plasma caffeine · paraxanthine · theobromine (Chen 2023 atlas; N ≈ 8,000)", size=7.2, color=BLUE, style="italic")'),
    ("EXPOSURES 箭头起点下移",
     'arrow(50, 116, 50, 110.5)',
     'arrow(50, 113.5, 50, 110.5)'),
    ("代谢物结果独立行（RG 框与 CONCLUSION 箭头之间）",
     'arrow(50, 40.5, 50, 35.5)',
     'txt(50, 38.2, "Plasma caffeine & paraxanthine: no genetic evidence of an association with AF (P ≥ 0.31)",\n    size=7.4, color=GREEN, weight="bold")\narrow(50, 40.5, 50, 35.5)'),
    ("底部三阶段收敛行",
     'txt(50, 18.5, "Direct measurement of milk-tea consumption in prospective East Asian cohorts remains needed.",\n    size=7.2, color=MUT, style="italic")',
     'txt(50, 19.5, "Genetic nulls converge with randomized trial evidence on susceptibility, acute exposure and recurrence.",\n    size=7.0, color=MUT, style="italic")\ntxt(50, 15.8, "Direct measurement of milk-tea consumption in prospective East Asian cohorts remains needed.",\n    size=7.2, color=MUT, style="italic")'),
    ("GA 输出名", "Graphical_Abstract_v50_300dpi.png", "Graphical_Abstract_v52_300dpi.png"),
]
ok = True
for name, old, new in ge:
    n = g.count(old)
    if n == 1:
        g = g.replace(old, new); print(f"PASS {name}")
    else:
        print(f"FAIL {name}: 命中 {n}"); ok = False
if ok:
    (S / "graphical_abstract_v52.py").write_text(g, encoding="utf-8", newline="\n")
    r = subprocess.run([PY, str(S / "graphical_abstract_v52.py")], capture_output=True, text=True)
    print("GA 运行:", r.stdout.strip()[-150:], r.stderr.strip()[-250:] if r.returncode else "")
    out = FIGS / "Graphical_Abstract_v52_300dpi.png"
    if out.exists():
        shutil.copy2(out, OUT / out.name); print("已拷贝 GA v52 到投稿包")
        old = OUT / "Graphical_Abstract_v50_300dpi.png"
        if old.exists():
            old.rename(old.parent.parent / "Graphical_Abstract_v50_旧版_已移出.png"); print("旧 GA 已移出")
