# -*- coding: utf-8 -*-
"""提取手稿中与审稿意见对应的关键段落：LDSC、阴性对照、中介、MVMR、单位解释、BBJ。"""
from docx import Document

path = r"C:\Users\64915\Desktop\EJPC投稿包_奶茶房颤MR_v4.5.6_20260826\01_手稿_Manuscript\Manuscript_v456_Sweetened_Beverages_AF_MR.docx"
doc = Document(path)
paras = [p.text.strip() for p in doc.paragraphs if p.text.strip()]

keywords = {
    "LDSC / ldsc / genetic correlation": ["LDSC", "ldsc", "genetic correlation", "cross-trait"],
    "negative control": ["negative control", "negative-control"],
    "mediation / mediated proportion": ["mediated proportion", "mediation", "120%"],
    "MVMR single instrument": ["single joint instrument", "joint instrument", "conditional direct"],
    "BioBank Japan / cross-ancestry": ["BioBank Japan", "cross-ancestry"],
    "defensible reading": ["defensible"],
    "ever measured milk tea": ["ever"],
    "units / servings": ["servings", "units of"],
}

for name, kws in keywords.items():
    print("=" * 72)
    print("【" + name + "】")
    seen = set()
    for i, p in enumerate(paras):
        if any(k.lower() in p.lower() for k in kws):
            key = p[:80]
            if key in seen:
                continue
            seen.add(key)
            print(f"[{i}] {p[:600]}")
            print("-" * 40)
