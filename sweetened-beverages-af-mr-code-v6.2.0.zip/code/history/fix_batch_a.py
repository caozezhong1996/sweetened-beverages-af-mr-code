# -*- coding: utf-8 -*-
"""Batch A: verified corrections in the manuscript builder."""
import io
import pathlib
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
P = pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
                 r"\04_docx构建脚本\build_manuscript_v51_JAHA.js")
t = P.read_text(encoding="utf-8")
E = []


def add(old, new):
    E.append((old, new))


# 1. principal findings: power + coffee clause
add("and the null estimates exclude moderate-to-large but not small effects.",
    "and the null estimates exclude effects above their 95% confidence upper bounds (about 17% in the European meta-analysis), but not effects of the magnitude reported observationally (10–20%).")
add("was traced to adiposity-locus instruments—removing them abolished the association in both overlap-free sources and made the three source-specific estimates converge on 1.26–1.39.",
    "was partly carried by adiposity-locus instruments: removing them collapsed the between-source spread from 1.26–1.79 to 1.39–1.48, but left a residual association (pooled OR 1.41, 1.16–1.72; P = 0.0007), so adiposity explains the heterogeneity rather than the whole signal.")

# 2. coffee literature paragraph
add("Evidence converges across three independent designs: susceptibility (genetic nulls here and previously [8,33,44]), acute triggering (day-long randomized exposure showed no atrial arrhythmia excess [30]) and recurrence (39% lower hazard with randomized caffeinated coffee [9]), as recently reviewed [46]; morphology- and metabolite-based analyses concord [31].",
    "Randomized and genetic evidence is nevertheless largely reassuring: acute triggering showed no atrial arrhythmia excess [30], and in DECAF, 200 post-cardioversion coffee drinkers had 39% lower AF/flutter recurrence with randomized caffeinated coffee [9]; the broader coffee–cardiovascular literature has been reviewed recently [46], and morphology- and metabolite-based analyses concord [31]. Our own estimate is positive but non-robust, with an adiposity-excluded residual of about 1.4 that remains unexplained.")
add("and removing adiposity-locus variants returned the estimate to the null in both overlap-free sources. The adiposity-excluded estimate in Nielsen 2018 remained nominally significant (OR 1.39, 1.04–1.86; P = 0.028), however, so an adiposity-independent effect of small magnitude cannot be excluded from that source alone.",
    "and removing adiposity-locus variants collapsed the between-source spread while leaving residual associations of 1.39 (1.04–1.86; P = 0.028) in Nielsen 2018 and 1.48 (1.01–2.18; P = 0.044) in Yuan 2025; only FinnGen R13 became non-significant (P = 0.096). Adiposity therefore does not fully account for the coffee signal, and an adiposity-independent effect cannot be excluded.")

# 3. BMI positive-control paragraph: remove untraceable numbers and soften priority
add("The BMI-mediated indirect effect was similar in magnitude to the nominal coffee association (Table S16); however, when the eight coffee instruments lying within 500 kb of a genome-wide-significant BMI locus were excluded, the mediated proportion fell from 120% to 66% and the difference-method direct estimate shifted from OR 0.955 to 1.084. The mediated fraction is therefore not separable from adiposity liability at these loci.",
    "The BMI-mediated indirect effect was similar in magnitude to the nominal coffee association (Table S16), but the difference-method direct estimate (OR 0.955, 0.705–1.292) is compatible with a substantial residual effect, and the mediated fraction cannot be separated from adiposity liability at these loci.")
add("so does the convergence of the three source-specific coffee estimates on 1.26–1.39 once adiposity-locus instruments are removed, which converts a source-dependent 1.26–1.79 spread into a single stable estimate.",
    "so does the collapse of between-source spread once adiposity-locus instruments are removed (1.26–1.79 to 1.39–1.48), which a placebo test shows is not regression to the mean (only 0.9% of 2,000 random exclusions achieved an equally small spread). The residual pooled estimate (1.41) nevertheless indicates that adiposity does not fully explain the association.")
add("This distinction shifts preventive emphasis toward weight management and dietary pattern [1].",
    "This distinction is compatible with adiposity-related pleiotropy; it does not, by itself, establish that weight management should take precedence over beverage-specific advice [1].")

# 4. abstract conclusions: power wording
add("moderate-to-large effects are excluded, small ones are not, and component-level nulls cannot certify the safety of composite milk-tea beverages.",
    "effects above their 95% confidence upper bounds (about 17%) are excluded, effects of the magnitude reported observationally (10–20%) are not, and component-level nulls cannot certify the safety of composite milk-tea beverages.")

# 5. Clinical Perspective bullet
add("These nulls exclude moderate-to-large effects but not small ones, and component-level nulls cannot certify the safety of composite milk-tea beverages; direct prospective studies of milk tea intake in East Asian cohorts remain needed.",
    "The 95% confidence upper bounds exclude risk increases above about 17% for most exposures, but not effects of the magnitude reported observationally (10–20%). Component-level nulls cannot certify the safety of composite milk-tea beverages; direct prospective studies of milk tea intake in East Asian cohorts remain needed.")

# 6. MR-RAPS sign consistency
add("were directionally consistent with the primary IVW analysis across all 21 exposure–outcome pairs (Tables S23 and S26).",
    "were broadly consistent with the primary IVW analysis across the 21 exposure–outcome pairs (Tables S23 and S26), with three sign reversals among the null estimates (sugar added to tea against Nielsen 2018, and sugar added to coffee and tea intake against FinnGen R13; all P ≥ 0.62).")

# 7. citations S1/S3/S4/S9
add("Between 8 and 34 independent SNPs per exposure were analyzed against the primary outcome (median 17; Table 2), with the same index variants harmonised to every outcome panel (BioBank Japan required four proxies; Table 2).",
    "Between 8 and 34 independent SNPs per exposure were analyzed against the primary outcome (median 17; Table S1), with the same index variants harmonised to every outcome panel (BioBank Japan required several proxy substitutions; Table S1).")
add("and weighted-median, MR-Egger and weighted-mode estimates were directionally consistent and non-significant (Table 3; Table S2).",
    "and weighted-median, MR-Egger and weighted-mode estimates were directionally consistent and non-significant (Table 3; Tables S2 and S3).")
add("with outlier correction resolving the estimate to the null in Nielsen 2018 (P = 0.20) but not FinnGen R13 (β = 0.345; P = 0.007).",
    "with outlier correction resolving the estimate to the null in Nielsen 2018 (P = 0.20) but not FinnGen R13 (β = 0.345; P = 0.007; Table S4).")
add("This study is reported in accordance with the STROBE-MR checklist [12].",
    "This study is reported in accordance with the STROBE-MR checklist [12] (Table S9).")

# 8. S16 direct CI in Results
add("difference-method residual OR 0.955, 0.775–1.176",
    "difference-method residual OR 0.955, 0.705–1.292")

# 9. 133 unique / 137 pairs
add("Of the 133 unique instrument variants, 128 (96%) were present in the UK Biobank-free Yuan 2025 panel, leaving 8–30 SNPs per exposure against that outcome (Table 2).",
    "Of the 133 unique instrument variants (137 exposure–instrument pairs across the seven exposures), 128 (96%) were present in the UK Biobank-free Yuan 2025 panel, leaving 8–30 SNPs per exposure against that outcome (Table 2).")

# 10. reference meaning
add("with the highest risk (HR 3.51, an interaction estimate) among participants with high genetic susceptibility and high ASB intake [2].",
    "with the highest risk (HR 3.51) in the joint category of high genetic susceptibility and high ASB intake [2].")

# 11. co-primary -> replication (global, done at the end)
# 12. pre-specified wording
add("Five deviations are reported transparently:",
    "Deviations from that plan are reported transparently (the study was not registered; the analysis plan and consistency criteria were defined by the authors before the outcome data were analyzed but were not externally validated):")

ok = True
for i, (old, new) in enumerate(E, 1):
    c = t.count(old)
    tag = "PASS" if c == 1 else f"FAIL x{c}"
    print(f"{tag:8}A{i:<3} {old[:70]!r}")
    if c != 1:
        ok = False
        continue
    t = t.replace(old, new)

if not ok:
    print("ABORTED")
    sys.exit(1)
P.write_text(t, encoding="utf-8", newline="\n")
print("written manuscript")
