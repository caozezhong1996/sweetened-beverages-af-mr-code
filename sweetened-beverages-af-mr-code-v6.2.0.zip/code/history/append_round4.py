# -*- coding: utf-8 -*-
import io
import pathlib
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

ADD = """

---

## 第四轮（2026-10-27）：Figure 2 重画 + 表格超宽根治

### Figure 2 重画（`build_fig2_v53.py`）
- **画布按印刷尺寸建**：17.40 × 15.60 cm @600 dpi（4110×3685 px）。因此脚本里的 pt 就是实印 pt，不再有\"设计 11 in、印成 17.4 cm\"导致的 0.6 倍缩水。
- **版式改为 2 行 × 3 列小多图**（原来是一条轴堆 5 个来源 + 3 个数值列）：
  上排 Nielsen（primary）/ FinnGen R13（co-primary）/ **Yuan 2025（co-primary, UKB-free）**；
  下排 EUR meta / AFGen 2018（sensitivity）/ BioBank Japan（EAS context）。
- **实印字号**：暴露标签 9.4 pt、x 轴刻度 9 pt、轴题 9.6 pt、面板标题 9 pt、脚注 8.2 pt。全部 ≥ 8 pt。
- **边距由实测文字宽度反推**（TextPath 量标签宽度），不再手填 —— 上一版左标签被裁掉就是因为手填 0.215。
- 超出坐标轴的置信区间用 **箭头标记截断**，不再默默画到边框。
- 代谢物只在 EUR meta 面板有估计，脚注明示，不画\"not available\"（视觉噪声）。
- 部署：`figures/Figure2_Forest.png`（旧 v52 移入归档 `旧版图件/Figure2_Forest_v52.png`）。

### 表格超宽：从机制上根治
问题根源：构建器同时写 `width: 100%` 和绝对 `columnWidths`，Word 按列宽渲染 → 列宽之和超栏宽就溢出。
过去只能逐张量、逐张改。现在在两个构建器的 `makeTable` 里加 `fitWidths()`：**列宽之和超过可印宽度时按比例缩放到恰好填满**（尾列吸收舍入误差）。
- 手稿上限 9026 twips（15.92 cm）、补充材料 9906 twips（17.47 cm）。
- 结果：手稿 4/4、补充材料 28/28 张表全部合栏，**以后新增表格自动合规**。

### 校验（verify_final.py）
摘要 248/250；引文 46 条连续；手稿 4 张表 ≤ 15.92 cm；补充材料 28 张表 ≤ 17.47 cm；
表 2 八列且第 4 列为 Yuan；表 1 含 Yuan 行；Figure 2 = 17.40 cm 宽。

### 仍在的三张图（已量，未动）
| 图 | 当前物理宽 | 印到 15.92 cm 的缩放 | 后果 |
|---|---|---|---|
| Figure 1 研究设计 | 29.21 cm | 0.55× | 正文 9 pt → 实印约 5.0 pt |
| Figure S1 LOO/漏斗 | 27.94 cm | 0.57× | 同上 |
| Figure S2 LDSC 森林 | 25.05 cm | 0.64× | 同上 |
| Graphical Abstract | 12.50 cm | 1.27× | 合格（比栏宽窄，放大印刷） |

Figure 1 不能靠改参数解决：3 列版式在 29 cm 画布上正文 9 pt 才放得下，
要印到 8 pt 就得把**版式改成 2 列并精简框内文字**，属重新设计，需要单独一轮。
"""

p = pathlib.Path(r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版"
                 r"\JAHA_v525_改稿留档\审读意见_20261026\修正记录_20261026.md")
t = p.read_text(encoding="utf-8")
if "第四轮" in t:
    print("skip")
else:
    p.write_text(t + ADD, encoding="utf-8")
    print("revision log updated;", len((t + ADD).splitlines()), "lines")

MEM = """

## Figure 2 重画 + 表格超宽根治（15:05–16:20）

- **Figure 2 v53**：`build_fig2_v53.py`，画布直接按印刷尺寸 17.40×15.60 cm @600 dpi 建，
  所以脚本里的 pt 就是实印 pt。版式改 2×3 小多图（6 个来源各一面板），实印字号 8.2–9.6 pt。
  边距用 TextPath 实测标签宽度反推（手填必裁边——上一版就裁了）。CI 超出轴用箭头标截断。
- **表格超宽根治**：两个构建器的 `makeTable` 加 `fitWidths()`，列宽和超限即按比例缩放（尾列吸收舍入）。
  手稿 9026 twips、补充 9906 twips。手稿 4/4、补充 28/28 全部合栏。
- **教训**：`width:{size:100,type:PERCENTAGE}` 与绝对 `columnWidths` 并存时，Word 按列宽渲染 —— 百分比不救场。
  凡是这种模板，**必须在代码里归一化，不要逐张手改**。
- **教训**：画图前先算「设计宽 → 印刷宽」的缩放比，再反推该用多大 pt。
  设计 11.5 in 印成 15.92 cm，缩放 0.55，9 pt 变 5 pt。
- **遗留**：Figure 1（29.21 cm, 0.55×）、S1（27.94 cm, 0.57×）、S2（25.05 cm, 0.64×）同样超宽。
  Fig 1 需改 2 列版式 + 精简框内文字，属重新设计。
"""

m = pathlib.Path(r"C:\Users\64915\WorkBuddy\2026-10-06-13-49-21\.workbuddy\memory\2026-10-27.md")
t2 = m.read_text(encoding="utf-8")
if "Figure 2 重画 + 表格超宽根治" in t2:
    print("memory skip")
else:
    m.write_text(t2 + MEM, encoding="utf-8")
    print("memory updated")
