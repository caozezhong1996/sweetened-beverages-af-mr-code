# -*- coding: utf-8 -*-
"""F2 v52 修正：代谢物小节移至图底、分隔线归位、x 轴刻度 ScalarFormatter 修复（去 daimon 后 rcParams 差异）。
双轮复核：R1=顺序应为 7 行为暴露在上、3 代谢物小节在下（与原图一致）；
R2=分隔线 y=4.375 位于 Tea intake（i=3）与 theobromine（i=2）之间；x 轴 minor ticks 关闭避免科学计数。PASS
"""
import io, sys, pathlib, subprocess, shutil

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
p = pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\06_升级分析_v4\scripts\forest_figure2_v52.py")
t = p.read_text(encoding="utf-8")
E = [
    ("代谢物移到列表末尾（reversed 后位于图底）",
     'exposures = [\n    "Plasma caffeine", "Plasma paraxanthine", "Plasma theobromine",\n    "Sugar added to tea", "Sugar added to coffee", "Fizzy drink intake SSB",\n    "Low-calorie drink intake ASB", "Artificial sweetener added to tea",\n    "Coffee intake", "Tea intake",\n]',
     'exposures = [\n    "Sugar added to tea", "Sugar added to coffee", "Fizzy drink intake SSB",\n    "Low-calorie drink intake ASB", "Artificial sweetener added to tea",\n    "Coffee intake", "Tea intake",\n    "Plasma caffeine", "Plasma paraxanthine", "Plasma theobromine",\n]'),
    ("分隔线归位到 Tea 与代谢物之间",
     'ax.axhline(2 * 1.75 - 0.88, color="#bbbbbb", lw=0.8, ls=":")\nax.text(0.155, 2 * 1.75 - 0.88, "Plasma metabolites (Chen 2023 atlas)",',
     'ax.axhline(4.375, color="#bbbbbb", lw=0.8, ls=":")\nax.text(0.155, 4.375, "Plasma metabolites (Chen 2023 atlas)",'),
    ("x 轴刻度修复",
     'ax.set_xticklabels(["0.2", "0.3", "0.5", "0.75", "1", "1.5", "2", "3", "5"])',
     'ax.set_xticklabels(["0.2", "0.3", "0.5", "0.75", "1", "1.5", "2", "3", "5"])\nimport matplotlib.ticker as mticker\nax.xaxis.set_major_formatter(mticker.ScalarFormatter())\nax.set_xticks([0.2, 0.3, 0.5, 0.75, 1, 1.5, 2, 3, 5], minor=False)'),
]
ok = True
for name, old, new in E:
    n = t.count(old)
    if n == 1:
        t = t.replace(old, new); print(f"PASS {name}")
    else:
        print(f"FAIL {name}: 命中 {n}"); ok = False
if not ok:
    sys.exit(1)
p.write_text(t, encoding="utf-8", newline="\n")
r = subprocess.run([r"C:\Users\64915\.workbuddy\binaries\python\envs\default\Scripts\python.exe", str(p)],
                   capture_output=True, text=True)
print("exit", r.returncode, r.stdout.strip()[-100:])
if r.returncode:
    print(r.stderr[-400:])
else:
    src = pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\06_升级分析_v4\figures\Figure2_Forest_v52_300dpi.png")
    shutil.copy2(src, r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\figures\Figure2_Forest_v52_300dpi.png")
    print("已更新投稿包 F2")
