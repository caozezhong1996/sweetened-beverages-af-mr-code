# -*- coding: utf-8 -*-
"""Re-query the low-scoring references with CrossRef's title index."""
import io
import json
import re
import sys
import time
import urllib.parse
import urllib.request

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
MAILTO = "caozezhong1996@163.com"
LOW = [4, 9, 12, 13, 14, 15, 17, 19, 37]

data = json.load(open(r"C:\Users\64915\WorkBuddy\2026-10-06-13-49-21\ref_check.json",
                      encoding="utf-8"))
by_n = {d["n"]: d for d in data}


def norm(s):
    return set(re.findall(r"[a-z0-9]+", s.lower()))


def sim(a, b):
    A, B = norm(a), norm(b)
    return len(A & B) / len(A | B) if A and B else 0.0


for n in LOW:
    d = by_n[n]
    title = d["title"]
    url = ("https://api.crossref.org/works?" + urllib.parse.urlencode(
        {"query.title": title, "rows": 5, "mailto": MAILTO}))
    req = urllib.request.Request(url, headers={"User-Agent": f"refcheck/3 (mailto:{MAILTO})"})
    try:
        with urllib.request.urlopen(req, timeout=45) as r:
            items = json.load(r)["message"]["items"]
        best = max(items, key=lambda it: sim(title, (it.get("title") or [""])[0]))
        t = (best.get("title") or [""])[0]
        sc = sim(title, t)
        jr = (best.get("container-title") or [""])[0]
        yr = (best.get("issued", {}).get("date-parts") or [[None]])[0][0]
        flag = "OK" if sc >= 0.70 else "REVIEW"
        print(f"{flag:<7}[{n}] {sc:.2f}  {t[:78]}")
        print(f"         {jr[:52]}  {yr}  doi:{best.get('DOI')}")
    except Exception as e:
        print(f"ERR    [{n}] {type(e).__name__}: {e}")
    time.sleep(0.5)
