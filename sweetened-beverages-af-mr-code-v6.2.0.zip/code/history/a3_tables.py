#!/usr/bin/env python
"""Assemble the A3 result tables (Yuan co-primary + adiposity sensitivity)."""
import csv, io, os, sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
D = r"C:\a3work"

ORDER = ["Sugar added to tea", "Sugar added to coffee", "Fizzy drinks (SSB)",
         "Low-calorie drinks (ASB)", "Sweetener added to tea", "Coffee intake", "Tea intake"]


def f(x, n=2):
    try:
        return f"{float(x):.{n}f}"
    except (TypeError, ValueError):
        return "—"


def g(x, n=3):
    try:
        v = float(x)
        return f"{v:.2g}" if v < 0.01 else f"{v:.3f}"
    except (TypeError, ValueError):
        return "—"


mr = list(csv.DictReader(open(os.path.join(D, "yuan2025_mr.csv"), encoding="utf-8")))
by = {}
for r in mr:
    by.setdefault(r["exposure"], {})[r["method"]] = r

ad = list(csv.DictReader(open(os.path.join(D, "adiposity_sensitivity_all_cohorts.csv"), encoding="utf-8")))
adx = {(r["outcome"], r["exposure"]): r for r in ad}

print("### Table A3-1  Yuan 2025 (GCST90624413), random-effects IVW + estimators\n")
print("| Exposure | n SNP | OR (95% CI) | P | Weighted median P | MR-Egger P | MR-RAPS P | Cochran Q P |")
print("|---|---:|---|---:|---:|---:|---:|---:|")
for e in ORDER:
    m = by.get(e, {})
    ivw = m.get("Inverse variance weighted", {})
    print("| {} | {} | {} ({}-{}) | {} | {} | {} | {} | {} |".format(
        e, ivw.get("nsnp", ""), f(ivw.get("OR")), f(ivw.get("lo")), f(ivw.get("hi")),
        g(ivw.get("p")), g(m.get("Weighted median", {}).get("p")),
        g(m.get("MR Egger", {}).get("p")), g(m.get("MR-RAPS", {}).get("p")),
        g(m.get("MR-PRESSO global test", {}).get("p"))))

print("\n### Table A3-2  Adiposity-locus sensitivity (all three cohorts)\n")
print("| Outcome | Exposure | All instruments | P | Excluding adiposity loci | P | Δ n |")
print("|---|---|---|---:|---|---:|---|")
for oc in ["Nielsen", "FinnGen R13", "Yuan 2025"]:
    for e in ORDER:
        r = adx.get((oc, e))
        if not r:
            continue
        print("| {} | {} | {} ({}-{}) | {} | {} ({}-{}) | {} | {}→{} |".format(
            oc, e, f(r["OR"]), f(r["lo"]), f(r["hi"]), g(r["p"]),
            f(r["OR_clean"]), f(r["lo_clean"]), f(r["hi_clean"]), g(r["p_clean"]),
            r["n"], r["n_clean"]))

print("\n### Table A3-3  Coffee: cohort-by-cohort consistency\n")
print("| Outcome | OR (95% CI) | P | OR excl. adiposity loci | P |")
print("|---|---|---:|---|---:|")
for oc in ["Nielsen", "FinnGen R13", "Yuan 2025"]:
    r = adx.get((oc, "Coffee intake"))
    if r:
        print("| {} | {} ({}-{}) | {} | {} ({}-{}) | {} |".format(
            oc, f(r["OR"]), f(r["lo"]), f(r["hi"]), g(r["p"]),
            f(r["OR_clean"]), f(r["lo_clean"]), f(r["hi_clean"]), g(r["p_clean"])))
