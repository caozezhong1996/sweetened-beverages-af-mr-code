# -*- coding: utf-8 -*-
"""PDF 版式检验：定位关键页并渲染为 PNG。"""
import io, sys, os
import pymupdf

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
PDF = r"C:\Users\64915\WorkBuddy\2026-10-06-13-49-21\visual_check\manuscript_v52_JAHA.pdf"
OUT = r"C:\Users\64915\WorkBuddy\2026-10-06-13-49-21\visual_check"
doc = pymupdf.open(PDF)
print("总页数:", len(doc))
marks = {}
for i, page in enumerate(doc):
    text = page.get_text()[:400].replace("\n", " | ")
    for kw in ["Clinical Perspective", "Biomarker MR", "Declarations", "References", "Table 1", "Table 4", "Figure 1", "Nonstandard"]:
        if kw in text and kw not in marks:
            marks[kw] = i + 1
print("关键页定位:", marks)
# 渲染关键页（1 标题页、2 摘要、CP、生物标志物小节、Declarations、References 末页、Table 1、Figure legends）
targets = {1, 2, len(doc) - 2, len(doc) - 1, len(doc)}
for kw in ["Clinical Perspective", "Biomarker MR", "Declarations", "Table 1", "Table 4"]:
    if kw in marks:
        targets.add(marks[kw])
        targets.add(marks[kw] + 1)
for pno in sorted(targets):
    if 1 <= pno <= len(doc):
        pix = doc[pno - 1].get_pixmap(dpi=110)
        path = os.path.join(OUT, f"page_{pno:02d}.png")
        pix.save(path)
        print("渲染:", path)
