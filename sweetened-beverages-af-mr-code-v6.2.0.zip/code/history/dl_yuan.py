# -*- coding: utf-8 -*-
"""Resumable downloader with explicit Range handling (curl -C is unreliable here)."""
import io
import os
import sys
import time
import urllib.request

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

URL = ("https://ftp.ebi.ac.uk/pub/databases/gwas/summary_statistics/"
       "GCST90624001-GCST90625000/GCST90624413/GCST90624413.tsv.gz")
DST = (r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
       r"\06_升级分析_v4\downloads\yuan2025\GCST90624413.tsv.gz")

req = urllib.request.Request(URL, method="HEAD")
with urllib.request.urlopen(req, timeout=60) as r:
    total = int(r.headers["Content-Length"])
print(f"total = {total/1e6:.1f} MB", flush=True)

t0 = time.time()
for attempt in range(60):
    have = os.path.getsize(DST) if os.path.exists(DST) else 0
    if have >= total:
        print("done", flush=True)
        break
    try:
        req = urllib.request.Request(URL, headers={"Range": f"bytes={have}-"})
        with urllib.request.urlopen(req, timeout=120) as r:
            if r.status != 206:
                print(f"  server returned {r.status}; restarting from 0", flush=True)
                have = 0
            with open(DST, "ab") as fh:
                while True:
                    chunk = r.read(1024 * 1024)
                    if not chunk:
                        break
                    fh.write(chunk)
    except Exception as e:
        print(f"  attempt {attempt}: {type(e).__name__} {e}", flush=True)
        time.sleep(3)
    have = os.path.getsize(DST)
    print(f"  {have/1e6:7.1f} MB / {total/1e6:.1f} MB  ({time.time()-t0:.0f}s)", flush=True)

have = os.path.getsize(DST)
print(f"final {have/1e6:.1f} MB, complete={have >= total}")
