# -*- coding: utf-8 -*-
"""All 46 references are now verified: update the checklist and README."""
import io
import pathlib
import re
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

CHK = pathlib.Path(r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版"
                   r"\JAHA_v525_改稿留档\审读意见_20261026\投稿前自检清单_20261027.md")
README = pathlib.Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\README_投稿包.md")

NEW_S6 = """### 6. 文献真实性（46 条，**全部确认**）

| 核验方式 | 条数 | 说明 |
|---|---:|---|
| CrossRef 标题匹配（包含度 ≥ 0.80） | 40 | 自动确认 |
| 模糊检索未命中 → **DOI 精确解析** | 6 | 标题 / 第一作者 / 期刊 / 年 / 卷 / 起页 逐字段核对 |

6 条的 DOI 核验结果：

| # | DOI | 核对结果 |
|---|---|---|
| 13 | 10.1038/s41588-018-0171-3 | Nielsen JB, Thorolfsdottir RB, Fritsche LG, et al. *Nat Genet* 2018;50(9):1234-1239 ✔ 作者顺序与标题逐字一致 |
| 14 | 10.1038/s41588-018-0133-9 | Roselli C, Chaffin MD, Weng LC, et al. *Nat Genet* 2018;50(9):1225-1233 ✔ |
| 15 | 10.1038/s41586-022-05473-8 | Kurki MI, Karjalainen J, Palta P, et al. *Nature* 2023;613(7944):508-518 ✔ |
| 17 | 10.1038/s41588-020-0640-3 | Ishigaki K, Akiyama M, Kanai M, et al. *Nat Genet* 2020;52(7):669-679 ✔ |
| 19 | 10.1038/s41588-018-0307-5 | Liu M, Jiang Y, Wedow R, et al. *Nat Genet* 2019;51(2):237-244 ✔ |
| 37 | 10.1001/jama.2018.18179 | Choi SH, Weng LC, Roselli C, et al. *JAMA* 2018;320(22):2354-2364 ✔ |

> 这 6 条此前的"未通过"是 **CrossRef 模糊检索排序问题**——正文标题带副标题时 Jaccard 相似度被压低
> （例如 0.46 那条其实是同一篇），并非查无此文或作者错配。改用 DOI 直查后六项字段全部吻合。
> **46 条参考文献全部可核验，无虚构、无错配、无重复。**

"""

t = CHK.read_text(encoding="utf-8")
i = t.find("### 6. 文献真实性")
j = t.find("## 二、")
assert i > 0 and j > i, (i, j)
t = t[:i] + NEW_S6 + "---\n\n" + t[j:]

# 人工确认从 3 件减为 2 件
old3 = """- [ ] **EM 系统作者栏**：Given name = Zezhong，Family name = Cao（上次 Elsevier 把名重复成 "Cao Zezhong Zezhong"）
- [ ] **是否填 excluded reviewer**：建议 Susanna C. Larsson
- [ ] 上表 6 条文献逐个搜索确认（约 2 分钟）"""
new3 = """- [ ] **EM 系统作者栏**：Given name = Zezhong，Family name = Cao（上次 Elsevier 把名重复成 "Cao Zezhong Zezhong"）
- [ ] **是否填 excluded reviewer**：建议 Susanna C. Larsson"""
assert t.count(old3) == 1
t = t.replace(old3, new3)
t = t.replace("## 三、需要人工确认的 3 件事", "## 三、需要人工确认的 2 件事")
CHK.write_text(t, encoding="utf-8")
print("checklist updated")

r = README.read_text(encoding="utf-8")
r = r.replace("机器已核验（见下方清单文件），人工只需确认三件事：",
              "机器已核验（见下方清单文件），人工只需确认两件事：")
r = r.replace("- [ ] 是否填写 excluded reviewer（Larsson）\n- [ ] 投稿类型选 Original Research，并把 4 张主图按 Figure 1/2 + Supplemental Figure 1/2 分派",
              "- [ ] 是否填写 excluded reviewer（Larsson）\n- [ ] 投稿类型选 Original Research，并把 4 张主图按 Figure 1/2 + Supplemental Figure 1/2 分派")
README.write_text(r, encoding="utf-8")
print("README updated")
