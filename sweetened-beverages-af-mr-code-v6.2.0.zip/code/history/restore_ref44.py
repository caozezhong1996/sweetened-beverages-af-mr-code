import io
import sys
from pathlib import Path
from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
path = Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\Manuscript.docx")
doc = Document(str(path))
old = "For East Asian consumers, the AF-prevention message remains the established one: healthy weight, limited alcohol and cardiometabolic risk control [1]."
new = "Global estimates document a substantial absolute SSB-attributable cardiovascular burden among adults aged 35–64 years [44], but they do not specifically quantify risk in young East Asian milk-tea consumers. For East Asian consumers, the AF-prevention message remains the established one: healthy weight, limited alcohol and cardiometabolic risk control [1]."
hits = 0
for p in doc.paragraphs:
    if old in p.text:
        full = p.text.replace(old, new)
        for run in p.runs:
            run.text = ""
        p.runs[0].text = full
        hits += 1
assert hits == 1, hits
doc.save(str(path))
print("restored accurate ref44 context")
