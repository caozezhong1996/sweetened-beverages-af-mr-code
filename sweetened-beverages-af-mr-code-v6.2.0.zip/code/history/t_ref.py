import io, re, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
from docx import Document
man = Document(r"C:/Users/64915/Desktop/JAHA投稿包_奶茶房颤MR_20261013/Manuscript.docx")
full = "\n".join(p.text.strip() for p in man.paragraphs if p.text.strip())
refs = [(int(n), t) for n, t in re.findall(r"(?m)^(\d+)\.\s(.+)$", full)]
print("refs found:", len(refs), flush=True)
for n, t in refs[:2]:
    print(n, t[:150], flush=True)
