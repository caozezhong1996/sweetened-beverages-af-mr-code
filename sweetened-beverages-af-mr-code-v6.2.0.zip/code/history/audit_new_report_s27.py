# -*- coding: utf-8 -*-
import csv, math, os, sys, io
import numpy as np
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
D = r"C:\a3work"
TAGS = ["Sugar_added_to_tea", "Sugar_added_to_coffee", "Fizzy_drink_intake_SSB", "Low_calorie_drink_intake_ASB", "Artificial_sweetener_added_to_tea", "Coffee_intake", "Tea_intake"]
LOCI = np.array([(int(x["chr"]), int(x["pos"])) for x in csv.DictReader(open(os.path.join(D, "tmp_bmi_instruments_v46.csv"), encoding="utf-8"))])
COMP = str.maketrans("ACGT", "TGCA")
def comp(a): return a.translate(COMP)
def near(c,p): return ((LOCI[:,0] == c) & (np.abs(LOCI[:,1]-p) <= 500000)).any()
def ivw(rows):
    if len(rows)<3: return (float("nan"),)*4
    bx=np.array([r[3] for r in rows]); by=np.array([r[4] for r in rows]); se=np.array([r[5] for r in rows]); w=1/se**2
    b=(w*bx*by).sum()/(w*bx**2).sum(); se0=math.sqrt(1/(w*bx**2).sum()); q=(w*(by-b*bx)**2).sum(); se1=se0*max(1,math.sqrt(q/(len(rows)-1)))
    return math.exp(b), math.exp(b-1.96*se1), math.exp(b+1.96*se1), math.erfc(abs(b/se1)/math.sqrt(2))
yuan=list(csv.DictReader(open(os.path.join(D,"yuan2025_instruments.tsv"),encoding="utf-8"),delimiter="\t"))
for tag in TAGS:
    exp={r["SNP"]:r for r in csv.DictReader(open(os.path.join(D,f"dat_{tag}_ebi_a_GCST006414.csv"),encoding="utf-8"))}
    rows=[]; skipped=[]
    for r in yuan:
        if r["exposure"]!=tag or r["SNP"] not in exp: continue
        e=exp[r["SNP"]]; ea=e["effect_allele.exposure"]; oa=e["other_allele.exposure"]; beta=float(r["beta.out"])
        if (r["ea.out"],r["oa.out"])==(ea,oa): pass
        elif (r["ea.out"],r["oa.out"])==(oa,ea): beta=-beta
        elif (r["ea.out"],r["oa.out"])==(comp(ea),comp(oa)): pass
        elif (r["ea.out"],r["oa.out"])==(comp(oa),comp(ea)): beta=-beta
        else: skipped.append(r["SNP"]); continue
        rows.append((r["SNP"],int(e["chr"]),int(e["pos"]),float(e["beta.exposure"]),beta,float(r["se.out"])))
    keep=[r for r in rows if not near(r[1],r[2])]
    a=ivw(rows); b=ivw(keep)
    print(f"{tag}: n={len(rows)} skipped={skipped} all={a[0]:.4f} ({a[1]:.4f}-{a[2]:.4f}) P={a[3]:.4g}; clean n={len(keep)} OR={b[0]:.4f} ({b[1]:.4f}-{b[2]:.4f}) P={b[3]:.4g}")
