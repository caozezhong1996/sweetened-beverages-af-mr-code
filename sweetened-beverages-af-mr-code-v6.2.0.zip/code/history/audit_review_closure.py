import io
import math
import re
import sys
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
PKG = Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")
W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def raw_text(name):
    with zipfile.ZipFile(PKG / name) as z:
        root = ET.fromstring(z.read("word/document.xml"))
    paragraphs = []
    for p in root.iter(W + "p"):
        text = "".join(t.text or "" for t in p.iter(W + "t"))
        if text.strip():
            paragraphs.append(text.strip())
    return "\n".join(paragraphs)


man = raw_text("Manuscript.docx")
sup = raw_text("Supplement.docx")
cl = raw_text("Cover_Letter.docx")
hl = raw_text("Highlights.docx")

checks = [
    ("S27 Yuan corrected", "1.48 (1.01-2.18)" in sup and "0.044" in sup, sup),
    ("S16 direct CI corrected", "0.705–1.292" in man, man),
    ("Abstract residual pooled OR", "pooled OR 1.41; P = 0.0007" in man, man),
    ("Placebo result", "only 0.9% produced" in man, man),
    ("STROBE S9 cited", "STROBE-MR checklist [14] (Table S9)" in man, man),
    ("133 unique vs 137 pairs clarified", "133 unique instrument variants (137 exposure–instrument pairs" in man, man),
    ("Unregistered plan disclosed", "the study was not registered" in man, man),
    ("No unsupported eight/66%/1.084 sentence", "eight coffee instruments" not in man and "1.084" not in man, man),
    ("Highlights corrected", "residual OR 1.41" in hl and "abolished" not in hl, hl),
]
for label, ok, _ in checks:
    print(("PASS " if ok else "FAIL ") + label)

print("\nRESIDUALS confirmed in raw DOCX XML:")
residuals = [
    ("CP old adiposity/abolished claim", "carried by adiposity-locus instruments" in man and "abolished it in both overlap-free outcome sources" in man, man),
    ("CP observational confounding + prevention priority", "most likely reflects adiposity-related confounding" in man and "better directed at established cardiometabolic risk factors" in man, man),
    ("Results old moderate-to-large wording", "null findings therefore exclude moderate-to-large causal effects" in man, man),
    ("Conclusion old moderate-to-large wording", "moderate-to-large effects are excluded" in man, man),
    ("Non-independent Neale fixed-effect meta retained", "cross-GWAS fixed-effect meta-analysis gave OR 1.23" in man, man),
    ("MRlap overstatement retained", "excluding material overlap bias" in man, man),
    ("Coloc causal overstatement retained", "directly implicating adiposity-linked pleiotropy" in man, man),
    ("Alcohol quantity/frequency mechanism retained", "consistent with cumulative quantity, rather than frequency" in man, man),
    ("Participant-disjoint claim retained", "participant-disjoint replication" in man, man),
    ("Cover old abolished + 1.26–1.39", "abolished it in both overlap-free sources" in cl and "1.26–1.39" in cl, cl),
    ("Cover weak-MVMR mechanism retained", "OR 0.82; P = 0.099" in cl, cl),
    ("Cover AI sentence garbled", "own by an artificial-intelligence tool" in cl, cl),
    ("AHA statement lacks volume/issue/pages", "Circulation. 2026. doi:10.1161/CIR.0000000000001454" in man, man),
    ("Casiglia sixth initial still D", "Mazza A, Montagnana D, et al." in man, man),
]
for label, found, _ in residuals:
    print(("OPEN " if found else "CLEAR ") + label)

body = man.split("References")[0]
order = []
for group in re.findall(r"\[([0-9,\s–-]+)\]", body):
    for token in re.findall(r"\d+", group):
        n = int(token)
        if 1 <= n <= 46 and n not in order:
            order.append(n)
print("\nReference first-use sequential:", order == list(range(1, 47)))

se_direct = math.sqrt(0.1120**2 + 0.1063**2)
log_or = math.log(0.9546)
lo = math.exp(log_or - 1.96 * se_direct)
hi = math.exp(log_or + 1.96 * se_direct)
print(f"S16 independent delta check: SE={se_direct:.4f}, CI={lo:.3f}–{hi:.3f}")
