# -*- coding: utf-8 -*-
import io
import pathlib
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

ADD = """

### 补记：Author Contributions（2026-10-27 17:40）
按作者口述分工补入 Declarations（置于 Disclosures 之后）：

> Author Contributions: Cao Zezhong conceived and designed the study and wrote the manuscript.
> Chen Rongrong reviewed and revised the manuscript. Both authors read and approved the final
> version and agree to be accountable for all aspects of the work.

只写了作者明确给出的两项（构思+写作 / 审核+修改），未代填数据分析、数据管理、监督等角色。
如需更细的 CRediT 式分工（如"formal analysis""data curation"），告诉作者补。
"""

p = pathlib.Path(r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版"
                 r"\JAHA_v525_改稿留档\审读意见_20261026\修正记录_20261026.md")
t = p.read_text(encoding="utf-8")
if "补记：Author Contributions" in t:
    print("skip")
else:
    p.write_text(t + ADD, encoding="utf-8")
    print("revision log updated")

MEM = """

## Author Contributions 补齐（17:40）

- 作者口述分工：Cao = 构思 + 写作；Chen = 审核 + 修改。
- 写入 Declarations，位置在 Disclosures 之后、Data integrity 之前（AHA 惯例）。
- **只写作者给出的角色，不代填** CRediT 的其他项（formal analysis / data curation / supervision 等）。
  这是反复出现的约束：作者分工、利益冲突、基金这类声明，宁缺毋滥，不能替作者编。
"""

m = pathlib.Path(r"C:\Users\64915\WorkBuddy\2026-10-06-13-49-21\.workbuddy\memory\2026-10-27.md")
t2 = m.read_text(encoding="utf-8")
if "Author Contributions 补齐" in t2:
    print("memory skip")
else:
    m.write_text(t2 + MEM, encoding="utf-8")
    print("memory updated")
