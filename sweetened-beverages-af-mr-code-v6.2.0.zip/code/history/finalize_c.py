# -*- coding: utf-8 -*-
"""收尾2：清理旧版副本 + Response Letter 表号统一 + 日志/README 更新。"""
import io, sys, os

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
P = r"C:\Users\64915\Desktop\EHJOpen投稿包_奶茶房颤MR_v5.0_20261006"

# 1. 旧版补充材料副本改名（避免与新 v50 混淆；原件仍在 EJPC 投稿包）
old = os.path.join(P, "02_补充材料_Supplement", "Supplement_v456_Sweetened_Beverages_AF_MR.docx")
if os.path.exists(old):
    os.rename(old, os.path.join(P, "02_补充材料_Supplement", "Supplement_v456_旧版_参考.docx"))
    print("旧版补充材料已改名 _旧版_参考.docx")

# 2. Response Letter 表号统一
RL = os.path.join(P, "05_投稿信与回复_Submission", "Response_to_Reviewers_v50.md")
t = open(RL, encoding="utf-8").read()
reps = [
    ("(draft enclosed: Table_S22_instrument_strength_draft.csv; all F > 20; cumulative R\u00b2 0.06\u20130.42%)",
     "(new Supplementary Table S22; all F > 20; cumulative R\u00b2 0.06\u20130.42%)"),
    ("MR_RAPS_v50.csv enclosed",
     "new Supplementary Table S23"),
    ("mrlap_v50_*.csv enclosed",
     "Supplementary Table S17, continued for tea"),
]
for old_s, new_s in reps:
    n = t.count(old_s)
    if n == 1:
        t = t.replace(old_s, new_s); print("PASS Response 更新:", new_s[:40])
    else:
        print(f"备注: 命中 {n} — {old_s[:40]}")
open(RL, "w", encoding="utf-8").write(t)

# 3. 修订日志追加第九节
LOG = os.path.join(P, "00_修订日志_RevisionLog_v50.md")
lt = open(LOG, encoding="utf-8").read()
lt += """

## 九、其他事项推进（17:25–17:50，双轮复核制）

| 事项 | 内容 | 复核 | 状态 |
|---|---|---|---|
| 补充材料 v50 | build_supplement_v50.js：S17 扩展 tea（Table S17 continued，全套 14 项量 × 2 结局，S17b TSV）；新增 S22 工具强度（7 暴露，nsnp 与 Table 2 完全一致）、S23 MR-RAPS（14 组合）；Contents 同步；表格数 21→24 | R1=数字与计算 CSV 逐位核对；R2=表号无冲突（S21 已存在故顺延 S22/S23）、note 与手稿表述一致。审计 ALL PASS（含表格单元格扫描） | ✅ |
| 手稿表引用 | M28c 补 (Table S23)、M28d 补 (Table S22)，重建后摘要仍 246/250 | 双 PASS | ✅ |
| Cover Letter v50 | EHJ Open 转投信（05_投稿信与回复/Cover_Letter_EHJOpen_v50.txt）：转投场景要素+修订七点概述+声明+通讯作者 | R1=转投要素齐备；R2=**第三轮核验案例**：AI 披露初稿措辞与原 EJPC 版不一致，以原版逐句为准（"assisted by an artificial-intelligence tool (Kimi, Moonshot AI)"），保持披露一致性 | ✅ |
| 声明文件包 | 04_声明_Declarations/：Disclosures、Data Availability（与手稿 Zenodo DOI 一致）、ICMJE COI 说明（2 作者待填）、第一作者 bio 草稿 | R1=对照 EHJ Open 要求逐项；R2=DOI/事实核对 | ✅ |
| Tea MRlap 完整套 | run_v50_s17b_tea.R 重跑并提取全套 14 项量（seed 42，数字与批跑一致） | 效应量与三轮批跑逐位一致 | ✅ |

**S22 数据修正说明**：初版 PB1 草表 SNP 数与 Table 2 不符（误用 AFGen 版 dat），本轮以 Nielsen 主结局版 dat 重算（14/34/8/17/15/17/32，与 Table 2 完全一致）——此为双轮复核机制又一生效案例。

## 十、剩余待办（最终版）

1. **条件 F**：等 OpenGWAS API 恢复（脚本三件套已备，token 至 10-20 有效）
2. 第一作者照片（JPEG 5×6、72 dpi）——仅用户可提供
3. 陈荣蓉 COI 表 + 共同作者验证邮件
4. 提交时：编译 PDF 核 Figure 1 右缘
"""
open(LOG, "w", encoding="utf-8").write(lt)
print("修订日志已追加第九、十节")

# 4. README 更新
RD = os.path.join(P, "README_投稿包.md")
rt = open(RD, encoding="utf-8").read()
rt = rt.replace("| `02_补充材料_Supplement` | Supplement_v456 原版（S1–S20） | ⏳ 待 B 级计算后加 S22/S17 扩展 |",
                "| `02_补充材料_Supplement` | **Supplement_v50**（S1–S23：新增 S17 tea 扩展、S22 工具强度、S23 MR-RAPS；表格 24 张） | ✅ 完成 |")
rt = rt.replace("| `05_投稿信与回复` | **Response_to_Reviewers_v50.md**（逐条回应，3 处 [COMPUTATION IN PROGRESS] 待计算后填）；旧 Cover Letter 仅参考 | ⏳ 转投 Cover Letter 待重写 |",
                "| `05_投稿信与回复` | **Response_to_Reviewers_v50.md**（逐条，全部为实际结果）+ **Cover_Letter_EHJOpen_v50.txt**（转投信，AI 披露与原版一致）；旧 Cover Letter 仅参考 | ✅ 完成 |")
rt = rt.replace("1b. 补充材料并入 Table S22 / MR-RAPS / MRlap 扩展表",
                "1b. ~~补充材料并入~~ ✅（Supplement_v50 已含 S17 扩展/S22/S23）\n1c. ~~转投 Cover Letter~~ ✅ / ~~声明文件包~~ ✅（04_声明_Declarations/）")
open(RD, "w", encoding="utf-8").write(rt)
print("README 已更新")
