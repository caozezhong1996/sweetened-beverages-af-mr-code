import csv
from copy import deepcopy
import docx
from docx.shared import Pt, Cm
from docx.enum.section import WD_ORIENT, WD_SECTION
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

SUP = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\Supplement.docx"
CSV = r"C:\Users\64915\WorkBuddy\2026-10-30-20-42-58\TableS30_per_variant.csv"

rows = list(csv.reader(open(CSV, encoding="utf-8-sig")))
head, body = rows[0], rows[1:]

doc = docx.Document(SUP)
src_tblPr = deepcopy(doc.tables[0]._tbl.tblPr)

sec = doc.add_section(WD_SECTION.NEW_PAGE)
sec.orientation = WD_ORIENT.LANDSCAPE
sec.page_width, sec.page_height = Cm(29.7), Cm(21.0)
sec.left_margin = sec.right_margin = Cm(1.4)
sec.top_margin = sec.bottom_margin = Cm(1.4)

p = doc.add_paragraph()
r = p.add_run("Table S30. Per-variant instrument-level estimates for coffee intake against atrial fibrillation "
              "(Nielsen 2018, FinnGen R13 and Yuan 2025)")
r.bold = True
r.font.size = Pt(9)
r.font.name = "Calibri"
r._element.rPr.rFonts.set(qn("w:eastAsia"), "\u5fae\u8f6f\u96c5\u9ed1")

tb = doc.add_table(rows=1, cols=len(head))
_tbl = tb._tbl
_tbl.remove(_tbl.tblPr)
_tbl.insert(0, deepcopy(src_tblPr))

widths = [3.6, 2.2, 1.6, 1.2, 1.3, 1.6, 1.6, 1.0, 1.6, 1.6, 1.4, 1.4, 1.4]

for i, h in enumerate(head):
    c = tb.rows[0].cells[i]
    c.text = ""
    par = c.paragraphs[0]
    par.paragraph_format.space_after = Pt(0)
    run = par.add_run(h)
    run.bold = True
    run.font.size = Pt(7)
    c.width = Cm(widths[i])

trPr = tb.rows[0]._tr.get_or_add_trPr()
th = OxmlElement("w:tblHeader")
th.set(qn("w:val"), "true")
trPr.append(th)

for rec in body:
    cells = tb.add_row().cells
    for i, v in enumerate(rec):
        cells[i].text = ""
        par = cells[i].paragraphs[0]
        par.paragraph_format.space_after = Pt(0)
        par.paragraph_format.line_spacing = 1.0
        run = par.add_run(v)
        run.font.size = Pt(7)
        cells[i].width = Cm(widths[i])

notes = [
    "Estimates are per-SNP Wald ratios (beta_outcome / beta_exposure) with 95% confidence intervals derived from "
    "SE_outcome / |beta_exposure|. F = beta_exposure^2 / SE_exposure^2.",
    "For the Yuan 2025 outcome, exposure-side parameters (beta_exposure, SE_exposure, alleles, allele frequency) "
    "are those of the primary exposure GWAS (ukb-b-5237), because the released Yuan file carries outcome "
    "statistics only; the same instrument set and scaling are therefore used across sources.",
    "rs1421085 (FTO) carries the largest individual Wald ratio against Yuan 2025 (OR 9.95, 6.59-15.02; F = 127.2) "
    "and rs13387939 (TMEM18) the second largest (OR 10.67, 5.91-19.29; F = 59.9). Both are strong instruments "
    "rather than weak ones. Across the three sources these two variants yielded Wald ORs of 4.86-19.66 "
    "(rs1421085) and 9.23-32.06 (rs13387939). An effect of this magnitude for a single adiposity variant acting "
    "through coffee intake is not biologically credible, and indicates failure of the exclusion-restriction "
    "assumption at these variants rather than a large coffee-specific effect.",
    "Nine of the 302 per-variant ratios lie outside the range 0.1-10 (Table S30, all exposures). These reflect "
    "near-zero per-variant associations with the exposure rather than effect modification; they carry negligible "
    "weight in the inverse-variance-weighted estimator and are retained here for completeness. The two FTO/TMEM18 "
    "ratios described above are not of this kind: their per-variant F statistics are 127.2 and 59.9.",
    "Per-variant estimates are shown for the three outcome sources for which harmonised instrument-level data were "
    "retained. AFGen 2018 and BioBank Japan estimates are summarized at the exposure level in Table S2.",
    "Nominal per-variant associations are not interpreted individually; they are provided so that the "
    "instrument-level basis of the aggregate estimates, the leave-one-out analyses and the adiposity-locus "
    "sensitivity analysis can be verified.",
]
for n in notes:
    par = doc.add_paragraph()
    par.paragraph_format.space_after = Pt(2)
    run = par.add_run(n)
    run.font.size = Pt(7.5)

doc.save(SUP)
print("tables:", len(doc.tables), "| last rows:", len(doc.tables[-1].rows), "cols:", len(doc.tables[-1].columns))
print("empty cells in last table:", sum(1 for row in doc.tables[-1].rows for c in row.cells if not c.text.strip()))
