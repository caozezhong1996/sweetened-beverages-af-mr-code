# -*- coding: utf-8 -*-
import io
import pathlib
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

ADD = """

---

## 第七轮（2026-10-27）：投稿前自检

### 结论：0 FAIL，可上传；6 条文献建议人工点开
机器核验 **77 项**（结构 22 + 引用 4 + 编号 10 + 数字回源 28 + 文件 13），0 FAIL、1 良性 WARN。
清单见 `投稿前自检清单_20261027.md`。

### 自检发现并修掉的三个问题
1. **Graphical Abstract 与正文矛盾** —— 仍在讲 "East Asian contextual analysis"、结局只列 4 个来源、
   咖啡框是旧的 "BMI-adjusted OR 0.82"。重做为 v53：副标题改 UKB-free co-primary、结局列 5 个来源
   （含 Yuan 192,851）、咖啡框改「剔除 724 个 BMI 位点邻近工具后 1.79 → 1.26（P = 0.18），三来源收敛 1.26–1.39」。
   同时把两处出框的粗体字号从 7.7/7.6 降到 7.1/7.0。
2. **MR-RAPS 口径过期** —— Methods 写 "against both co-primary outcomes"、Results 写 "14 pairs"。
   加入 Yuan 后是 21 对。已改为「21 对（S23 + S26）」并补上 Yuan 下咖啡 RAPS P = 0.18。
3. **README 严重过期** —— 47 条引文 / S1–S25 / 5 图均 300 dpi / 标题带 East Asian / 正文≤6000 词，全部不符。
   已按实际重写（46 条、S1–S27、4 图 600 dpi、新标题、正文 7277 词）。

### 顺手核实的政策点
JAHA 原创研究**没有正文字数硬上限**（官方文章类型表 Words 一栏为"—"），摘要上限 250 词。
README 里"正文 ≤6000 词"是误记（那是 Circulation Research 的口径），已删。

### 文献真实性核查（46 条）
- CrossRef 标题匹配 ≥0.80：**40 条**自动确认。
- 6 条（13/14/15/17/19/37）模糊检索命中错，PubMed 被墙（SSL handshake timeout）、
  DOI 直连被限流，未能自动闭环 → 已列成表格让作者点开确认（都是 AF GWAS / GWAS 方法学常见文献）。
- **教训**：Jaccard 对"带副标题"的标题惩罚过重（0.46 的其实是同一篇）；改用**包含度**
  `|A∩B| / min(|A|,|B|)` 后降到 6 条不符。以后核文献直接用包含度。
"""

p = pathlib.Path(r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版"
                 r"\JAHA_v525_改稿留档\审读意见_20261026\修正记录_20261026.md")
t = p.read_text(encoding="utf-8")
if "第七轮" in t:
    print("skip")
else:
    p.write_text(t + ADD, encoding="utf-8")
    print("revision log updated")

MEM = """

## 投稿前自检（2026-10-27 晚）

- 机器核验 77 项，0 FAIL、1 良性 WARN（S17 是 coffee/tea 两表共用标题）。
- 自检抓到三个真问题：**GA 与正文矛盾**（缺 Yuan、缺体脂剔除结果）、**MR-RAPS 口径过期**（14 对 → 21 对）、
  **README 全篇过期**。均已在源头修掉。
- JAHA 原创研究**无正文字数上限**（文章类型表 Words 为"—"），摘要 250 词上限。
  "正文 ≤6000 词"是 Circulation Research 的口径，别混。
- 文献核查：CrossRef 标题匹配 40/46 自动确认；6 条模糊检索命中错。
  **核文献相似度要用包含度 `|A∩B|/min(|A|,|B|)`，不要用 Jaccard** —— 带副标题的标题会被 Jaccard 误判。
- 本机 **PubMed E-utilities 被墙**（SSL handshake timeout）；CrossRef 可通但批量查询后会被限流。
"""

m = pathlib.Path(r"C:\Users\64915\WorkBuddy\2026-10-06-13-49-21\.workbuddy\memory\2026-10-27.md")
t2 = m.read_text(encoding="utf-8")
if "投稿前自检（2026-10-27 晚）" in t2:
    print("memory skip")
else:
    m.write_text(t2 + MEM, encoding="utf-8")
    print("memory updated")
