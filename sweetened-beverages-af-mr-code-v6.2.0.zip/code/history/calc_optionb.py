# -*- coding: utf-8 -*-
"""Option B: keep the milk-tea framing, add the component-level caveat to the
abstract conclusion, and retitle (drop the 'East Asian Contextual Analysis'
subtitle). Word budget is computed before anything is written."""
import io
import re
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")


def n(s):
    s = re.sub(r"^(Background|Methods and Results|Conclusions):", "", s)
    return len([w for w in s.split() if re.search(r"[A-Za-z0-9]", w)])


BG = ("Background: Milk tea (typically 35–50 g sugar and 100–200 mg caffeine per serving) "
      "has never been prospectively studied for atrial fibrillation (AF) and is not instrumented "
      "in genome-wide association studies (GWAS). We tested whether genetically proxied intake of "
      "its sweetened-beverage components is causally associated with AF.")

OLD_MR = ("Methods and Results: Seven beverage phenotypes were instrumented in UK Biobank "
          "(N = 64,949–447,485). AF statistics came from Nielsen 2018 (60,620; primary), two "
          "overlap-free co-primary sources (FinnGen R13, 67,783; UK Biobank-free Yuan 2025, "
          "192,851) and BioBank Japan (8,180; East Asian context). Robust estimators, multivariable MR, "
          "colocalization and LD-score regression were applied. No sweetened-beverage exposure showed "
          "evidence of a causal association with AF (European meta-analytic odds ratios 0.82–0.97, "
          "P ≥ 0.06; UK Biobank-free panel 0.76–1.04, P ≥ 0.083). A coffee association recurred in "
          "every source (meta-analytic OR 1.34, 1.11–1.62; UK Biobank-free 1.79, 1.23–2.60) but was "
          "carried by adiposity-locus instruments: excluding variants within 500 kb of "
          "body-mass-index loci reduced it to 1.26 (0.90–1.75) in Yuan 2025 and 1.39 (0.94–2.04) in "
          "FinnGen R13, converging all three estimates on 1.26–1.39. Sweetened-beverage traits "
          "nonetheless showed positive genetic correlations with AF (rg = 0.24–0.31; FDR q < 0.05). "
          "Caffeine and paraxanthine instruments were null (P ≥ 0.31); theobromine's nominal inverse "
          "association (P = 0.029) did not survive Bonferroni correction.")

NEW_MR = ("Methods and Results: Seven beverage phenotypes were instrumented in UK Biobank "
          "(N = 64,949–447,485). AF data came from Nielsen 2018 (60,620; primary), two overlap-free "
          "co-primary sources (FinnGen R13, 67,783; UK Biobank-free Yuan 2025, 192,851) and BioBank "
          "Japan (8,180). Complementary estimators, multivariable MR and colocalization were applied. "
          "No sweetened-beverage exposure showed evidence of a causal association with AF (European "
          "meta-analytic odds ratios 0.82–0.97, P ≥ 0.06; UK Biobank-free 0.76–1.04, P ≥ 0.083). "
          "A coffee association recurred in all sources (meta-analytic OR 1.34, 1.11–1.62; "
          "UK Biobank-free 1.79, 1.23–2.60) but was carried by adiposity-locus instruments: excluding "
          "variants within 500 kb of body-mass-index loci reduced it to 1.26 (0.90–1.75) in Yuan 2025 "
          "and 1.39 (0.94–2.04) in FinnGen R13, converging the three estimates on 1.26–1.39. "
          "Sweetened-beverage traits nonetheless showed positive genetic correlations with AF "
          "(rg = 0.24–0.31; q < 0.05). Caffeine and paraxanthine instruments were null (P ≥ 0.31); "
          "theobromine's nominal inverse association (P = 0.029) did not survive correction.")

OLD_CON = ("Conclusions: Genetically proxied sweetened-beverage intake showed no evidence of a causal "
           "association with AF; moderate-to-large effects are excluded, small ones are not. The one "
           "recurring coffee signal was carried by adiposity-locus instruments, so observational "
           "associations most plausibly reflect adiposity-related confounding; direct milk-tea studies "
           "in East Asian cohorts remain needed.")

NEW_CON = ("Conclusions: Genetically proxied sweetened-beverage intake showed no evidence of a causal "
           "association with AF; moderate-to-large effects are excluded, small ones are not, and "
           "component-level nulls cannot certify the safety of composite milk-tea beverages. The one "
           "recurring coffee signal was carried by adiposity-locus instruments, so observational "
           "associations most plausibly reflect adiposity-related confounding; direct milk-tea studies "
           "in East Asian cohorts remain needed.")

for lab, s in [("BG", BG), ("OLD_MR", OLD_MR), ("NEW_MR", NEW_MR),
               ("OLD_CON", OLD_CON), ("NEW_CON", NEW_CON)]:
    print(f"{lab:<8}{n(s):>4}")

before = n(BG) + n(OLD_MR) + n(OLD_CON)
after = n(BG) + n(NEW_MR) + n(NEW_CON)
print(f"\nabstract: {before} -> {after}  (limit 250)")
print("OK" if after <= 250 else f"STILL {after-250} OVER")
