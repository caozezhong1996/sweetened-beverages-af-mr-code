# -*- coding: utf-8 -*-
"""Rewrite the adiposity-locus Results paragraph, abstract, and Highlights with
coordinate-corrected values."""
import io
import pathlib
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
BASE = pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
                    r"\04_docx构建脚本")
MAN = BASE / "build_manuscript_v51_JAHA.js"
HL = pathlib.Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\Highlights.docx")

t = MAN.read_text(encoding="utf-8")

OLD_RES = ("To separate the coffee signal from the adiposity it tracks, each exposure was re-estimated after removing "
           "every instrument lying within 500 kb of one of 724 genome-wide-significant BMI loci (Table S27). "
           "This removed 15 of the 30 coffee instruments, including rs1421085 at FTO and rs13387939 at TMEM18—the "
           "two variants with by far the largest individual Wald ratios against AF in Yuan 2025 (OR 9.95 and 10.67, "
           "against a median of 1.2 for the remaining variants). The coffee estimate fell from 1.79 (1.23–2.60) to "
           "1.26 (0.90–1.75; P = 0.18) in Yuan 2025 and from 1.58 (1.09–2.29) to 1.39 (0.94–2.04; P = 0.096) in "
           "FinnGen R13, while in Nielsen 2018 it moved from 1.26 (1.02–1.57) to 1.39 (1.04–1.86; P = 0.028). "
           "Removing these variants also collapsed the between-source spread: the three source-specific estimates "
           "converged on 1.26–1.39, against 1.26–1.79 before removal, indicating that the between-source variability "
           "was itself largely adiposity-driven. No sweetened-beverage estimate became significant under the same "
           "exclusion (all P ≥ 0.057).")

NEW_RES = ("To separate the coffee signal from the adiposity it tracks, each exposure was re-estimated after removing "
           "every instrument lying within 500 kb of one of 724 genome-wide-significant BMI loci (Table S27). "
           "This removed 15–17 of the 30–34 coffee instruments, including rs1421085 at FTO and rs13387939 at TMEM18, "
           "the two variants with the largest individual Wald ratios against AF in Yuan 2025 (OR 9.95 and 10.67, "
           "against a median of 1.2 for the remaining variants). The between-source spread of the coffee estimate "
           "collapsed from 1.26–1.79 to 1.39–1.48 (log-odds range 0.35 to 0.067), indicating that the between-source "
           "variability was largely carried by these loci. A placebo test confirmed that the convergence is not simply "
           "the consequence of losing instruments: across 2,000 random deletions of the same size per source, only 0.9% "
           "produced an equally small between-source range. The association nevertheless persisted. After exclusion the "
           "estimates were 1.39 (1.04–1.86; P = 0.028) in Nielsen 2018, 1.48 (1.01–2.18; P = 0.044) in Yuan 2025 and "
           "1.39 (0.94–2.04; P = 0.096) in FinnGen R13, with a fixed-effect combined OR of 1.41 (1.16–1.72; P = 0.0007). "
           "Adiposity-locus instruments therefore explain the heterogeneity of the coffee signal, not the whole of it; "
           "the residual association of about 1.4 remains unexplained. No sweetened-beverage estimate became significant "
           "under the same exclusion (all P ≥ 0.15).")

assert t.count(OLD_RES) == 1, "results paragraph not found"
t = t.replace(OLD_RES, NEW_RES)

OLD_MR = ("A coffee association recurred in all sources (meta-analytic OR 1.34, 1.11–1.62; "
          "UK Biobank-free 1.79, 1.23–2.60) but was carried by adiposity-locus instruments: excluding "
          "variants within 500 kb of body-mass-index loci reduced it to 1.26 (0.90–1.75) in Yuan 2025 "
          "and 1.39 (0.94–2.04) in FinnGen R13, converging the three estimates on 1.26–1.39.")
NEW_MR = ("A coffee association recurred in all sources (meta-analytic OR 1.34, 1.11–1.62; "
          "UK Biobank-free 1.79, 1.23–2.60). Excluding instruments within 500 kb of body-mass-index loci "
          "collapsed the between-source spread from 1.26–1.79 to 1.39–1.48 but left a residual association "
          "(pooled OR 1.41, 1.16–1.72; P = 0.0007), so adiposity explains the heterogeneity rather than "
          "the whole signal.")
assert t.count(OLD_MR) == 1, "abstract M&R not found"
t = t.replace(OLD_MR, NEW_MR)

OLD_CON = ("The one recurring coffee signal was carried by adiposity-locus instruments, so observational "
           "associations most plausibly reflect adiposity-related confounding; direct milk-tea studies "
           "in East Asian cohorts remain needed.")
NEW_CON = ("The recurring coffee signal was attenuated but not eliminated by removing adiposity-locus "
           "instruments, so part of it is compatible with adiposity-related pleiotropy while a residual "
           "association remains; direct milk-tea studies in East Asian cohorts remain needed.")
assert t.count(OLD_CON) == 1, "abstract conclusions not found"
t = t.replace(OLD_CON, NEW_CON)

MAN.write_text(t, encoding="utf-8", newline="\n")
print("manuscript: 3 replacements")

# Highlights
from docx import Document
d = Document(str(HL))
old = "The recurring coffee signal was carried by adiposity-locus instruments: removing them abolished it (OR 1.79 to 1.26) in the UK Biobank-free outcome, and no caffeine-handling pathway was implicated."
new = "Removing adiposity-locus instruments collapsed between-source spread of the coffee estimate (1.26–1.79 to 1.39–1.48) but left a residual association (pooled OR 1.41); no caffeine-handling pathway was implicated."
hit = 0
for p in d.paragraphs:
    if old in p.text:
        for r in p.runs:
            r.text = ""
        p.runs[0].text = new
        hit += 1
assert hit == 1
d.save(str(HL))
print("highlights updated")
