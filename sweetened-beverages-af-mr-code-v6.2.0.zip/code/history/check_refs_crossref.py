# -*- coding: utf-8 -*-
"""Verify every reference against CrossRef: does the cited title exist?"""
import io
import json
import os
import re
import sys
import time
import urllib.parse
import urllib.request

from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

PKG = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013"
OUT = r"C:\Users\64915\WorkBuddy\2026-10-06-13-49-21\ref_check.json"
MAILTO = "caozezhong1996@163.com"

man = Document(os.path.join(PKG, "Manuscript.docx"))
full = "\n".join(p.text.strip() for p in man.paragraphs if p.text.strip())
refs = [(int(n), t) for n, t in re.findall(r"(?m)^(\d+)\.\s(.+)$", full)]
print("references:", len(refs))


def guess_title(s):
    parts = [p.strip() for p in s.split(". ") if len(p.strip()) > 12]
    if not parts:
        return ""
    # the title is usually the longest of the first three segments
    head = parts[:3]
    title = max(head, key=len)
    title = re.sub(r"\.$", "", title)
    return title


def norm(s):
    return " ".join(re.findall(r"[a-z0-9]+", s.lower()))


def jaccard(a, b):
    A, B = set(norm(a).split()), set(norm(b).split())
    if not A or not B:
        return 0.0
    return len(A & B) / len(A | B)


def query(title):
    url = ("https://api.crossref.org/works?"
           + urllib.parse.urlencode({"query.bibliographic": title, "rows": 3,
                                     "select": "title,DOI,container-title,issued,author",
                                     "mailto": MAILTO}))
    req = urllib.request.Request(url, headers={"User-Agent": f"refcheck/1.0 (mailto:{MAILTO})"})
    with urllib.request.urlopen(req, timeout=40) as r:
        return json.load(r)["message"]["items"]


results = []
for n, txt in refs:
    title = guess_title(txt)
    rec = {"n": n, "ref": txt, "title": title, "best": None, "score": 0.0, "doi": None}
    for attempt in range(3):
        try:
            items = query(title)
            if items:
                best = max(items, key=lambda it: jaccard(title, (it.get("title") or [""])[0]))
                rec["best"] = (best.get("title") or [""])[0]
                rec["score"] = round(jaccard(title, rec["best"]), 3)
                rec["doi"] = best.get("DOI")
                rec["journal"] = (best.get("container-title") or [""])[0]
                rec["year"] = (best.get("issued", {}).get("date-parts") or [[None]])[0][0]
            break
        except Exception as e:
            rec["error"] = f"{type(e).__name__}: {e}"
            time.sleep(2 + 2 * attempt)
    results.append(rec)
    flag = "OK  " if rec["score"] >= 0.70 else ("??  " if rec["score"] >= 0.45 else "BAD ")
    print(f"{flag}[{n:>2}] {rec['score']:.2f}  {title[:64]}")
    time.sleep(0.4)

with open(OUT, "w", encoding="utf-8") as f:
    json.dump(results, f, ensure_ascii=False, indent=1)

low = [r for r in results if r["score"] < 0.70]
print(f"\nchecked {len(results)}; score>=0.70: {len(results)-len(low)}; <0.70: {len(low)}")
for r in low:
    print(f"\n[{r['n']}] score {r['score']}")
    print("  cited  :", r["title"][:150])
    print("  crossref:", (r["best"] or "-")[:150], "|", r["doi"])
