# -*- coding: utf-8 -*-
"""Audit the graphical abstract: per-block word counts + layout metrics."""
import io
import re
import sys

import matplotlib
matplotlib.use("Agg")

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

SRC = r"C:\Users\64915\WorkBuddy\2026-10-06-13-49-21\build_ga_v53.py"
ns = {"__name__": "__main__"}
exec(compile(open(SRC, encoding="utf-8").read(), "ga", "exec"), ns)

sections = ns["sections"]
tops = ns["tops"]
total = 0
print(f"{'block':<58}{'words':>6}{'lines':>6}{'height':>8}")
print("-" * 80)
for i, s in enumerate(sections):
    blocks = s.blocks or [s.block]
    w = l = 0
    for b in blocks:
        for text, size, weight, color, style, gap, ls in b.items:
            words = [x for x in re.split(r"\s+", text.replace("\n", " "))
                     if re.search(r"[A-Za-z0-9]", x)]
            w += len(words)
            l += text.count("\n") + 1
    label = " | ".join(b.items[0][0][:26] for b in blocks)
    total += w
    print(f"{label:<58}{w:>6}{l:>6}{s.height():>8.2f}")
print("-" * 80)
print(f"{'TOTAL':<58}{total:>6}")

body = sum(len([x for x in re.split(r"\s+", t.replace("\n", " "))
                if re.search(r"[A-Za-z0-9]", x)])
           for s in sections for b in (s.blocks or [s.block])
           for t, *_ in b.items)
print(f"\ntotal words in image: {body}")
print(f"figure size: {ns['W_CM']} x {ns['H_CM']} cm")
print(f"flow gap: {ns['F']:.2f} u = {ns['F'] * ns['PT_PER_UNIT']:.1f} pt; "
      f"arrow {ns['ARROW_LEN']} u = {ns['ARROW_LEN'] * ns['PT_PER_UNIT']:.1f} pt "
      f"(head {ns['ARROW_HEAD'] * 0.4:.1f} pt)")

# per-box ink density: text width vs box width
import matplotlib.pyplot as plt  # noqa: E402
fig, ax = ns["fig"], ns["ax"]
fig.canvas.draw()
r = fig.canvas.get_renderer()
inv = ax.transData.inverted()
print("\nbox fill (text block height / box content height):")
for i, s in enumerate(sections):
    if not s.boxed:
        continue
    blocks = s.blocks or [s.block]
    h = s.height()
    for b in blocks:
        frac = (b.content_h()) / (h - b.pad_t - b.pad_b) if h else 0
        print(f"  {b.items[0][0][:34]:<36} {frac * 100:5.1f}%")
