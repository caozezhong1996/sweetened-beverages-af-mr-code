# -*- coding: utf-8 -*-
"""Batch B: global terminology, cover letter, supplement captions, GA, Figure S2."""
import io
import pathlib
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
BASE = pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
                    r"\04_docx构建脚本")
MAN = BASE / "build_manuscript_v51_JAHA.js"
SUP = BASE / "build_supplement_v51_JAHA.js"
CL = BASE / "build_cover_letter_v51_JAHA.js"
GA = BASE.parent / "06_升级分析_v4" / "scripts" / "graphical_abstract_v53.py"
S2 = pathlib.Path(r"C:\Users\64915\WorkBuddy\2026-10-06-13-49-21\build_figs2_v53.py")

# ---- 1. global terminology: co-primary -> replication ----
for path in (MAN, SUP, CL, GA):
    t = path.read_text(encoding="utf-8")
    n = t.count("co-primary")
    t = t.replace("co-primary", "replication")
    path.write_text(t, encoding="utf-8", newline="\n")
    print(f"{path.name}: {n} 处 co-primary → replication")

# ---- 2. manuscript-specific remaining items ----
t = MAN.read_text(encoding="utf-8")
E = [
    # Table 4: drop the single-instrument sugar-added-to-tea row and adjust the footnote
    ('Coffee intake + sugar added to tea + BMI; direct effects',
     'Coffee intake + BMI; direct effects'),
    ('Conditional estimation for sugar added to tea relied on a single joint instrument and is retained for completeness only; it should not be considered informative (OR 0.99; P = 0.96).',
     'The sugar-added-to-tea conditional estimate relied on a single joint instrument and is not informative; it is therefore omitted from Table 4 (value retained in Table S24 for completeness).'),
    # Figure S2 legend: explain the intercept
    ('Figure S2. Forest plot of cross-trait LDSC genetic correlations (rg) between beverage intake and atrial fibrillation, with same-trait and overlap validation controls.',
     'Figure S2. Forest plot of cross-trait LDSC genetic correlations (rg) between beverage intake and atrial fibrillation, with same-trait and overlap validation controls. The two control rows also report the cross-trait intercept, which is the quantity that diagnoses sample overlap: the same-trait control has rg = 0.923 with intercept 0.042, whereas the coffee × tea control has rg = 0.005 with intercept −0.318 (SE 0.011).'),
    # ref 33 page
    ('Larsson SC, Woolf B, Gill D. Appraisal of the causal effect of plasma caffeine on adiposity, type 2 diabetes and cardiovascular diseases: a Mendelian randomization study. BMJ Med. 2023;2(1):1-8.',
     'Larsson SC, Woolf B, Gill D. Appraisal of the causal effect of plasma caffeine on adiposity, type 2 diabetes, and cardiovascular disease: two sample Mendelian randomisation study. BMJ Med. 2023;2(1):e000335.'),
    # ref 30 title suffix
    ('Coffee consumption and incident tachyarrhythmias: reported behavior, habitual intake, and atrial fibrillation (CRAVE trial).',
     'Coffee Consumption and Incident Tachyarrhythmias.'),
]
ok = True
for i, (old, new) in enumerate(E, 1):
    c = t.count(old)
    print(("PASS  " if c == 1 else f"FAIL x{c}  ") + f"M{i} " + old[:66])
    if c != 1:
        ok = False
        continue
    t = t.replace(old, new)
if ok:
    MAN.write_text(t, encoding="utf-8", newline="\n")
    print("manuscript extras written")

# ---- 3. supplement: S24 caption reconciliation ----
t = SUP.read_text(encoding="utf-8")
old = "Table S24. Sanderson–Windmeijer conditional F statistics for the multivariable MR instrument set (471 harmonized SNPs)"
new = "Table S24. Sanderson–Windmeijer conditional F statistics for the multivariable MR joint instrument set (471 SNPs; the fitted BMI term in Table 4 uses 467)"
print("S24 caption count:", t.count(old))
if t.count(old) == 1:
    t = t.replace(old, new)
    SUP.write_text(t, encoding="utf-8", newline="\n")
    print("S24 caption updated")

# ---- 4. cover letter: power + AI disclosure ----
t = CL.read_text(encoding="utf-8")
E = [
    ("and the null estimates exclude moderate-to-large effects of the magnitude reported observationally.",
     "and the null estimates exclude effects above their 95% confidence upper bounds (about 17% in the European meta-analysis), but not effects of the magnitude reported observationally (10–20%)."),
    ("portions of the analysis workflow and drafting were assisted",
     "an artificial-intelligence assistant (Kimi, Moonshot AI) was used for language editing and code assistance; all analyses, interpretations and conclusions are the authors' own"),
]
for i, (old, new) in enumerate(E, 1):
    c = t.count(old)
    print(("PASS  " if c == 1 else f"FAIL x{c}  ") + f"C{i} " + old[:60])
    if c == 1:
        t = t.replace(old, new)
CL.write_text(t, encoding="utf-8", newline="\n")

# ---- 5. GA: coffee box + conclusion ----
t = GA.read_text(encoding="utf-8")
E = [
    ('"Excluding variants near 724 BMI loci\\n"\n'
     '              "abolished it: 1.79 → 1.26 (P = 0.18);\\n"\n'
     '              "sources converge on 1.26–1.39"',
     '"Removing variants near 724 BMI loci\\n"\n'
     '              "collapsed spread to 1.39–1.48, but\\n"\n'
     '              "a residual OR 1.41 (P = 0.0007) remains"'),
    ('txt(74, 68.6, "Coffee signal (OR 1.34) is adiposity", size=7.6, weight="bold", color=AMBER)',
     'txt(74, 68.6, "Coffee signal is partly adiposity", size=7.6, weight="bold", color=AMBER)'),
    ('"best explained by adiposity-related confounding; prevention should target\\n"',
     '"may partly reflect adiposity-related pleiotropy; prevention should target\\n"'),
    ('"Genetic nulls converge with randomized trial evidence (CRAVE, DECAF).",',
     '"The coffee estimate is positive but non-robust; its residual is unexplained.",'),
]
ok = True
for i, (old, new) in enumerate(E, 1):
    c = t.count(old)
    print(("PASS  " if c == 1 else f"FAIL x{c}  ") + f"G{i} " + old.split("\n")[0][:56])
    if c != 1:
        ok = False
        continue
    t = t.replace(old, new)
if ok:
    GA.write_text(t, encoding="utf-8", newline="\n")
    print("GA updated")

# ---- 6. Figure S2: annotate intercepts on the control rows ----
t = S2.read_text(encoding="utf-8")
old = '''    ax.text(1.02, yv, f"{rg:+.2f}", transform=ax.get_yaxis_transform(),
            va="center", ha="left", fontsize=8.0, color=C_CTRL)'''
new = '''    intercepts = {"same": 0.0418, "over": -0.3182}
    ax.text(1.02, yv, f"{rg:+.2f}  (int {intercepts[key]:+.3f})", transform=ax.get_yaxis_transform(),
            va="center", ha="left", fontsize=8.0, color=C_CTRL)'''
print("S2 intercept anchor:", t.count(old))
if t.count(old) == 1:
    t = t.replace(old, new)
    S2.write_text(t, encoding="utf-8", newline="\n")
    print("Figure S2 script updated")
