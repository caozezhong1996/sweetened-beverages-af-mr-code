# -*- coding: utf-8 -*-
import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
p = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\README_投稿包.md"
t = open(p, encoding="utf-8").read()
t = t.replace("`figures/Figure2_Forest_v41_300dpi.png` | 图 2 · 主结果森林图 | Figure 2 |",
              "`figures/Figure2_Forest_v52_300dpi.png` | 图 2 · 主结果森林图（含代谢物小节） | Figure 2 |")
t = t.replace("`figures/Graphical_Abstract_v50_300dpi.png` | 图文摘要 | Graphical Abstract |",
              "`figures/Graphical_Abstract_v52_300dpi.png` | 图文摘要（含代谢物与三阶段收敛） | Graphical Abstract |")
t = t.replace("# JAHA 投稿包 · 奶茶房颤MR · v5.2.5（2026-10-24，补引 [47] 后终审通过，可投稿）",
              "# JAHA 投稿包 · 奶茶房颤MR · v5.2.5（2026-10-24，补引 [47] + 图件 v52 后终审通过，可投稿）")
t += """
- 图件 v52（2026-10-24）：Figure 2 底部新增 3 行代谢物 meta 小节（caffeine/paraxanthine/theobromine，与正文 Results 一致；标题改 "beverage and plasma-metabolite exposures"），Graphical Abstract EXPOSURES 框加 3 代谢物行、底部加三阶段收敛行 (CRAVE, DECAF)。LibreOffice/PyMuPDF 目检通过。图件构建链：forest_figure2_v52.py（daimon/seaborn 依赖已移除，x 轴 FixedFormatter + NullLocator minor）、graphical_abstract_v52.py（从 v50 源重建）。
"""
open(p, "w", encoding="utf-8").write(t)
print("README 图件清单已更新")
