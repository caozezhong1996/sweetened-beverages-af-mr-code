# -*- coding: utf-8 -*-
"""Slim the submission package: version records -> master folder; version-free filenames."""
import shutil
import sys
from pathlib import Path

sys.stdout = __import__("io").TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

PKG = Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")
MASTER = Path(r"C:\Users\64915\Desktop\维护母版_心脏—胃肠_改稿只在这里\奶茶房颤MR_JAHA")
ARC = MASTER / "旧版图件"

OLD_FIGS = [
    "Graphical_Abstract_v50_旧版_已移出.png",
    "Graphical_Abstract_v52_300dpi_旧版_已移出.png",
    "Graphical_Abstract_v53_300dpi_旧版_已移出.png",
    "Figure1_Study_Design_v52_300dpi_旧版_已移出.png",
    "Figure2_v41_旧版_已移出.png",
]

RENAMES = [
    ("manuscript_v52_JAHA.docx", "Manuscript.docx"),
    ("supplement_v52_JAHA.docx", "Supplement.docx"),
    ("cover_letter_v52_JAHA.docx", "Cover_Letter.docx"),
    ("highlights_v51.docx", "Highlights.docx"),
    ("figures/Figure1_Study_Design_v53_300dpi.png", "figures/Figure1_Study_Design.png"),
    ("figures/Figure2_Forest_v52_300dpi.png", "figures/Figure2_Forest.png"),
    ("figures/FigureS1_LOO_Funnel_v43_300dpi.png", "figures/FigureS1_LOO_Funnel.png"),
    ("figures/FigureS2_LDSC_rg_v45_300dpi.png", "figures/FigureS2_LDSC_rg.png"),
    ("figures/Graphical_Abstract_v54_300dpi.png", "figures/Graphical_Abstract.png"),
]

ARC.mkdir(parents=True, exist_ok=True)
print("master:", MASTER)

print("\n--- move retired figures to master ---")
for f in OLD_FIGS:
    src, dst = PKG / f, ARC / f
    if not src.exists():
        print("  skip (absent):", f)
        continue
    if dst.exists():
        print("  skip (already archived):", f)
        continue
    shutil.move(str(src), str(dst))
    print(f"  moved {f}  ({(dst.stat().st_size/1024):.0f} KB)")

print("\n--- strip version labels from filenames ---")
for old, new in RENAMES:
    s, d = PKG / old, PKG / new
    if not s.exists():
        print("  skip (absent):", old)
        continue
    if d.exists():
        print("  SKIP (target exists, not overwriting):", new)
        continue
    s.rename(d)
    print(f"  {old}  ->  {new}")

print("\n--- package now ---")
for p in sorted(PKG.rglob("*")):
    if p.is_file():
        print(f"  {(p.stat().st_size/1024):7.0f} KB  {p.relative_to(PKG)}")
