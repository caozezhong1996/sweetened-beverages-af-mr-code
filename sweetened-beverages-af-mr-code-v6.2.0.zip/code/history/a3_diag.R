# Diagnostic: dump harmonised coffee data and compute FE / RE IVW by hand.
suppressMessages({library(data.table); library(TwoSampleMR)})
RES <- "C:/a3work"

harm <- function(e) {
  expo <- fread(file.path(RES, sprintf("dat_%s_ebi_a_GCST006414.csv", e)))
  expo <- expo[mr_keep %in% c(TRUE, "TRUE")]
  ex <- format_data(as.data.frame(expo), type = "exposure", snp_col = "SNP",
                    beta_col = "beta.exposure", se_col = "se.exposure",
                    effect_allele_col = "effect_allele.exposure",
                    other_allele_col = "other_allele.exposure",
                    eaf_col = "eaf.exposure", pval_col = "pval.exposure")
  yo <- fread(file.path(RES, "yuan2025_instruments.tsv"))
  yo <- yo[exposure == e]
  out <- format_data(as.data.frame(yo), type = "outcome", snp_col = "SNP",
                     beta_col = "beta.out", se_col = "se.out",
                     effect_allele_col = "ea.out", other_allele_col = "oa.out",
                     eaf_col = "eaf.out", pval_col = "pval.out")
  d <- harmonise_data(ex, out, action = 2)
  d[d$mr_keep %in% c(TRUE, "TRUE"), ]
}

re_ivw <- function(bx, by, sy) {
  w <- 1 / sy^2
  b <- sum(w * bx * by) / sum(w * bx^2)
  se_fe <- sqrt(1 / sum(w * bx^2))
  q <- sum(w * (by - b * bx)^2)
  df <- length(bx) - 1
  infl <- max(1, sqrt(q / df))
  se_re <- se_fe * infl
  c(b = b, se_fe = se_fe, se_re = se_re, Q = q, Qp = pchisq(q, df, lower.tail = FALSE),
    infl = infl, p_fe = 2 * pnorm(-abs(b / se_fe)),
    p_re = 2 * pnorm(-abs(b / se_re)))
}

EXPO <- c("Sugar_added_to_tea", "Sugar_added_to_coffee", "Fizzy_drink_intake_SSB",
          "Low_calorie_drink_intake_ASB", "Artificial_sweetener_added_to_tea",
          "Coffee_intake", "Tea_intake")
LAB <- c("Sugar added to tea", "Sugar added to coffee", "Fizzy drinks (SSB)",
         "Low-calorie drinks (ASB)", "Sweetener added to tea", "Coffee intake", "Tea intake")

cat(sprintf("%-24s %3s %8s %8s %8s %8s %8s %8s %6s\n", "exposure", "n", "OR_FE",
            "P_FE", "OR_RE", "P_RE", "Qp", "infl", "palind"))
res <- list()
for (i in seq_along(EXPO)) {
  d <- harm(EXPO[i])
  if (nrow(d) < 3) next
  m <- re_ivw(d$beta.exposure, d$beta.outcome, d$se.outcome)
  pal <- sum(d$palindromic %in% c(TRUE, "TRUE"))
  cat(sprintf("%-24s %3d %8.3f %8.4f %8.3f %8.4f %8.2e %8.2f %6d\n",
              LAB[i], nrow(d), exp(m["b"]), m["p_fe"], exp(m["b"]), m["p_re"],
              m["Qp"], m["infl"], pal))
  d$OR_wald <- exp(d$beta.outcome / d$beta.exposure)
  res[[i]] <- data.table(exposure = LAB[i], n = nrow(d), b = m["b"],
                         OR_fe = exp(m["b"]), lo_fe = exp(m["b"] - 1.96 * m["se_fe"]),
                         hi_fe = exp(m["b"] + 1.96 * m["se_fe"]), p_fe = m["p_fe"],
                         lo_re = exp(m["b"] - 1.96 * m["se_re"]),
                         hi_re = exp(m["b"] + 1.96 * m["se_re"]), p_re = m["p_re"],
                         Q = m["Q"], Qp = m["Qp"], infl = m["infl"], n_palindromic = pal)
}
fwrite(rbindlist(res), file.path(RES, "yuan2025_ivw_manual.csv"))

d <- harm("Coffee_intake")
fwrite(d[, .(SNP, effect_allele.exposure, other_allele.exposure, eaf.exposure,
             beta.exposure, se.exposure, effect_allele.outcome, other_allele.outcome,
             eaf.outcome, beta.outcome, se.outcome, palindromic, ambiguous,
             OR_wald = exp(beta.outcome / beta.exposure),
             F = (beta.exposure / se.exposure)^2)],
       file.path(RES, "diag_coffee_yuan.csv"))
cat("\nwrote yuan2025_ivw_manual.csv + diag_coffee_yuan.csv\n")
