# -*- coding: utf-8 -*-
"""Port the A3 co-primary updates into build_cover_letter_v51_JAHA.js so a
rebuild no longer reverts the docx."""
import io
import pathlib
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

P = pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
                 r"\04_docx构建脚本\build_cover_letter_v51_JAHA.js")
src = P.read_text(encoding="utf-8")

E = [
    ("and estimated their effects on AF in the largest available European-ancestry GWAS (Nielsen 2018; "
     "60,620 cases; primary), in FinnGen release R13 (67,783 cases), which shares no participants with "
     "UK Biobank and served as a co-primary, overlap-free outcome, in AFGen 2018 (sensitivity), and in "
     "BioBank Japan (East Asian contextual arm).",
     "and estimated their effects on AF in four European-ancestry sources—Nielsen 2018 (60,620 cases; "
     "primary), FinnGen release R13 (67,783 cases) and the UK Biobank-free European arm of Yuan 2025 "
     "(192,851 cases), the last two serving as overlap-free co-primary outcomes—with AFGen 2018 as a "
     "sensitivity source and BioBank Japan as an East Asian contextual arm."),
    ("The single nominal signal—for coffee intake (European meta-analytic OR 1.34, 1.11–1.62; P = 0.002)—"
     "failed every pre-specified robustness criterion and was dissected mechanistically: it attenuated "
     "after multivariable adjustment for body mass index (OR 0.82; P = 0.099), colocalized with AF only "
     "at the adiposity locus FTO and not at caffeine-metabolism loci, and was compatible with correlated "
     "pleiotropy in genome-wide CAUSE analysis.",
     "The single recurring signal—for coffee intake (European meta-analytic OR 1.34, 1.11–1.62; P = 0.002; "
     "UK Biobank-free OR 1.79, 1.23–2.60)—failed every pre-specified robustness criterion and was dissected "
     "mechanistically: it attenuated after multivariable adjustment for body mass index (OR 0.82; P = 0.099), "
     "colocalized with AF only at the adiposity locus FTO and not at caffeine-metabolism loci, was compatible "
     "with correlated pleiotropy in genome-wide CAUSE analysis, and was carried by adiposity-locus "
     "instruments—removing variants within 500 kb of body-mass-index loci abolished it in both overlap-free "
     "sources and made the three source-specific estimates converge on 1.26–1.39."),
    ("at roughly sixteen times the outcome case count of prior beverage–AF MR work",
     "at up to fifty times the outcome case count of prior beverage–AF MR work"),
    ("plus cis estimation, four outcome sources including an overlap-free co-primary and an East Asian "
     "contextual arm, twenty-five supplementary tables",
     "plus cis estimation, five outcome sources including two overlap-free co-primary outcomes and an East "
     "Asian contextual arm, twenty-seven supplementary tables"),
]

ok = True
for i, (old, new) in enumerate(E, 1):
    c = src.count(old)
    print(("PASS  " if c == 1 else f"FAIL x{c}  ") + f"C{i} " + old[:66])
    if c != 1:
        ok = False
        continue
    src = src.replace(old, new)

if ok:
    P.write_text(src, encoding="utf-8", newline="\n")
    print("\nwritten", P.name)
else:
    print("\nABORTED")
