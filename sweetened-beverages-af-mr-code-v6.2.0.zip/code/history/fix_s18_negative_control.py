import io
import sys
from pathlib import Path
from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
path = Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\Supplement.docx")
doc = Document(str(path))
old = "The coffee and sugar-in-tea estimates mirrored the direction and magnitude of their AF associations (+0.458 and -0.506, respectively, in FinnGen R13), the expected behavior if both endpoints share the adiposity-mediated pathway (BMI is an established risk factor for atrioventricular block); the analysis is therefore interpreted as a positive control for the shared pathway rather than a discriminator of instrument validity, and AF-specificity of these instruments cannot be formally established (manuscript Limitations)."
new = "The coffee and sugar-in-tea estimates mirrored the direction and magnitude of their AF associations (+0.458 and -0.506, respectively, in FinnGen R13). The negative control therefore failed for sugar added to tea and cannot validate instrument specificity. Shared adiposity or another correlated pathway is a possible explanation, but this analysis does not establish it; AF-specificity of these instruments cannot be formally established (manuscript Limitations)."
hits = 0
for p in doc.paragraphs:
    if old in p.text:
        full = p.text.replace(old, new)
        for run in p.runs:
            run.text = ""
        p.runs[0].text = full
        hits += 1
assert hits == 1, hits
doc.save(str(path))
print("S18 negative-control interpretation corrected")
