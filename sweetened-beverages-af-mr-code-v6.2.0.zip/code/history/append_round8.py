# -*- coding: utf-8 -*-
import io
import pathlib
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

ADD = """

---

## 第八轮（2026-10-27 晚）：渲染级视觉复核

### 为什么必须做
前七轮全是 XML / 文本层校验（python-docx 读段落、量列宽、比对数字），**看不到排版**。
这一轮用真渲染，一次抓出 4 个前面全部漏掉的问题。

**管线**：`soffice --headless --convert-to pdf`（LibreOffice 已装）→ `pymupdf` 逐页栅格化 → 逐图目检；
另用 **node** 读投稿包内 5 张 PNG 的 IHDR / pHYs 头算物理尺寸、生成图表页 HTML，Chrome 无头截图核对。

### 抓到并修掉 4 个问题
1. **Table 2 八列不可读**：表头占 6 行；`0.72–` 与 `1.17` 被拆到两行；单元格挤成 3 行。
   → 改 **6 列**（primary + 两个 co-primary + meta + SNPs），AFGen / BBJ 移入 Table S2（本来就在）；
   字号 10→9 pt；`P = x` 用 U+00A0 绑定不换行，只在逗号处折行。
2. **Table 1 "OpenGWAS" 折成 "OpenGWA/S"**：单元格边距 90 + 列宽 1100 不够。
   → 边距 90→70 twips，Access 列放宽到 1250。
3. **表行跨页断开**：metabolites 行被切成两页。
   → 所有表行加 `cantSplit`（docx-js 的 TableRow 选项），表头自动重复。
4. **Table S26 脚注事实错误**：写"只有咖啡和茶异质"，实际糖加茶 Q P = 5.2×10⁻¹⁸、甜味剂 3.8×10⁻⁶ 也都 P<0.001。
   → 改为四个暴露并列 + "其余 Q P ≥ 0.026"。

### 代码层的两处连带改动
- `makeTable` 增加第 4 个参数 `size`（默认 20 半磅），`cell()` 改为解构 `{size = 20, ...rest}`。
  **注意**：箭头函数从表达式体改成块体后，**必须补 `};` 收尾**，否则 node 报 `Unexpected reserved word`。
- `fitWidths` 在上轮已加（列宽和超限自动归一化）；本轮把行级 `cantSplit` 一并加上。

### 渲染结果
手稿 27 页 / 补材 18 页 / 投稿信 3 页 / Highlights 1 页；
逐页扫描：**除页码页脚外无内容越出版心**；三套机器校验复跑仍全 PASS（49 / 28 / 全过）。

### 结论
**XML 全绿 ≠ 能印。** 表 2 的不可读、OpenGWA/S 折行、行跨页，这三样只有渲染出来才看得见。
以后凡动表格或图，收尾必跑 `soffice → pdf → png` 目检一遍。
"""

p = pathlib.Path(r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版"
                 r"\JAHA_v525_改稿留档\审读意见_20261026\修正记录_20261026.md")
t = p.read_text(encoding="utf-8")
if "第八轮" in t:
    print("skip")
else:
    p.write_text(t + ADD, encoding="utf-8")
    print("revision log updated")

MEM = """

## 渲染级视觉复核（10-27 晚）

- 环境：**LibreOffice 已装**（`C:\\Program Files\\LibreOffice\\program\\soffice.exe`），Chrome 也在。
  管线：`soffice --convert-to pdf` → `pymupdf` 逐页出 PNG → 看图。
- **node 视觉验证**：node 读 PNG 的 IHDR(宽高) + pHYs(DPI) 算物理尺寸 → 生成 HTML 图表页 → Chrome
  `--headless=new --screenshot` 截图。尺寸来自文件头，不是手填。
- 一次抓出 4 个 XML 层看不见的问题：表 2 八列不可读、OpenGWAS 折成 OpenGWA/S、表行跨页断开、
  S26 脚注把"四个暴露异质"写成"两个"。
- 修法沉淀：表格 `makeTable(widths, header, rows, size)`；行 `cantSplit: true`；单元格 `P = x` 用 U+00A0 绑定。
- **docx-js 坑**：箭头函数从 `=> expr` 改成 `=> { const ...; return ... }` 后必须补 `};`，
  否则 node 直接 `SyntaxError: Unexpected reserved word`。
- 结论：**XML 全绿 ≠ 能印**。改完表格/图必须 `soffice → pdf → png` 目检。
"""

m = pathlib.Path(r"C:\Users\64915\WorkBuddy\2026-10-06-13-49-21\.workbuddy\memory\2026-10-27.md")
t2 = m.read_text(encoding="utf-8")
if "渲染级视觉复核" in t2:
    print("memory skip")
else:
    m.write_text(t2 + MEM, encoding="utf-8")
    print("memory updated")
