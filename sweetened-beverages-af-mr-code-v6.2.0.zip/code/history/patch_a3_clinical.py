# -*- coding: utf-8 -*-
"""Update the Clinical Perspective box for the A3 co-primary outcome."""
import io
import pathlib
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
P = pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
                 r"\04_docx构建脚本\build_manuscript_v51_JAHA.js")
src = P.read_text(encoding="utf-8")

E = [
    (
        "showed no evidence of a causal association with atrial fibrillation across three European outcome sources and an East Asian contextual analysis.",
        "showed no evidence of a causal association with atrial fibrillation across four European-ancestry outcome sources, including a UK Biobank-free panel of 192,851 cases, and an East Asian contextual analysis.",
    ),
    (
        "T`• The only nominal signal (coffee intake) was not attributable to caffeine-handling pathways: it attenuated after body-mass-index adjustment and colocalized with atrial fibrillation only at the FTO locus, not at caffeine-metabolism loci. The coffee instrument set also tracks adiposity liability, the direction of which is not identifiable here.`",
        "T`• The only recurring signal (coffee intake) was not attributable to caffeine-handling pathways: it was carried by adiposity-locus instruments—removing variants within 500 kb of body-mass-index loci abolished it in both overlap-free outcome sources—and colocalized with atrial fibrillation only at the FTO locus, not at caffeine-metabolism loci.`",
    ),
]

ok = True
for i, (o, n) in enumerate(E, 1):
    c = src.count(o)
    print(("PASS" if c == 1 else f"FAIL x{c}"), f"C{i}", o[:60])
    if c != 1:
        ok = False
        continue
    src = src.replace(o, n)

if not ok:
    print("ABORT"); sys.exit(1)
P.write_text(src, encoding="utf-8", newline="\n")
print("written")
