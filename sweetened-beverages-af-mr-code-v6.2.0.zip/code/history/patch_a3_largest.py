# -*- coding: utf-8 -*-
"""Fix 'largest AF GWAS' claims now that Yuan 2025 (192,851 cases) is the largest
source used; also update strengths/limitations wording."""
import io
import pathlib
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
P = pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
                 r"\04_docx构建脚本\build_manuscript_v51_JAHA.js")
src = P.read_text(encoding="utf-8")

E = [
    # Introduction
    ("Leveraging UK Biobank beverage-consumption GWAS [11] and the largest public AF GWAS, we conducted",
     "Leveraging UK Biobank beverage-consumption GWAS [11] and the largest public AF GWAS—including a UK Biobank-free meta-analysis of 192,851 cases—we conducted"),
    # Discussion, principal findings
    ("In this two-sample and multivariable Mendelian randomization study using the largest available European-ancestry AF GWAS,",
     "In this two-sample and multivariable Mendelian randomization study using four European-ancestry AF sources, including the largest public one (192,851 cases),"),
    # Discussion, comparison with previous work
    ("five sweetened-beverage phenotypes and their caffeinated counterparts examined against the largest public AF GWAS, with adiposity modeled jointly",
     "five sweetened-beverage phenotypes and their caffeinated counterparts examined against four European-ancestry AF sources including the largest public one, with adiposity modeled jointly"),
    # Strengths
    ("Strengths include multiple complementary estimators, the largest public European-ancestry AF GWAS, pre-specified multiplicity control",
     "Strengths include multiple complementary estimators, four European-ancestry AF sources including the largest public one, pre-specified multiplicity control"),
]

ok = True
for i, (o, n) in enumerate(E, 1):
    c = src.count(o)
    print(("PASS" if c == 1 else f"FAIL x{c}"), f"L{i}", o[:64])
    if c != 1:
        ok = False
        continue
    src = src.replace(o, n)

# Limitations: add the post hoc caveat about the adiposity-locus analysis
old = ("Two-step mediation MR through BMI was performed during revision for the sole nominal signal (coffee intake) as a mechanistic probe;")
if old in src:
    print("PASS L5 limitations anchor")
    src = src.replace(
        old,
        "Two-step mediation MR through BMI and the adiposity-locus instrument sensitivity analysis (Table S27) were performed during revision for the sole recurring signal (coffee intake) as mechanistic probes, and are therefore post hoc rather than pre-specified;")
else:
    print("SKIP L5 (anchor not found)")

P.write_text(src, encoding="utf-8", newline="\n")
print("written")
