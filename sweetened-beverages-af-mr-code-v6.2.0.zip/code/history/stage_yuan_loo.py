# -*- coding: utf-8 -*-
import csv
D=r"C:\a3work"
exp={r["SNP"]:r for r in csv.DictReader(open(D+r"\dat_Coffee_intake_ebi_a_GCST006414.csv",encoding="utf-8"))}
comp=lambda a:a.translate(str.maketrans("ACGT","TGCA"))
rows=[]
for r in csv.DictReader(open(D+r"\yuan2025_instruments.tsv",encoding="utf-8"),delimiter="\t"):
    if r["exposure"]!="Coffee_intake" or r["SNP"] not in exp:continue
    e=exp[r["SNP"]];ea=e["effect_allele.exposure"];oa=e["other_allele.exposure"]
    if (r["ea.out"],r["oa.out"])==(ea,oa):by=float(r["beta.out"])
    elif (r["ea.out"],r["oa.out"])==(oa,ea):by=-float(r["beta.out"])
    elif (r["ea.out"],r["oa.out"])==(comp(ea),comp(oa)):by=float(r["beta.out"])
    elif (r["ea.out"],r["oa.out"])==(comp(oa),comp(ea)):by=-float(r["beta.out"])
    else:continue
    rows.append({"SNP":r["SNP"],"beta.exposure":e["beta.exposure"],"beta.outcome":by,"se.outcome":r["se.out"],"mr_keep":"TRUE"})
assert len(rows)==30
with open(D+r"\dat_Coffee_intake_yuan.csv","w",encoding="utf-8",newline="") as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print("wrote",len(rows),"Yuan harmonised rows")
