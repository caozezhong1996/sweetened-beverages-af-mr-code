# -*- coding: utf-8 -*-
"""Independently verify the review's checkable claims against the submitted files."""
import io
import re
import sys

from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

PKG = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013"
MS = Document(PKG + r"\Manuscript.docx")
SUP = Document(PKG + r"\Supplement.docx")
mp = [p.text.strip() for p in MS.paragraphs if p.text.strip()]
mf = "\n".join(mp)

def show(tag, ok, detail=""):
    print(f"[{'PASS' if ok else 'FAIL'}] {tag}" + (f"  → {detail}" if detail else ""))

print("=== A1 参考文献 [31] 与 [47] 是否重复 ===")
refs = {int(m.group(1)): m.group(2) for m in re.finditer(r"(?m)^(\d+)\.\s+(.*)$", mf)}
r31, r47 = refs.get(31, ""), refs.get(47, "")
print("  [31]:", r31[:140])
print("  [47]:", r47[:140])
show("两条完全相同", r31[:60] == r47[:60] and len(r31) > 20)

print("\n=== A2 茶摄入 SNP 数 ===")
t1 = MS.tables[0]
for row in t1.rows:
    c = [x.text.strip() for x in row.cells]
    if c and c[0].lower().startswith("tea"):
        print("  Table 1 茶行:", " | ".join(c[-2:]))
show("正文出现 identical instrument lists",
     "identical instrument lists" in mf.lower(),
     re.search(r"[^.]*identical instrument lists[^.]*\.", mf, re.I).group(0)[:160] if "identical instrument lists" in mf.lower() else "")

print("\n=== A7 MR-RAPS 'P ≥ 0.51' ===")
m = re.search(r"[^.]*P ≥ 0\.51[^.]*\.", mf)
print("  正文:", m.group(0)[:200] if m else "未找到")

print("\n=== A8 代谢物 F 值引用 ===")
for mm in re.finditer(r"[^.]*F\s*30[–-]49[^.]*\.", mf):
    print("  正文:", mm.group(0)[:200])
show("正文引用 Table S25", "Table S25" in mf)
s_tables = SUP.tables
print("  补充材料表格数:", len(s_tables))

print("\n=== B1 图注是否残留版本化文件名 ===")
leg = [p for p in mp if re.search(r"Figure\s*(S?\d)\.", p)][:8]
for l in leg:
    if ".png" in l.lower():
        print("  图注含文件名:", l[:160])
hits = re.findall(r"\S*_v\d+_300dpi\.png", mf)
show("无版本化文件名", not hits, str(hits[:3]))

print("\n=== C6 方法/结果 F 阈值是否一致 ===")
for kw in [r"F\s*>\s*10", r"F\s*>\s*20", r"F statistics exceeded 20"]:
    for mm in re.finditer(kw, mf):
        s = max(0, mm.start() - 80)
        print(f"  {kw}: ...{mf[s:mm.end()+80].replace(chr(10),' ')}...")

print("\n=== A4 '1.01–1.17' 与排除观察值的表述 ===")
m = re.search(r"[^.]*1\.01[–-]1\.1[0-9][^.]*\.", mf)
print("  正文:", m.group(0)[:260] if m else "未找到")
print("  Table 1 欧洲 meta 上界：")
for row in t1.rows[1:]:
    c = [x.text.strip() for x in row.cells]
    if len(c) > 5:
        print("   ", c[0][:26], "|", c[-2][:34])

print("\n=== 摘要是否提及 theobromine / rg 来源 ===")
ab = mf[mf.find("Abstract"):mf.find("Keywords")]
print("  theobromine in abstract:", "theobromine" in ab)
print("  abstract rg 句:", re.search(r"[^.]*genetic correlations[^.]*\.", ab).group(0)[:200] if "genetic correlations" in ab else "无")

print("\n=== B3 补充材料目录是否含 Table S25 ===")
toc = [p for p in (x.text.strip() for x in SUP.paragraphs) if re.match(r"Table S\d+", p or "")]
print("  目录条目数:", len(toc), "最后 3 条:", toc[-3:])
