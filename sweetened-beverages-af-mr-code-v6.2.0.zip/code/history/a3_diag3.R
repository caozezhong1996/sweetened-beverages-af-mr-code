# Coffee -> AF (Yuan 2025): pleiotropy diagnostics, Egger intercept by hand,
# MR-PRESSO, and IVW after removing adiposity-locus instruments.
suppressMessages({library(data.table); library(TwoSampleMR); library(MRPRESSO)})
RES <- "C:/a3work"

get_d <- function(e) {
  expo <- fread(file.path(RES, sprintf("dat_%s_ebi_a_GCST006414.csv", e)))
  expo <- expo[mr_keep %in% c(TRUE, "TRUE")]
  ex <- format_data(as.data.frame(expo), type = "exposure", snp_col = "SNP",
                    beta_col = "beta.exposure", se_col = "se.exposure",
                    effect_allele_col = "effect_allele.exposure",
                    other_allele_col = "other_allele.exposure",
                    eaf_col = "eaf.exposure", pval_col = "pval.exposure")
  yo <- fread(file.path(RES, "yuan2025_instruments.tsv"))[exposure == e]
  out <- format_data(as.data.frame(yo), type = "outcome", snp_col = "SNP",
                     beta_col = "beta.out", se_col = "se.out",
                     effect_allele_col = "ea.out", other_allele_col = "oa.out",
                     eaf_col = "eaf.out", pval_col = "pval.out")
  d <- harmonise_data(ex, out, action = 2)
  d[d$mr_keep %in% c(TRUE, "TRUE"), ]
}

# harmonised data has no chr/pos; recover from the exposure file
attach_pos <- function(d, e) {
  src <- fread(file.path(RES, sprintf("dat_%s_ebi_a_GCST006414.csv", e)))
  src <- src[, .(SNP, chr = as.integer(chr), pos = as.integer(pos))]
  merge(as.data.table(d), src, by = "SNP", all.x = TRUE)
}

re_ivw <- function(bx, by, sy) {
  w <- 1 / sy^2
  b <- sum(w * bx * by) / sum(w * bx^2)
  se_fe <- sqrt(1 / sum(w * bx^2))
  q <- sum(w * (by - b * bx)^2)
  df <- length(bx) - 1
  infl <- max(1, sqrt(q / df))
  se_re <- se_fe * infl
  c(b = b, se = se_re, Q = q, Qp = pchisq(q, df, lower.tail = FALSE), infl = infl,
    p = 2 * pnorm(-abs(b / se_re)))
}

# Egger with explicit intercept, same convention as TwoSampleMR::mr_egger_regression
# (weighted lm of b_out on b_exp; SE divided by min(1, residual sigma))
egger <- function(bx, by, sx, sy) {
  w <- 1 / sy^2
  fit <- lm(by ~ bx, weights = w)
  s <- summary(fit)
  sig <- s$sigma
  scale <- min(1, sig)
  co <- s$coefficients
  b0 <- co[1, 1]; se0 <- co[1, 2] / scale; p0 <- 2 * pt(-abs(b0 / se0), length(by) - 2)
  b1 <- co[2, 1]; se1 <- co[2, 2] / scale; p1 <- 2 * pt(-abs(b1 / se1), length(by) - 2)
  c(intercept = b0, se_i = se0, p_i = p0, slope = b1, se_s = se1, p_s = p1)
}

bmi <- fread(file.path(RES, "tmp_bmi_instruments_v46.csv"))
bmi <- bmi[!is.na(chr) & !is.na(pos)]
WIN <- 500000

near_bmi <- function(d) {
  idx <- integer(0)
  for (k in seq_len(nrow(d))) {
    if (is.na(d$chr[k])) next
    if (any(bmi$chr == d$chr[k] & abs(bmi$pos - d$pos[k]) <= WIN)) idx <- c(idx, k)
  }
  idx
}

EXPO <- c("Coffee_intake", "Sugar_added_to_tea", "Fizzy_drink_intake_SSB",
          "Low_calorie_drink_intake_ASB", "Artificial_sweetener_added_to_tea",
          "Sugar_added_to_coffee", "Tea_intake")
LAB <- c("Coffee intake", "Sugar added to tea", "Fizzy drinks (SSB)",
         "Low-calorie drinks (ASB)", "Sweetener added to tea", "Sugar added to coffee",
         "Tea intake")

out <- list()
for (i in seq_along(EXPO)) {
  d <- attach_pos(get_d(EXPO[i]), EXPO[i])
  if (nrow(d) < 3) next
  m <- re_ivw(d$beta.exposure, d$beta.outcome, d$se.outcome)
  eg <- egger(d$beta.exposure, d$beta.outcome, d$se.exposure, d$se.outcome)
  nb <- near_bmi(d)
  keep <- if (length(nb)) d[-nb, ] else d
  m2 <- if (nrow(keep) >= 3) re_ivw(keep$beta.exposure, keep$beta.outcome, keep$se.outcome)
        else c(b = NA, se = NA, Q = NA, Qp = NA, infl = NA, p = NA)
  cat(sprintf("%-24s n=%2d  OR=%.2f (%.2f-%.2f) P=%.4f  Qp=%.1e | Egger int P=%.3f | drop%d -> n=%2d OR=%.2f P=%.3f\n",
              LAB[i], nrow(d), exp(m["b"]), exp(m["b"] - 1.96 * m["se"]), exp(m["b"] + 1.96 * m["se"]),
              m["p"], m["Qp"], eg["p_i"], length(nb), nrow(keep),
              ifelse(is.na(m2["b"]), NA, exp(m2["b"])), m2["p"]))
  out[[i]] <- data.table(exposure = LAB[i], n = nrow(d), OR = exp(m["b"]),
                         lo = exp(m["b"] - 1.96 * m["se"]), hi = exp(m["b"] + 1.96 * m["se"]),
                         p = m["p"], Qp = m["Qp"], infl = m["infl"],
                         egger_int = eg["intercept"], egger_int_p = eg["p_i"],
                         egger_slope = eg["slope"], egger_slope_p = eg["p_s"],
                         n_adipo = length(nb), n_clean = nrow(keep),
                         OR_clean = ifelse(is.na(m2["b"]), NA, exp(m2["b"])),
                         lo_clean = ifelse(is.na(m2["b"]), NA, exp(m2["b"] - 1.96 * m2["se"])),
                         hi_clean = ifelse(is.na(m2["b"]), NA, exp(m2["b"] + 1.96 * m2["se"])),
                         p_clean = m2["p"])
}
fwrite(rbindlist(out), file.path(RES, "yuan2025_adipo_sensitivity.csv"))

# MR-PRESSO for coffee (signature check)
d <- as.data.frame(get_d("Coffee_intake"))
set.seed(20261027)
pr <- tryCatch(mr_presso(BetaOutcome = "beta.outcome", BetaExposure = "beta.exposure",
                         SdOutcome = "se.outcome", SdExposure = "se.exposure",
                         data = d, NbDistribution = 5000, SignifThreshold = 0.05),
               error = function(x) { cat("PRESSO error:", conditionMessage(x), "\n"); NULL })
if (!is.null(pr)) {
  cat("\n=== MR-PRESSO (coffee) ===\n")
  print(pr$`Main MR results`)
  g <- pr$`MR-PRESSO results`$`Global Test`
  cat("Global test P:", g$`P-value`, "\n")
  cat("Outlier indices:", paste(pr$`MR-PRESSO results`$`Distortion Test`$`Outliers Indices`, collapse = ","), "\n")
}
cat("\nwrote yuan2025_adipo_sensitivity.csv\n")
