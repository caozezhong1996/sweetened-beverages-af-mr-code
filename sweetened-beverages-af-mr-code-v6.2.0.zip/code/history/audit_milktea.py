# -*- coding: utf-8 -*-
"""Where does the milk-tea framing actually live in the current manuscript?"""
import io
import re
import sys

from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

P = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\Manuscript.docx"
d = Document(P)
mp = [p.text.strip() for p in d.paragraphs if p.text.strip()]

print("TITLE:")
print(" ", mp[0])
print()

heads = {"Abstract", "Introduction", "Methods", "Results", "Discussion",
         "Clinical Perspective", "Tables", "References", "Conclusions"}
section = "front"
hits = {}
for i, t in enumerate(mp):
    if t in heads or t.startswith("Clinical Perspective"):
        section = t
    for m in re.finditer(r"milk[-\s]?tea", t, re.I):
        hits.setdefault(section, []).append((i, t[max(0, m.start() - 90):m.start() + 110]))

total = 0
for sec, items in hits.items():
    total += len(items)
    print(f"[{sec}]  {len(items)} mentions")
    for i, ctx in items:
        print(f"   [{i}] ...{ctx.strip()}...")
    print()
print("TOTAL milk-tea mentions:", total)

print("\n--- word counts by block ---")
for i, t in enumerate(mp):
    if t.startswith(("Background:", "Methods and Results:", "Conclusions:")):
        print(f"  [{i}] {t.split(':')[0]}: {len(t.split())} words")

print("\n--- East Asian mentions in title / abstract / conclusions ---")
for i, t in enumerate(mp):
    if re.search(r"East Asian", t) and (i < 20 or t.startswith("Conclusions")):
        print(f"  [{i}] {t[:200]}")
