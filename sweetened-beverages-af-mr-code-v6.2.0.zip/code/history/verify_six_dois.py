# -*- coding: utf-8 -*-
"""Resolve the six remaining references by DOI, with retries and field comparison."""
import io
import json
import re
import sys
import time
import urllib.parse
import urllib.request

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
MAILTO = "caozezhong1996@163.com"

TARGETS = {
    13: ("10.1038/s41588-018-0171-3",
         "Biobank-driven genomic discovery yields new insight into atrial fibrillation biology",
         "Nielsen", "Nat Genet", 2018, "50", "1234"),
    14: ("10.1038/s41588-018-0133-9",
         "Multi-ethnic genome-wide association study for atrial fibrillation",
         "Roselli", "Nat Genet", 2018, "50", "1225"),
    15: ("10.1038/s41586-022-05473-8",
         "FinnGen provides genetic insights from a well-phenotyped isolated population",
         "Kurki", "Nature", 2023, "613", "508"),
    17: ("10.1038/s41588-020-0640-3",
         "Large-scale genome-wide association study in a Japanese population identifies novel "
         "susceptibility loci across different diseases",
         "Ishigaki", "Nat Genet", 2020, "52", "669"),
    19: ("10.1038/s41588-018-0307-5",
         "Association studies of up to 1.2 million individuals yield new insights into the genetic "
         "etiology of tobacco and alcohol use",
         "Liu", "Nat Genet", 2019, "51", "237"),
    37: ("10.1001/jama.2018.18179",
         "Association between titin loss-of-function variants and early-onset atrial fibrillation",
         "Choi", "JAMA", 2018, "320", "2354"),
}


def fetch(doi):
    last = None
    for attempt in range(5):
        for scheme in ("https", "http"):
            url = f"{scheme}://api.crossref.org/works/{urllib.parse.quote(doi)}"
            try:
                req = urllib.request.Request(url, headers={
                    "User-Agent": f"refcheck/6 (mailto:{MAILTO})",
                    "Accept": "application/json"})
                with urllib.request.urlopen(req, timeout=30) as r:
                    return json.load(r)["message"]
            except Exception as e:
                last = f"{type(e).__name__}: {e}"
        time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(last)


ok_all = True
for n, (doi, title, first_au, journal, year, vol, page) in TARGETS.items():
    try:
        m = fetch(doi)
    except Exception as e:
        print(f"[{n}] FETCH FAIL {e}")
        ok_all = False
        continue
    got_title = (m.get("title") or [""])[0].rstrip(".")
    got_journal = (m.get("container-title") or [""])[0]
    got_year = (m.get("issued", {}).get("date-parts") or [[None]])[0][0]
    got_vol = m.get("volume")
    got_page = (m.get("page") or "").split("-")[0]
    aus = m.get("author") or []
    got_first = (aus[0].get("family") if aus else "") or ""

    checks = [
        ("title", got_title.lower().rstrip(".") == title.lower().rstrip(".")),
        ("first author", first_au.lower() in got_first.lower()),
        ("journal", journal.lower().replace(".", "") in got_journal.lower().replace(".", "")),
        ("year", str(got_year) == str(year)),
        ("volume", str(got_vol) == str(vol)),
        ("start page", str(got_page) == str(page)),
    ]
    bad = [k for k, v in checks if not v]
    status = "PASS" if not bad else "CHECK"
    if bad:
        ok_all = False
    print(f"{status:<6}[{n}]  {got_first} et al. {got_journal} {got_year};{got_vol}:{m.get('page')}  doi {doi}")
    print(f"        {got_title[:96]}")
    if bad:
        print(f"        MISMATCH: {bad}")
    time.sleep(0.6)

print("\nALL VERIFIED" if ok_all else "\nSOME FIELDS NEED ATTENTION")
