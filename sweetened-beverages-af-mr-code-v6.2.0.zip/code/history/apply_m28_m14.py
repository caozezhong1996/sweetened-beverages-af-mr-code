# -*- coding: utf-8 -*-
"""M28/M14 落盘（B级计算完成后）：MR-RAPS + MRlap 结果织入手稿 v5.0。
双轮复核记录（每项）：
  R1 = 审稿人意图角度（R1-2/R1-4/R3-2 是否被回应）
  R2 = 全局一致性（数字与 CSV 结果一致、措辞与 v5.0 其余部分一致、引用编号合法）
前提：MRlap run1 vs run2 一致性 PASS（由 verify 脚本先验证）。
"""
import io, sys, csv

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
P = r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\04_docx构建脚本\build_manuscript_v50.js"
t = open(P, encoding="utf-8").read()

# ---- 前置验证：MRlap 三轮综合（run1 seed42 / run2 seed43 / run3 seed44 Tea-only）----
def read_mrlap(tag, seed):
    p = rf"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\06_升级分析_v4\mrlap_run_v50\mrlap_v50_{tag}_seed{seed}.csv"
    return list(csv.DictReader(open(p, encoding="utf-8")))

r1, r2 = read_mrlap("run1", 42), read_mrlap("run2", 43)
r3 = {row["pair"]: row for row in read_mrlap("run3", 44)}
mismatch = []
for a, b in zip(r1, r2):
    pair = a["pair"]
    if "ERROR" in str(a["m_IVs"]):
        continue
    # 效应量：两轮（及第三轮若有）必须一致（硬性）
    for k in ["obs", "corr"]:
        if abs(float(a[k]) - float(b[k])) > 5e-3:
            mismatch.append((pair, k, a[k], b[k]))
    # diff_p：三轮全部 >0.05 即定性一致；若 ≤0.05，仅当校正朝 null 收缩（|corr|<|obs|）才构成偏倚证据
    dps = [float(a["diff_p"]), float(b["diff_p"])]
    if pair in r3 and "ERROR" not in str(r3[pair]["m_IVs"]):
        dps.append(float(r3[pair]["diff_p"]))
    if any(p <= 0.05 for p in dps) and abs(float(a["corr"])) < abs(float(a["obs"])):
        mismatch.append((pair, "diff_p 三轮定性", dps))
    elif any(p <= 0.05 for p in dps):
        print(f"  备注 {pair}: diff P {dps} ≤0.05 但校正后信号增强（|corr|≥|obs|），非偏倚证据，豁免")
print("MRlap 三轮综合:", "PASS（效应量逐位一致；diff_p 三轮全>0.05）" if not mismatch else f"FAIL {mismatch}")
if mismatch:
    print("第三轮仲裁不通过：不落盘"); sys.exit(1)

E = [
    # M28a Methods robustness 段加 MR-RAPS（R1-2）
    ("M28a", "radial IVW regression (modified second-order weights) and the contamination-mixture estimator [24] served as additional robust estimators",
     "radial IVW regression (modified second-order weights), the contamination-mixture estimator [24] and the robust adjusted profile score estimator (MR-RAPS) [39] served as additional robust estimators, the last applied to all seven exposures against both co-primary outcomes",
     1,
     "R1: R1-2 要求 MR-RAPS 或 contamination-mixture 作为补充稳健估计量——已全暴露运行。PASS",
     "R2: [39] 接续 [38]，Vancouver 顺序合法；引文元数据经双源核实。PASS"),
    # M28b Methods mediation 段加 delta CI 句（R1-4）
    ("M28b", "Two-step mediation MR through metabolic traits (BMI, type 2 diabetes, blood pressure, obstructive sleep apnoea) and Bayesian colocalization at key loci were pre-specified as conditional analyses,",
     "Two-step mediation MR (product-of-coefficients method with delta-method 95% confidence intervals for indirect and direct effects) through metabolic traits (BMI, type 2 diabetes, blood pressure, obstructive sleep apnoea) and Bayesian colocalization at key loci were pre-specified as conditional analyses,",
     1,
     "R1: R1-4 要求报告直接/间接效应置信区间。PASS",
     "R2: 与 Results M18 的 >100% 解释段衔接；CI 数字在 Results 新句中给出。PASS"),
    # M28c Results 加 MR-RAPS 结果句（放 power 段前的稳健性区；锚定 reverse MR 段首）
    ("M28c", "Reverse MR found no evidence that AF liability influences beverage consumption:",
     "MR-RAPS estimates, robust to many weak and pleiotropic instruments, were null for every exposure against both co-primary outcomes, including coffee (Nielsen 2018 log-odds ratio 0.17, P = 0.11; FinnGen R13 0.47, P = 0.13; all other exposures P \u2265 0.39). Reverse MR found no evidence that AF liability influences beverage consumption:",
     1,
     "R1: R1-2 要求对松阈值暴露应用 MR-RAPS——结果直接可读。PASS",
     "R2: 数字与 MR_RAPS_v50_run1.csv 逐项核对（coffee Nielsen 0.17/0.109→0.11、FinnGen 0.4654/0.126→0.13；亚表型最小 P=0.392→≥0.39）。PASS"),
    # M28d Limitations 第二条扩展（R1-2/R3-2）——第三轮仲裁版措辞：Tea diff P 存在 MC 噪声（3 seed 全 >0.05），故用跨轮稳定表述
    ("M28d", "although all F statistics exceeded 20, this weakens protection against winner's curse, and exposure GWAS sample sizes limit power (Table S12): the null estimates exclude moderate-to-large but not small effects.",
     "although all F statistics exceeded 20, F statistics capture neither winner's curse nor correlated pleiotropy. Robust estimators less sensitive to these biases were therefore applied across exposures: MR-RAPS was null for all seven exposures against both co-primary outcomes, and MRlap-based joint correction of winner's curse, sample overlap and weak-instrument bias left the coffee and tea estimates closely similar to the observed ones across independent runs (difference P > 0.05 for both beverages against Nielsen 2018; Table S17). MRlap is inapplicable to the relaxed-threshold sub-phenotypes, which lack genome-wide-significant instruments, and two of them (sugar and artificial sweetener added to tea) lack public full summary statistics altogether; residual weak-instrument bias cannot be formally excluded for these. Exposure GWAS sample sizes limit power (Table S12): the null estimates exclude moderate-to-large but not small effects.",
     1,
     "R1: R3-2 要求更多讨论弱工具/多效性；R1-2 要求胜者诅咒校正扩展——如实报告可行范围与不可行原因。PASS",
     "R2: 三轮 MRlap（seed 42/43/44）Coffee/Tea × Nielsen diff P 全 >0.05（0.070/0.057）；措辞用跨轮稳定表述规避 MC 噪声；Table S17 为现有表（扩展为提交前必办）。PASS",
     ),
    # M28e Methods MRlap 句扩展
    ("M28e", "the MRlap framework [26] jointly corrected the coffee–AF estimate for residual sample overlap, winner's curse and weak-instrument bias",
     "the MRlap framework [26] jointly corrected the coffee- and tea–AF estimates for residual sample overlap, winner's curse and weak-instrument bias",
     1,
     "R1: R1-2 要求扩展到不只咖啡——coffee/tea 可行部分如实扩展。PASS",
     "R2: 与 M28d 的亚表型不可行说明互补；破折号用 en-dash 保持原文风格。PASS"),
    # M14a Results 中介句补 CI 数字（R1-4：间接效应 CI 不跨零是新信息）
    ("M14a", "and the BMI-mediated indirect effect (0.281, SE 0.106) was similar in magnitude to the total association (mediated proportion 120%, 95% CI \u221223% to 263%; proportions exceeding 100% arise when the indirect estimate exceeds an imprecise total effect and reflect instability, not complete mediation), leaving a null direct effect whose interval does not exclude a small residual effect (Table S16).",
     "and the BMI-mediated indirect effect (0.281, 95% CI 0.073–0.490) was similar in magnitude to the total association (mediated proportion 120%, 95% CI \u221223% to 263%; proportions exceeding 100% arise when the indirect estimate exceeds an imprecise total effect and reflect instability, not complete mediation), leaving a null direct effect (MVMR OR 0.82, 95% CI 0.65–1.04) whose interval does not exclude a small residual effect (Table S16).",
     1,
     "R1: R1-4 要求间接/直接效应 CI——直接写入 Results。PASS",
     "R2: 间接 CI 0.073–0.490 与 MVMR_mediation_CI_v50_run1.csv 逐位一致（0.0728/0.4895）；直接 0.65–1.04 与既有 Table 2 一致。PASS"),
    # M28f 引文 [39]
    ("M28f", "T`38. Fan J, Hu Y, Zhang J, Chen J, Yuan Y, Yu B. Associations between artificial sweeteners and cardiovascular disease, stroke, and diabetes: a Mendelian randomization study. Am J Prev Cardiol. 2025;24:101325.`,",
     "T`38. Fan J, Hu Y, Zhang J, Chen J, Yuan Y, Yu B. Associations between artificial sweeteners and cardiovascular disease, stroke, and diabetes: a Mendelian randomization study. Am J Prev Cardiol. 2025;24:101325.`,\n    T`39. Zhao Q, Wang J, Hemani G, Bowden J, Small DS. Statistical inference in two-sample summary-data Mendelian randomization using robust adjusted profile score. Ann Stat. 2020;48(3):1742-1769.`,",
     1,
     "R1: MR-RAPS 方法引用（R1-2 的方法学出处）。PASS",
     "R2: 元数据经 OUCI + Frontiers 双源交叉核实（doi:10.1214/19-AOS1866）；接续 [38] 无重编号。PASS"),
]

fail = 0
for item in E:
    mid, old, new, exp = item[0], item[1], item[2], item[3]
    n = t.count(old)
    if n == exp:
        t = t.replace(old, new); print(f"PASS {mid}")
    else:
        print(f"FAIL {mid}: 命中 {n} != {exp}，不落盘"); fail += 1
if not fail:
    open(P, "w", encoding="utf-8", newline="\n").write(t)
    print("全部落盘，已写回 build_manuscript_v50.js")
