# -*- coding: utf-8 -*-
from docx import Document
from PIL import Image
import pathlib,re,zipfile,io,sys,csv,os
sys.stdout=io.TextIOWrapper(sys.stdout.buffer,encoding="utf-8")
PKG=pathlib.Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")
NEW=pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\06_升级分析_v4\results")
def flat(d):return "\n".join(p.text for p in d.paragraphs)+"\n"+"\n".join(c.text for t in d.tables for r in t.rows for c in r.cells)
def ok(x,s):
    assert x,s
    print("PASS",s)
man=Document(str(PKG/"Manuscript.docx"));sup=Document(str(PKG/"Supplement.docx"));hl=Document(str(PKG/"Highlights.docx"))
mt=flat(man);st=flat(sup);ht=flat(hl)
refs=[p.text for p in man.paragraphs if re.match(r"^\d+\.\s",p.text)]
ok(len(refs)==47 and refs[4].startswith("5. You X") and "10.1007/s00394-026-03944-6" in refs[4],"You 2026 inserted as reference 5")
body="\n".join(p.text for p in man.paragraphs).split("References")[0];order=[]
for g in re.findall(r"\[([0-9,\s–-]+)\]",body):
    for n in re.findall(r"\d+",g):
        n=int(n)
        if 1<=n<=47 and n not in order:order.append(n)
ok(order==list(range(1,48)),"First-citation order 1-47")
ok("attenuated estimates to 1.26–1.39" not in mt and "narrowed the between-source range" in mt,"Abstract direction corrected")
ok("except sugar added to coffee and coffee intake" in mt,"AFGen exceptions corrected")
ok("I² = 67%; 0–6% for others" in mt and "I² = 0–6%" in mt,"I2 corrected in Results and Table 2 note")
ok("nearly twice-larger" not in mt and mt.count("nearly twice the total sample size")>=2,"Total sample size qualifier corrected twice")
ok("European or East Asian populations" not in mt and "contextual rather than independent East Asian evidence" in mt,"BBJ conclusion bounded")
ok("robust direct effect" not in mt and "bias multivariable estimates toward the null" not in mt and "471 joint instruments" in mt and "Table S4" in mt,"MVMR strength and table references corrected")
ok("The sugar-in-tea negative control failed" in mt and "sugar-in-tea negative control failed" in ht,"Negative control disclosed in abstract and Highlights")
ok("P = 0.078 and 0.208" in mt and "P = 0.078 (Nielsen 2018) and P = 0.208 (FinnGen R13)" in st and "Signal carried entirely" not in st,"Caffeine subgroup difference tests added")
ok("2–19 variants" in st and "3–19 variants" not in st,"S27 removal range corrected")
ok("03_结果数据" not in st and "06_升级分析" not in st and "independently replicated in FinnGen R13" not in st,"S8 paths and independence wording corrected")
ok("five selected exposure–source combinations" in mt and "every exposure–source combination" not in mt and "n.e. = not estimated" in mt,"Figure captions corrected")
# Six biomarker source estimates must exist and match the values used in Figure 2.
expected={("caffeine","nielsen"):5,("caffeine","finngen"):1,("paraxanthine","nielsen"):7,("paraxanthine","finngen"):2,("theobromine","nielsen"):2,("theobromine","finngen"):2}
for (bio,src),n in expected.items():
    rows=list(csv.DictReader(open(NEW/f"mr_biomarker_{bio}_{src}.csv",encoding="utf-8")))
    ok(any(int(r["nsnp"])==n and r["method"] in ("Inverse variance weighted","Wald ratio") for r in rows),f"Figure 2 source estimate {bio} {src}")
im=Image.open(PKG/"figures/FigureS1_LOO_Funnel.png");dpi=im.info.get("dpi",(600,600))[0]
ok(abs(im.size[1]/dpi*2.54-23.0)<0.03,"Figure S1 23 cm height")
for name in ["Manuscript.docx","Supplement.docx","Cover_Letter.docx","Highlights.docx"]:
    with zipfile.ZipFile(PKG/name) as z:ok(z.testzip() is None,f"{name} ZIP integrity")
print("ALL 20261029 REVISION CHECKS PASSED")
