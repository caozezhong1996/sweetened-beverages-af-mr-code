# -*- coding: utf-8 -*-
import csv, pathlib, zipfile, sys, io
from docx import Document
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
PKG = pathlib.Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")
A3 = pathlib.Path(r"C:\a3work")
passed=0
def ok(cond,label):
    global passed
    assert cond,label
    passed+=1; print("PASS",label)
def flat(d): return "\n".join(p.text for p in d.paragraphs)+"\n"+"\n".join(c.text for t in d.tables for r in t.rows for c in r.cells)
docs={n:Document(str(PKG/n)) for n in ["Manuscript.docx","Supplement.docx","Cover_Letter.docx","Highlights.docx"]}
texts={n:flat(d) for n,d in docs.items()}
for n,t in texts.items():
    for old in ["pooled OR 1.41","residual OR 1.41","P = 0.0007","1.39–1.48","0.9%","1.48 (1.01–2.18)","about 17%","~17%","Proportion mediated"]:
        ok(old not in t,f"{n} removed {old}")
man=texts["Manuscript.docx"]
for s in ["1.26 (0.90–1.75; P = 0.178)","1.26–1.39","2.1%","were not pooled","Per-category OR upper bounds ranged from 1.01 to 1.17","β = 0.351, SE = 0.031; 321 SNPs"]:
    ok(s in man,f"Manuscript contains {s}")
sup=docs["Supplement.docx"]
t27=next(t for t in sup.tables if "SNPs (kept)" in " ".join(c.text for c in t.rows[0].cells))
records=list(csv.DictReader(open(A3/"S27_regenerated.csv",encoding="utf-8")))
order={"Nielsen":0,"FinnGen R13":1,"Yuan 2025":2}; expo=["Sugar added to tea","Sugar added to coffee","Fizzy drink intake (SSB)","Low-calorie drink intake (ASB)","Artificial sweetener added to tea","Coffee intake","Tea intake"]
records.sort(key=lambda r:(order[r["outcome"]],expo.index(r["exposure"])))
def f2(x): return f"{float(x):.2f}"
def fp(x):
    v=float(x); return "<0.001" if v<0.001 else f"{v:.3f}"
for row,rec in zip(t27.rows[1:],records):
    exp=[rec["outcome"],rec["exposure"],rec["n"],f"{f2(rec['OR'])} ({f2(rec['lo'])}–{f2(rec['hi'])})",fp(rec["p"]),rec["n_clean"],f"{f2(rec['OR_clean'])} ({f2(rec['lo_clean'])}–{f2(rec['hi_clean'])})",fp(rec["p_clean"])]
    ok([c.text for c in row.cells]==exp,f"S27 {rec['outcome']} {rec['exposure']}")
yuan_sugar=next(r for r in t27.rows[1:] if r.cells[0].text=="Yuan 2025" and r.cells[1].text=="Sugar added to coffee")
ok(yuan_sugar.cells[2].text=="13" and yuan_sugar.cells[3].text.startswith("0.98"),"S26/S27 Yuan sugar-coffee harmonisation consistent")
t16=next(t for t in sup.tables if t.rows[0].cells[0].text=="Component" and any(r.cells[0].text=="Total effect" for r in t.rows[1:]))
ok(not any(r.cells[0].text.startswith("Proportion mediated") for r in t16.rows),"S16 no mediated proportion")
ld=next(r for r in t16.rows if any("LD clumped" in c.text for c in r.cells))
ok(ld.cells[3].text=="321" and ld.cells[4].text=="0.3506" and ld.cells[5].text=="0.0307","S16 LD-clumped sensitivity values")
ps=[p.text for p in docs["Manuscript.docx"].paragraphs]; a=ps.index("Abstract"); k=next(i for i in range(a+1,len(ps)) if ps[i].startswith("Keywords:")); wc=sum(len(x.split()) for x in ps[a+1:k])
ok(wc<=240,f"Abstract conservative word count {wc} <= 240")
for n in docs:
    with zipfile.ZipFile(PKG/n) as z: ok(z.testzip() is None,f"{n} ZIP integrity")
print(f"ALL {passed} CHECKS PASSED")
