# -*- coding: utf-8 -*-
"""Replace Table S27 with the coordinate-corrected values and rewrite its note."""
import csv
import io
import os
import pathlib
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
D = r"C:\a3work"
SP = pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
                  r"\04_docx构建脚本\build_supplement_v51_JAHA.js")

records = list(csv.DictReader(open(os.path.join(D, "S27_regenerated.csv"), encoding="utf-8")))
order = {"Nielsen": 0, "FinnGen R13": 1, "Yuan 2025": 2}
expo_order = ["Sugar added to tea", "Sugar added to coffee", "Fizzy drink intake (SSB)",
              "Low-calorie drink intake (ASB)", "Artificial sweetener added to tea",
              "Coffee intake", "Tea intake"]
records.sort(key=lambda r: (order[r["outcome"]], expo_order.index(r["exposure"])))


def f2(x):
    return f"{float(x):.2f}"


def fp(x):
    v = float(x)
    return "<0.001" if v < 0.001 else f"{v:.3f}"


lines = []
for r in records:
    cells = [
        r["outcome"], r["exposure"], r["n"],
        f"{f2(r['OR'])} ({f2(r['lo'])}-{f2(r['hi'])})", fp(r["p"]),
        r["n_clean"],
        f"{f2(r['OR_clean'])} ({f2(r['lo_clean'])}-{f2(r['hi_clean'])})", fp(r["p_clean"]),
    ]
    lines.append("    [" + ", ".join('"' + c.replace('"', '\\"') + '"' for c in cells) + "],")
new_rows = "\n".join(lines)

NOTE = ('Instruments were removed if they lay within 500 kb of any of 724 genome-wide-significant body-mass-index loci '
        '(Yengo et al. 2018, GCST006900). All estimates are random-effects inverse-variance-weighted. '
        'Coordinates were matched on GRCh37 throughout: Yuan outcome positions are GRCh38, so instrument positions '
        'were taken from the GRCh37 harmonised exposure datasets, with direct, swapped and complementary-strand '
        'alleles aligned explicitly. Removing adiposity-locus instruments reduced the between-source spread of the '
        'coffee estimates from 1.26-1.79 to 1.26-1.39: Nielsen 2018 gave 1.39 (1.04-1.86; P = 0.028), Yuan 2025 '
        'gave 1.26 (0.90-1.75; P = 0.178), and FinnGen R13 gave 1.39 (0.94-2.04; P = 0.096). Because the outcome '
        'sources are not mutually independent, no pooled estimate or pooled P value is reported. A placebo test '
        '(2,000 random deletions of the same size per source) produced an equally small range in 2.1% of replicates. '
        'Residual estimates remain compatible with other pleiotropy and do not establish an adiposity-independent '
        'causal effect. No sweetened-beverage estimate became significant under the same exclusion (all P >= 0.057).')

src = SP.read_text(encoding="utf-8")
start = src.find('children.push(caption("Table S27.')
assert start > 0
mid = src.find('children.push(makeTable(', start)
rows_start = src.find("  [\n", mid)
rows_end = src.find("  ], 18));", rows_start)
assert rows_start > 0 and rows_end > 0
src = src[:rows_start] + "  [\n" + new_rows + "\n" + src[rows_end:]

# replace the note
i = src.find('children.push(note("Instruments were removed if they lay within 500 kb')
assert i > 0
j = src.find('"));', i)
assert j > 0
src = src[:i] + 'children.push(note("' + NOTE + '"))' + src[j + 3:]

SP.write_text(src, encoding="utf-8", newline="\n")
print("S27 rows replaced:", len(records))
print("note replaced")
