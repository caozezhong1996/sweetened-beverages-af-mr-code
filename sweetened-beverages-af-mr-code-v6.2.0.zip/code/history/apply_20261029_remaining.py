# -*- coding: utf-8 -*-
from docx import Document
import pathlib,re,io,sys
sys.stdout=io.TextIOWrapper(sys.stdout.buffer,encoding="utf-8")
PKG=pathlib.Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")
def set_text(p,text):
    if not p.runs:p.add_run(text)
    else:
        for r in p.runs:r.text=""
        p.runs[0].text=text
def paras(doc):
    return list(doc.paragraphs)+[p for t in doc.tables for row in t.rows for c in row.cells for p in c.paragraphs]
def replace(doc,old,new):
    hits=[p for p in paras(doc) if old in p.text]
    assert len(hits)==1,(old,len(hits))
    set_text(hits[0],hits[0].text.replace(old,new))
def shift_ref(m):
    n=int(m.group(1));return f"manuscript ref {n+1 if n>=5 else n}"
def shift_citations(text):
    return re.sub(r"\[([0-9,\s–-]+)\]",lambda m:"["+re.sub(r"\d+",lambda x:str(int(x.group())+1 if int(x.group())>=5 else int(x.group())),m.group(1))+"]",text)
sup=Document(str(PKG/"Supplement.docx"))
for p in paras(sup):
    t=shift_citations(re.sub(r"manuscript ref (\d+)",shift_ref,p.text))
    if t!=p.text:set_text(p,t)
replace(sup,"which removed 3–19 variants per exposure (median 5)","which removed 2–19 variants per exposure (median 5)")
replace(sup,"independently replicated in FinnGen R13","also observed in FinnGen R13")
replace(sup,"Per-region summary statistics: 03_结果数据_mr_results/upgrade_coloc_*.csv (AFGen), 06_升级分析_v4/results/upgrade_coloc_coffee_loci_Nielsen.csv (Nielsen) and upgrade_coloc_FTO_FinnGenR13.csv (R13).","Per-region summary statistics are available in the colocalization results directory of the Zenodo archive (concept DOI 10.5281/zenodo.22099675).")
replace(sup,"Signal carried entirely by non-caffeine-pathway instruments","Positive estimate in the remaining instruments; between-subgroup difference P = 0.078")
replace(sup,"Replicated in FinnGen R13; weighted median OR 2.16","Positive estimate in FinnGen R13; between-subgroup difference P = 0.208; weighted median OR 2.16")
replace(sup,"The Yuan non-caffeine row includes the two caffeine-window SNPs not recovered in that outcome.","The Yuan non-caffeine row includes the two caffeine-window SNPs not recovered in that outcome. Between-subgroup log-OR difference tests were P = 0.078 (Nielsen 2018) and P = 0.208 (FinnGen R13), so no significant caffeine-versus-remaining subgroup difference was detected. These subgroup analyses share instruments with the adiposity-locus exclusion and are not independent evidence lines.")
sup.save(str(PKG/"Supplement.docx"))
hl=Document(str(PKG/"Highlights.docx"))
replace(hl,"No genetic evidence that sweetened-beverage intake causes atrial fibrillation.","No genetic evidence that sweetened-beverage intake causes AF, but the sugar-in-tea negative control failed.")
hl.save(str(PKG/"Highlights.docx"))
rp=PKG/"README_投稿包.md";t=rp.read_text(encoding="utf-8").replace("46 条参考文献","47 条参考文献");rp.write_text(t,encoding="utf-8")
print("Supplement, highlights and README completed")
