# -*- coding: utf-8 -*-
"""图件 v5.0：图形摘要（5 处）+ Figure 1（2 处），与手稿措辞同步。
双轮复核记录见各修改项注释；出图后目检验收。"""
import io, sys, shutil, subprocess, pathlib

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
S = pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\06_升级分析_v4\scripts")
FIGS = pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\06_升级分析_v4\figures")
OUT = pathlib.Path(r"C:\Users\64915\Desktop\EHJOpen投稿包_奶茶房颤MR_v5.0_20261006\03_图_Figures")
OUT.mkdir(parents=True, exist_ok=True)

def apply(src, dst, edits, py):
    t = open(src, encoding="utf-8").read()
    ok = True
    for name, old, new, exp, r1, r2 in edits:
        n = t.count(old)
        if n == exp:
            t = t.replace(old, new)
            print(f"  PASS {name}")
        else:
            print(f"  FAIL {name}: 命中 {n} != {exp}，不落盘")
            ok = False
    if ok:
        open(dst, "w", encoding="utf-8", newline="\n").write(t)
        return True
    return False

print("=== 图形摘要（M33；R1: 措辞与手稿 v5.0 同步；R2: 布局行宽逐一验算 → 双 PASS）===")
ga_edits = [
    ("GA-1 副标题口径", "with cross-ancestry replication", "with East Asian contextual analysis", 1,
     "R1: 与新标题 M01 一致。", "R2: 行长 33 字符，7.0pt 无溢出。"),
    ("GA-2 KEY FINDING 左框箭头句（R1-6 点名）",
     'txt(26, 68.6, "Sweetened beverages", size=7.9, weight="bold", color=GREEN)\ntxt(26, 65.9, "→ NO causal association with AF", size=7.9, weight="bold", color=GREEN)\ntxt(26, 60.8, "Meta-analytic OR 0.82–0.97\\nall P ≥ 0.06; null across cohorts,\\nestimators and ancestries",\n    size=7.4)',
     'txt(26, 68.9, "Sweetened beverages", size=7.9, weight="bold", color=GREEN)\ntxt(26, 65.7, "→ No genetic evidence of a\\ncausal association with AF", size=7.7, weight="bold", color=GREEN)\ntxt(26, 59.3, "Meta-analytic OR 0.82–0.97, all P ≥ 0.06;\\nnull across cohorts, estimators, ancestries",\n    size=7.3)',
     1,
     "R1: R1-6 要求 NO causal association → no genetic evidence of a causal association。", "R2: 两行块 64.4~67.4 与标题底 67.9 不重叠；统计两行 58~60.6 在框内；行长 40 字符 < 44 单位框宽。"),
    ("GA-3 CONCLUSION 块（R1-1/R1-5 同步）",
     'txt(50, 27.75, "Sweetened-beverage intake is not causally associated with atrial fibrillation.\\n'
     '               "Observational associations are best explained by adiposity-related confounding;\\n'
     '               "prevention should target established cardiometabolic risk factors.",\n    size=7.8, color="white")',
     'txt(50, 27.9, "Genetically proxied sweetened-beverage intake showed no evidence of a\\n'
     '               "causal association with atrial fibrillation. Observational associations are\\n'
     '               "best explained by adiposity-related confounding; prevention should target\\n'
     '               "established cardiometabolic risk factors.",\n    size=7.4, color="white")',
     1,
     "R1: 与摘要 M05 同口径（genetically proxied + no evidence of）。", "R2: 4 行×7.4pt 行块 25.3~30.5，与 CONCLUSION 标题底 32.2 不重叠，框 22.5~35.5 容纳；最长行 70 字符×0.13cm≈9.1cm < 11.5cm。"),
    ("GA-4 OUTCOME 框 BBJ+FinnGen 同步",
     '"Nielsen 2018 (60,620 cases; primary)  ·  FinnGen R13 (67,783)\\n"\n               "AFGen 2018 (55,114; sensitivity)  ·  BioBank Japan (8,180; East Asian replication)"',
     '"Nielsen 2018 (60,620 cases; primary)  ·  FinnGen R13 (67,783; co-primary)\\n"\n               "AFGen 2018 (55,114; sensitivity)  ·  BioBank Japan (8,180; East Asian contextual)"',
     1, "R1: 与 M11/M31 口径一致。", "R2: 最长行 80 字符×0.13≈10.4cm < 11.5cm，字号 7.8 保持。"),
]
ga_src = S / "graphical_abstract_v45.py"
ga_dst = S / "graphical_abstract_v50.py"
t = open(ga_src, encoding="utf-8").read()
ga_ok = True
for name, old, new, exp, r1, r2 in ga_edits:
    n = t.count(old)
    if n == exp:
        t = t.replace(old, new); print(f"  PASS {name}")
    else:
        print(f"  FAIL {name}: 命中 {n} != {exp}"); ga_ok = False
if ga_ok:
    # 输出路径改到 figures 目录新文件名
    t = t.replace(r"Graphical_Abstract_v45_300dpi.png", "Graphical_Abstract_v50_300dpi.png")
    open(ga_dst, "w", encoding="utf-8", newline="\n").write(t)
    print("  写出 graphical_abstract_v50.py")

print("=== Figure 1（M39/M40）===")
f1_edits = [
    ("F1-1 Band3 分析框口径", 'box(52.6, y3, 23, h3, "Cross-ancestry replication",',
     'box(52.6, y3, 23, h3, "East Asian contextual analysis",', 1,
     "R1: 与 M01 一致。", "R2: 30 字符 vs 框 23 单位≈2.9cm，title_fs 10→9 适配（下一项处理）。"),
    ("F1-1b 标题字号适配", '    C_ANA, title_fs=10, body_fs=8.8)\nbox(77.9, y3, 20.1, h3, "Multivariable MR",',
     '    C_ANA, title_fs=9, body_fs=8.8)\nbox(77.9, y3, 20.1, h3, "Multivariable MR",',
     1, "R1: 长标题降字号防溢出。", "R2: 仅影响该框。"),
    ("F1-2 FinnGen 标注 co-primary", '"FinnGen R13 (EUR, supporting):\\n67,783 / 241,269\\n"',
     '"FinnGen R13 (EUR, co-primary):\\n67,783 / 241,269\\n"', 1,
     "R1: 与 M11a/M31b 一致。", "R2: 行长 +2 字符，框 30 单位足够。"),
]
f1_src = S / "figure1_design_v4.py"
f1_dst = S / "figure1_design_v50.py"
t = open(f1_src, encoding="utf-8").read()
f1_ok = True
for name, old, new, exp, r1, r2 in f1_edits:
    n = t.count(old)
    if n == exp:
        t = t.replace(old, new); print(f"  PASS {name}")
    else:
        print(f"  FAIL {name}: 命中 {n} != {exp}"); f1_ok = False
if f1_ok:
    t = t.replace("Figure1_Study_Design_v4_300dpi.png", "Figure1_Study_Design_v50_300dpi.png")
    open(f1_dst, "w", encoding="utf-8", newline="\n").write(t)
    print("  写出 figure1_design_v50.py")

print("=== 重出图 ===")
PY = r"C:\Users\64915\.workbuddy\binaries\python\envs\default\Scripts\python.exe"
if ga_ok:
    r = subprocess.run([PY, str(ga_dst)], capture_output=True, text=True)
    print(r.stdout.strip(), r.stderr.strip()[-200:] if r.returncode else "")
if f1_ok:
    r = subprocess.run([PY, str(f1_dst)], capture_output=True, text=True)
    print(r.stdout.strip(), r.stderr.strip()[-200:] if r.returncode else "")

# 拷贝到桌面投稿包
import shutil as sh
for f in ["Graphical_Abstract_v50_300dpi.png", "Figure1_Study_Design_v50_300dpi.png"]:
    p = FIGS / f
    if p.exists():
        sh.copy2(p, OUT / f); print("拷贝:", f)
