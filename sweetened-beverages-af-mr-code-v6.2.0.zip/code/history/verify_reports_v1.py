# -*- coding: utf-8 -*-
"""Independent verification of the numerical/factual allegations in the three reports."""
import csv
import io
import math
import os
import re
import sys

from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
D = r"C:\a3work"
PKG = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013"
M = r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"


def ivw(path):
    rows = list(csv.DictReader(open(path, encoding="utf-8")))
    for r in rows:
        if r["method"] == "Inverse variance weighted":
            return float(r["b"]), float(r["se"]), float(r["pval"]), int(r["nsnp"])
    return None


def fe(items):
    """fixed-effect meta of (b, se) pairs"""
    ws = [1 / s ** 2 for _, s in items]
    b = sum(w * x for (x, _), w in zip(items, ws)) / sum(ws)
    se = math.sqrt(1 / sum(ws))
    z = b / se
    p = math.erfc(abs(z) / math.sqrt(2))
    return b, se, p, math.exp(b), math.exp(b - 1.96 * se), math.exp(b + 1.96 * se)


def show(tag, b, se, p):
    print(f"  {tag:<34} OR {math.exp(b):.3f} ({math.exp(b-1.96*se):.3f}–{math.exp(b+1.96*se):.3f}), P = {p:.4g}")


print("=" * 72)
print("V1  S16 直接效应 CI（delta 法，零协方差）")
print("=" * 72)
b_tot, se_tot, p_tot, _ = ivw(os.path.join(M, "06_升级分析_v4", "results",
                                        "mr_Coffee_intake_ebi_a_GCST006414.csv"))
print(f"  total (coffee→AF, Nielsen): b = {b_tot:.4f}, se = {se_tot:.4f}")
b_ind, se_ind = 0.281165, 0.1063   # as printed in S16 / dual report
b_dir = b_tot - b_ind
se_dir = math.sqrt(se_tot ** 2 + se_ind ** 2)
print(f"  direct b = {b_dir:.4f}  → OR {math.exp(b_dir):.4f}")
print(f"  correct se = {se_dir:.4f}")
print(f"  correct 95% CI = ({math.exp(b_dir-1.96*se_dir):.3f}, {math.exp(b_dir+1.96*se_dir):.3f})")
se_printed = (math.log(1.176) - math.log(0.775)) / (2 * 1.96)
print(f"  稿件印的是 (0.775, 1.176) → 反推 SE = {se_printed:.4f}（≈ 间接效应 SE {se_ind}）")

print()
print("=" * 72)
print("V2  剔除后三源合并估计（M1 的核心指控）")
print("=" * 72)
sup = Document(os.path.join(PKG, "Supplement.docx"))
s27 = None
for t in sup.tables:
    if "SNPs (kept)" in " ".join(c.text for c in t.rows[0].cells):
        s27 = t
        break
rows = [[c.text.strip() for c in r.cells] for r in s27.rows[1:]]
post = {}
pre = {}
for src, expo, n, orall, pall, nkeep, orcl, pcl in rows:
    if expo == "Coffee intake":
        m1 = re.match(r"([\d.]+) \(([\d.]+)-([\d.]+)\)", orall)
        m2 = re.match(r"([\d.]+) \(([\d.]+)-([\d.]+)\)", orcl)
        pre[src] = (math.log(float(m1.group(1))),
                    (math.log(float(m1.group(3))) - math.log(float(m1.group(2)))) / (2 * 1.96))
        post[src] = (math.log(float(m2.group(1))),
                     (math.log(float(m2.group(3))) - math.log(float(m2.group(2)))) / (2 * 1.96))
print("  剔除前:"); show("3-source FE", *fe(list(pre.values()))[:3])
print("  剔除后:"); show("3-source FE", *fe(list(post.values()))[:3])
for s, v in post.items():
    print(f"    {s:<16} OR {math.exp(v[0]):.2f}, se {v[1]:.4f}")

print()
print("=" * 72)
print("V3  Yuan 剔除后甜饮料的方向移动（M3 指控）")
print("=" * 72)
for src, expo, n, orall, pall, nkeep, orcl, pcl in rows:
    if src == "Yuan 2025":
        print(f"  {expo:<34} {orall:<20} → {orcl:<22} P {pall} → {pcl}")

print()
print("=" * 72)
print("V4  Discussion 'eight' vs S27 剔除数；S16 是否含剔除后中介行")
print("=" * 72)
for src, expo, n, orall, pall, nkeep, orcl, pcl in rows:
    if expo == "Coffee intake":
        print(f"  {src:<16} 工具 {n} → {nkeep}（剔除 {int(n)-int(nkeep)}）")
man = Document(os.path.join(PKG, "Manuscript.docx"))
mp = [p.text.strip() for p in man.paragraphs if p.text.strip()]
med = next(p for p in mp if p.startswith("Two-step mediation MR"))
print("  Discussion 原句:", med[med.find("however, when the"):med.find("however, when the") + 250])
s16 = None
for i, t in enumerate(sup.tables):
    head = " ".join(c.text for c in t.rows[0].cells)
    if "Indirect" in head or "Mediated" in head or "Step" in head:
        print(f"  候选 S16 表{i}: {head[:90]}")

print()
print("=" * 72)
print("V5  Table 4 BMI 467 vs S24 471")
print("=" * 72)
t4 = man.tables[3]
for r in t4.rows:
    c = [x.text.strip() for x in r.cells]
    if "BMI" in c[0] or "Body" in c[0]:
        print("  Table 4:", c)
print("  S24 标题:", next(p for p in sup.paragraphs if p.text.strip().startswith("Table S24."))[:120])

print()
print("=" * 72)
print("V6  S1/S3/S4/S9 是否被正文引用")
print("=" * 72)
full = "\n".join(mp)
for s in ("S1", "S3", "S4", "S9"):
    n = len(re.findall(rf"Table {s}\b", full))
    print(f"  Table {s}: {n} 次")

print()
print("=" * 72)
print("V7  唯一工具变异数 133 vs 137")
print("=" * 72)
all_snp = set()
for tag in ["Sugar_added_to_tea", "Sugar_added_to_coffee", "Fizzy_drink_intake_SSB",
            "Low_calorie_drink_intake_ASB", "Artificial_sweetener_added_to_tea",
            "Coffee_intake", "Tea_intake"]:
    p = os.path.join(M, "06_升级分析_v4", "results", f"dat_{tag}_ebi_a_GCST006414.csv")
    if not os.path.exists(p):
        continue
    snps = {r["SNP"] for r in csv.DictReader(open(p, encoding="utf-8"))
            if str(r.get("mr_keep", "TRUE")).upper() != "FALSE"}
    print(f"  {tag:<36} {len(snps)}")
    all_snp |= snps
print(f"  合计唯一变异: {len(all_snp)}")

print()
print("=" * 72)
print("V8  MR-RAPS 与 IVW 的符号一致性")
print("=" * 72)
raps = list(csv.DictReader(open(os.path.join(M, "06_升级分析_v4", "supplement_tables",
                                            "S23_raps.tsv"), encoding="utf-8"))) if os.path.exists(
    os.path.join(M, "06_升级分析_v4", "supplement_tables", "S23_raps.tsv")) else []
if not raps:
    import glob
    cand = glob.glob(os.path.join(M, "**", "*raps*"), recursive=True)
    print("  候选文件:", cand[:4])
else:
    for r in raps[:4]:
        print(" ", r)

print()
print("=" * 72)
print("V9  BBJ 代理表述")
print("=" * 72)
for p in mp:
    if "four proxies" in p:
        print("  ", p[:260])
print("  S27 中 BBJ 行（无，因为 S27 只含三源）")
s1 = next((t for t in sup.tables if "BioBank" in " ".join(c.text for r in t.rows for c in r.cells)), None)
