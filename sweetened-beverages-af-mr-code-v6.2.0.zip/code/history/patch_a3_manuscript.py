# -*- coding: utf-8 -*-
"""A3 integration into build_manuscript_v51_JAHA.js (option A: Yuan reported
alongside, not pooled into the pre-specified meta-analysis)."""
import io
import re
import sys
import pathlib

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

P = pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
                 r"\04_docx构建脚本\build_manuscript_v51_JAHA.js")
src = P.read_text(encoding="utf-8")

E = []

# ---------------- R1: abstract Methods and Results ----------------
E.append((
    "T`Methods and Results: Seven beverage phenotypes were instrumented in UK Biobank (N = 64,949–447,485); AF statistics came from Nielsen 2018 (60,620; primary), non-overlapping FinnGen R13 (67,783; co-primary), AFGen 2018 and BioBank Japan (East Asian context). Inverse-variance-weighted estimates were complemented by robust estimators, multivariable MR, colocalization and LD-score regression. No sweetened-beverage exposure showed evidence of a causal association with AF (European meta-analytic odds ratios 0.82–0.97; P ≥ 0.06). A nominal coffee association (OR 1.34, 1.11–1.62; P = 0.002) was not robust: weighted-median and outlier-robust estimates were inconsistent, it attenuated with body-mass-index adjustment (OR 0.82; P = 0.099), and colocalization was confined to the FTO locus. Sweetened-beverage traits nonetheless showed positive genetic correlations with AF against FinnGen R13 (rg = 0.24–0.31; FDR q < 0.05). Caffeine and paraxanthine instruments were null (P ≥ 0.31); theobromine showed a nominal inverse association (P = 0.029) that did not survive Bonferroni correction. The genetic estimate is compatible with no harm but is not concordant in direction with the protective effect reported in DECAF.`",
    "T`Methods and Results: Seven beverage phenotypes were instrumented in UK Biobank (N = 64,949–447,485). AF statistics came from Nielsen 2018 (60,620; primary) and two overlap-free co-primary sources, FinnGen R13 (67,783) and the UK Biobank-free European arm of Yuan 2025 (192,851), plus BioBank Japan (8,180; East Asian context). Estimates were complemented by robust estimators, multivariable MR, colocalization and LD-score regression. No sweetened-beverage exposure showed evidence of a causal association with AF (European meta-analytic odds ratios 0.82–0.97, all P ≥ 0.06; UK Biobank-free panel 0.76–1.04, all P ≥ 0.083). A coffee association recurred in every source (meta-analytic OR 1.34, 1.11–1.62; UK Biobank-free OR 1.79, 1.23–2.60) but was carried by adiposity-locus instruments: excluding variants within 500 kb of body-mass-index loci reduced it to 1.26 (0.90–1.75) in the UK Biobank-free panel and 1.39 (0.94–2.04) in FinnGen R13, all three source-specific estimates converging on 1.26–1.39. Sweetened-beverage traits nonetheless showed positive genetic correlations with AF (rg = 0.24–0.31; FDR q < 0.05). Caffeine and paraxanthine instruments were null (P ≥ 0.31); theobromine showed a nominal inverse association (P = 0.029) that did not survive Bonferroni correction.`",
))

# ---------------- R2: abstract Conclusions ----------------
E.append((
    "T`Conclusions: Genetically proxied sweetened-beverage intake showed no evidence of a causal association with AF; moderate-to-large effects are excluded, small ones are not. Observational associations likely reflect adiposity-related confounding; direct milk-tea studies in East Asian cohorts remain needed.`",
    "T`Conclusions: Genetically proxied sweetened-beverage intake showed no evidence of a causal association with AF; moderate-to-large effects are excluded, small ones are not. The one recurring coffee signal was carried by adiposity-locus instruments, so observational associations most plausibly reflect adiposity-related confounding; direct milk-tea studies in East Asian cohorts remain needed.`",
))

# ---------------- R3: Methods, outcome data ----------------
E.append((
    "Outcome data. Primary analyses used the largest available European-ancestry AF GWAS, the biobank-driven meta-analysis of Nielsen et al. [13] (60,620 cases and 970,216 controls; ebi-a-GCST006414). Two further European sources were analyzed: the AFGen consortium 2018 release (55,114 cases and 482,295 controls; Roselli et al. [14]), which shares participating cohorts with Nielsen 2018 and was treated as a sensitivity source, and FinnGen release R13 [15] (phenotype I9_AF; 67,783 cases and 241,269 controls), which shares no participants with UK Biobank and therefore served as a co-primary, overlap-free outcome. A larger cross-population meta-analysis was recently published [16]. Its European-ancestry summary statistics are now publicly available (GCST90624413; 192,851 cases and 1,239,541 controls; CC0 licence). Nielsen 2018 was retained as the primary outcome for comparability with previous Mendelian randomization studies, and FinnGen R13 provided an independent, overlap-free co-primary outcome.",
    "Outcome data. Four European-ancestry AF sources were analyzed. The primary outcome was the biobank-driven meta-analysis of Nielsen et al. [13] (60,620 cases and 970,216 controls; ebi-a-GCST006414), retained for comparability with previous Mendelian randomization studies. Two overlap-free co-primary outcomes were then analyzed: FinnGen release R13 [15] (phenotype I9_AF; 67,783 cases and 241,269 controls) and the European-ancestry arm of the cross-population meta-analysis of Yuan et al. [16] (GCST90624413; 192,851 cases and 1,239,541 controls; CC0 licence). The released Yuan 2025 statistics comprise the eight discovery cohorts only; UK Biobank contributed 36,075 further cases to a larger release that is not public, so the analysed file shares no participants with the UK Biobank exposure data. The AFGen consortium 2018 release (55,114 cases and 482,295 controls; Roselli et al. [14]) shares participating cohorts with Nielsen 2018 and was treated as a sensitivity source. The pre-specified European meta-analysis combined Nielsen 2018 and FinnGen R13 only; because Yuan 2025 was released after that analysis was defined, it is reported alongside the meta-analysis rather than pooled into it.",
))

# ---------------- R4: Methods, new adiposity-locus subsection ----------------
E.append((
    "  ]),\n  h2(T`Genetic correlation and overlap diagnostics`),",
    "  ]),\n"
    "  mix([\n"
    "    T`Adiposity-locus sensitivity. Because genetic instruments for beverage intake index intake behaviour together with its adiposity correlates, every exposure–outcome pair was re-estimated after removing all instruments lying within 500 kb of one of 724 genome-wide-significant BMI loci (GIANT consortium, ieu-b-40), using the same random-effects inverse-variance-weighted estimator (Table S27). This analysis was introduced during revision, after the mediation, multivariable and colocalization results indicated that the coffee estimate was carried by adiposity variants, and is therefore reported as a post hoc robustness analysis rather than a pre-specified one.`,\n"
    "  ]),\n"
    "  h2(T`Genetic correlation and overlap diagnostics`),",
))

# ---------------- R5: Results, instrument availability ----------------
E.append((
    "Between 8 and 34 independent SNPs per exposure were analyzed against the primary outcome (median 17; Table 2), with the same index variants harmonised to every outcome panel (BioBank Japan required four proxies; Table 2).",
    "Between 8 and 34 independent SNPs per exposure were analyzed against the primary outcome (median 17; Table 2), with the same index variants harmonised to every outcome panel (BioBank Japan required four proxies; Table 2). Of the 133 unique instrument variants, 128 (96%) were present in the UK Biobank-free Yuan 2025 panel, leaving 8–30 SNPs per exposure against that outcome (Table 2).",
))

# ---------------- R6: Results, sweetened beverages + Yuan ----------------
E.append((
    "IVW odds ratios (ORs) per unit higher instrumented intake in Nielsen 2018 were 0.91 (95% CI 0.72–1.17) for sugar added to tea, 0.91 (0.67–1.22) for fizzy drink intake (SSBs), 0.99 (0.86–1.13) for low-calorie drink intake (ASBs) and 0.91 (0.72–1.14) for artificial sweetener added to tea (all P ≥ 0.40).",
    "IVW odds ratios (ORs) per unit higher instrumented intake in Nielsen 2018 were 0.91 (95% CI 0.72–1.17) for sugar added to tea, 0.91 (0.67–1.22) for fizzy drink intake (SSBs), 0.99 (0.86–1.13) for low-calorie drink intake (ASBs) and 0.91 (0.72–1.14) for artificial sweetener added to tea (all P ≥ 0.40). The UK Biobank-free Yuan 2025 co-primary outcome gave the same answer at more than three times the case count: 0.76 (0.56–1.04) for sugar added to tea, 0.98 (0.85–1.12) for sugar added to coffee, 1.00 (0.77–1.30) for SSBs, 1.04 (0.96–1.14) for ASBs and 1.03 (0.74–1.43) for artificial sweetener added to tea (all P ≥ 0.083), with null weighted-median, MR-Egger and MR-RAPS estimates throughout (Table S26).",
))

E.append((
    "This signal was not supported by the weighted median (P = 0.061), absent from the other three sources (all P > 0.21), significantly heterogeneous (Q P = 8 × 10⁻⁶) with a null MR-Egger intercept, and attenuated in the meta-analysis (P = 0.060); we attribute this signal to chance.",
    "This signal was not supported by the weighted median (P = 0.061), absent from the other four sources (all P > 0.08, including OR 0.76, 0.56–1.04 in Yuan 2025 where the same inverse direction was not conventionally significant), significantly heterogeneous (Q P = 8 × 10⁻⁶) with a null MR-Egger intercept, and attenuated in the meta-analysis (P = 0.060); we attribute this signal to chance.",
))

# ---------------- R7: Results, coffee paragraph ----------------
E.append((
    "Coffee intake was nominally associated with higher AF odds in the primary outcome (Nielsen 2018 IVW OR 1.26, 1.02–1.57; P = 0.036), concordant in AFGen 2018 (OR 1.26; P = 0.031), significant in FinnGen R13 (OR 1.58, 1.09–2.29; P = 0.016), with a European meta-analytic OR of 1.34 (1.11–1.62; P = 0.002) that survived Benjamini–Hochberg correction (threshold P = 0.007).",
    "Coffee intake was nominally associated with higher AF odds in the primary outcome (Nielsen 2018 IVW OR 1.26, 1.02–1.57; P = 0.036), concordant in AFGen 2018 (OR 1.26; P = 0.031) and in both overlap-free co-primary outcomes—FinnGen R13 (OR 1.58, 1.09–2.29; P = 0.016) and Yuan 2025 (OR 1.79, 1.23–2.60; P = 0.0022)—with a European meta-analytic OR of 1.34 (1.11–1.62; P = 0.002) that survived Benjamini–Hochberg correction (threshold P = 0.007). The point estimate therefore rose with outcome sample size (1.26 → 1.58 → 1.79) instead of shrinking toward the null, which is the behaviour expected of a bias that accumulates with power rather than of a causal effect.",
))

E.append((
    "with outlier correction resolving the estimate to the null in Nielsen 2018 (P = 0.20) but not FinnGen R13 (β = 0.345; P = 0.007).",
    "with outlier correction resolving the estimate to the null in Nielsen 2018 (P = 0.20) but not FinnGen R13 (β = 0.345; P = 0.007). In Yuan 2025 the pattern was more extreme still: Cochran's Q P = 1.5 × 10⁻³⁰, with null weighted-median (P = 0.11), MR-Egger (P = 0.061) and MR-RAPS (P = 0.18) estimates.",
))

# ---------------- R8: new Results paragraph on adiposity-locus sensitivity ----
E.append((
    "  h2(T`Multivariable MR: attenuation of the coffee signal by adiposity`),",
    "  h2(T`Adiposity-locus instruments carry the coffee signal`),\n"
    "  mix([\n"
    "    T`To separate the coffee signal from the adiposity it tracks, each exposure was re-estimated after removing every instrument lying within 500 kb of one of 724 genome-wide-significant BMI loci (Table S27). This removed 15 of the 30 coffee instruments, including rs1421085 at FTO and rs13387939 at TMEM18—the two variants with by far the largest individual Wald ratios against AF in Yuan 2025 (OR 9.95 and 10.67, against a median of 1.2 for the remaining variants). The coffee estimate fell from 1.79 (1.23–2.60) to 1.26 (0.90–1.75; P = 0.18) in Yuan 2025 and from 1.58 (1.09–2.29) to 1.39 (0.94–2.04; P = 0.096) in FinnGen R13, while in Nielsen 2018 it moved from 1.26 (1.02–1.57) to 1.39 (1.04–1.86; P = 0.028). Removing these variants also collapsed the between-source spread: the three source-specific estimates converged on 1.26–1.39, against 1.26–1.79 before removal, indicating that the between-source variability was itself largely adiposity-driven. No sweetened-beverage estimate became significant under the same exclusion (all P ≥ 0.057).`,\n"
    "  ]),\n"
    "  h2(T`Multivariable MR: attenuation of the coffee signal by adiposity`),",
))

# ---------------- R9: Discussion, principal findings ----------------
E.append((
    "This null finding held across five conceptually distinct exposures (including sugar added to tea or coffee, the closest genetic proxy for milk-tea-type beverages), three European outcome sources and all complementary estimators. Three nominal IVW signals emerged, but none survived scrutiny: the inverse association for sugar added to coffee failed to replicate in the larger primary outcome; a nominal inverse association for sugar added to tea in FinnGen R13 was absent from the other three sources and attenuated in the meta-analysis; and the positive association for coffee intake also failed scrutiny despite nominal significance after Benjamini–Hochberg correction (meta-analytic OR 1.34; P = 0.002).",
    "This null finding held across five conceptually distinct exposures (including sugar added to tea or coffee, the closest genetic proxy for milk-tea-type beverages), four European-ancestry outcome sources—including a UK Biobank-free panel of 192,851 cases—and all complementary estimators. Three nominal IVW signals emerged, but none survived scrutiny: the inverse association for sugar added to coffee failed to replicate in the larger primary outcome; a nominal inverse association for sugar added to tea in FinnGen R13 was absent from the other four sources and attenuated in the meta-analysis; and the positive association for coffee intake, which recurred in every source and grew with sample size (meta-analytic OR 1.34, P = 0.002; UK Biobank-free OR 1.79), was traced to adiposity-locus instruments—removing them abolished the association in both overlap-free sources and made the three source-specific estimates converge on 1.26–1.39.",
))

# ---------------- R10: Discussion, coffee literature ----------------
E.append((
    "Colocalization reinforced this reading: the coffee signal had no AF counterpart at the CYP1A1–CYP1A2 and AHR loci (PP.H4 ≤ 0.008) but shared a causal variant with AF at FTO (PP.H4 = 0.894; replicated at 0.906); tea showed the same dissociation (Table S21), and caffeine-metabolism-locus instruments were null while the remainder carried the signal.",
    "Colocalization reinforced this reading: the coffee signal had no AF counterpart at the CYP1A1–CYP1A2 and AHR loci (PP.H4 ≤ 0.008) but shared a causal variant with AF at FTO (PP.H4 = 0.894; replicated at 0.906); tea showed the same dissociation (Table S21), and caffeine-metabolism-locus instruments were null while the remainder carried the signal. The instrument-level analysis points the same way: FTO rs1421085 and TMEM18 rs13387939 produced the two largest Wald ratios against AF, and removing adiposity-locus variants returned the estimate to the null in both overlap-free sources. The adiposity-excluded estimate in Nielsen 2018 remained nominally significant (OR 1.39, 1.04–1.86; P = 0.028), however, so an adiposity-independent effect of small magnitude cannot be excluded from that source alone.",
))

# ---------------- R11: Discussion, BMI positive control ----------------
E.append((
    "Strong colocalization of the coffee signal with AF at FTO, and its absence at caffeine-metabolism loci, provides locus-level corroboration, and the positive genetic correlations of SSB and ASB intake with AF (rg = 0.24–0.31, q < 0.05) alongside null MR estimates exemplify the distinction: sweetened-drink intake shares heritable architecture with AF without a detectable causal beverage effect.",
    "Strong colocalization of the coffee signal with AF at FTO, and its absence at caffeine-metabolism loci, provides locus-level corroboration; so does the convergence of the three source-specific coffee estimates on 1.26–1.39 once adiposity-locus instruments are removed, which converts a source-dependent 1.26–1.79 spread into a single stable estimate. The positive genetic correlations of SSB and ASB intake with AF (rg = 0.24–0.31, q < 0.05) alongside null MR estimates exemplify the same distinction: sweetened-drink intake shares heritable architecture with AF without a detectable causal beverage effect.",
))

# ---------------- R12: Figure 2 legend ----------------
E.append((
    "T`Figure 2. Forest plot of IVW estimates for each beverage exposure against atrial fibrillation, by outcome source, with European fixed-effect meta-analysis (Nielsen 2018 + FinnGen R13).`",
    "T`Figure 2. Forest plot of IVW estimates for each beverage exposure against atrial fibrillation, by outcome source, with European fixed-effect meta-analysis (Nielsen 2018 + FinnGen R13). The UK Biobank-free Yuan 2025 co-primary outcome is shown alongside the meta-analysis rather than within it.`",
))

# ---------------- R13: Table 1 rows ----------------
E.append((
    "      [T`Outcome: AF (co-primary, overlap-free)`, T`FinnGen release R13, AF and flutter (I9_AF)`, T`67,783 cases / 241,269 controls`, T`European`, T`FinnGen public release`],",
    "      [T`Outcome: AF (co-primary, overlap-free)`, T`FinnGen release R13, AF and flutter (I9_AF)`, T`67,783 cases / 241,269 controls`, T`European`, T`FinnGen public release`],\n"
    "      [T`Outcome: AF (co-primary, UKB-free)`, T`Yuan et al. 2025, European arm (GCST90624413)`, T`192,851 cases / 1,239,541 controls`, T`European`, T`GWAS Catalog (CC0)`],",
))

# ---------------- R14: Table 1 footnote ----------------
E.append((
    "Nielsen 2018 and AFGen 2018 share participating cohorts and were not meta-analyzed together.",
    "Nielsen 2018 and AFGen 2018 share participating cohorts and were not meta-analyzed together. The Yuan 2025 release analysed here comprises its eight discovery cohorts and excludes UK Biobank; it is reported alongside, not within, the pre-specified Nielsen+FinnGen meta-analysis.",
))

# ---------------- R15: Data availability ----------------
E.append((
    "Full per-variant summary statistics used for LD score regression were obtained from the Neale lab UK Biobank round-2 release (http://www.nealelab.is/uk-biobank), GWAS Catalog (GCST006414, GCST010636) and FinnGen (release R13).",
    "Full per-variant summary statistics used for LD score regression were obtained from the Neale lab UK Biobank round-2 release (http://www.nealelab.is/uk-biobank), GWAS Catalog (GCST006414, GCST010636, GCST90624413; the last released under CC0) and FinnGen (release R13).",
))

# ---------------- R16: table widths (all four tables now fit the text column) --
E.append(("    [2350, 2850, 1900, 1100, 1500],", "    [2300, 2900, 1650, 1050, 1100],"))
E.append(("    [1650, 1720, 1720, 1720, 1720, 1750, 1200],", "    [1500, 1070, 1070, 1070, 1070, 1070, 1070, 1080],"))
E.append(("    [2150, 1950, 1950, 1350, 1150, 1350],", "    [1950, 1770, 1770, 1230, 1050, 1230],"))
E.append(("    [2700, 2400, 1900, 1200, 1500],", "    [2500, 2230, 1760, 1110, 1400],"))

# ---------------- apply ----------------
ok = True
for i, (old, new) in enumerate(E, 1):
    c = src.count(old)
    tag = "PASS" if c == 1 else f"FAIL x{c}"
    print(f"{tag:8} R{i:<3} {old[:64]!r}")
    if c != 1:
        ok = False
        continue
    src = src.replace(old, new)

if not ok:
    print("\nABORTED - nothing written")
    sys.exit(1)

P.write_text(src, encoding="utf-8", newline="\n")
print(f"\nwritten {P}  ({len(src)} chars)")
