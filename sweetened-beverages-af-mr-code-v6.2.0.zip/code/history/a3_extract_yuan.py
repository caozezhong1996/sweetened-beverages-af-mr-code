# -*- coding: utf-8 -*-
"""Step A: stream the Yuan 2025 sumstats once and pull out the instrument SNPs only."""
import csv
import gzip
import io
import sys
import time

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

RES = r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\06_升级分析_v4\results"
SRC = (r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
       r"\06_升级分析_v4\downloads\yuan2025\GCST90624413.tsv.gz")
OUT = RES + r"\yuan2025_instruments.tsv"

EXPO = ["Artificial_sweetener_added_to_tea", "Coffee_intake", "Fizzy_drink_intake_SSB",
        "Low_calorie_drink_intake_ASB", "Sugar_added_to_coffee", "Sugar_added_to_tea", "Tea_intake"]

instr = {}
for e in EXPO:
    rows = list(csv.DictReader(open(f"{RES}\\dat_{e}_ebi_a_GCST006414.csv", encoding="utf-8")))
    for r in rows:
        if str(r.get("mr_keep", "TRUE")).upper() == "FALSE":
            continue
        instr[r["SNP"]] = e
print("instrument rsIDs:", len(instr))

want = set(instr)
hits = {}
t0 = time.time()
n = 0
with gzip.open(SRC, "rt", encoding="utf-8", errors="ignore") as f:
    hdr = f.readline().rstrip("\n").split("\t")
    idx = {c: i for i, c in enumerate(hdr)}
    for line in f:
        n += 1
        if n % 5_000_000 == 0:
            print(f"  scanned {n/1e6:.0f}M rows, {time.time()-t0:.0f}s, hits={len(hits)}")
        p = line.rstrip("\n").split("\t")
        snp = p[idx["rs_id"]]
        if snp in want and snp not in hits:
            hits[snp] = p
print(f"scanned {n} rows in {time.time()-t0:.0f}s; matched {len(hits)}/{len(want)}")

with open(OUT, "w", newline="", encoding="utf-8") as fh:
    w = csv.writer(fh, delimiter="\t")
    w.writerow(["SNP", "exposure", "chr", "pos", "ea.out", "oa.out", "beta.out", "se.out", "eaf.out", "pval.out", "n.out"])
    for snp, p in hits.items():
        w.writerow([snp, instr[snp], p[idx["chromosome"]], p[idx["base_pair_location"]],
                    p[idx["effect_allele"]].upper(), p[idx["other_allele"]].upper(),
                    p[idx["beta"]], p[idx["standard_error"]],
                    p[idx["effect_allele_frequency"]], p[idx["p_value"]], p[idx["n"]]])
print("written:", OUT)
missing = sorted(want - set(hits))
print("missing rsIDs:", missing[:12], "..." if len(missing) > 12 else "", f"({len(missing)})")
