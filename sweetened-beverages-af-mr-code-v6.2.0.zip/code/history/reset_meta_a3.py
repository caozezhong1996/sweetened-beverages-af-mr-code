# -*- coding: utf-8 -*-
"""Re-apply docx core properties after rebuilding from the JS builders."""
import io
import sys
from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

P = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013"
TITLE = ("Genetically Proxied Sweetened Beverage Intake and Atrial Fibrillation: A Two-Sample and "
         "Multivariable Mendelian Randomization Study")

META = {
    "Manuscript": (TITLE, "Original research",
                   "Mendelian randomization; atrial fibrillation; sugar-sweetened beverages; coffee; genetic correlation"),
    "Supplement": ("Supplemental material: " + TITLE, "Supplemental material",
                   "supplementary tables; sensitivity analyses"),
    "Cover_Letter": ("Cover letter: " + TITLE, "Cover letter", "submission"),
    "Highlights": ("Highlights: " + TITLE, "Highlights", "key findings"),
}

for name, (title, subj, kw) in META.items():
    path = f"{P}\\{name}.docx"
    d = Document(path)
    cp = d.core_properties
    cp.author = "Cao Zezhong"
    cp.last_modified_by = "Cao Zezhong"
    cp.title = title
    cp.subject = subj
    cp.keywords = kw
    cp.comments = ""
    d.save(path)
    print(f"{name:<14} author={cp.author!r}  title={cp.title[:46]!r}")
