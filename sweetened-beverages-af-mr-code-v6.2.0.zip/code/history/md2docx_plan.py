# -*- coding: utf-8 -*-
"""Minimal markdown -> docx converter for the revision plan (headings, tables, bullets)."""
import io
import re
import sys
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt, Cm, RGBColor

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

SRC = Path(r"C:\Users\64915\WorkBuddy\2026-10-06-13-49-21\修正方案_20261026.md")
DST = Path(r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版\JAHA_v525_改稿留档"
           r"\审读意见_20261026\修正方案_20261026.docx")

lines = SRC.read_text(encoding="utf-8").split("\n")

doc = Document()
st = doc.styles["Normal"]
st.font.name = "Times New Roman"
st.font.size = Pt(10.5)
st.paragraph_format.space_after = Pt(4)
st.paragraph_format.line_spacing = 1.25
for s in doc.sections:
    s.left_margin = s.right_margin = Cm(2.0)
    s.top_margin = s.bottom_margin = Cm(2.0)

INLINE = re.compile(r"\*\*(.+?)\*\*")


def add_runs(par, text):
    pos = 0
    for m in INLINE.finditer(text):
        if m.start() > pos:
            par.add_run(text[pos:m.start()])
        r = par.add_run(m.group(1))
        r.bold = True
        pos = m.end()
    if pos < len(text):
        par.add_run(text[pos:])


i = 0
while i < len(lines):
    ln = lines[i].rstrip()
    if not ln.strip():
        i += 1
        continue
    if ln.startswith("| "):
        block = []
        while i < len(lines) and lines[i].lstrip().startswith("|"):
            block.append(lines[i].strip())
            i += 1
        rows = [[c.strip() for c in r.strip("|").split("|")] for r in block]
        rows = [r for r in rows if not all(re.fullmatch(r":?-{2,}:?", c or "-") for c in r)]
        if not rows:
            continue
        ncol = max(len(r) for r in rows)
        tb = doc.add_table(rows=0, cols=ncol)
        tb.style = "Table Grid"
        for ri, r in enumerate(rows):
            cells = tb.add_row().cells
            for ci in range(ncol):
                txt = r[ci] if ci < len(r) else ""
                p = cells[ci].paragraphs[0]
                p.paragraph_format.space_after = Pt(0)
                add_runs(p, txt)
                for run in p.runs:
                    run.font.size = Pt(8.5)
                    if ri == 0:
                        run.bold = True
        doc.add_paragraph()
        continue
    if ln.startswith("# "):
        h = doc.add_heading("", level=0)
        add_runs(h, ln[2:])
        i += 1
        continue
    m = re.match(r"^(#{2,4})\s+(.*)$", ln)
    if m:
        h = doc.add_heading("", level=min(len(m.group(1)) - 1, 4))
        add_runs(h, m.group(2))
        i += 1
        continue
    if ln.startswith(">"):
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Cm(0.6)
        r = p.add_run(ln.lstrip("> ").strip())
        r.italic = True
        r.font.size = Pt(9)
        i += 1
        continue
    if re.match(r"^\s*[-*]\s+", ln):
        p = doc.add_paragraph(style="List Bullet")
        add_runs(p, re.sub(r"^\s*[-*]\s+", "", ln))
        i += 1
        continue
    if re.match(r"^\s*\d+\.\s+", ln):
        p = doc.add_paragraph(style="List Number")
        add_runs(p, re.sub(r"^\s*\d+\.\s+", "", ln))
        i += 1
        continue
    if ln.strip() == "---":
        i += 1
        continue
    p = doc.add_paragraph()
    add_runs(p, ln)
    i += 1

cp = doc.core_properties
cp.author = "Cao Zezhong"
cp.title = "修正方案（针对 2026-10-26 审读意见）"
cp.subject = "Sweetened Beverage Consumption and Risk of Atrial Fibrillation — pre-submission revision plan"

DST.parent.mkdir(parents=True, exist_ok=True)
doc.save(DST)
print("written:", DST, f"{DST.stat().st_size/1024:.0f} KB")
