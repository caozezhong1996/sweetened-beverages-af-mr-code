# -*- coding: utf-8 -*-
from pathlib import Path

P = Path(r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版\JAHA_v525_改稿留档\审读意见_20261026\修正记录_20261026.md")

ADD = """

---

## 第二轮（2026-10-27 00:00–00:40）

### A5 已完成：剔除体脂位点后重跑中介

从 17 个咖啡→BMI 工具中，剔除落在 724 个 BMI 全基因组显著位点 ±500 kb 窗口内的 9 个（FTO 区命中 rs1421085）。随机效应 IVW（与 Table S16 口径一致）：

| 工具集 | n | coffee→BMI β | 间接效应（95% CI） | 中介比例 | 直接效应 OR |
|---|---:|---:|---|---:|---:|
| 全部 | 17 | +0.820 | 0.281（0.073–0.490） | 120% | 0.955 |
| 剔 FTO | 16 | +0.572 | 0.196（0.050–0.343） | 84% | 1.039 |
| 剔全部 BMI 位点 | 8 | +0.449 | 0.154（0.018–0.289） | 66% | 1.084 |

中介比例随体脂位点剔除单调下降（120%→84%→66%），直接效应由 0.955 翻转为 1.084——中介成分无法与体质倾向分离。已写入 Results 中介段与 Discussion 机制段。

### C4 已完成
摘要补 theobromine（P = 0.029，Bonferroni 不过）并压缩其他句子，摘要 248/250。

### A8 / S25 已完成（改为更稳的做法）
不新增表格列，改把 S25 注脚的「per-variant F 30-49」精确到分代谢物：29.8–35.3（caffeine）、30.1–48.7（paraxanthine）、32.2–46.2（theobromine）；正文指针恢复为「per-variant F 29.8–48.7; Table S25」。

### A3 未完成：数据下载受 EBI 限速
- 已确认 GCST90624413 为**不含 UK Biobank** 的欧洲裔合并（192,851 例 / 1,239,541 对照，CC0），"样本重叠"这条退路不成立。
- 文件 781 MB，EBI 单连接限速约 4 MB/min（并行无加速），已下 229 MB，支持 Range 续传。
- 脚本已就绪：`a3_extract_yuan.py`（按 rsID 流式抽取 137 个工具位点）、`a3_mr_yuan.R`（harmonise + IVW/RE/WM/Egger/MR-RAPS）。
- 剩余：文件下完 → 跑两个脚本 → 得到 Yuan 结局下 7 个暴露的结果 → 更新为并为主结局的表述与表格。
"""

P.write_text(P.read_text(encoding="utf-8") + ADD, encoding="utf-8")
print("appended, chars:", P.stat().st_size)
