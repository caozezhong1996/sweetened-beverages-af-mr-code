# -*- coding: utf-8 -*-
"""图件修复第二轮：GA-3 精确匹配 + Figure1 去 daimon_runtime 依赖 + 重出图。"""
import io, sys, subprocess, pathlib, shutil

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
S = pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\06_升级分析_v4\scripts")
FIGS = pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\06_升级分析_v4\figures")
OUT = pathlib.Path(r"C:\Users\64915\Desktop\EHJOpen投稿包_奶茶房颤MR_v5.0_20261006\03_图_Figures")
PY = r"C:\Users\64915\.workbuddy\binaries\python\envs\default\Scripts\python.exe"

# ---- 1. GA：从 v45 源码重建 v50（GA-1/2/3/4 全部精确匹配，全部通过才落盘）----
ga_src = S / "graphical_abstract_v45.py"
ga = S / "graphical_abstract_v50.py"
t = open(ga_src, encoding="utf-8").read()

GA_EDITS = [
    ("GA-1 副标题口径", "with cross-ancestry replication", "with East Asian contextual analysis", 1),
    ("GA-2 KEY FINDING 左框",
     'txt(26, 68.6, "Sweetened beverages", size=7.9, weight="bold", color=GREEN)\n'
     'txt(26, 65.9, "→ NO causal association with AF", size=7.9, weight="bold", color=GREEN)\n'
     'txt(26, 60.8, "Meta-analytic OR 0.82–0.97\\nall P ≥ 0.06; null across cohorts,\\nestimators and ancestries",\n'
     '    size=7.4)',
     'txt(26, 68.9, "Sweetened beverages", size=7.9, weight="bold", color=GREEN)\n'
     'txt(26, 65.7, "→ No genetic evidence of a\\ncausal association with AF", size=7.7, weight="bold", color=GREEN)\n'
     'txt(26, 59.3, "Meta-analytic OR 0.82–0.97, all P ≥ 0.06;\\nnull across cohorts, estimators, ancestries",\n'
     '    size=7.3)', 1),
    ("GA-3 CONCLUSION 块",
     'txt(50, 27.75, "Sweetened-beverage intake is not causally associated with atrial fibrillation.\\n"\n'
     '               "Observational associations are best explained by adiposity-related confounding;\\n"\n'
     '               "prevention should target established cardiometabolic risk factors.",\n'
     '    size=7.8, color="white")',
     'txt(50, 27.9, "Genetically proxied sweetened-beverage intake showed no evidence of a\\n"\n'
     '               "causal association with atrial fibrillation. Observational associations are\\n"\n'
     '               "best explained by adiposity-related confounding; prevention should target\\n"\n'
     '               "established cardiometabolic risk factors.",\n'
     '    size=7.4, color="white")', 1),
    ("GA-4 OUTCOME 框",
     '"Nielsen 2018 (60,620 cases; primary)  ·  FinnGen R13 (67,783)\\n"\n'
     '               "AFGen 2018 (55,114; sensitivity)  ·  BioBank Japan (8,180; East Asian replication)"',
     '"Nielsen 2018 (60,620 cases; primary)  ·  FinnGen R13 (67,783; co-primary)\\n"\n'
     '               "AFGen 2018 (55,114; sensitivity)  ·  BioBank Japan (8,180; East Asian contextual)"', 1),
]
ga_ok = True
for name, old, new, exp in GA_EDITS:
    n = t.count(old)
    if n == exp:
        t = t.replace(old, new); print(f"PASS {name}")
    else:
        print(f"FAIL {name}: 命中 {n} != {exp}，不落盘"); ga_ok = False
if ga_ok:
    t = t.replace("Graphical_Abstract_v45_300dpi.png", "Graphical_Abstract_v50_300dpi.png")
    open(ga, "w", encoding="utf-8", newline="\n").write(t)
    print("graphical_abstract_v50.py 已写出")

# ---- 2. Figure1 去 daimon_runtime 依赖 ----
f1 = S / "figure1_design_v50.py"
t = open(f1, encoding="utf-8").read()
t = t.replace('sys.path.insert(0, str(Path(sys.executable).parent.parent.parent))\n', '')
t = t.replace('from daimon_runtime import setup_plot\n', '')
t = t.replace('setup_plot()\n\n', '')
open(f1, "w", encoding="utf-8", newline="\n").write(t)
print("figure1_design_v50.py 已移除 daimon_runtime 依赖（R2: 图形纯英文，默认 DejaVu Sans 与原图一致，出图后目检）")

# ---- 3. 重出图 ----
for script, outname in [(ga, "Graphical_Abstract_v50_300dpi.png"), (f1, "Figure1_Study_Design_v50_300dpi.png")]:
    r = subprocess.run([PY, str(script)], capture_output=True, text=True)
    print(f"--- {outname}: exit {r.returncode}")
    if r.stdout.strip():
        print(r.stdout.strip()[:300])
    if r.returncode:
        print("STDERR:", r.stderr.strip()[-400:])

# ---- 4. 拷贝 ----
for f in ["Graphical_Abstract_v50_300dpi.png", "Figure1_Study_Design_v50_300dpi.png"]:
    p = FIGS / f
    if p.exists():
        shutil.copy2(p, OUT / f); print("拷贝至桌面投稿包:", f)
    else:
        print("未生成:", f)
