# -*- coding: utf-8 -*-
"""Pre-submission audit: structure, citations, numbering, files."""
import csv
import io
import os
import re
import sys

from docx import Document
from PIL import Image

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

PKG = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013"
A3 = r"C:\a3work"
rows = []


def rec(status, area, item, detail=""):
    rows.append((status, area, item, detail))
    print(f"{status:<5}{area:<10}{item}" + (f"   [{detail}]" if detail else ""))


man = Document(os.path.join(PKG, "Manuscript.docx"))
sup = Document(os.path.join(PKG, "Supplement.docx"))
cl = Document(os.path.join(PKG, "Cover_Letter.docx"))
hl = Document(os.path.join(PKG, "Highlights.docx"))
mp = [p.text.strip() for p in man.paragraphs if p.text.strip()]
sp = [p.text.strip() for p in sup.paragraphs if p.text.strip()]
full = "\n".join(mp)

# ---------------- 1. structure ----------------
print("=== 结构 ===")
title = mp[0]
rec("PASS" if len(title.split()) <= 25 else "WARN", "结构", f"标题 {len(title.split())} 词", title[:70])
rec("PASS" if "Short title" in full else "FAIL", "结构", "短标题")
rec("PASS" if re.search(r"Corresponding author", full) else "FAIL", "结构", "通讯作者")
rec("PASS" if "ORCID" in full else "FAIL", "结构", "ORCID")
for h in ["Abstract", "Introduction", "Methods", "Results", "Discussion", "Conclusions",
          "Clinical Perspective", "References"]:
    rec("PASS" if any(x == h or x.startswith(h + " ") for x in mp) else "FAIL", "结构", f"章节 {h}")
for d in ["Acknowledgements", "Sources of Funding", "Disclosures", "Author Contributions",
          "Data integrity", "Use of artificial intelligence", "Data availability"]:
    rec("PASS" if any(x.startswith(d) for x in mp) else "FAIL", "结构", f"声明 {d}")
rec("PASS" if any(x.startswith("Keywords:") for x in mp) else "FAIL", "结构", "关键词")
rec("PASS" if "Nonstandard Abbreviations" in full else "FAIL", "结构", "缩略语表")

ai = mp.index("Abstract")
words = {}
for j in range(ai + 1, ai + 8):
    lab = mp[j].split(":")[0]
    if lab in ("Background", "Methods and Results", "Conclusions"):
        words[lab] = len([w for w in mp[j].split() if re.search(r"[A-Za-z0-9]", w)]) - 1
tot = sum(words.values())
rec("PASS" if tot <= 250 else "FAIL", "结构", f"摘要 {tot}/250", str(words))

# ---------------- 2. references ----------------
print("\n=== 引用 ===")
nums = [int(m.group(1)) for m in re.finditer(r"(?m)^(\d+)\.\s", full)]
rec("PASS" if nums == list(range(1, len(nums) + 1)) else "FAIL", "引用",
    f"文末 {len(nums)} 条，编号连续")
refs = re.findall(r"(?m)^(\d+)\.\s(.+)$", full)
cited = set()
for m in re.finditer(r"\[([0-9,\s–-]+)\]", full):
    for part in m.group(1).split(","):
        part = part.strip()
        if re.fullmatch(r"\d+", part):
            cited.add(int(part))
        elif re.fullmatch(r"\d+\s*[–-]\s*\d+", part):
            a, b = re.split(r"\s*[–-]\s*", part)
            cited.update(range(int(a), int(b) + 1))
bad = sorted(c for c in cited if c > len(nums))
rec("PASS" if not bad else "FAIL", "引用", "正文引用编号不越界", f"越界 {bad}" if bad else "")
uncited = sorted(set(range(1, len(nums) + 1)) - cited)
rec("PASS" if not uncited else "WARN", "引用", "每条文献都被正文引用",
    f"未被引用 {uncited}" if uncited else "")

# duplicate detection: first author + year
seen = {}
dups = []
for n, text in refs:
    key = re.sub(r"[^A-Za-z]", "", text.split(".")[0].lower())[:18]
    yr = re.search(r"\b(19|20)\d{2}\b", text)
    k = (key, yr.group(0) if yr else "")
    if k in seen:
        dups.append(f"[{seen[k]}]≈[{n}]")
    else:
        seen[k] = n
rec("PASS" if not dups else "WARN", "引用", "疑似重复文献", ", ".join(dups) if dups else "")

# ---------------- 3. numbering ----------------
print("\n=== 编号 ===")
tab_caps = [f"Table {i}" for i in range(1, 5)]
for t in tab_caps:
    rec("PASS" if any(x.startswith(t + ".") for x in mp) else "FAIL", "编号", f"{t} 标题存在")
rec("PASS" if len(man.tables) == 4 else "WARN", "编号", f"手稿表格数 {len(man.tables)}")
fig_leg = [x for x in mp if re.match(r"^Figure [0-9S]", x)]
rec("PASS" if len(fig_leg) == 4 else "WARN", "编号", f"图注 {len(fig_leg)} 条",
    "; ".join(x.split(".")[0] for x in fig_leg))

scaps = [int(m.group(1)) for m in re.finditer(r"^Table S(\d+)\.", "\n".join(sp), re.M)]
rec("PASS" if scaps == list(range(1, len(scaps) + 1)) else "FAIL", "编号",
    f"补充表 S1–S{max(scaps) if scaps else 0} 连续", str(scaps[:5]) + "...")
rec("PASS" if len(sup.tables) == len(scaps) else "WARN", "编号",
    f"补充表数量 {len(sup.tables)} 张 vs {len(scaps)} 个标题")
cited_s = sorted({int(m.group(1)) for m in re.finditer(r"Table S(\d+)", full)})
missing = [c for c in cited_s if c not in scaps]
rec("PASS" if not missing else "FAIL", "编号", "正文引用的 Table S 都存在",
    f"缺 {missing}" if missing else f"S{cited_s[0]}–S{cited_s[-1]}")
contents = next((x for x in sp if x.startswith("Contents:")), "")
missing_c = [n for n in scaps if f"Table S{n} " not in contents and f"Table S{n}." not in contents]
rec("PASS" if not missing_c else "WARN", "编号", "目录覆盖全部补充表",
    f"目录缺 {missing_c}" if missing_c else "")

# ---------------- 4. numeric trace ----------------
print("\n=== 数字回源 ===")
t2 = man.tables[1]
mr = list(csv.DictReader(open(os.path.join(A3, "yuan2025_mr.csv"), encoding="utf-8")))
by = {}
for r in mr:
    by.setdefault(r["exposure"], {})[r["method"]] = r
LAB = {"Sugar added to tea": "Sugar added to tea", "Sugar added to coffee": "Sugar added to coffee",
       "Fizzy drinks (SSB)": "Fizzy drink intake (SSB)",
       "Low-calorie drinks (ASB)": "Low-calorie drink intake (ASB)",
       "Sweetener added to tea": "Artificial sweetener added to tea",
       "Coffee intake": "Coffee intake", "Tea intake": "Tea intake"}
bad = []
for e, lab in LAB.items():
    row = next((r for r in t2.rows[1:] if r.cells[0].text.strip() == lab), None)
    if not row:
        bad.append(f"{lab} 缺行")
        continue
    ivw = by[e]["Inverse variance weighted"]
    want = f"{float(ivw['OR']):.2f} ({float(ivw['lo']):.2f}–{float(ivw['hi']):.2f})"
    if not row.cells[3].text.strip().startswith(want):
        bad.append(f"{lab}: {row.cells[3].text.strip()} vs {want}")
rec("PASS" if not bad else "FAIL", "数字", "Table 2 Yuan 列回源", "; ".join(bad))

# abstract numbers must exist somewhere in the results/tables
abs_txt = " ".join(mp[ai + 1:ai + 8])
for probe in ["1.26", "1.39", "0.028", "192,851"]:
    rec("PASS" if probe in abs_txt and probe in full else "FAIL", "数字", f"摘要关键值 {probe}")

# ---------------- 5. files ----------------
print("\n=== 文件 ===")
files = sorted(os.listdir(PKG))
allowed = {"Cover_Letter.docx", "Highlights.docx", "Manuscript.docx", "README_投稿包.md", "Supplement.docx", "figures"}
rec("PASS" if set(files) == allowed else "FAIL",
    "文件", "投稿包仅含指定交付件", ", ".join(files))
figs = sorted(os.listdir(os.path.join(PKG, "figures")))
rec("PASS" if len(figs) == 5 else "WARN", "文件", f"图片 {len(figs)} 张", ", ".join(figs))
for f in figs:
    im = Image.open(os.path.join(PKG, "figures", f))
    dpi = im.info.get("dpi", (300, 300))[0]
    w = im.size[0] / dpi * 2.54
    rec("PASS" if w <= 17.5 else "FAIL", "文件", f"{f} {w:.2f} cm @{dpi:.0f} dpi")
rec("PASS" if all(Document(os.path.join(PKG, f + ".docx")).core_properties.author == "Cao Zezhong"
                  for f in ["Manuscript", "Supplement", "Cover_Letter", "Highlights"]) else "FAIL",
    "文件", "四份 docx 元数据")

print()
n_fail = sum(1 for s, *_ in rows if s == "FAIL")
n_warn = sum(1 for s, *_ in rows if s == "WARN")
print(f"合计 {len(rows)} 项：PASS {len(rows)-n_fail-n_warn}，WARN {n_warn}，FAIL {n_fail}")
