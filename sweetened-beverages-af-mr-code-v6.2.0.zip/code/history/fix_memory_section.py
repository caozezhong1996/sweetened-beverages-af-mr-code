# -*- coding: utf-8 -*-
"""Repair the figure-size section in ~/.workbuddy/MEMORY.md (backticks were
eaten by shell command substitution)."""
import io
import pathlib
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

GOOD = """## 出图必须按印刷尺寸建画布（2026-10-27，踩过两次）

- matplotlib 用 `figsize=(11.5, 8.6)` 建图时，`fontsize=9` 只是**设计尺寸上的 9 pt**。
  印到 15.92 cm 栏宽要缩 0.55 倍，实印只剩 5 pt —— 屏幕上看不出来，送印刷就是不合格。
- **正解：`figsize` 直接等于成品尺寸**（如 17.4 cm 写 6.85 in），这样 `fontsize` 就是实印 pt。
- 判断是否合格：物理宽 = `px / dpi × 2.54`，与栏宽（A4 双栏正文 15.9–17.4 cm）比；
  缩放比 < 0.95 就要重做。
- **左右边距不要手填**：用 `TextPath(...).get_extents().width / 72` 量出最长标签宽度再反推，
  否则长标签会被裁掉（"Low-calorie drinks (ASB)" 这类）。
- 图注不要描述没画出来的东西：先画再写图注，或写"见 Table Sxx"。

"""

p = pathlib.Path(r"C:\Users\64915\.workbuddy\MEMORY.md")
t = p.read_text(encoding="utf-8")
i = t.find("## 出图必须按印刷尺寸建画布")
j = t.find("## 改 docx 的两个必踩坑")
assert i >= 0 and j > i, (i, j)
t = t[:i] + GOOD + t[j:]
p.write_text(t, encoding="utf-8")
print("repaired")
print(t[i:i + 200])
