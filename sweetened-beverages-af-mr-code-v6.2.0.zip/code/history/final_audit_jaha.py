# -*- coding: utf-8 -*-
"""JAHA v5.2.x 投稿包全面终审：四步增强落实 + 结构 + 词数 + 引文链 + 数字 + README 一致性。"""
import io, sys, re

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
from docx import Document

P = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013"
man = Document(P + r"\manuscript_v52_JAHA.docx")
paras = [p.text.strip() for p in man.paragraphs if p.text.strip()]
full = "\n".join(paras)

print("=" * 66)
print("【A. 四步增强落实核查（04:38 更新内容）】")
a_checks = [
    ("A1 三阶段收敛叙事（易感/急性/复发）", ("susceptibility" in full.lower() and "recurrence" in full.lower() and "DECAF" in full) or "three stages" in full.lower() or "trigger level" in full.lower()),
    ("A2 Marcus EHJ 2025 综述引用", "state-of-the-art" in full or "state of the art" in full),
    ("A2b 引文 46 存在", any(p.startswith("46.") for p in paras)),
    ("A3 摘要挂靠 DECAF/RCT", "convergent with randomized" in full or ("randomized recurrence" in full)),
    ("A4 Cover Letter 工作量显性化", None),  # 单独查
]
for n, p in a_checks:
    if p is not None:
        print(("  PASS " if p else "  FAIL/未落实 ") + n)
cl = Document(P + r"\cover_letter_v52_JAHA.docx")
clf = "\n".join(p.text for p in cl.paragraphs if p.text.strip())
for kw in ["25 supplementary", "supplementary tables", "312", "Zenodo", "three exposure", "harness"]:
    print(f"  CL 含 '{kw}':", kw in clf)
print("  CL 词数:", len(clf.split()))

print()
print("【B. 结构完整性（JAHA 必备）】")
b_checks = [
    ("结构化摘要三标签", all(k in paras for k in ["Background:", "Methods and Results:", "Conclusions:"]) or any("Methods and Results" in p for p in paras[:10])),
    ("Nonstandard Abbreviations 节", any("Nonstandard Abbreviations" in p or p == "NAA" for p in paras)),
    ("Clinical Perspective 节", any("Clinical Perspective" in p for p in paras)),
    ("What Is New / Clinical Implications", any("What Is New" in p for p in paras) and any("What Are the Clinical Implications" in p for p in paras)),
    ("Sources of Funding", any("Sources of Funding" in p or "SOURCES OF FUNDING" in p.upper() for p in paras)),
    ("Disclosures", any(p == "Disclosures" or "Disclosures" in p[:30] for p in paras)),
]
for n, p in b_checks:
    print(("  PASS " if p else "  FAIL ") + n)

print()
print("【C. 词数】")
ai = paras.index("Abstract")
tot = sum(len(paras[j].split()) - 1 for j in range(ai + 1, ai + 6)
          if paras[j].split(":")[0] in ("Background", "Methods and Results", "Conclusions"))
print(f"  摘要: {tot}/250", "PASS" if tot <= 250 else "FAIL")
ii = paras.index("Introduction")
di = next((i for i, p in enumerate(paras) if p.startswith("Sources of") or p == "Acknowledgements"), len(paras))
print(f"  正文粗口径（含图表注/CP）: {len(' '.join(paras[ii:di]).split())}")

print()
print("【D. 引文链完整性】")
refs = {}
for p in paras:
    m = re.match(r"^(\d+)\. ", p)
    if m:
        refs[int(m.group(1))] = p
n_ref = max(refs) if refs else 0
print(f"  引文条目: 1..{n_ref}，缺失: {[i for i in range(1, n_ref + 1) if i not in refs] or '无'}")
# 正文引用扫描（排除参考文献区）
body_text = "\n".join(paras[:[i for i, p in enumerate(paras) if re.match(r'^1\. ', p)][0]])
cited = set()
for m in re.finditer(r"\[(\d+(?:[,\s\-–]+\d+)*)\]", body_text):
    for part in re.split(r"[,\s]+", m.group(1)):
        if "-" in part or "–" in part:
            continue
        if part.isdigit():
            cited.add(int(part))
uncovered = [i for i in range(1, n_ref + 1) if i not in cited]
print(f"  正文引用的编号范围: {min(cited)}–{max(cited)}；未被正文引用的条目: {uncovered or '无'}")
orphan = [i for i in cited if i > n_ref]
print(f"  正文引用但无条目: {orphan or '无'}")

print()
print("【E. v5.2.2 既有修复保持 + 关键数字】")
e_checks = [
    ("Larsson 划界句（正文）", "whose null findings included atrial fibrillation" in full),
    ("min detectable OR 代谢物", "1.07" in full and "1.25" in full),
    ("[45] Liu 2025 JAHA GBD", any(p.startswith("45. Liu") for p in paras)),
    ("关键数字: 60,620/67,783/1.34/0.82/120%", all(x in full for x in ["60,620", "67,783", "1.34", "0.82"])),
    ("rg 0.24–0.31", "0.24–0.31" in full),
    ("DECAF [9] JAMA 2026", "JAMA. 2026" in full),
    ("组件≠复合物段", "component-proxy design estimates the marginal" in full),
    ("East Asian contextual 口径", "East Asian contextual" in full),
]
for n, p in e_checks:
    print(("  PASS " if p else "  FAIL ") + n)

print()
print("【F. Highlights 与 README】")
h = Document(P + r"\highlights_v51.docx")
hf = [p.text for p in h.paragraphs if p.text.strip()]
print(f"  Highlights 条数: {len(hf) - 1}；代谢物条在位: {'Plasma caffeine, paraxanthine' in hf[-1]}")
rd = open(P + r"\README_投稿包.md", encoding="utf-8").read()
print("  README 版本标注:", rd.split("\n")[0][:70])
for kw in ["45 条", "46 条", "5999", "6000"]:
    print(f"  README 含 '{kw}':", kw in rd)
