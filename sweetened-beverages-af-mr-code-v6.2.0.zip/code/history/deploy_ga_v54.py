# -*- coding: utf-8 -*-
"""Deploy GA v54 into the JAHA package; retire v53."""
import shutil
from pathlib import Path

SRC = Path(r"C:/Users/64915/Documents/kimi/workspace/奶茶房颤MR_迁移包_20260822/06_升级分析_v4/figures")
PKG = Path(r"C:/Users/64915/Desktop/JAHA投稿包_奶茶房颤MR_20261013")
FIG = PKG / "figures"

new, old = "Graphical_Abstract_v54_300dpi.png", "Graphical_Abstract_v53_300dpi.png"
shutil.copy2(SRC / new, FIG / new)
print(f"copied {new}  {(FIG / new).stat().st_size / 1024:.0f} KB")
o = FIG / old
if o.exists():
    dst = PKG / old.replace(".png", "_旧版_已移出.png")
    shutil.move(str(o), str(dst))
    print(f"moved {old} -> {dst.name}")

rd = PKG / "README_投稿包.md"
t = rd.read_text(encoding="utf-8")
t = t.replace("figures/Graphical_Abstract_v53_300dpi.png",
              "figures/Graphical_Abstract_v54_300dpi.png")
t = t.replace("图文摘要（含代谢物与三阶段收敛；v53 版式重排）",
              "图文摘要（v54：内容按正文核对修正，逻辑改为 DATA→DESIGN→FINDINGS）")
rd.write_text(t, encoding="utf-8")
print("README updated")

for f in sorted(FIG.iterdir()):
    print("  ", f.name)
