# -*- coding: utf-8 -*-
"""Propagate the reference renumbering to the cover letter and supplement."""
import io
import re
import sys

from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
ORDER = [1, 2, 3, 8, 29, 40, 4, 5, 6, 7, 9, 10, 11, 12, 13, 15, 16, 14, 17, 18, 19, 44,
         20, 42, 21, 22, 23, 24, 39, 25, 26, 27, 28, 41, 32, 33, 31, 30, 46, 34, 35, 36, 38, 45, 37, 43]
MAP = {old: i + 1 for i, old in enumerate(ORDER)}
for old in range(1, 47):
    MAP.setdefault(old, len(MAP) + 1)

CIT = re.compile(r"\[([0-9,\s–-]+)\]")


def expand(g):
    out = []
    for part in g.split(","):
        part = part.strip()
        if re.fullmatch(r"\d+", part):
            out.append(int(part))
        elif re.fullmatch(r"\d+\s*[–-]\s*\d+", part):
            a, b = re.split(r"\s*[–-]\s*", part)
            out.extend(range(int(a), int(b) + 1))
    return out


def remap_text(text):
    def sub(m):
        ns = sorted({MAP[n] for n in expand(m.group(1))})
        return "[" + ",".join(str(n) for n in ns) + "]"
    return CIT.sub(sub, text)


def process(path, also_refword=False):
    d = Document(path)
    changed = 0
    for p in d.paragraphs:
        txt = p.text
        new = remap_text(txt)
        if also_refword:
            new = re.sub(r"manuscript ref (\d+)", lambda m: f"manuscript ref {MAP[int(m.group(1))]}", new)
        if new != txt:
            for r in p.runs:
                r.text = ""
            p.runs[0].text = new
            changed += 1
    for t in d.tables:
        for row in t.rows:
            for c in row.cells:
                for p in c.paragraphs:
                    txt = p.text
                    new = remap_text(txt)
                    if also_refword:
                        new = re.sub(r"manuscript ref (\d+)", lambda m: f"manuscript ref {MAP[int(m.group(1))]}", new)
                    if new != txt:
                        for r in p.runs:
                            r.text = ""
                        p.runs[0].text = new
                        changed += 1
    d.save(path)
    print(f"{path.split(chr(92))[-1]}: {changed} 处引用更新")


process(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\Cover_Letter.docx")
process(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\Supplement.docx", also_refword=True)
