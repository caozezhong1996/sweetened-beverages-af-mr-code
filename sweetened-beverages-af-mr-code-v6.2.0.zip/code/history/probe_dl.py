#!/usr/bin/env python
"""Probe EBI download: parallel aggregate speed + partial-file sanity."""
import gzip, io, os, sys, time, subprocess, threading, urllib.request

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

D = r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\06_升级分析_v4\downloads\yuan2025"
PART = os.path.join(D, "GCST90624413.tsv.gz")
BASE = ("https://ftp.ebi.ac.uk/pub/databases/gwas/summary_statistics/"
        "GCST90624001-GCST90625000/GCST90624413/")

# ---------- 1) 已下载前缀是否完整可解压 ----------
def head_lines(path, n=3):
    out = []
    try:
        with gzip.open(path, "rt", encoding="utf-8", errors="replace") as f:
            for i, line in enumerate(f):
                out.append(line.rstrip("\n"))
                if i + 1 >= n:
                    break
    except (EOFError, OSError) as e:
        out.append(f"<{type(e).__name__}: {e}>")
    return out

print("=== 已下载前缀 ===")
print(f"size = {os.path.getsize(PART)/1e6:.1f} MB")
for ln in head_lines(PART, 3):
    print("  ", ln[:220])

# ---------- 2) 并行聚合速度 ----------
def fetch_range(idx, start, end, bucket, key):
    url = BASE + "GCST90624413.tsv.gz"
    req = urllib.request.Request(url, headers={"Range": f"bytes={start}-{end}"})
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=90) as r:
            data = r.read()
        bucket[key] = (len(data), time.time() - t0, None)
    except Exception as e:
        bucket[key] = (0, time.time() - t0, f"{type(e).__name__}: {e}")

def parallel_test(n=6, span=6_000_000, offset=300_000_000):
    bucket = {}
    ths = []
    t0 = time.time()
    for i in range(n):
        s = offset + i * span
        th = threading.Thread(target=fetch_range, args=(i, s, s + span - 1, bucket, i))
        th.start()
        ths.append(th)
    for th in ths:
        th.join()
    wall = time.time() - t0
    tot = sum(v[0] for v in bucket.values())
    errs = [v[2] for v in bucket.values() if v[2]]
    print(f"\n=== 并行 {n} 路 ===")
    print(f"总 {tot/1e6:.1f} MB / {wall:.1f}s = {tot/wall/1024:.0f} KB/s 聚合")
    for k in sorted(bucket):
        sz, el, err = bucket[k]
        print(f"   conn{k}: {sz/1e6:5.2f} MB in {el:5.1f}s = {sz/max(el,1e-9)/1024:5.0f} KB/s {err or ''}")
    return tot / wall if wall else 0

if __name__ != "__main__" or len(sys.argv) > 1:
    parallel_test()
