# -*- coding: utf-8 -*-
import csv
import io
import os
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

M = r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
p = os.path.join(M, "06_升级分析_v4", "results", "ldsc_rg_v44.csv")
print("exists:", os.path.exists(p))
rows = list(csv.DictReader(open(p, encoding="utf-8")))
print("cols:", list(rows[0].keys()), "n =", len(rows))
for r in rows:
    print(f"  {r['exposure']:<10} {r['outcome']:<10} rg={r['rg']:>7} se={r['rg_se']:>7} "
          f"p={r.get('rg_p','?'):>7} fdr={r.get('rg_fdr','?')}")
