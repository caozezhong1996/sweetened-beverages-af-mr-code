# -*- coding: utf-8 -*-
from docx import Document
from docx.table import Table
from docx.text.paragraph import Paragraph
import pathlib, io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
SRC = pathlib.Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\审稿与编辑评估_20261029.docx")
OUT = pathlib.Path(r"C:\Users\64915\WorkBuddy\2026-10-06-13-49-21\review_20261029.txt")
doc = Document(str(SRC))
lines=[]
for child in doc.element.body.iterchildren():
    if child.tag.endswith('}p'):
        p=Paragraph(child,doc)
        if p.text.strip(): lines.append(p.text)
    elif child.tag.endswith('}tbl'):
        t=Table(child,doc)
        lines.append('[TABLE]')
        for r in t.rows: lines.append(' | '.join(c.text.replace('\n',' / ') for c in r.cells))
        lines.append('[/TABLE]')
OUT.write_text('\n'.join(lines),encoding='utf-8')
print('paragraphs',len(doc.paragraphs),'tables',len(doc.tables),'chars',sum(map(len,lines)),'output',OUT)
