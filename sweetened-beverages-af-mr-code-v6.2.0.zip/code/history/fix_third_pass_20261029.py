# -*- coding: utf-8 -*-
from docx import Document
import pathlib
PKG=pathlib.Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")
man=Document(str(PKG/"Manuscript.docx"))
reps=[("distinguished correlated pleiotropy from causation","was used to assess correlated pleiotropy versus causation"),("the remaining FinnGen tests were null (smallest P = 0.49)","the remaining FinnGen tests were null (smallest P = 0.51)"),("was non-significant in both replication sources","was non-significant in both outcome sources")]
n=0
for p in man.paragraphs:
    t=p.text
    for old,new in reps:
        if old in t:t=t.replace(old,new);n+=1
    if t!=p.text:
        for r in p.runs:r.text=""
        p.runs[0].text=t
assert n==3,n
man.save(str(PKG/"Manuscript.docx"))
sup=Document(str(PKG/"Supplement.docx"))
vals=iter(["0.0092","-0.0090","-0.0148"]);k=0
for t in sup.tables:
    for row in t.rows:
        if row.cells[0].text.startswith("Test of difference (corrected - observed)"):
            row.cells[1].text=next(vals);k+=1
        elif len(row.cells)>2 and row.cells[1].text.startswith("Test of difference (corrected - observed)"):
            row.cells[2].text=next(vals);k+=1
assert k==3,k
sup.save(str(PKG/"Supplement.docx"))
print("Third-pass corrections complete")
