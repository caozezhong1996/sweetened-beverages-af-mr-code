# -*- coding: utf-8 -*-
from docx import Document
import pathlib,io,sys
sys.stdout=io.TextIOWrapper(sys.stdout.buffer,encoding="utf-8")
PKG=pathlib.Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")
def paras(d):return list(d.paragraphs)+[p for t in d.tables for r in t.rows for c in r.cells for p in c.paragraphs]
def rep(d,old,new,n=1):
    h=[p for p in paras(d) if old in p.text]
    if not h:return
    assert len(h)==n,(old,len(h))
    for p in h:
        t=p.text.replace(old,new)
        for r in p.runs:r.text=""
        p.runs[0].text=t
man=Document(str(PKG/"Manuscript.docx"))
rep(man,"weighted-median, MR-Egger and weighted-mode estimates were directionally consistent and non-significant","weighted-median, MR-Egger and weighted-mode estimates were non-significant")
rep(man,"the concordant MR-RAPS (Table S23) and MRlap estimates (difference P > 0.05; Table S17) mitigate, but do not eliminate, this concern.","MR-RAPS for beverage phenotypes and MRlap for coffee and tea provide partial sensitivity evidence but do not eliminate this concern (Tables S17 and S23).")
rep(man,"whereas FinnGen R13 and the UK Biobank-free Yuan 2025 estimate included the null.","whereas the estimates in FinnGen R13 and UK Biobank-free Yuan 2025 included the null.")
man.save(str(PKG/"Manuscript.docx"))
sup=Document(str(PKG/"Supplement.docx"))
rep(sup,"which are addressed by MR-RAPS (Table S23) and MRlap (Table S17), respectively discussed in the manuscript Limitations.","MR-RAPS was applied to beverage phenotypes and MRlap to coffee and tea only (Tables S17 and S23); these analyses provide partial rather than definitive sensitivity evidence.")
rep(sup,"atrial fibrillation (both replication outcomes)","atrial fibrillation (Nielsen 2018 and FinnGen R13)")
rep(sup,"against both replication outcomes","against Nielsen 2018 and FinnGen R13",n=3)
rep(sup,"Estimates were directionally consistent with the primary IVW analysis for all 14 exposure–outcome pairs:","Estimates were broadly consistent with the primary IVW analysis, apart from three sign reversals among null estimates:")
rep(sup,"values below the conventional threshold of 10 indicate limited conditional strength, biasing multivariable estimates toward the null.","values below the conventional threshold of 10 indicate limited conditional strength; all conditional estimates are exploratory and the direction of weak-instrument bias is not assumed.")
rep(sup,"corroborating adiposity-linked pleiotropy as the source of the nominal coffee–AF signal.","compatible with adiposity-linked pleiotropy contributing to the nominal coffee–AF signal.")
rep(sup,"including the adiposity-mediated component colocalizing at FTO","including the adiposity-linked component colocalizing at FTO")
sup.save(str(PKG/"Supplement.docx"))
print("Second-pass inconsistencies corrected")
