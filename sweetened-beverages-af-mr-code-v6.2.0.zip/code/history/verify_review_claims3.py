# -*- coding: utf-8 -*-
"""Third batch: table inventory, S25 contents, Methods sentences."""
import io
import re
import sys

from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

PKG = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013"
MS = Document(PKG + r"\Manuscript.docx")
SUP = Document(PKG + r"\Supplement.docx")
mp = [p.text.strip() for p in MS.paragraphs if p.text.strip()]
mf = "\n".join(mp)

print("=== 手稿表格清单 ===")
for i, t in enumerate(MS.tables):
    hdr = [c.text.strip() for c in t.rows[0].cells]
    print(f"  表{i}: {len(t.rows)}行 x {len(t.columns)}列 | " + " | ".join(h[:16] for h in hdr[:6]))

print("\n=== 结果表里的茶行（找 36）===")
for i, t in enumerate(MS.tables):
    txt = " ".join(c.text for r in t.rows for c in r.cells)
    if "36" in txt and "SNP" in " ".join(c.text for c in t.rows[0].cells):
        for r in t.rows:
            c = [x.text.strip() for x in r.cells]
            if c[0].lower().startswith(("tea", "coffee", "sugar", "fizzy", "low")):
                print(f"  表{i}:", " | ".join(x[:40] for x in c))

print("\n=== Methods 一致性判据 ===")
for m in re.finditer(r"[^.]*consistency criteri[^.]*\.", mf, re.I):
    print("  ", m.group(0)[:300])

print("\n=== Methods 关于 Yuan / 不公开 ===")
for m in re.finditer(r"[^.]*(not public|not publicly|GCST90624413|Yuan)[^.]*\.", mf, re.I):
    print("  ", m.group(0)[:300])

print("\n=== 补充材料 S25 表 ===")
hit = 0
for t in SUP.tables:
    txt = " ".join(c.text for r in t.rows for c in r.cells)
    if "Paraxanthine" in txt or "paraxanthine" in txt:
        hdr = [c.text.strip() for c in t.rows[0].cells]
        print("  表头:", hdr)
        for r in t.rows[:10]:
            print("   ", " | ".join(c.text.strip()[:26] for c in r.cells))
        hit += 1
        break
if not hit:
    print("  未找到")

print("\n=== 图注中的文件名 ===")
for p in mp:
    if re.match(r"^Figure (S?\d)\.", p):
        print("  ", p[:220])
