import io
import sys
from pathlib import Path
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
OUT = Path(r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版\JAHA_v525_改稿留档\审读意见_20261028\方法学闭环方案_20261028.docx")
doc = Document()
sec = doc.sections[0]
sec.left_margin = Cm(2.2)
sec.right_margin = Cm(2.2)
styles = doc.styles
styles["Normal"].font.name = "Arial"
styles["Normal"].font.size = Pt(10)
for name in ("Title", "Heading 1", "Heading 2"):
    styles[name].font.name = "Arial"

doc.core_properties.title = "三份审读报告方法学闭环方案"
doc.core_properties.author = "Cao Zezhong"
doc.core_properties.subject = "JAHA sweetened beverage and atrial fibrillation MR"

title = doc.add_paragraph(style="Title")
title.alignment = WD_ALIGN_PARAGRAPH.CENTER
title.add_run("三份审读报告方法学闭环方案")
p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.add_run("JAHA 甜饮料与房颤 MR｜2026-10-28").bold = True

doc.add_heading("一、总体判断", level=1)
doc.add_paragraph(
    "当前最合理的定位是“既往甜饮料—房颤关联的因果稳健性评估”，而不是奶茶安全性研究或脂肪机制证明。"
    "全文必须区分四件事：统计异质性、水平多效性、因果中介和样本独立性。体脂位点剔除可以解释来源间差异，"
    "但不能单独证明 BMI 中介；FTO 共定位可以提供位点级一致性，但不能单独证明脂肪通路；Yuan 不含 UKB 暴露样本，"
    "但与 FinnGen/AFGen 并非相互独立；阴性估计不能等同于饮料安全。"
)
doc.add_paragraph(
    "因此，审稿意见不应全盘照做。应优先修复会影响结论方向的识别与表述问题，而不是继续堆叠敏感性分析。"
    "当前版本已经撤回 abolished、moderate-to-large、participant-disjoint、预防优先级和弱 MVMR 机制证明等过强表述。"
)

doc.add_heading("二、本轮已经落地的文本与一致性问题", level=1)
for text in [
    "Clinical Perspective、Results、Discussion、Conclusions 和 Cover Letter 已统一为：体脂位点解释咖啡估计的异质性，但残余合并 OR 1.41（1.16–1.72），P = 0.0007，机制未明。",
    "甜饮料结论统一为：只能排除各暴露 95% CI 上限以上的效应，不能排除观察量级效应，也不能证明奶茶或复合饮料安全。",
    "Neale field 1498 改列为 UK Biobank 内的表型定义敏感性分析；主文不再把 cross-GWAS 固定效应结果当作独立复制或精度增益，Table S19 已同步改写。",
    "MRlap、LDSC、FTO 共定位、酒精阳性对照和 AV block 阴性对照均按证据强度重新表述；AV block 明确写为糖加茶阴性对照未通过。",
    "Cover Letter 删除工作量推销、旧 abolished 数值和弱 MVMR 机制句，AI 披露病句已修复。",
    "AHA 2026 声明补为 Circulation. 2026;154(9):e345-e355；Casiglia 第六作者改为 Montagnana M。",
    "Graphical Abstract 删除“观察关联由脂肪解释”和“截距排除重叠”的表述。",
]:
    doc.add_paragraph(text, style="List Bullet")

doc.add_heading("三、开放方法学问题的分层解决方案", level=1)
rows = [
    (
        "样本重叠与复制层级",
        "补一张暴露、结局、BMI 的样本重叠矩阵。明确 UKB 暴露与 Nielsen 重叠；Yuan 不含 UKB，但含 FinnGen R12/AFGen 队列，因此结局之间不独立。Yuan 不与 FinnGen 合并。S19 已降格，无需再删除原始结果。",
        "投稿前必做，纯元数据工作",
        "矩阵与 Table 1、Table S19、Methods 完全一致；不再出现 independent/participant-disjoint 等未限定词。",
    ),
    (
        "糖加茶等估计方向与 AV block 阴性对照",
        "阴性对照已在正文判为未通过。若要进一步诊断，可做七个暴露→BMI 的双向 MR，使用 GIANT 主分析、Neale 复算，配合 Steiger 和体脂位点剔除。该分析只能诊断多效性方向，不能用来证明糖无害或有害。",
        "强烈建议，但当前降调后不构成阻断",
        "无论结果正负，正文只写“存在向下或向上偏倚的可能”；不把方向性诊断升级为机制证明。",
    ),
    (
        "弱条件 MVMR",
        "保留 Table 4 为探索性结果，咖啡与 BMI 的条件 F 和向零偏倚必须同时出现。糖加茶 n = 1 继续留在 S24，不回主表。Cover Letter 不再使用 OR 0.82 作为机制证据。若审稿人要求，可在修回阶段补弱工具稳健 MVMR；不必为初投新造一套分析。",
        "现有结果即可闭环",
        "摘要、CP、Discussion 和 Cover Letter 均不把 MVMR 当作独立机制证据。",
    ),
    (
        "咖啡—BMI 中介识别失败",
        "S16 保留为探索性分解，直接效应 CI 已修正。不要在主线中使用 120% 介导比例证明完全中介。若未来要强化机制，需做双向咖啡–BMI MR、独立工具、协方差感知估计及全程体脂位点剔除；否则维持当前降格。",
        "当前可闭环；机制强化才需新增分析",
        "正文只写 direction not identifiable，不写 complete mediation 或 adiposity accounts for the signal。",
    ),
    (
        "FTO 共定位与多信号位点",
        "最省事且合理的补全是对 CYP1A1–CYP1A2、AHR、FTO 三个位点统一报告 H0–H4、p12 扫描和窗口敏感性。若 LD 与全量统计齐备，再补 coloc.susie。不要把 coffee–AF 的 H4 直接解释为 coffee–BMI–AF 中介。",
        "统一敏感性报告建议补；SuSiE 非绝对阻断",
        "三个位点采用同一报告标准；FTO p12 = 10⁻⁶ 时 PP.H4 = 0.457 不被隐藏。",
    ),
    (
        "咖啡因亚组仅 3 个工具",
        "补累计 R²、F、MDE 以及与 724 个 BMI 位点的重叠数/比例；rs2472297 与 rs762551 仅在数据可得时报告单变异 Wald 比。三个工具上做 MR-Egger 没有实际意义，不建议为回应审稿而加入。",
        "小工作量、建议补",
        "亚组结论限定为“未检出”，并明确低功效；不比较 3 工具与 31 工具效应大小来证明通路。",
    ),
    (
        "松弛阈值与 winner’s curse",
        "F > 20 只说明弱工具偏倚有限，不解决 winner’s curse 或相关多效性。当前 Limitations 已承认这一点。可将 MRlap/MR-RAPS 作为缓解证据；若能获得独立暴露 GWAS，再做独立或拆分样本验证，否则不必强行新增。",
        "当前可闭环",
        "全文不再用 F > 20 宣布工具有效或排除 winner’s curse。",
    ),
    (
        "未注册与 pre-specified",
        "把实际分析计划、版本日期和偏离表存入 Zenodo/OSF，取得新的时间戳。时间戳只能证明存档时间，不能追溯为预注册。正文保留未注册声明，并将可验证的原始计划与修订期新增分析分开。",
        "投稿前建议完成",
        "计划 DOI 可解析；每项 pre-specified 均能在计划原文中找到，找不到的一律标为 revision-stage/post hoc。",
    ),
    (
        "东亚 BBJ 情境臂",
        "不建议用欧洲工具的 BBJ 结果支撑人群特异性结论。最简方案是把详细估计和第六面板移到补充材料，正文仅保留“跨族群工具错配，不能独立复制”。若未来有东亚暴露 GWAS，再做真正的人群特异性 MR。",
        "呈现优化，非数据阻断",
        "主文不出现东亚咖啡 OR 2.34 的独立证据含义；标题不再使用 East Asian contextual analysis。",
    ),
    (
        "暴露标度",
        "不将 UKB 每类别 OR 与队列高/低摄入 HR 做数值等价比较。若 UKB 文档可得，补各暴露类别定义和人数分布；没有个体数据时不做克数或份数换算。",
        "正文已修正，补充定义可选",
        "Discussion 不再出现“观察 HR 落在 MR CI 内，因此效应一致”的跨标度论证。",
    ),
    (
        "阳性对照与分析灵敏度",
        "以明确的 BMI→AF 效应作为主要阳性对照，酒精作为方向性、次要的阳性对照。酒精单独结局不显著时必须同时报告，不能写 confirmed/verified。频率与量的差异只作假设，不作机制结论。",
        "本轮已闭环",
        "正文、Cover Letter、GA 使用 qualified support，无 confirming analytical sensitivity。",
    ),
    (
        "篇幅、UPF 与标题",
        "JAHA 无正文硬上限，篇幅不是科学阻断项。可将详细估计器结果移入补充材料，目标约 5,500–6,000 词即可，不必机械压到 5,000。UPF 不是本研究暴露，不建议为追热点重构。标题可另行为 Genetically Proxied Sweetened Beverage Intake and Atrial Fibrillation…，但需五处同步。",
        "作者定位选择，不影响本轮纠错",
        "标题、手稿、补充材料、Cover Letter、GA 和核心属性一致；UPF 最多作为未来研究一句。",
    ),
]

table = doc.add_table(rows=1, cols=4)
table.alignment = WD_TABLE_ALIGNMENT.CENTER
table.style = "Table Grid"
hdr = table.rows[0].cells
for i, text in enumerate(("问题", "合理处理", "优先级", "闭环判据")):
    hdr[i].text = text
for item in rows:
    cells = table.add_row().cells
    for i, text in enumerate(item):
        cells[i].text = text
        cells[i].vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP
for row in table.rows:
    for cell in row.cells:
        for p in cell.paragraphs:
            for run in p.runs:
                run.font.size = Pt(8.5)

doc.add_heading("四、推荐的最低风险投稿路线", level=1)
doc.add_paragraph(
    "采用“稳健性评估”而非“机制证明”路线。当前文本降调后，初投前只需完成三项低成本工作："
    "（1）样本重叠矩阵；（2）分析计划时间戳及 pre-specified 对照；（3）三个共定位位点统一敏感性报告和咖啡因亚组 F/R²/MDE。"
    "暴露→BMI 双向 MR 与 SuSiE 可作为增强项，但不应为了保留脂肪机制叙事而无限追加。"
)
doc.add_paragraph(
    "若坚持“咖啡信号由脂肪通路承载”的强机制定位，则必须升级为另一条工作线：独立暴露复制、双向咖啡–BMI MR、"
    "弱工具稳健 MVMR、条件/多信号共定位及咖啡–BMI–AF 联合分析。两条路线不应混用。"
)

doc.add_heading("五、最终验收标准", level=1)
for text in [
    "所有数值在摘要、正文、主表和补充表中一致，禁止旧值 1.26（0.90–1.75）/ P = 0.178 回流。",
    "禁止 abolished、moderate-to-large effects are excluded、participant-disjoint replication、confirmed analytical sensitivity 等无依据表述回流。",
    "46 条文献首引连续且全部被引用；新增或删除引用后必须重新排序，而不是局部手改。",
    "手稿、补充材料、Highlights、Cover Letter、GA 对咖啡残余关联和甜饮料功效限制采用同一口径。",
    "DOCX 真渲染无越界或表格断裂，Node 从投稿包实际 PNG 文件头复核尺寸并目检图内结论。",
]:
    doc.add_paragraph(text, style="List Bullet")

doc.save(str(OUT))
print(OUT)
