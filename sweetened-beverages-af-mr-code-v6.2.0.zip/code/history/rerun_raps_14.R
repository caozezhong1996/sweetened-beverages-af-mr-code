# Full re-run of Table S23 (14 cells) from the R13 + Nielsen inputs, two passes.
suppressMessages({library(data.table); library(mr.raps)})

RES <- "C:/Users/64915/Documents/kimi/workspace/奶茶房颤MR_迁移包_20260822/06_升级分析_v4/results"
OUT <- "C:/Users/64915/WorkBuddy/2026-10-06-13-49-21/raps_rerun_14.csv"

exposures <- c("Artificial_sweetener_added_to_tea", "Coffee_intake",
               "Fizzy_drink_intake_SSB", "Low_calorie_drink_intake_ASB",
               "Sugar_added_to_coffee", "Sugar_added_to_tea", "Tea_intake")
src <- c("GCST006414" = "Nielsen 2018", "finngen_R13" = "FinnGen R13")

fit_one <- function(path) {
  d <- fread(path)
  if ("mr_keep" %in% names(d)) d <- d[mr_keep %in% c(TRUE, "TRUE")]
  ok <- complete.cases(d$beta.exposure, d$se.exposure, d$beta.outcome, d$se.outcome)
  d <- d[ok, ]
  f <- tryCatch(mr.raps.mle(b_exp = d$beta.exposure, se_exp = d$se.exposure,
                            b_out = d$beta.outcome, se_out = d$se.outcome,
                            over.dispersion = TRUE, loss.function = "tukey"),
                error = function(e) NULL)
  if (is.null(f)) return(list(n = nrow(d), b = NA, se = NA, p = NA))
  list(n = nrow(d), b = f$beta.hat, se = f$beta.se, p = f$beta.p.value)
}

for (pass in 1:2) {
  rows <- list()
  for (e in exposures) {
    for (sid in names(src)) {
      path <- file.path(RES, sprintf("dat_%s_ebi_a_%s.csv", e, sid))
      if (sid == "finngen_R13") path <- file.path(RES, sprintf("dat_%s_%s.csv", e, sid))
      r <- fit_one(path)
      rows[[length(rows) + 1]] <- data.table(exposure = e, outcome = src[[sid]],
                                             nsnp = r$n, b = r$b, se = r$se, p = r$p,
                                             pass = pass)
    }
  }
  dt <- rbindlist(rows)
  fwrite(dt, sub("\\.csv$", sprintf("_pass%d.csv", pass), OUT))
  cat("pass", pass, "written\n")
}
