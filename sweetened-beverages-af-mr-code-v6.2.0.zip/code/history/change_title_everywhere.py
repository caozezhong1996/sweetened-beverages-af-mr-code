import io
import shutil
import sys
from pathlib import Path
from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
PKG = Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")
ARC = Path(r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版\JAHA_v525_改稿留档\审读意见_20261028")
OLD = "Sweetened Beverage Consumption and Risk of Atrial Fibrillation: A Two-Sample and Multivariable Mendelian Randomization Study"
NEW = "Genetically Proxied Sweetened Beverage Intake and Atrial Fibrillation: A Two-Sample and Multivariable Mendelian Randomization Study"


def replace_doc(path, core_prefix=""):
    shutil.copy2(path, ARC / f"改标题前备份_{path.name}")
    doc = Document(str(path))
    hits = 0
    for p in doc.paragraphs:
        if OLD in p.text:
            full = p.text.replace(OLD, NEW)
            for run in p.runs:
                run.text = ""
            p.runs[0].text = full
            hits += 1
    assert hits >= 1, (path, hits)
    doc.core_properties.title = core_prefix + NEW
    doc.core_properties.author = "Cao Zezhong"
    doc.core_properties.last_modified_by = "Cao Zezhong"
    doc.save(str(path))
    print("updated", path.name, "visible replacements", hits)


replace_doc(PKG / "Manuscript.docx")
replace_doc(PKG / "Supplement.docx", "Supplemental material: ")
replace_doc(PKG / "Cover_Letter.docx", "Cover letter: ")
replace_doc(ARC / "Analysis_plan_and_deviations_archive_20261028.docx")

# Highlights has no visible full title, but its metadata and backup are updated here.
hl = PKG / "Highlights.docx"
shutil.copy2(hl, ARC / "改标题前备份_Highlights.docx")
doc = Document(str(hl))
doc.core_properties.title = "Highlights: " + NEW
doc.core_properties.author = "Cao Zezhong"
doc.save(str(hl))
print("updated Highlights metadata")

# Guard against the earlier stray title character while changing the title.
man = Document(str(PKG / "Manuscript.docx"))
assert man.paragraphs[0].text == NEW, man.paragraphs[0].text
assert len(NEW.split()) == 15
print("title verified:", NEW)
