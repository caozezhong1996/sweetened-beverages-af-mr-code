# -*- coding: utf-8 -*-
"""Visual pass: render the PDFs page by page and flag content outside the margins."""
import io
import os
import sys

import pymupdf

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
VIS = r"C:\Users\64915\WorkBuddy\2026-10-06-13-49-21\vis"
CM = 28.3465  # pt per cm

for name in ["Manuscript", "Supplement", "Cover_Letter", "Highlights"]:
    pdf = os.path.join(VIS, name + ".pdf")
    doc = pymupdf.open(pdf)
    p0 = doc[0]
    W, H = p0.rect.width, p0.rect.height
    # margins: manuscript 2.54 cm; supplement 1000 twips = 1.76 cm
    margin = 2.54 * CM if name in ("Manuscript", "Cover_Letter", "Highlights") else 1000 / 20 / 2.54 * 2.54
    print(f"\n=== {name}: {doc.page_count} 页, {W/CM:.2f} x {H/CM:.2f} cm, 左/右 {margin/CM:.2f} cm ===")
    over = []
    for i, page in enumerate(doc):
        thr_r = W - margin + 3
        thr_b = H - margin + 3
        worst_r = 0
        for b in page.get_text("blocks"):
            worst_r = max(worst_r, b[2])
        for d in page.get_drawings():
            worst_r = max(worst_r, d["rect"].x1)
        worst_b = 0
        for b in page.get_text("blocks"):
            worst_b = max(worst_b, b[3])
        for d in page.get_drawings():
            worst_b = max(worst_b, d["rect"].y1)
        flags = []
        if worst_r > thr_r:
            flags.append(f"右溢出 {worst_r - thr_r:.0f}pt")
        if worst_b > thr_b:
            flags.append(f"下溢出 {worst_b - thr_b:.0f}pt")
        if flags:
            over.append((i + 1, flags, worst_r))
    if over:
        for pg, fl, wr in over:
            print(f"   p{pg}: {' / '.join(fl)}  (最右 {wr:.0f}pt / 版心右界 {W - margin:.0f}pt)")
    else:
        print("   无越界内容（全部在版心内）")
    doc.close()
