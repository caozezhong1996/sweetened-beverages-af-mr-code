# -*- coding: utf-8 -*-
"""Reset core properties after rebuild, and verify key numbers."""
import io
import re
import sys
from pathlib import Path

from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

P = Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")
T = ("Sweetened Beverage Consumption and Risk of Atrial Fibrillation: A Two-Sample and "
     "Multivariable Mendelian Randomization Study With East Asian Contextual Analysis")

spec = {
    "Manuscript.docx": (T, "Original research", "Mendelian randomization; atrial fibrillation; sugar-sweetened beverages; coffee; genetic correlation"),
    "Supplement.docx": ("Supplemental material: " + T, "Supplemental material", "supplementary tables; sensitivity analyses"),
    "Cover_Letter.docx": ("Cover letter: " + T, "Cover letter", "submission"),
    "Highlights.docx": ("Highlights: " + T, "Highlights", "key findings"),
}
for fn, (title, subj, kw) in spec.items():
    d = Document(P / fn)
    cp = d.core_properties
    cp.author = "Cao Zezhong"
    cp.last_modified_by = "Cao Zezhong"
    cp.title = title
    cp.subject = subj
    cp.keywords = kw
    cp.comments = ""
    d.save(P / fn)
    print(f"meta set: {fn}")

m = Document(P / "Manuscript.docx")
mp = [x.text.strip() for x in m.paragraphs if x.text.strip()]
ai = mp.index("Abstract")
tot = sum(len(mp[j].split()) - 1 for j in range(ai + 1, ai + 8)
          if mp[j].split(":")[0] in ("Background", "Methods and Results", "Conclusions"))
full = "\n".join(mp)
print("\n摘要:", tot, "/250")
print("引文:", len(re.findall(r"(?m)^\d+\.\s", full)))
print("S25 指针恢复:", "per-variant F 29.8–48.7; Table S25" in full)

s = Document(P / "Supplement.docx")
st = " ".join(x.text for x in s.paragraphs)
print("S25 注脚含分代谢物 F:", "for paraxanthine and 32.2-46.2" in st)
