import csv, os
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.section import WD_ORIENT
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

CSV = r"C:\Users\64915\WorkBuddy\2026-10-30-20-42-58\TableS30_per_variant.csv"
OUT = r"C:\Users\64915\WorkBuddy\2026-10-30-20-42-58\TableS30_per_variant.docx"

rows = list(csv.reader(open(CSV, encoding="utf-8-sig")))
head, body = rows[0], rows[1:]

doc = Document()
st = doc.styles["Normal"]
st.font.name = "Calibri"
st.font.size = Pt(7.5)
st._element.rPr.rFonts.set(qn("w:eastAsia"), "\u5fae\u8f6f\u96c5\u9ed1")

sec = doc.sections[0]
sec.orientation = WD_ORIENT.LANDSCAPE
sec.page_width, sec.page_height = Cm(29.7), Cm(21.0)
sec.left_margin = sec.right_margin = Cm(1.4)
sec.top_margin = sec.bottom_margin = Cm(1.4)

p = doc.add_paragraph()
r = p.add_run("Table S30. Per-variant instrument-level estimates for coffee intake against atrial fibrillation "
              "(Nielsen 2018, FinnGen R13 and Yuan 2025)")
r.bold = True
r.font.size = Pt(9)

tb = doc.add_table(rows=1, cols=len(head))
tb.style = "Table Grid"
tb.alignment = WD_TABLE_ALIGNMENT.CENTER

widths = [3.5, 2.2, 1.5, 2.1, 1.2, 1.2, 1.5, 1.5, 1.0, 1.4, 1.4, 1.3, 1.3, 1.3]

for i, h in enumerate(head):
    cell = tb.rows[0].cells[i]
    cell.text = ""
    par = cell.paragraphs[0]
    par.paragraph_format.space_after = Pt(0)
    run = par.add_run(h)
    run.bold = True
    run.font.size = Pt(7)
    cell.width = Cm(widths[i])

# repeat header row
trPr = tb.rows[0]._tr.get_or_add_trPr()
th = OxmlElement("w:tblHeader")
th.set(qn("w:val"), "true")
trPr.append(th)

for rec in body:
    cells = tb.add_row().cells
    for i, v in enumerate(rec):
        cells[i].text = ""
        par = cells[i].paragraphs[0]
        par.paragraph_format.space_after = Pt(0)
        par.paragraph_format.line_spacing = 1.0
        run = par.add_run(v)
        run.font.size = Pt(7)
        cells[i].width = Cm(widths[i])

notes = [
    "Estimates are per-SNP Wald ratios (beta_outcome / beta_exposure) with 95% confidence intervals derived from "
    "SE_outcome / |beta_exposure|. F = beta_exposure^2 / SE_exposure^2. Positions are GRCh37.",
    "For the Yuan 2025 outcome, exposure-side parameters (beta_exposure, SE_exposure, alleles, allele frequency, "
    "position) are those of the primary exposure GWAS (ukb-b-5237), because the released Yuan file carries outcome "
    "statistics only; the same instrument set and scaling are therefore used across sources.",
    "rs1421085 (FTO, chr16:53,866,583) carries the largest individual Wald ratio against Yuan 2025 (OR 9.95, "
    "6.59-15.02; F = 127.2) and rs13387939 (TMEM18) the second largest (OR 10.67, 5.91-19.29; F = 59.9). "
    "Both are strong instruments rather than weak ones; across the three sources these two variants yielded "
    "Wald ORs of 4.86-19.66 (rs1421085) and 9.23-32.06 (rs13387939). An effect of this magnitude for a single "
    "adiposity variant acting through coffee intake is not biologically credible, and indicates failure of the "
    "exclusion-restriction assumption at these variants.",
    "Per-variant estimates are shown for the three outcome sources for which harmonised instrument-level data were "
    "retained. AFGen 2018 and BioBank Japan estimates are summarized at the exposure level in Table S2.",
    "Nominal per-variant associations are not interpreted individually; they are provided so that the "
    "instrument-level basis of the aggregate estimates, the leave-one-out analyses and the adiposity-locus "
    "sensitivity analysis can be verified.",
]
doc.add_paragraph()
for i, n in enumerate(notes, 1):
    par = doc.add_paragraph()
    par.paragraph_format.space_after = Pt(2)
    run = par.add_run(("" if i > 1 else "") + n)
    run.font.size = Pt(7.5)

doc.save(OUT)
print("saved", OUT, "rows", len(body))
