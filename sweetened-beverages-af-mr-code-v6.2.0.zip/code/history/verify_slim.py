# -*- coding: utf-8 -*-
"""Verify the slimmed package: contents, no version tokens, README refs, docx metadata."""
import io
import re
import sys
import zipfile
from pathlib import Path

from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

PKG = Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")
MASTER = Path(r"C:\Users\64915\Desktop\维护母版_心脏—胃肠_改稿只在这里\奶茶房颤MR_JAHA")

files = sorted(p for p in PKG.rglob("*") if p.is_file())
print(f"=== 投稿包 {len(files)} 个文件 ===")
for p in files:
    print(f"  {(p.stat().st_size/1024):7.0f} KB  {p.relative_to(PKG)}")
total = sum(p.stat().st_size for p in files)
print(f"  合计 {total/1024/1024:.2f} MB")

print("\n=== 文件名版本标注检查 ===")
bad = [p.name for p in files if re.search(r"(?i)(^|[_\W])v\d", p.name) or "旧版" in p.name]
print("  PASS — 无版本标注" if not bad else f"  FAIL — {bad}")

print("\n=== README 引用一致性 ===")
rd = (PKG / "README_投稿包.md").read_text(encoding="utf-8")
refs = re.findall(r"`([A-Za-z0-9_./]+\.(?:docx|png))`", rd)
missing = [r for r in refs if not (PKG / r).exists()]
unlisted = [str(p.relative_to(PKG)).replace("\\", "/") for p in files
            if p.name != "README_投稿包.md" and str(p.relative_to(PKG)).replace("\\", "/") not in refs]
print(f"  README 引用 {len(refs)} 个；缺失 {missing or '无'}；未列出 {unlisted or '无'}")
print("  PASS" if not missing and not unlisted else "  FAIL")

print("\n=== docx 内部版本标注检查（可能被编辑看到）===")
for p in sorted(PKG.glob("*.docx")):
    d = Document(p)
    cp = d.core_properties
    meta = {k: getattr(cp, k) for k in ("title", "subject", "keywords", "comments", "category")}
    hits = {k: v for k, v in meta.items() if v and re.search(r"(?i)\bv?5\.\d|v5", str(v))}
    hdr = []
    for s in d.sections:
        for part in (s.header, s.footer):
            t = " ".join(par.text for par in part.paragraphs).strip()
            if t:
                hdr.append(t)
    hdr_v = [t for t in hdr if re.search(r"(?i)\bv?\d\.\d\b", t)]
    body = "\n".join(par.text for par in d.paragraphs)
    body_v = re.findall(r"(?i)\bv5\.\d+\.?\d*\b", body)[:5]
    print(f"  {p.name:<22} 元数据命中 {hits or '无'} | 页眉页脚 {hdr_v or '无'} | 正文 'v5.x' {body_v or '无'}")

print("\n=== 母版 ===")
for p in sorted(MASTER.rglob("*")):
    if p.is_file():
        print(f"  {(p.stat().st_size/1024):7.0f} KB  {p.relative_to(MASTER)}")
