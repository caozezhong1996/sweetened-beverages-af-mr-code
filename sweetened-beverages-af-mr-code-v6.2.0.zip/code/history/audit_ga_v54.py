# -*- coding: utf-8 -*-
"""Post-change audit: every string and number in GA v54 checked against the manuscript."""
import io
import re
import sys

import matplotlib
matplotlib.use("Agg")
from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

SRC = r"C:\Users\64915\WorkBuddy\2026-10-06-13-49-21\build_ga_v54.py"
MS = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\manuscript_v52_JAHA.docx"
SUP = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\supplement_v52_JAHA.docx"

ns = {"__name__": "__main__"}
exec(compile(open(SRC, encoding="utf-8").read(), "ga", "exec"), ns)

ga = []
for s in ns["sections"]:
    for b in (s.blocks or [s.block]):
        for text, *_ in b.items:
            ga.append(text)
GA = " ".join(t.replace("\n", " ") for t in ga).strip()

words = [w for w in re.split(r"\s+", GA) if re.search(r"[A-Za-z0-9]", w)]
print(f"GA words: {len(words)}   (v53 was 236)")

# ---- manuscript corpus (normalise dashes, quotes, spacing) ----
def norm(s):
    s = s.replace("\u2013", "-").replace("\u2014", "-").replace("\u2212", "-")
    s = s.replace("\u00a0", " ").replace("\u2009", " ")
    return re.sub(r"\s+", " ", s)


ms = norm(" ".join(p.text for p in Document(MS).paragraphs))
sup = norm(" ".join(p.text for p in Document(SUP).paragraphs)
           + " " + " ".join(c.text for t in Document(SUP).tables
                            for r in t.rows for c in r.cells))
corpus = ms + " " + sup

print("\n--- numbers in the GA ---")
nums = sorted(set(re.findall(r"\d[\d,\.]*", GA)))
for n in nums:
    where = "Methods/Results" if n in ms else ("Supplement only" if n in sup else "NOT FOUND")
    mark = "ok  " if n in corpus else "??  "
    print(f"  {mark}{n:<12} {where}")

print("\n--- required fixes present ---")
need = {
    "P0-2 order DATA->DESIGN": GA.find("DATA") < GA.find("DESIGN") < GA.find("KEY FINDINGS"),
    "P0-3 likely reflect": "likely reflect adiposity-related confounding" in GA,
    "P1-2 7 beverage phenotypes": "7 beverage phenotypes" in GA,
    "P1-3 sweetener added to tea": "sweetener added to tea" in GA,
    "P1-4 metabolite result": "paraxanthine null" in GA,
    "P1-5 power caveat": "moderate-to-large effects are excluded" in GA,
    "P1-5 than at beverage avoidance": "than at beverage avoidance" in GA,
    "P1-6 not robust wording": "Not robust" in GA,
    "P2-2 no maths glyph": "\u2260" not in GA,
    "P2-3 bar holds KEY FINDINGS": any(s.bar for s in ns["sections"]),
    "non-overlapping FinnGen": "non-overlapping FinnGen" in GA,
}
for k, v in need.items():
    print(("  PASS  " if v else "  FAIL  ") + k)

print("\n--- forbidden (removed) strings ---")
bad = {
    "P >= 0.11 (MR-RAPS)": "0.11" in GA,
    "fails every consistency test": "fails every consistency" in GA,
    "best explained": "best explained" in GA,
    "7 beverages +": "7 beverages +" in GA,
    "sweetener in tea": "sweetener in tea" in GA,
    "= causation glyph": "\u2260" in GA,
}
for k, v in bad.items():
    print(("  PASS  " if not v else "  FAIL  ") + k)

print("\n--- sentence-by-sentence ---")
for t in ga:
    print("  •", t.replace("\n", " / "))
