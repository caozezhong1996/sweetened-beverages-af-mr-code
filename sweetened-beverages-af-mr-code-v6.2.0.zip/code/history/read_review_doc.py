# -*- coding: utf-8 -*-
"""Extract full text, tables, comments and tracked-change counts from a docx."""
import io
import re
import sys
import zipfile
from docx import Document
from docx.table import Table
from docx.text.paragraph import Paragraph

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

P = r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版\JAHA_v525_改稿留档\审读意见_20261026\审读意见_审稿人+编辑_20261026.docx"

doc = Document(P)
body = doc.element.body
out = []
for child in body.iterchildren():
    tag = child.tag.split("}")[-1]
    if tag == "p":
        p = Paragraph(child, doc)
        t = p.text.strip()
        if t:
            st = p.style.name if p.style is not None else ""
            out.append(("H:" + st if st.lower().startswith(("heading", "title")) else "") + t)
    elif tag == "tbl":
        tb = Table(child, doc)
        out.append("【表格】")
        for row in tb.rows:
            out.append("  | " + " | ".join(c.text.strip().replace("\n", " ") for c in row.cells))

print("\n".join(out))

z = zipfile.ZipFile(P)
names = z.namelist()
print("\n\n===== 结构信息 =====")
print("media:", [n for n in names if n.startswith("word/media/")])
if "word/comments.xml" in names:
    x = z.read("word/comments.xml").decode("utf-8", "ignore")
    cs = re.findall(r'<w:comment [^>]*w:author="([^"]*)"[^>]*>(.*?)</w:comment>', x, re.S)
    print(f"批注 {len(cs)} 条:")
    for a, body_ in cs:
        txt = re.sub(r"<[^>]+>", "", body_).strip()
        print(f"  [{a}] {txt[:300]}")
else:
    print("无批注")
doc_xml = z.read("word/document.xml").decode("utf-8", "ignore")
print("修订痕迹 w:ins =", doc_xml.count("<w:ins "), " w:del =", doc_xml.count("<w:del "))
