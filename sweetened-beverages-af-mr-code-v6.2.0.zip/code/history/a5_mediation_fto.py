# -*- coding: utf-8 -*-
"""A5 sensitivity: re-run the mediation after removing FTO-region coffee instruments."""
import csv
import io
import math
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

R = r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\06_升级分析_v4\results"

step1 = list(csv.DictReader(open(R + r"\mediation_step1_dat_coffee_bmi_v46.csv", encoding="utf-8")))
cof = list(csv.DictReader(open(R + r"\dat_Coffee_intake_ebi_a_GCST006414.csv", encoding="utf-8")))
pos = {r["SNP"]: (r.get("chr", ""), r.get("pos", "")) for r in cof}

print("=== 17 个中介工具的染色体位置 ===")
for r in step1:
    c, p = pos.get(r["SNP"], ("?", "?"))
    flag = ""
    try:
        if str(c) in ("16", "chr16") and 53_200_000 < int(float(p)) < 54_400_000:
            flag = "  <== FTO 区域"
    except ValueError:
        pass
    print(f"  {r['SNP']:<14} chr{c}:{p}{flag}")

FTO = [r for r in step1
       if str(pos.get(r["SNP"], ("", ""))[0]) in ("16", "chr16")
       and pos.get(r["SNP"], ("", "0"))[1] not in ("", None)
       and 53_200_000 < float(pos[r["SNP"]][1]) < 54_400_000]

print(f"\nFTO 区域（chr16:53.2–54.4 Mb）内的工具：{[r['SNP'] for r in FTO]}")


def ivw(rows):
    num = den = 0.0
    for r in rows:
        bx, sx = float(r["beta.exposure"]), float(r["se.exposure"])
        by, sy = float(r["beta.outcome"]), float(r["se.outcome"])
        w = 1.0 / sy ** 2
        num += w * bx * by
        den += w * bx * bx
    b = num / den
    se = math.sqrt(1.0 / den)
    q = sum(((by - b * bx) ** 2) / (sy ** 2) for r in rows for by, bx, sy in
            [(float(r["beta.outcome"]), float(r["beta.exposure"]), float(r["se.outcome"]))])
    return b, se, q, len(rows)


b2, se2 = 0.3428, 0.0265          # BMI -> AF (Nielsen), Table S16
total, total_se = 0.2347, 0.1120  # coffee -> AF (Nielsen), Table S16

for tag, rows in (("all 17 instruments", step1),
                  ("FTO removed", [r for r in step1 if r not in FTO])):
    b1, se1, q, n = ivw(rows)
    ind = b1 * b2
    ind_se = math.sqrt((b2 * se1) ** 2 + (b1 * se2) ** 2)
    direct = total - ind
    print(f"\n--- {tag} (n={n}) ---")
    print(f"  step1 coffee->BMI : beta={b1:+.4f}  SE={se1:.4f}  P={2*(1-0.5*(1+math.erf(abs(b1/se1)/math.sqrt(2)))):.3g}  Q={q:.1f}")
    print(f"  indirect          : {ind:+.4f}  SE={ind_se:.4f}  95%CI {ind-1.96*ind_se:+.3f} to {ind+1.96*ind_se:+.3f}")
    print(f"  proportion mediated: {ind/total*100:.0f}%")
    print(f"  direct (total-ind) : {direct:+.4f}   OR={math.exp(direct):.3f}")
