# -*- coding: utf-8 -*-
"""Deploy v53 figures (GA + Figure 1) into the JAHA package and update README."""
import shutil
from pathlib import Path

SRC = Path(r"C:/Users/64915/Documents/kimi/workspace/奶茶房颤MR_迁移包_20260822/06_升级分析_v4/figures")
PKG = Path(r"C:/Users/64915/Desktop/JAHA投稿包_奶茶房颤MR_20261013")
FIG = PKG / "figures"

pairs = [
    ("Graphical_Abstract_v53_300dpi.png", "Graphical_Abstract_v52_300dpi.png"),
    ("Figure1_Study_Design_v53_300dpi.png", "Figure1_Study_Design_v52_300dpi.png"),
]
for new, old in pairs:
    s, d = SRC / new, FIG / new
    shutil.copy2(s, d)
    print(f"copied {new}  {d.stat().st_size/1024:.0f} KB")
    o = FIG / old
    if o.exists():
        dst = PKG / old.replace(".png", "_旧版_已移出.png")
        shutil.move(str(o), str(dst))
        print(f"  moved old {old} -> {dst.name}")

# README
rd = PKG / "README_投稿包.md"
t = rd.read_text(encoding="utf-8")
t = t.replace("figures/Figure1_Study_Design_v52_300dpi.png", "figures/Figure1_Study_Design_v53_300dpi.png")
t = t.replace("figures/Graphical_Abstract_v52_300dpi.png", "figures/Graphical_Abstract_v53_300dpi.png")
t = t.replace("图 1 · 研究设计（含生物标志物臂）", "图 1 · 研究设计（含生物标志物臂；v53 版式重排）")
t = t.replace("图文摘要（含代谢物与三阶段收敛）", "图文摘要（含代谢物与三阶段收敛；v53 版式重排）")
rd.write_text(t, encoding="utf-8")
print("README updated")

for f in sorted(FIG.iterdir()):
    print("  ", f.name, f"{f.stat().st_size/1024:.0f} KB")
