# -*- coding: utf-8 -*-
"""Option B patch: retitle (drop the East Asian subtitle) and add the
component-level caveat to the abstract conclusion, with word budget enforced."""
import io
import pathlib
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

BASE = pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
                    r"\04_docx构建脚本")
MAN = BASE / "build_manuscript_v51_JAHA.js"
SUP = BASE / "build_supplement_v51_JAHA.js"
CL = BASE / "build_cover_letter_v51_JAHA.js"
META = pathlib.Path(r"C:\Users\64915\WorkBuddy\2026-10-06-13-49-21\reset_meta_a3.py")

OLD_TITLE = ("Sweetened Beverage Consumption and Risk of Atrial Fibrillation: A Two-Sample and "
             "Multivariable Mendelian Randomization Study With East Asian Contextual Analysis")
NEW_TITLE = ("Sweetened Beverage Consumption and Risk of Atrial Fibrillation: A Two-Sample and "
             "Multivariable Mendelian Randomization Study")

OLD_MR = ("T`Methods and Results: Seven beverage phenotypes were instrumented in UK Biobank "
          "(N = 64,949–447,485). AF statistics came from Nielsen 2018 (60,620; primary), two "
          "overlap-free co-primary sources (FinnGen R13, 67,783; UK Biobank-free Yuan 2025, "
          "192,851) and BioBank Japan (8,180; East Asian context). Robust estimators, multivariable MR, "
          "colocalization and LD-score regression were applied. No sweetened-beverage exposure showed "
          "evidence of a causal association with AF (European meta-analytic odds ratios 0.82–0.97, "
          "P ≥ 0.06; UK Biobank-free panel 0.76–1.04, P ≥ 0.083). A coffee association recurred in "
          "every source (meta-analytic OR 1.34, 1.11–1.62; UK Biobank-free 1.79, 1.23–2.60) but was "
          "carried by adiposity-locus instruments: excluding variants within 500 kb of "
          "body-mass-index loci reduced it to 1.26 (0.90–1.75) in Yuan 2025 and 1.39 (0.94–2.04) in "
          "FinnGen R13, converging all three estimates on 1.26–1.39. Sweetened-beverage traits "
          "nonetheless showed positive genetic correlations with AF (rg = 0.24–0.31; FDR q < 0.05). "
          "Caffeine and paraxanthine instruments were null (P ≥ 0.31); theobromine's nominal inverse "
          "association (P = 0.029) did not survive Bonferroni correction.`")

NEW_MR = ("T`Methods and Results: Seven beverage phenotypes were instrumented in UK Biobank "
          "(N = 64,949–447,485). AF data came from Nielsen 2018 (60,620; primary), two overlap-free "
          "co-primary sources (FinnGen R13, 67,783; UK Biobank-free Yuan 2025, 192,851) and BioBank "
          "Japan (8,180). Complementary estimators, multivariable MR and colocalization were applied. "
          "No sweetened-beverage exposure showed evidence of a causal association with AF (European "
          "meta-analytic odds ratios 0.82–0.97, P ≥ 0.06; UK Biobank-free 0.76–1.04, P ≥ 0.083). "
          "A coffee association recurred in all sources (meta-analytic OR 1.34, 1.11–1.62; "
          "UK Biobank-free 1.79, 1.23–2.60) but was carried by adiposity-locus instruments: excluding "
          "variants within 500 kb of body-mass-index loci reduced it to 1.26 (0.90–1.75) in Yuan 2025 "
          "and 1.39 (0.94–2.04) in FinnGen R13, converging the three estimates on 1.26–1.39. "
          "Sweetened-beverage traits nonetheless showed positive genetic correlations with AF "
          "(rg = 0.24–0.31; q < 0.05). Caffeine and paraxanthine instruments were null (P ≥ 0.31); "
          "theobromine's nominal inverse association (P = 0.029) did not survive correction.`")

OLD_CON = ("T`Conclusions: Genetically proxied sweetened-beverage intake showed no evidence of a causal "
           "association with AF; moderate-to-large effects are excluded, small ones are not. The one "
           "recurring coffee signal was carried by adiposity-locus instruments, so observational "
           "associations most plausibly reflect adiposity-related confounding; direct milk-tea studies "
           "in East Asian cohorts remain needed.`")

NEW_CON = ("T`Conclusions: Genetically proxied sweetened-beverage intake showed no evidence of a causal "
           "association with AF; moderate-to-large effects are excluded, small ones are not, and "
           "component-level nulls cannot certify the safety of composite milk-tea beverages. The one "
           "recurring coffee signal was carried by adiposity-locus instruments, so observational "
           "associations most plausibly reflect adiposity-related confounding; direct milk-tea studies "
           "in East Asian cohorts remain needed.`")

ok = True

# 1-2. manuscript: abstract blocks
t = MAN.read_text(encoding="utf-8")
for label, old, new in [("abstract M&R", OLD_MR, NEW_MR), ("abstract conclusions", OLD_CON, NEW_CON)]:
    c = t.count(old)
    print(("PASS  " if c == 1 else f"FAIL x{c}  ") + label)
    if c != 1:
        ok = False
    else:
        t = t.replace(old, new)
if ok:
    MAN.write_text(t, encoding="utf-8", newline="\n")

# 3. title in three builders
for path in (MAN, SUP, CL):
    s = path.read_text(encoding="utf-8")
    c = s.count(OLD_TITLE)
    print(("PASS  " if c == 1 else f"FAIL x{c}  ") + f"title in {path.name}")
    if c != 1:
        ok = False
        continue
    path.write_text(s.replace(OLD_TITLE, NEW_TITLE), encoding="utf-8", newline="\n")

# 4. metadata script
s = META.read_text(encoding="utf-8")
if OLD_TITLE in s:
    META.write_text(s.replace(OLD_TITLE, NEW_TITLE), encoding="utf-8", newline="\n")
    print("PASS  title in reset_meta_a3.py")
else:
    print("SKIP  reset_meta_a3.py (title already updated or different)")

if ok:
    print("\nnew title:", NEW_TITLE)
    print("length:", len(NEW_TITLE.split()), "words")
else:
    print("\nABORTED - one or more anchors missing")
