# -*- coding: utf-8 -*-
"""提取 JAHA v5.2 手稿全文关键部分。"""
import io, sys
from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
P = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\manuscript_v52_JAHA.docx"
doc = Document(P)
paras = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
print("总段落数:", len(paras))
print("=" * 70)
print("【前 10 段：标题/作者/摘要】")
for i, p in enumerate(paras[:10]):
    print(f"[{i}] {p[:600]}")
    print("-" * 40)
print("【含 biomarker/paraxanthine/theobromine/caffeine metabolite 的段落】")
for i, p in enumerate(paras):
    low = p.lower()
    if any(k in low for k in ["paraxanthine", "theobromine", "biomarker", "chen et al", "plasma caffeine"]):
        print(f"[{i}] {p[:700]}")
        print("-" * 40)
print("【Clinical Perspective】")
for i, p in enumerate(paras):
    if "clinical perspective" in p.lower() or "what is new" in p.lower() or "what are the clinical" in p.lower():
        print(f"[{i}] {p[:500]}")
        print("-" * 40)
