# -*- coding: utf-8 -*-
"""Clamp table widths to the printable text column inside both builders.

The builders set `width: 100%` but also pass absolute `columnWidths`; Word
renders from the column widths, so any array summing above the text column
overflows the margin. Normalising here fixes every table, present and future.
"""
import io
import pathlib
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

NEW_FN = """const MAX_TABLE_TWIPS = {maxw};   // printable text column
const fitWidths = (widths) => {{
  const total = widths.reduce((a, b) => a + b, 0);
  if (total <= MAX_TABLE_TWIPS) return widths;
  const scaled = widths.map((w, i) =>
    i === widths.length - 1 ? 0 : Math.max(320, Math.round(w * MAX_TABLE_TWIPS / total)));
  const used = scaled.reduce((a, b) => a + b, 0);
  scaled[scaled.length - 1] = MAX_TABLE_TWIPS - used;
  return scaled;
}};
"""

TARGETS = [
    (r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
     r"\04_docx构建脚本\build_manuscript_v51_JAHA.js", 9026),
    (r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
     r"\04_docx构建脚本\build_supplement_v51_JAHA.js", 9906),
]

for path, maxw in TARGETS:
    p = pathlib.Path(path)
    t = p.read_text(encoding="utf-8")
    name = p.name
    if "fitWidths" in t:
        print(f"{name}: already patched")
        continue

    helper = NEW_FN.format(maxw=maxw)

    # manuscript: makeTable(widths, headerRow, bodyRows)
    old_m = """const makeTable = (widths, headerRow, bodyRows) =>
  new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    columnWidths: widths,"""
    new_m = helper + """const makeTable = (widths0, headerRow, bodyRows) => {
  const widths = fitWidths(widths0);
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    columnWidths: widths,"""

    # supplement: makeTable(widths, headerRow, bodyRows, size = 20)
    old_s = """const makeTable = (widths, headerRow, bodyRows, size = 20) =>
  new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    columnWidths: widths,"""
    new_s = helper + """const makeTable = (widths0, headerRow, bodyRows, size = 20) => {
  const widths = fitWidths(widths0);
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    columnWidths: widths,"""

    if t.count(old_m) == 1:
        t = t.replace(old_m, new_m)
        # close the arrow-function body: the original ends with "});"
        old_tail = """      ...bodyRows.map((row) => new TableRow({ children: row.map((parts, i) => cell(parts, widths[i])) })),
    ],
  });"""
        new_tail = """      ...bodyRows.map((row) => new TableRow({ children: row.map((parts, i) => cell(parts, widths[i])) })),
    ],
  });
};"""
        assert t.count(old_tail) == 1, "manuscript tail"
        t = t.replace(old_tail, new_tail)
        kind = "manuscript"
    elif t.count(old_s) == 1:
        t = t.replace(old_s, new_s)
        old_tail = """      ...bodyRows.map((r) => new TableRow({ children: r.map((t, i) => cell(t, widths[i], size)) })),
    ],
  });"""
        new_tail = """      ...bodyRows.map((r) => new TableRow({ children: r.map((t, i) => cell(t, widths[i], size)) })),
    ],
  });
};"""
        assert t.count(old_tail) == 1, "supplement tail"
        t = t.replace(old_tail, new_tail)
        kind = "supplement"
    else:
        print(f"{name}: makeTable signature not matched - skipped")
        continue

    p.write_text(t, encoding="utf-8", newline="\n")
    print(f"{name}: patched ({kind}, max {maxw} twips = {maxw/567:.2f} cm)")
