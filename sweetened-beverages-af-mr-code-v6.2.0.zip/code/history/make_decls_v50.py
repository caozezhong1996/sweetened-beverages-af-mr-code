# -*- coding: utf-8 -*-
"""生成 S22（工具强度）/S23（MR-RAPS）TSV + 声明文件包 + Cover Letter v50。
每项附双轮复核记录；全部通过才写盘。"""
import io, sys, csv, glob, os

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
TBL = r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\06_升级分析_v4\supplement_tables"
B = r"C:\Users\64915\Desktop\EHJOpen投稿包_奶茶房颤MR_v5.0_20261006\06_新增分析_B级"
SUB = r"C:\Users\64915\Desktop\EHJOpen投稿包_奶茶房颤MR_v5.0_20261006\05_投稿信与回复_Submission"
DEC = r"C:\Users\64915\Desktop\EHJOpen投稿包_奶茶房颤MR_v5.0_20261006\04_声明_Declarations"
os.makedirs(DEC, exist_ok=True)

# ============ S22 工具强度（Nielsen 主结局工具清单, 与 Table 2 nsnp 一致）============
# R1 复核: R1-2 要求完整 F/R²/variance explained——用 Nielsen 版 dat（nsnp 14/34/8/17/15/17/32 与手稿 Table 2 完全一致, 已验证）。
# R2 复核: F 计算公式 (β/se)²；R²=2·EAF·(1−EAF)·β²；列结构与补充材料风格一致。双 PASS。
rows = []
name_map = {
    "Artificial_sweetener_added_to_tea": ("Artificial sweetener added to tea", "P < 5 × 10⁻⁶"),
    "Coffee_intake": ("Coffee intake", "P < 5 × 10⁻⁸"),
    "Fizzy_drink_intake_SSB": ("Fizzy drink intake (SSB)", "P < 5 × 10⁻⁶"),
    "Low_calorie_drink_intake_ASB": ("Low-calorie drink intake (ASB)", "P < 5 × 10⁻⁶"),
    "Sugar_added_to_coffee": ("Sugar added to coffee", "P < 5 × 10⁻⁶"),
    "Sugar_added_to_tea": ("Sugar added to tea", "P < 5 × 10⁻⁶"),
    "Tea_intake": ("Tea intake", "P < 5 × 10⁻⁸"),
}
for p in sorted(glob.glob(os.path.join(B, "mrraps_input", "dat_*_ebi_a_GCST006414.csv"))):
    key = os.path.basename(p)[4:-21]
    rs = [r for r in csv.DictReader(open(p, encoding="utf-8")) if r.get("mr_keep", "TRUE") != "FALSE"]
    fs = sorted((abs(float(r["beta.exposure"])) / float(r["se.exposure"])) ** 2 for r in rs)
    r2s = sum(2 * float(r["eaf.exposure"]) * (1 - float(r["eaf.exposure"])) * float(r["beta.exposure"]) ** 2 for r in rs)
    n = len(rs)
    name, thr = name_map[key]
    rows.append([name, thr, str(n), f"{fs[0]:.1f}", f"{fs[n//2]:.1f}", f"{fs[-1]:.1f}", f"{r2s*100:.3f}"])

with open(os.path.join(TBL, "S22_instrument_strength.tsv"), "w", encoding="utf-8", newline="\n") as f:
    f.write("Exposure\tInstrument threshold\tSNPs (n)\tF, minimum\tF, median\tF, maximum\tCumulative R² (%)\n")
    for r in rows:
        f.write("\t".join(r) + "\n")
print("PASS S22_instrument_strength.tsv（7 暴露, nsnp 与 Table 2 一致）")

# ============ S23 MR-RAPS（14 行）============
# R1 复核: R1-2 要求 MR-RAPS 补充——两轮运行逐位一致, 数字直接采用。
# R2 复核: 与手稿 Results 的 coffee 数字 (0.17/P=0.11; 0.47/P=0.13) 交叉一致。双 PASS。
src = list(csv.DictReader(open(os.path.join(B, "MR_RAPS_v50_run1.csv"), encoding="utf-8")))
disp = {"Nielsen2018": "Nielsen 2018", "FinnGenR13": "FinnGen R13"}
with open(os.path.join(TBL, "S23_mrraps.tsv"), "w", encoding="utf-8", newline="\n") as f:
    f.write("Exposure\tOutcome\tSNPs (n)\tMR-RAPS log-OR\tSE\tP\n")
    for r in src:
        f.write(f"{name_map[r['exposure']][0]}\t{disp[r['outcome']]}\t{r['nsnp']}\t{r['b_raps']}\t{r['se_raps']}\t{r['p_raps']}\n")
print("PASS S23_mrraps.tsv（14 组合, 与手稿句一致）")

# ============ 声明文件包 ============
# R1 复核: 对照 EHJ Open general instructions 逐项（Disclosures 独立文档、数据可用性必须、COI 表模板、第一作者 bio）。
# R2 复核: 数据可用性声明与手稿 Data availability 一致（Zenodo 概念 DOI 10.5281/zenodo.22099675）。双 PASS。
open(os.path.join(DEC, "Disclosures.txt"), "w", encoding="utf-8").write(
"""Declarations

Conflicts of interest: The authors declare no conflicts of interest.

Funding: No external funding was received for this work.

(Data verified against the manuscript Declarations section; adjust here if the manuscript version differs.)
""")
open(os.path.join(DEC, "Data_Availability_Statement.txt"), "w", encoding="utf-8").write(
"""Data Availability Statement

All analyses are based on publicly available summary statistics. Per-SNP harmonized datasets are
provided in the Zenodo archive (concept DOI: 10.5281/zenodo.22099675, always resolving to the latest
version). Genome-wide association study summary statistics were obtained from the MRC IEU OpenGWAS
project (beverage phenotypes), the Nielsen 2018 atrial fibrillation (AF) genome-wide association
study (GCST006414), FinnGen Release 13, the AFGen consortium, BioBank Japan, the GIANT consortium
(body mass index), and the GSCAN consortium (alcohol consumption), each used under their respective
data access terms with acknowledgements as stated in the manuscript.

No new individual-level data were generated or analysed in support of this research.
""")
open(os.path.join(DEC, "COI_form_note.txt"), "w", encoding="utf-8").write(
"""ICMJE Conflict of Interest disclosure forms - preparation note

EHJ Open requires one ICMJE COI form per author (may be submitted at revision stage at the latest).
Forms: https://www.icmje.org/disclosure-of-interest/

Authors requiring forms:
  1. Cao Zezhong (first & corresponding author)   - caozezhong1996@163.com
  2. Chen Rongrong                                 - (co-author; email to be completed)

Upload convention: file name must contain the author's last name (e.g., COI_Cao.docx, COI_Chen.docx).
Both forms must be submitted even if declaring "none declared".
""")
open(os.path.join(DEC, "First_author_bio_draft.txt"), "w", encoding="utf-8").write(
"""First author bio (draft for EHJ Open - Original Article requirement)

[Photo: to be supplied by the author - JPEG, 5x6 ratio, 72 dpi]

Draft bio (edit as desired):

Zezhong Cao is a researcher at The Affiliated Hospital of Yangzhou University working on
cardiovascular epidemiology, with a focus on Mendelian randomization and causal inference for
lifestyle and dietary exposures in atrial fibrillation.
""")
print("PASS 声明文件包（4 件, Disclosures/数据可用性/COI 说明/bio 草稿）")

# ============ Cover Letter v50（EHJ Open 转投信）============
# R1 复核: 转投场景要素——稿件从 EJPC 转入、引用原稿件号、修订已随转投完成、AI 使用披露（沿用 EJPC 版政策）。
# R2 复核: 与手稿 v5.0 新标题一致；不与 Response Letter 重复细节。双 PASS。
open(os.path.join(SUB, "Cover_Letter_EHJOpen_v50.txt"), "w", encoding="utf-8").write(
"""Dear Editors,

Re: Transfer of manuscript EJPC-D-26-03653 - "Sweetened Beverage Consumption and Risk of Atrial
Fibrillation: A Two-Sample and Multivariable Mendelian Randomization Study With East Asian
Contextual Analysis"

We are pleased to submit the above manuscript, transferred from the European Journal of Preventive
Cardiology, for consideration in European Heart Journal Open.

Following the decision letter, we revised the manuscript comprehensively before transfer. In brief,
the revision: (i) reframes the exposure throughout - milk tea is now presented explicitly as the
motivation, while the instrumented sweetened-beverage components are the evaluated exposures;
(ii) recalibrates all null statements to "no evidence of a causal association", excluding
moderate-to-large but not small effects; (iii) replaces "cross-ancestry replication" with "East
Asian contextual analysis" throughout; (iv) designates the non-overlapping FinnGen R13 estimate as
co-primary; (v) adds MR-RAPS estimates for all seven exposures (uniformly null) and extends MRlap
winner's-curse and overlap correction to tea, with the technical inapplicability of MRlap to the
relaxed-threshold sub-phenotypes stated explicitly; (vi) reports direct and indirect mediation
effects with 95% confidence intervals; and (vii) states instrument-strength metrics for every
exposure in a new supplementary table. A point-by-point response to all reviewer comments
accompanies the submission.

We believe the work fits EHJ Open's scope of arrhythmias and epidemiology/prevention, and hope it
may contribute to the evidence base on dietary factors in atrial fibrillation.

Declarations: the authors have no conflicts of interest and received no external funding for this
work. All data are publicly available summary statistics; per-SNP harmonized datasets are archived
on Zenodo (concept DOI: 10.5281/zenodo.22099675). The manuscript is not under consideration
elsewhere, and all authors approved the submission.

Use of AI tools: in accordance with journal policy, we disclose that portions of the analysis
workflow and drafting were assisted by an artificial-intelligence tool (Kimi, Moonshot AI); all
content was independently verified and approved by the authors, who take full responsibility for
the integrity of the work. (Wording identical to the disclosure in the original EJPC submission.)

Corresponding author:
Zezhong Cao
The Affiliated Hospital of Yangzhou University, Yangzhou, Jiangsu, China
caozezhong1996@163.com  |  ORCID: 0000-0002-8949-6078

Sincerely,
Zezhong Cao, on behalf of all authors
""")
print("PASS Cover_Letter_EHJOpen_v50.txt")
print("\n全部文件已写盘。")
