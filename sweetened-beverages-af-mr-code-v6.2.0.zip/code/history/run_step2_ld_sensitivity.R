suppressMessages({library(data.table); library(ieugwasr); library(TwoSampleMR)})
iv <- fread("C:/a3work/tmp_bmi_instruments_v46.csv")
stopifnot(nrow(iv) == 724)
cl <- ld_clump(dat = dplyr::tibble(rsid = iv$rsid, pval = iv$p, id = "BMI"),
               clump_r2 = 0.001, clump_kb = 10000, pop = "EUR")
dat <- fread("C:/a3work/mediation_step2_dat_bmi_af_v46.csv")
dat <- dat[SNP %in% cl$rsid & mr_keep == TRUE]
stopifnot(all(dat$SNP %in% cl$rsid), nrow(dat) >= 3)
res <- mr(dat, method_list = c("mr_ivw"))
print(res)
fwrite(data.frame(n_input = nrow(iv), n_clumped = nrow(cl), n_mr = nrow(dat), b = res$b, se = res$se, pval = res$pval),
       "C:/a3work/step2_ld_clumped_ivw.csv")
fwrite(dat, "C:/a3work/step2_ld_clumped_dat.csv")
cat("LD-clumped step 2 complete\n")
