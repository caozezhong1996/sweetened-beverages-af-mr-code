# -*- coding: utf-8 -*-
from docx import Document
import pathlib, re, io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
PKG = pathlib.Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")

def set_text(p,text):
    if not p.runs: p.add_run(text)
    else:
        for r in p.runs:r.text=""
        p.runs[0].text=text

def replace(doc,old,new,n=1):
    hits=[p for p in doc.paragraphs if old in p.text]
    assert len(hits)==n,(old,len(hits))
    for p in hits:set_text(p,p.text.replace(old,new))

def replace_para(doc,prefix,text):
    hits=[p for p in doc.paragraphs if p.text.startswith(prefix)]
    assert len(hits)==1,(prefix,len(hits))
    set_text(hits[0],text)

def shift_citations(text):
    def repl(m):
        return "["+re.sub(r"\d+",lambda x:str(int(x.group())+1 if int(x.group())>=5 else int(x.group())),m.group(1))+"]"
    return re.sub(r"\[([0-9,\s–-]+)\]",repl,text)

# --- Manuscript: shift old references 5-46 to 6-47, then insert You as ref 5.
man=Document(str(PKG/"Manuscript.docx"))
refs=[p for p in man.paragraphs if re.match(r"^\d+\.\s",p.text)]
assert len(refs)==46,len(refs)
for p in man.paragraphs:
    t=shift_citations(p.text)
    m=re.match(r"^(\d+)\.\s",t)
    if m and int(m.group(1))>=5:
        t=re.sub(r"^\d+\.",f"{int(m.group(1))+1}.",t, count=1)
    if t!=p.text:set_text(p,t)
ref6=next(p for p in man.paragraphs if p.text.startswith("6. Xie"))
newref=ref6.insert_paragraph_before("5. You X, Guo W, Huang K, et al. Association between genetically predicted dietary patterns and atrial fibrillation: a two sample Mendelian randomization study. Eur J Nutr. 2026;65(3):95. doi:10.1007/s00394-026-03944-6")
newref.style=ref6.style
replace(man,"Previous Mendelian randomization analyses examined individual beverages in smaller outcome resources, without adiposity modelling or East Asian context [4,6,7].","Previous Mendelian randomization analyses examined individual beverages in smaller outcome resources, without adiposity modelling or East Asian context [4,5,6,7].")
replace(man,"For coffee, the literature is mixed: a smaller MR study reported no causal coffee–AF association [4];","For coffee, the literature is mixed: a smaller MR study reported no causal coffee–AF association [4], whereas a 2026 dietary-pattern MR study reported a positive estimate (OR 1.281, 1.036–1.583; P = 0.022) [5];")

# Objective text corrections.
replace(man,"Coffee was associated in primary analyses, but excluding adiposity-locus instruments attenuated estimates to 1.26–1.39; the UK Biobank-free estimate was 1.26 (0.90–1.75), P = 0.178.","Coffee was associated in primary analyses; excluding adiposity-locus instruments narrowed the between-source range from 1.26–1.79 to 1.26–1.39, and only Nielsen 2018 retained a nominal association (1.39, 1.04–1.86; P = 0.028).")
replace(man,"AFGen 2018 estimates were likewise null for all exposures except sugar added to coffee","AFGen 2018 estimates were likewise null for all exposures except sugar added to coffee and coffee intake")
replace(man,"I² = 67%; 0–3% for others","I² = 67%; 0–6% for others")
replace(man,"Between-source heterogeneity (Nielsen 2018 vs FinnGen R13) was negligible for all exposures (I² = 0–3%)","Between-source heterogeneity (Nielsen 2018 vs FinnGen R13) was low for all exposures (I² = 0–6%)")
replace(man,"in the nearly twice-larger primary outcome","in the primary outcome with nearly twice the total sample size")
replace(man,"showed no evidence of a causal association with atrial fibrillation in European or East Asian populations.","showed no evidence of a causal association with atrial fibrillation in European populations; BioBank Japan estimates were imprecise and contextual rather than independent East Asian evidence.")
replace(man,"Coffee findings were not robust across sensitivity analyses. Component-level nulls cannot certify composite milk-tea safety; direct studies remain needed.","Coffee findings were not robust across sensitivity analyses. The sugar-in-tea negative control failed, limiting instrument-specific inference. Component-level nulls cannot certify composite milk-tea safety; direct studies remain needed.")
replace(man,"Two-step mediation MR was exploratory and cannot identify direction at these loci.","Two-step mediation MR was exploratory and cannot identify direction at these loci.")
mvmr=("In MVMR including coffee intake, sugar added to tea and BMI against the primary outcome (Table 4), the BMI estimate was positive "
"(OR 1.47 per SD, 1.37–1.57; P = 2.0 × 10⁻²⁷; 467 exposure-specific instruments), and the coffee estimate was attenuated "
"(OR 0.82, 0.65–1.04; P = 0.099). These are exploratory conditional estimates, not a formal positive-control validation or "
"proof of mediation. The model used 471 joint instruments; Table 4 reports exposure-specific counts. The sugar-added-to-tea "
"estimate relied on a single instrument and is not informative (retained in Table S4). Conditional F statistics were below 10 "
"for all three exposures (coffee 5.2; sugar added to tea 1.3; BMI 7.5; Table S24), so no conditional estimate, including BMI, "
"is treated as definitive and the direction of weak-instrument bias is not assumed.")
replace_para(man,"In MVMR including coffee intake, sugar added to tea and BMI",mvmr)
# Table 4 labels and note.
t4=next(t for t in man.tables if t.rows[0].cells[0].text=="Exposure (conditional)")
t4.rows[0].cells[3].text="Exposure-specific nsnp"
t4.rows[1].cells[4].text="Expected direction; conditional F < 10"
replace(man,"Estimates are MVMR-IVW odds ratios per unit of each exposure conditional on the others. Conditional F statistics (Table S24) were 5.2 (coffee intake), 1.3 (sugar added to tea) and 7.5 (BMI), below the conventional threshold of 10.","Estimates are MVMR-IVW odds ratios per unit of each exposure conditional on the others. The model included 471 joint instruments; nsnp values are exposure-specific (BMI 467, coffee 14). Conditional F statistics (Table S24) were 5.2 (coffee intake), 1.3 (sugar added to tea) and 7.5 (BMI), below the conventional threshold of 10. The single-instrument sugar-added-to-tea estimate is uninformative and is reported only in Table S4.")
# Subgroup difference tests and shared-instrument caveat.
replace(man,"They do not establish absence of a caffeine-handling effect.","Between-subgroup log-OR difference tests were non-significant (P = 0.078 and 0.208), and these subgroups share instruments with the adiposity-exclusion analysis, so they are not independent lines of evidence. They do not establish absence of a caffeine-handling effect.")
# Ethics simplified without inventing an institutional exemption.
replace(man,"All data are de-identified, publicly available summary statistics; per the Chinese Measures for Ethical Review of Life Science and Medical Research Involving Human Subjects (Article 32, 2023), studies using legally obtained public data are exempt from ethics review.","This study used publicly available, de-identified summary statistics; institutional review board approval and informed consent were not required.")
man.save(str(PKG/"Manuscript.docx"))

# --- Supplement: shift manuscript ref numbers, objective notes and subgroup tests.
sup=Document(str(PKG/"Supplement.docx"))
def shift_ref_match(m):
    n=int(m.group(1)); return f"manuscript ref {n+1 if n>=5 else n}"
for p in sup.paragraphs:
    t=re.sub(r"manuscript ref (\d+)",shift_ref_match,p.text)
    t=shift_citations(t)
    if t!=p.text:set_text(p,t)
replace(sup,"which removed 3–19 variants per exposure (median 5)","which removed 2–19 variants per exposure (median 5)")
replace(sup,"independently replicated in FinnGen R13","also observed in FinnGen R13")
replace(sup,"Per-region summary statistics: 03_结果数据_mr_results/upgrade_coloc_*.csv (AFGen), 06_升级分析_v4/results/upgrade_coloc_coffee_loci_Nielsen.csv (Nielsen) and upgrade_coloc_FTO_FinnGenR13.csv (R13).","Per-region summary statistics are available in the colocalization results directory of the Zenodo archive (concept DOI 10.5281/zenodo.22099675).")
replace(sup,"Signal carried entirely by non-caffeine-pathway instruments","Positive estimate in the remaining instruments; between-subgroup difference P = 0.078")
replace(sup,"Replicated in FinnGen R13; weighted median OR 2.16","Positive estimate in FinnGen R13; between-subgroup difference P = 0.208; weighted median OR 2.16")
replace(sup,"The Yuan non-caffeine row includes the two caffeine-window SNPs not recovered in that outcome.","The Yuan non-caffeine row includes the two caffeine-window SNPs not recovered in that outcome. Between-subgroup log-OR difference tests were P = 0.078 (Nielsen 2018) and P = 0.208 (FinnGen R13), so no significant caffeine-versus-remaining subgroup difference was detected. These subgroup analyses share instruments with the adiposity-locus exclusion and are not independent evidence lines.")
sup.save(str(PKG/"Supplement.docx"))

# --- Highlights: symmetric disclosure without removing the main result.
hl=Document(str(PKG/"Highlights.docx"))
replace(hl,"No genetic evidence that sweetened-beverage intake causes atrial fibrillation.","No genetic evidence that sweetened-beverage intake causes AF, but the sugar-in-tea negative control failed.")
hl.save(str(PKG/"Highlights.docx"))

# --- README counts.
rp=PKG/"README_投稿包.md"
t=rp.read_text(encoding="utf-8").replace("46 条参考文献","47 条参考文献")
rp.write_text(t,encoding="utf-8")
print("Text, references and supplement notes updated")
