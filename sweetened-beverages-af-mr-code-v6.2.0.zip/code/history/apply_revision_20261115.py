# -*- coding: utf-8 -*-
import os,re,csv,json,hashlib
from copy import deepcopy
import docx
W=r"C:\Users\64915\WorkBuddy\2026-10-30-20-42-58"
D=os.path.join(W,"_review3_fix")
B=r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013"
LOG={"paragraph_changes":[],"cell_changes":[],"files":{}}
def sha(p): return hashlib.sha256(open(p,"rb").read()).hexdigest()
def set_para(p,new,tag):
    old=p.text
    if old==new: return
    assert p.runs,tag
    p.runs[0].text=new
    for r in p.runs[1:]: r.text=""
    LOG["paragraph_changes"].append({"id":tag,"old":old,"new":new})
def set_cell(c,new,tag):
    old=c.text
    if old==new: return
    p=c.paragraphs[0]
    if p.runs:
        p.runs[0].text=str(new)
        for r in p.runs[1:]: r.text=""
    else: p.add_run(str(new))
    for pp in c.paragraphs[1:]:
        for r in pp.runs: r.text=""
    LOG["cell_changes"].append({"id":tag,"old":old,"new":str(new)})
def replace_para(p,old,new,tag):
    assert old in p.text,(tag,old)
    set_para(p,p.text.replace(old,new),tag)
def f2(x): return f"{float(x):.2f}"
def p3(x):
    x=float(x)
    return "<0.001" if x<0.001 else f"{x:.3f}"
def orci(r,en="–"): return f'{f2(r["OR"])} ({f2(r["lo"])}{en}{f2(r["hi"])})'

# ---------- Manuscript ----------
mpath=os.path.join(B,"Manuscript.docx"); m=docx.Document(mpath); ps=m.paragraphs
new_abs=("Methods and Results: Seven UK Biobank phenotypes were analyzed against Nielsen 2018, FinnGen R13, UK Biobank-free Yuan 2025 (192,851 cases) and BioBank Japan. "
"No sweetened-beverage exposure satisfied the causal criteria (European meta-analytic ORs 0.82–0.97; UK Biobank-free 0.76–1.04); European meta-analytic power to detect OR 1.10 was 13–47%, implying a 1.21–1.38 upper bound, so observational-magnitude effects remained unexcluded. "
"Coffee intake showed nominal associations in Nielsen, FinnGen and AFGen but not Yuan (1.32, 0.99–1.76; P = 0.055); the European meta-analytic OR was 1.34 (1.11–1.62; P = 0.002), the only signal surviving correction in the seven-test family. "
"Default-prior colocalization supported a shared FTO variant with Nielsen (0.894) and FinnGen (0.906), but was prior-sensitive and inconclusive in AFGen (0.362); at CYP1A1–CYP1A2 and AHR the coffee signal had no AF counterpart (PP.H1 ≥ 0.93; PP.H4 ≤ 0.008), as did tea. "
"After adiposity-locus exclusion the coffee estimates were 1.26–1.39; only Nielsen retained a nominal association (1.39, 1.04–1.86; P = 0.028). The sugar-in-tea negative control failed, rendering its null uninterpretable.")
set_para(ps[7],new_abs,"M-P007 abstract")
set_para(ps[14],"• In a unified Mendelian randomization framework of five sweetened-beverage phenotypes and their caffeinated counterparts, across four European AF outcome files including a UK Biobank-free panel of 192,851 cases, genetically proxied sweetened-beverage intake showed no robust evidence of a causal association with AF, although European meta-analytic power to detect OR 1.10 was 13–47%.","M-P014 CP1")
set_para(ps[15],"• The only signal surviving correction in the pre-specified seven-test family (coffee) did not meet the pre-specified consistency criteria and showed default-prior colocalization with AF at FTO (PP.H4 0.894 in Nielsen and 0.906 in FinnGen; inconclusive in AFGen, 0.362), but was prior-sensitive (0.457/0.491 at p12 = 10⁻⁶), rather than at the caffeine-metabolism loci CYP1A1–CYP1A2 and AHR (PP.H4 ≤ 0.008).","M-P015 CP2")
set_para(ps[16],"• Fizzy drink and artificially sweetened beverage intake shared genetic architecture with AF in FinnGen R13 only (rg 0.24–0.31, FDR q < 0.05), showing that shared heritability need not imply causation.","M-P016 CP3")
replace_para(ps[31],"An Author Correction published on 3 October 2025","An Author Correction [58] published on 3 October 2025","M-P031 correction citation")
set_para(ps[39],"Multiplicity. The seven European meta-analytic IVW tests were treated as the primary family and controlled by the Benjamini–Hochberg false discovery rate (q = 0.05); all other analyses were considered supportive or exploratory. This boundary follows the pre-specified design: each exposure contributes one primary estimand, the fixed-effect European meta-analysis of Nielsen 2018 and FinnGen R13. Source-specific estimates are supportive repeated estimation of the same exposure-level question; their correlated cohorts (Table S28) further preclude treating them as independent replication, but do not determine the family boundary. In a sensitivity analysis treating all 28 source-specific IVW tests (four outcome sources × seven exposures) as a single family, no test survived Benjamini–Hochberg correction (threshold P = 0.0018; smallest P = 0.014, for sugar added to tea against FinnGen R13). Analyses used R 4.6.1 with the TwoSampleMR (version 0.7.9) [29], MRPRESSO (version 1.0) [30] and coloc (version 5.2.3) packages; dataset identifiers are listed in Table 1 and analysis code is archived at https://doi.org/10.5281/zenodo.22099675.","M-P039 multiplicity")
replace_para(ps[40],"Causal direction was verified with the Steiger directionality test","Causal directionality was supported by the Steiger directionality test","M-P040 Steiger")
replace_para(ps[40],"prior sensitivity at all three loci was assessed by varying the colocalization prior p12 from 10⁻⁶ to 5 × 10⁻⁵","prior sensitivity was assessed at the caffeine-metabolism loci against Nielsen 2018 and at FTO against Nielsen 2018 and FinnGen R13 by varying p12 from 10⁻⁶ to 5 × 10⁻⁵","M-P040 coloc prior sources")
replace_para(ps[50],"Of the 133 unique instrument variants, 128 (96%) were present in the UK Biobank-free Yuan 2025 panel (137 exposure–instrument pairs before this restriction).","Of the 133 unique instrument variants, 128 (96%) were present in the UK Biobank-free Yuan 2025 panel, corresponding to 132 of 137 exposure–instrument pairs (96%).","M-P050 corrected pairs")
replace_para(ps[54],"MR-PRESSO returned a non-significant global test (P = 0.36) with no outlier (Table S4), so horizontal pleiotropy does not account for this estimate either; we interpret it as a chance finding attributable to winner's curse.","MR-PRESSO did not detect global horizontal pleiotropy or an outlier (P = 0.36; Table S4); we interpret the nominal signal as compatible with chance or selection-related bias rather than as a confirmed winner's-curse effect.","M-P054 MR-PRESSO calibration")
new55=("Coffee intake was nominally associated with higher AF odds in Nielsen 2018 (IVW OR 1.26, 1.02–1.57; P = 0.036), AFGen 2018 (OR 1.26; P = 0.031) and FinnGen R13 (OR 1.58, 1.09–2.29; P = 0.016), but not in the UK Biobank-free Yuan 2025 outcome (OR 1.32, 0.99–1.76; P = 0.055). The pre-specified European meta-analytic OR was 1.34 (1.11–1.62; P = 0.002) and survived Benjamini–Hochberg correction (threshold P = 0.007). "
"The association did not satisfy the pre-specified consistency criteria: significant between-instrument heterogeneity in Nielsen and FinnGen (Cochran's Q P = 9 × 10⁻⁴ and P = 4 × 10⁻¹⁰); null weighted-median (OR 1.16, P = 0.26 and OR 1.29, P = 0.14) and MR-Egger (OR 1.12; P = 0.60) estimates; and MR-PRESSO global heterogeneity in both sources (P = 0.002 and P < 0.001), with outlier correction resolving the estimate to the null in Nielsen 2018 (P = 0.20) but not FinnGen R13 (β = 0.345; P = 0.007; Table S4). In Yuan 2025, heterogeneity remained extreme (Cochran's Q P = 1.2 × 10⁻³⁸), and weighted-median (P = 0.626), MR-Egger (P = 0.925) and MR-RAPS (P = 0.548) estimates were null. The signal therefore does not meet our criteria for credible causal interpretation; a small genuine effect cannot be excluded. "
"The contamination-mixture estimator gave the same source-dependent pattern: null in Nielsen 2018 (β = 0.068, −0.136 to 0.564; P = 0.45) but positive in FinnGen R13 (β = 0.689, 0.257–0.958; P = 0.001; Table S14). Genome-wide CAUSE analysis (1,081,418 shared variants) detected no causal effect: the posterior mean causal effect was centred on zero (γ = 0.01, 95% CI −0.01 to 0.04), and the causal model did not fit significantly better than the correlated-pleiotropy model (P = 0.53), so causal and correlated-pleiotropic explanations could not be separated (Table S15).")
set_para(ps[55],new55,"M-P055 corrected coffee")
new58=("To ask whether the coffee signal tracked the adiposity its instruments index, every exposure was re-estimated after removing each instrument lying within 500 kb of one of 724 genome-wide-significant BMI loci (Table S27), which removed 15–17 of the 32–34 coffee instruments, including rs1421085 at FTO and rs13387939 at TMEM18. Estimates after exclusion were 1.39 (1.04–1.86; P = 0.028) in Nielsen 2018, 1.39 (0.94–2.04; P = 0.096) in FinnGen R13 and 1.26 (0.90–1.75; P = 0.178) in Yuan 2025; the sources overlap and were not pooled, and the descriptive range narrowed from 1.26–1.58 to 1.26–1.39 (log-odds range 0.223 to 0.099). Removing 15–17 of the 32–34 coffee instruments raised the minimum detectable odds ratio from 1.37–1.53 to 1.52–1.73 (Table S27), so the post-exclusion confidence intervals are wider than the unrestricted ones and a null after exclusion cannot be read as elimination of the effect. "
"Two qualifications limit this. Under a zero-covariance approximation, the three unrestricted estimates were not statistically distinguishable (pairwise P = 0.31–0.81; Cochran Q = 1.03, df = 2, P = 0.60, I² = 0%), but the cohort overlap in Table S28 precludes a formal independence assumption. The narrowing is therefore descriptive rather than evidence of convergence on a common value. In addition, 3.8% of 2,000 random deletions per source produced an equally small range; this test does not identify what the excluded variants carry. The exclusion therefore supports, without establishing, an adiposity-linked origin. Among the fifteen sweetened-beverage estimates (five exposures × three sources), ten moved toward the null and five moved away; of the latter, two in Yuan 2025 approached nominal significance: low-calorie drink intake (1.04 to 1.13, 0.99–1.28; P = 0.062) and artificial sweetener added to tea (1.03 to 1.33, 0.99–1.78; P = 0.057). The adiposity explanation therefore does not hold uniformly, and no sweetened-beverage estimate became significant under exclusion.")
set_para(ps[58],new58,"M-P058 corrected exclusion")
replace_para(ps[67],"against the Yuan 2025 replication outcome, including coffee (P = 0.18)","against the Yuan 2025 replication outcome, including coffee (P = 0.548)","M-P067 Yuan RAPS")
replace_para(ps[70],"the two larger outcome GWAS","the two outcome GWAS with larger case counts","M-P070 case count wording")
replace_para(ps[90],"The number of instruments contributing to each panel is given in Table 2 and Table S2.","The number of instruments contributing to each panel is given in Table 2, Table S2 and, for metabolites, Table S25.","M-P090 Figure 2 caption")
oldclass="Across the seven phenotypes, three provide interpretable null estimates (fizzy drink, low-calorie drink and artificial sweetener added to tea), in that within-source heterogeneity was not significant in any of their four outcome panels (Table S3). Three are qualified rather than interpretable: sugar added to coffee showed significant within-source heterogeneity in three of its four panels (Q P = 0.018, 4.1 × 10⁻⁷ and 0.007); sugar added to tea showed the same and also failed the negative control; and tea intake showed both heterogeneity and a near-even split in variant direction (Results; Table S3). Coffee intake is not a null estimate."
newclass=("Using the four panels in Table S3, three phenotypes had no significant within-source heterogeneity (fizzy drink, low-calorie drink and artificial sweetener added to tea). This is not a five-source quality grade: in Yuan 2025, fizzy drink and artificial sweetener added to tea showed significant heterogeneity (Q P = 0.026 and <0.001; Table S26), so only the low-calorie-drink null retained that property across all five sources. Sugar added to coffee, sugar added to tea and tea intake remain qualified by heterogeneity, negative-control failure or opposing variant directions. Coffee intake is not a null estimate.")
replace_para(ps[78],oldclass,newclass,"M-P078 five-source null grading")
new95=("In this two-sample and multivariable Mendelian randomization study, genetically proxied sweetened-beverage intake showed no robust evidence of a causal association with atrial fibrillation across four European outcome files—at most two independent clusters (Table S28)—including a UK Biobank-free panel of 192,851 cases. That null is bounded rather than definitive: European meta-analytic power to detect OR 1.10 was 13–47%, and had that been the true effect the implied upper bound would have been 1.21–1.38. The study's positive contribution is locus-level. The coffee signal was more compatible with adiposity-linked pleiotropy than with a caffeine-specific pathway: default-prior colocalization showed a shared variant at FTO but was prior-sensitive, while a coffee-specific signal with no AF counterpart was observed at the two caffeine-metabolism loci. Instruments restricted to those loci did not reproduce the signal, whereas the remainder did, although the between-subgroup difference was not statistically significant. The UK Biobank-free Yuan coffee estimate was not nominally significant after correction of shared-instrument allocation (OR 1.32, 0.99–1.76), so the signal is not uniformly replicated. After adiposity-locus exclusion the coffee estimates were 1.26–1.39 and descriptively closer under a zero-covariance approximation, and no sweetened-beverage exposure became significant. Neither control validated the pipeline in both directions: the alcohol positive control reached nominal significance only after pooling, and the sugar-in-tea negative control failed. East Asian estimates were imprecise and contextual. The evidence for an adiposity-linked origin therefore rests on two primary lines: colocalization, which localized the shared signal to FTO in the two larger-case-count panels while showing no shared counterpart at the caffeine-metabolism loci; and the instrument-level pattern, in which the two largest single-variant estimates come from adiposity loci whose magnitudes are not biologically credible as coffee-specific effects. The adiposity-locus exclusion provides a post hoc consistency check rather than independent evidence. None alone is decisive; together they make adiposity-linked variation the more parsimonious explanation for the recurring coffee signal.")
set_para(ps[95],new95,"M-P095 conclusion")
replace_para(ps[103],"these two loci could be assessed against Nielsen 2018 only (Table S8)","default-prior results against AFGen 2018 and Nielsen 2018 are shown in Table S8; prior scans for these two loci used Nielsen 2018 only (Table S13)","M-P103 caffeine source coverage")
replace_para(ps[105],"because no heterogeneity was detectable before exclusion","while recognizing that the cross-source test used a zero-covariance approximation","M-P105 zero covariance")
replace_para(ps[107],"the marginal, lifelong effects of individual ingredients","the marginal, lifelong effects of component-related intake behaviors","M-P107 behavior estimand")
replace_para(ps[110],"and a milder version of the same caution applies to sugar added to tea and sugar added to coffee (Results; Table S3).","and a milder version of the same caution applies to sugar added to tea and sugar added to coffee (Results; Table S3). Yuan 2025 also showed significant heterogeneity for fizzy drink and artificial sweetener added to tea (Table S26), so their four-source interpretable-null labels do not extend across all five sources.","M-P110 Yuan heterogeneity")
replace_para(ps[110],"evaluable against a single outcome source at the two caffeine-metabolism loci","prior-scanned against Nielsen 2018 only at the two caffeine-metabolism loci","M-P110 caffeine prior scope")
# ref 9 and add correction as 58 without renumbering
for p in ps:
    if p.text.startswith("9. Li H, Xu J."):
        replace_para(p,"Mendelian randomization. Medicine","Mendelian randomization study. Medicine","M-ref9")
last=next(p for p in ps if p.text.startswith("57. "))
newp=deepcopy(last._p); last._p.addnext(newp)
from docx.text.paragraph import Paragraph
p58=Paragraph(newp,last._parent)
set_para(p58,"58. Yuan S, Chen J, Ruan X, Li Y, Abramowitz SA, Wang L, et al. Author Correction: Cross-population GWAS and proteomics improve risk prediction and reveal mechanisms in atrial fibrillation. Nat Commun. 2025;16:8811. doi:10.1038/s41467-025-64765-5.","M-ref58")
# Table 2: corrected Yuan cells and SNP counts
t=m.tables[1]
yuan=list(csv.DictReader(open(r"C:\a3work\yuan2025_mr_corrected.csv",encoding="utf-8")))
ymap={r["exposure"]:r for r in yuan if r["method"]=="Inverse variance weighted"}
for ri,label in [(2,"Sugar added to coffee"),(6,"Coffee intake")]:
    r=ymap[label]
    set_cell(t.rows[ri].cells[3],f'{f2(r["OR"])} ({f2(r["lo"])}–{f2(r["hi"])}), P\u00a0=\u00a0{p3(r["p"])}',f"M-T2-Yuan-{label}")
old=t.rows[2].cells[5].text; set_cell(t.rows[2].cells[5],"15 / 15 / 15","M-T2-n-sugar-coffee")
set_cell(t.rows[6].cells[5],"34 / 34 / 32","M-T2-n-coffee")
m.save(mpath); LOG["files"]["Manuscript.docx"]={"sha":sha(mpath),"abstract_words":len(new_abs.split())}

# ---------- Supplement ----------
spath=os.path.join(B,"Supplement.docx"); s=docx.Document(spath); sp=s.paragraphs
# S26 from corrected full-precision outputs
q=list(csv.DictReader(open(os.path.join(D,"yuan2025_q_corrected.csv"),encoding="utf-8")))
qmap={r["exposure"]:r for r in q}
labmap={"Sugar added to tea":"Sugar added to tea","Sugar added to coffee":"Sugar added to coffee","Fizzy drink intake (SSB)":"Fizzy drinks (SSB)","Low-calorie drink intake (ASB)":"Low-calorie drinks (ASB)","Artificial sweetener added to tea":"Sweetener added to tea","Coffee intake":"Coffee intake","Tea intake":"Tea intake"}
t=s.tables[27]
for ri in range(1,8):
    label=t.rows[ri].cells[0].text.strip(); y=ymap[labmap[label]]; qq=qmap[label]
    wm=next(r for r in yuan if r["exposure"]==labmap[label] and r["method"]=="Weighted median")
    eg=next(r for r in yuan if r["exposure"]==labmap[label] and r["method"]=="MR Egger")
    ra=next(r for r in yuan if r["exposure"]==labmap[label] and r["method"]=="MR-RAPS")
    vals=[label,str(y["nsnp"]),orci(y,en="-"),p3(y["p"]),p3(wm["p"]),p3(eg["p"]),p3(ra["p"]),"<0.001" if float(qq["Q_P"])<0.001 else f'{float(qq["Q_P"]):.3f}']
    for ci,v in enumerate(vals): set_cell(t.rows[ri].cells[ci],v,f"S26-r{ri}-c{ci}")
# S27 Yuan rows
s27=json.load(open(os.path.join(D,"s27_corrected.json"),encoding="utf-8"))
tagmap={"Sugar added to tea":"Sugar_added_to_tea","Sugar added to coffee":"Sugar_added_to_coffee","Fizzy drink intake (SSB)":"Fizzy_drink_intake_SSB","Low-calorie drink intake (ASB)":"Low_calorie_drink_intake_ASB","Artificial sweetener added to tea":"Artificial_sweetener_added_to_tea","Coffee intake":"Coffee_intake","Tea intake":"Tea_intake"}
t=s.tables[28]
for ri in range(15,22):
    label=t.rows[ri].cells[1].text.strip(); v=s27[tagmap[label]]; a=v["all"]; c=v["clean"]
    vals=[str(a["n"]),orci(a),f2(a["MDE"]),p3(a["P"]),str(c["n"]),orci(c),f2(c["MDE"]),p3(c["P"])]
    for ci,vv in zip(range(2,10),vals): set_cell(t.rows[ri].cells[ci],vv,f"S27-r{ri}-c{ci}")
# S30 full rebuild, non-Yuan rows unchanged and corrected complete Yuan rows
t=s.tables[30+2]  # table object 32
template=deepcopy(t.rows[1]._tr)
for r in list(t.rows)[1:]: t._tbl.remove(r._tr)
rows=list(csv.DictReader(open(os.path.join(D,"TableS30_per_variant_corrected.csv"),encoding="utf-8-sig")))
for rec in rows:
    t._tbl.append(deepcopy(template)); row=t.rows[-1]
    for ci,h in enumerate(rec): set_cell(row.cells[ci],rec[h],f"S30-{rec['SNP']}-{h}")
set_para(sp[71],"rs13387939 (TMEM18) carries the largest individual Wald ratio against Yuan 2025 (OR 10.67, 5.91–19.29; F = 59.9), followed by rs1421085 (FTO; OR 9.95, 6.59–15.02; F = 127.2). Both are strong instruments rather than weak ones. Across the three sources these two variants yielded Wald ORs of 9.23–32.06 (rs13387939) and 4.86–19.66 (rs1421085). An effect of this magnitude for a single adiposity variant acting through coffee intake is not biologically credible, and indicates failure of the exclusion-restriction assumption at these variants rather than a large coffee-specific effect.","S30-note-order")
set_para(sp[72],"Twelve of the 404 per-variant ratios lie outside the range 0.1–10 (Table S30, all exposures). They are not uniformly attributable to weak exposure associations: their printed F statistics range from 24.8 to 127.2 and their within-exposure/source IVW weights from 1.37% to 6.16%. These ratios are retained for completeness and interpreted descriptively rather than as evidence of effect modification.","S30-note-extremes")
# S13 explicit input-output mapping
set_para(sp[30],"The coloc.abf default prior is p12 = 10⁻⁵. The shared-causal-variant conclusion at FTO held for p12 ≥ 5 × 10⁻⁶ in both outcome sources (PP.H4 ≥ 0.81) and weakened under the most stringent prior (p12 = 10⁻⁶; PP.H4 = 0.46–0.49). The coffee-specific pattern at CYP1A1–CYP1A2 and AHR persisted across the same grid (PP.H1 ≥ 0.901 and PP.H4 ≤ 0.041), so no association with AF was detected at these caffeine-handling loci under any tested prior. Table S8 and the default-prior section above retain the original API-based Nielsen FTO merge (1,738 SNPs); the prior scan used a local full-summary-statistic rebuild (1,740 SNPs; a two-rsid multi-mapping difference). Both representations gave PP.H4 = 0.894 at p12 = 10⁻⁵.","S13-note-input-mapping")
# thousands separators only in SNP count columns of S13
for ti in [12,13]:
    tt=s.tables[ti]; hdr=[c.text.strip() for c in tt.rows[0].cells]
    cols=[i for i,h in enumerate(hdr) if h in ("SNPs","No. SNPs")]
    for row in tt.rows[1:]:
        for ci in cols:
            txt=row.cells[ci].text.strip()
            if re.fullmatch(r"\d{4,}",txt): set_cell(row.cells[ci],f"{int(txt):,}",f"S13-thousands-t{ti}-c{ci}")
# S4 BMI terminology and non-significant MR-PRESSO wording
for row in s.tables[3].rows:
    for c in row.cells:
        if "Positive control" in c.text and "BMI" in row.cells[0].text:
            set_cell(c,"Direction check; conditional F < 10, not positive-control validation","S4-BMI-direction-check")
        if "horizontal pleiotropy does not account" in c.text:
            set_cell(c,c.text.replace("horizontal pleiotropy does not account for this estimate","no global horizontal pleiotropy was detected"),"S4-MRPRESSO-calibration")
# STROBE quoted/summarized cells rewritten as summaries
strobe=s.tables[8]
set_cell(strobe.rows[1].cells[3],"MR is indicated in the title and Abstract Background, including the ASB question.","STROBE-1a-summary")
set_cell(strobe.rows[8].cells[3],"Case and control counts are given for each of the five principal AF outcome sources (Nielsen 2018, FinnGen R13, Yuan 2025, AFGen 2018 and BioBank Japan); early-onset AF is a separate sensitivity source. Cohort-level overlap is mapped in Table S28.","STROBE-7-principal-sources")
set_cell(strobe.rows[17].cells[3],"Eight to 34 independent SNPs per exposure were analyzed against the primary outcome (median 17; Table S1). Of 133 unique variants, 128 (96%) were present in Yuan 2025, corresponding to 132 of 137 exposure–instrument pairs (96%); Tables S1 and S31 give panel-specific recovery.","STROBE-14-corrected-counts")
set_cell(strobe.rows[19].cells[3],"Reported in full, including the failed negative control and outcome-source-specific heterogeneity. In Table S3 four panels, fizzy drink, low-calorie drink and artificial sweetener added to tea had no significant heterogeneity; in Yuan 2025 the first and third were heterogeneous (Q P = 0.026 and <0.001), so only the low-calorie-drink null retained that property across all five sources. Sugar added to coffee, sugar added to tea and tea remain qualified; coffee is not a null estimate (Results; Tables S3, S18 and S26).","STROBE-16-five-source")
s.save(spath); LOG["files"]["Supplement.docx"]={"sha":sha(spath),"s30_rows":len(rows)}

# ---------- Highlights: five bullets, <=120 chars, single bullet glyph ----------
hpath=os.path.join(B,"Highlights.docx"); h=docx.Document(hpath)
newh=[
"Coffee's default-prior colocalization at FTO (0.894/0.906) was prior-sensitive; caffeine loci had no AF counterpart.",
"No sweetened-beverage exposure met pre-specified causal criteria; sources spanned at most two independent clusters.",
"European meta-analytic power for OR 1.10 was 13–47%; observational-magnitude effects remain unexcluded.",
"ASB shared genetic architecture with AF in FinnGen R13 only (rg = 0.31, FDR q < 0.05), without a causal signal.",
"The sugar-in-tea negative control failed, so that exposure's null is uninterpretable."]
paras=[p for p in h.paragraphs if p.style.name=="List Bullet" or p.text.strip().startswith("•")]
assert len(paras)==5
for i,(p,txt) in enumerate(zip(paras,newh),1):
    assert len(txt)<=120,(i,len(txt)); set_para(p,txt,f"Highlight-{i}")
h.save(hpath); LOG["files"]["Highlights.docx"]={"sha":sha(hpath),"chars":[len(x) for x in newh]}

# ---------- Cover letter: same boundary narrative ----------
cpath=os.path.join(B,"Cover_Letter.docx"); c=docx.Document(cpath)
for p in c.paragraphs:
    if p.text.startswith("Using UK Biobank beverage GWAS"):
        replace_para(p,"coffee and AF colocalize at FTO under the default prior","coffee and AF colocalize at FTO under the default prior but with prior sensitivity","CL-prior-sensitive")
    if p.text.startswith("We are explicit about what the design cannot do."):
        replace_para(p,"Power to detect OR 1.10 was 13–47%","European meta-analytic power to detect OR 1.10 was 13–47%","CL-power-scope")
c.save(cpath); LOG["files"]["Cover_Letter.docx"]={"sha":sha(cpath)}

json.dump(LOG,open(os.path.join(D,"apply_revision_log.json"),"w",encoding="utf-8"),ensure_ascii=False,indent=2)
print("abstract words",len(new_abs.split()))
print("paragraph changes",len(LOG["paragraph_changes"]),"cell changes",len(LOG["cell_changes"]))
for k,v in LOG["files"].items(): print(k,v)
