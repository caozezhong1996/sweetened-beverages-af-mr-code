# -*- coding: utf-8 -*-
"""Append the change log to the GA audit report."""
from pathlib import Path

P = Path(r"C:/Users/64915/WorkBuddy/2026-10-06-13-49-21/GA内容审核_20261025.md")
t = P.read_text(encoding="utf-8")

t += """

---

# 八、修改执行记录（09:15–10:05）

## 8.1 改前核对（基线固化）

从 v53 脚本逐块抽取 236 词，逐数字回表：**8 项正确、1 项硬错**（P0-1 MR-RAPS 的 P ≥ 0.11 与 Table S23 的 0.032 冲突）。基线已存档于本节，改后逐条比对。

## 8.2 逐项落实

| 编号 | 改动 | 机械核对 |
|---|---|---|
| P0-1 | 删除 "null in MR-RAPS (P ≥ 0.11)"，改为 "→ Not robust to sensitivity analyses"；不再给 MR-RAPS 的具体 P 值 | PASS（"0.11" 已不在图中） |
| P0-2 | 顺序改为 **DATA → DESIGN → KEY FINDINGS → 结论**（原：暴露 → 方法 → 结局） | PASS（字符串位置 DATA < DESIGN < KEY FINDINGS） |
| P0-3 | "best explained" → "likely reflect" | PASS |
| P1-2 | "7 beverages" → "7 beverage phenotypes" | PASS |
| P1-3 | "sweetener in tea" → "sweetener added to tea" | PASS |
| P1-4 | 琥珀框补 "caffeine/paraxanthine null (P ≥ 0.31)"（沿用摘要口径） | PASS |
| P1-5 | 结论补 "moderate-to-large effects are excluded" 与 "than at beverage avoidance" | PASS |
| P1-6 | "fails every consistency test" → "Not robust to sensitivity analyses" | PASS |
| P2-1 | 列表统一用 "·"；标题用 "—" | PASS |
| P2-2 | "≠" → "does not imply causation" | PASS（图中已无 ≠） |
| P2-3 | KEY FINDINGS 改为**横条（图形）**，箭头指向图形而非文字 | PASS |
| P2-4 | 组间距 5.3 → 8.5 pt（1.4/2.6 单位），与流程间距 18.1 pt 形成两档而非三档 | PASS |
| P2-5 | 正文 7.0–7.8 → **7.7–8.05 pt**；行距统一 1.25 | PASS |
| 补充 | FinnGen 加 "non-overlapping"（正文 R1-3 的核心卖点） | PASS |

## 8.3 数字逐项复核（改后）

GA 中出现的全部数字串（0.06 / 0.24 / 0.31 / 0.82 / 0.97 / 1.34 / 3 / 7 / 2018 / 2023 / 8,000 / 8,180 / 55,114 / 60,620 / 64,949 / 67,783 / 447,485 等）逐一在正文或补充材料中命中，无孤立数字。`8,000` 为 8,005 / 7,840 / 8,137 的取整，属允许的近似。

## 8.4 字数

**236 → 217 词**（−19）。分块对照：

| 区块 | v53 | v54 | 说明 |
|---|---:|---:|---|
| 标题 + 副标题 | 17 | 17 | — |
| 数据（暴露 + 结局） | 66（两块） | 57（一块） | 合并、删重复标签 |
| 方法 | 23 | 17 | 三行压两行 |
| KEY FINDINGS | 2 | 2 | 改为横条 |
| 两个结果框 | 51 | 45 | 去掉不实的 MR-RAPS P 值 |
| 遗传相关框 | 28 | 28 | — |
| 结论 | 30 | 42 | **+12：补功效限定 + "相比饮料回避" 对照 + 奶茶研究缺口** |
| 脚注 | 19 | 9 | 第二行并入结论 |
| **合计** | **236** | **217** | |

未达到原先建议的 ~178：补进去的三处结果（代谢物、功效限定、对照）都是审稿人会核的点，删不得；再压只能删暴露清单或方法段，那正好回到"压缩版 Figure 1"的老问题。217 词是本稿在不丢结果前提下的下限。

## 8.5 版式数值（改后）

- 画布 12.5 × 18 cm @300 dpi（1476 × 2125 px），7 框 + 1 横条
- 流程间距 18.1 pt，箭头 14.9 pt（占 82%），箭头头部 3.6 pt
- 组间距 8.5 pt（两结果框 / 遗传相关框）
- 7 个框的实测文字块上下内边距均为 1.45 单位，两结果框高度均为 21.05 单位（完全等高）
- VERIFY：文字不越框、行宽不超限、块间不重叠、箭头等长 → **PASS**

## 8.6 仍未解决（需作者决定）

**Table S23 与 8 月本地 MR-RAPS 运行对 FinnGen 的估计不一致**：投稿表为 coffee log-OR 0.407（P = 0.045）、sugar-added-to-tea −0.366（P = 0.032）；本地运行 coffee P = 0.126。GA 已按投稿稿口径处理（不给具体 P 值），但**两套数字并存本身是隐患**——若审稿人复算或索要代码，会暴露版本不一致。建议投稿前确认 Table S23 使用的 FinnGen R13 版本与脚本，必要时统一重跑。
"""

P.write_text(t, encoding="utf-8")
print("appended, total chars:", len(t))
