# -*- coding: utf-8 -*-
"""Write the master-folder version record and a version-free package README."""
import io
import re
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

PKG = Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")
MASTER = Path(r"C:\Users\64915\Desktop\维护母版_心脏—胃肠_改稿只在这里\奶茶房颤MR_JAHA")
README = PKG / "README_投稿包.md"

old = README.read_text(encoding="utf-8")
blocks = re.split(r"(?m)^## ", old)
head = blocks[0]
sections = {"## " + b.split("\n", 1)[0]: "## " + b for b in blocks[1:]}

def grab(title):
    for k, v in sections.items():
        if title in k:
            return v.strip()
    return ""

hist_change = grab("v5.2 相对 v5.1 的变化")
hist_log = grab("版本与校验")

record = f"""# 奶茶房颤 MR · 投稿包版本沿革与校验记录

本文件保存投稿包的历史版本信息与机器校验记录。**投稿包内不再保留任何版本标注。**

- 母版位置：`{MASTER}`
- 旧版图件：`旧版图件/`（{len(list((MASTER / '旧版图件').glob('*.png')))} 个已退役版本，文件名保留版本号以便追溯）
- 图件生成脚本（主源，勿在此复制副本）：迁移包 `06_升级分析_v4/scripts/`、工作区 `build_ga_v54.py` / `build_fig1_v53.py` / `make_figures_v52.py`

---

{hist_change}

---

{hist_log}
"""

(MASTER / "投稿包_版本沿革与校验.md").write_text(record, encoding="utf-8")
print("written:", MASTER / "投稿包_版本沿革与校验.md", f"{len(record)} chars")

master_readme = """# 奶茶房颤 MR · JAHA 母版

这里存放**不进投稿包**的东西：已退役的图件版本、投稿包的版本沿革与校验记录。

- `旧版图件/` —— 每次重绘后从前一版投稿包移出的图（文件名带版本号，便于追溯）
- `投稿包_版本沿革与校验.md` —— 版本变更史、机器校验结论、构建链

投稿包本身（只含 9 个上传文件）在：
`C:\\Users\\64915\\Desktop\\JAHA投稿包_奶茶房颤MR_20261013`

规则：**改稿只在母版侧留痕；投稿文件夹永远只有当前要上传的文件，且文件名不带版本号。**
"""
(MASTER / "README_母版.md").write_text(master_readme, encoding="utf-8")
print("written:", MASTER / "README_母版.md")

new_readme = """# 投稿包 · 奶茶房颤 MR（JAHA）

目标期刊：**Journal of the American Heart Association (JAHA)** — AHA 金色开源刊
投稿系统：https://jaha-submit.aha-journals.org

本文件夹只放上传用的 9 个文件。版本沿革、旧版图件与校验记录在母版：
`桌面\\维护母版_心脏—胃肠_改稿只在这里\\奶茶房颤MR_JAHA\\`

## 文件与上传类目

| 文件 | 用途 | 上传类目（EM 系统） |
|---|---|---|
| `Cover_Letter.docx` | 投稿信（含生物标志物 MR 卖点、Larsson 划界） | Cover Letter |
| `Manuscript.docx` | 手稿（摘要 249 词、NAA、Clinical Perspective、正文 5997 词、47 条参考文献） | Manuscript |
| `Supplement.docx` | 在线补充材料（表 S1–S25） | Supplemental Material |
| `Highlights.docx` | Highlights（如系统要求） | Highlights / Other |
| `figures/Figure1_Study_Design.png` | 图 1 · 研究设计（含生物标志物臂） | Figure 1 |
| `figures/Figure2_Forest.png` | 图 2 · 主结果森林图（含代谢物小节） | Figure 2 |
| `figures/Graphical_Abstract.png` | 图文摘要 | Graphical Abstract |
| `figures/FigureS1_LOO_Funnel.png` | 补充图 S1 | Supplemental Figure |
| `figures/FigureS2_LDSC_rg.png` | 补充图 S2 | Supplemental Figure |

5 张图均为 300 dpi（已逐张核验）。

## JAHA 政策要点（2026-10 官网核实）

- **初投稿不要求符合期刊格式**：可传单个 PDF 或分散文件（手稿+表+图），系统自动合并 PDF。格式合规（正文 ≤6000 词等）在修回/录用阶段才执行——本稿正文 5997 词，已达标。
- **必备结构已内置**：结构化摘要（Background / Methods and Results / Conclusions）、Nonstandard Abbreviations and Acronyms、Clinical Perspective（What Is New? / What Are the Clinical Implications?）、Sources of Funding、Disclosures。
- **APC**：约 $3,700–3,810（AHA 会员约 $2,200），以投稿时官网为准；录用后支付。
- 可建议/回避审稿人。**建议**：将 Susanna C. Larsson 列入 excluded reviewers——她以 EHJ Open Section Editor 身份对本稿出具过拒绝意见，且其团队做过咖啡–AF 的 MR（Yuan & Larsson 2019），立场可预期。是否填写由你决定。
- Clinical Trial Registration：不适用（本研究为公开汇总数据 MR）。

## 填写提醒

- EM 系统通讯作者姓名栏：**Given name = Zezhong，Family name = Cao**。上次 Elsevier EM 把名重复成了 "Cao Zezhong Zezhong"，JAHA 系统虽不同，同样留意逐栏核对。
- 手稿标题用**长标题**（161 字符）："Sweetened Beverage Consumption and Risk of Atrial Fibrillation: A Two-Sample and Multivariable Mendelian Randomization Study With East Asian Contextual Analysis"——JAHA 初投稿不查格式，长标题经 EJPC 审稿轮定为优选。
- ORCID：0000-0002-8949-6078（Cao Zezhong）；共同作者 Chen Rongrong（chenrrxh@126.com）。
- 数据与代码可用性：概念 DOI 10.5281/zenodo.22099675（版本 DOI 10.5281/zenodo.23459526），已写入投稿信与手稿 Data Availability。

## 上传前检查

- [ ] 手稿：摘要 249 词、正文 5997 词、引文 1..47 连续
- [ ] 5 张图 300 dpi，Figure 1 含 10 个暴露、Figure 2 含代谢物小节
- [ ] 补充材料含 S1–S25
- [ ] 投稿信含 Larsson 2023 划界句（AF null 已发表）
- [ ] 回避审稿人 Larsson 已填
"""
README.write_text(new_readme, encoding="utf-8")
print("written:", README, f"{len(new_readme)} chars")
