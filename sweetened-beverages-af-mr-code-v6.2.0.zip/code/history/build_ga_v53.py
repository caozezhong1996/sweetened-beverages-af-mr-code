# -*- coding: utf-8 -*-
"""Graphical abstract v53 — measured layout engine.

Design rules enforced here (all computed, none hand-placed):
  * block heights come from font metrics -> no text can cross a border or
    another block;
  * vertical spacing follows a 3-tier rhythm:
        header gap  (title/annotation, no arrow)  = 2.4
        flow gap    (between pipeline stages, arrow) = F (solved for)
        group gap   (inside one group, no arrow)   = 1.1 / 1.4
  * every flow arrow is identical: same length, same head, centred in its gap.
12.5 x 18 cm @ 300 dpi.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

W_CM, H_CM, DPI = 12.5, 18.0, 300
XMAX, YMAX = 100.0, 144.0
MARGIN_X, MARGIN_TOP, MARGIN_BOT = 4.0, 2.8, 2.8
BOX_W = XMAX - 2 * MARGIN_X
GAP_HEADER, GAP_GROUP_A, GAP_GROUP_B = 2.6, 1.25, 1.5
ARROW_LEN = 3.3      # total arrow length (shaft + head), in axis units
ARROW_HEAD = 8.5     # mutation_scale: head is ~0.4 x this, in points

fig = plt.figure(figsize=(W_CM / 2.54, H_CM / 2.54), dpi=DPI)
ax = fig.add_axes([0, 0, 1, 1])
ax.set_xlim(0, XMAX)
ax.set_ylim(0, YMAX)
ax.axis("off")

PT_PER_UNIT = (W_CM / 2.54 * 72.0) / XMAX
LS = 1.25

INK, MUT = "#1f313a", "#5b6f79"
BLUE, LBLUE = "#2f6f8f", "#e3eef4"
GREEN, LGREEN = "#2e7d5b", "#e5f2ec"
AMBER, LAMBER = "#b3641c", "#f9eee0"
GREY = "#eef3f6"


def line_h(text, size, ls=LS):
    n = text.count("\n") + 1
    return n * ls * size / PT_PER_UNIT


class Block:
    def __init__(self, pad_t=1.30, pad_b=1.30):
        self.items, self.pad_t, self.pad_b = [], pad_t, pad_b

    def add(self, text, size=7.4, weight="normal", color=INK,
            style="normal", gap=0.0, ls=LS):
        self.items.append((text, size, weight, color, style, gap, ls))
        return self

    def content_h(self):
        return sum(g + line_h(t, s, ls) for t, s, w, c, st, g, ls in self.items)

    def height(self):
        return self.pad_t + self.content_h() + self.pad_b


class Section:
    def __init__(self, block, face=None, edge=None, gap_before=GAP_HEADER,
                 arrow=False, blocks=None, faces=None, edges=None):
        self.block, self.face, self.edge = block, face, edge
        self.gap_before, self.arrow = gap_before, arrow
        self.blocks = blocks              # set for a side-by-side row
        self.faces, self.edges = faces, edges

    @property
    def boxed(self):
        return self.face is not None or self.blocks is not None

    def height(self):
        if self.blocks:
            return max(b.height() for b in self.blocks)
        return self.block.height() if self.boxed else self.block.content_h()


def build():
    S = []

    t = Block(pad_t=0, pad_b=0)
    t.add("Sweetened Beverage Consumption and Risk of Atrial Fibrillation",
          size=8.6, weight="bold")
    t.add("Two-sample and multivariable Mendelian randomization with East Asian context",
          size=6.9, color=MUT, style="italic", gap=1.00)
    S.append(Section(t, gap_before=0.0))

    b = Block()
    b.add("EXPOSURES — 7 beverages + 3 plasma metabolites", size=7.8, weight="bold", color=BLUE)
    b.add("(UK Biobank GWAS, N = 64,949–447,485)", size=6.8, color=BLUE, gap=0.55)
    b.add("Sugar added to tea  ·  Sugar added to coffee  ·  Fizzy drinks (SSB)\n"
          "Low-calorie drinks (ASB)  ·  Artificial sweetener in tea\n"
          "Coffee intake  ·  Tea intake", size=7.8, gap=1.30)
    b.add("Plasma caffeine · paraxanthine · theobromine (Chen 2023 atlas; N ≈ 8,000)",
          size=6.9, color=BLUE, style="italic", gap=1.40)
    S.append(Section(b, LBLUE, BLUE, gap_before=GAP_HEADER))

    b = Block()
    b.add("CAUSAL-INFERENCE FRAMEWORK", size=7.8, weight="bold", color=MUT)
    b.add("Two-sample MR (IVW + MR-Egger / weighted median / MR-PRESSO)\n"
          "Multivariable MR with BMI · Locus-level colocalization · Cross-trait LDSC\n"
          "Reverse MR · Alcohol positive lifestyle control", size=7.1, gap=1.30)
    S.append(Section(b, GREY, MUT, gap_before="F", arrow=True))

    b = Block()
    b.add("OUTCOME — atrial fibrillation, four GWAS sources", size=7.8, weight="bold", color=BLUE)
    b.add("Primary Nielsen 2018 (60,620 cases) · co-primary FinnGen R13 (67,783)\n"
          "Sensitivity AFGen 2018 (55,114) · East Asian BioBank Japan (8,180)",
          size=7.3, gap=1.30)
    S.append(Section(b, LBLUE, BLUE, gap_before="F", arrow=True))

    k = Block(pad_t=0, pad_b=0)
    k.add("KEY FINDINGS", size=8.4, weight="bold")
    S.append(Section(k, gap_before="F", arrow=True))

    g = Block(pad_t=1.45, pad_b=1.45)
    g.add("Sweetened beverages", size=7.6, weight="bold", color=GREEN)
    g.add("→ No genetic evidence of a\ncausal association with AF",
          size=7.4, weight="bold", color=GREEN, gap=0.95)
    g.add("Meta-analytic OR 0.82–0.97,\nall P ≥ 0.06; null across\ncohorts and estimators",
          size=7.0, gap=1.25)
    a = Block(pad_t=1.45, pad_b=1.45)
    a.add("Coffee nominal signal (OR 1.34)", size=7.6, weight="bold", color=AMBER)
    a.add("→ fails every consistency test", size=7.4, weight="bold", color=AMBER, gap=0.95)
    a.add("Attenuated by BMI (OR 0.82)\nand null in MR-RAPS (P ≥ 0.11);\ncolocalizes with AF only at FTO\n(adiposity), not CYP1A1–CYP1A2/AHR",
          size=7.0, gap=1.25)
    S.append(Section(None, gap_before=GAP_GROUP_A, blocks=[g, a],
                     faces=[LGREEN, LAMBER], edges=[GREEN, AMBER]))

    b = Block()
    b.add("Genetic correlation ≠ causation", size=7.8, weight="bold", color=GREEN)
    b.add("SSB / ASB share genetic architecture with AF (rg = 0.24–0.31, FDR q < 0.05)\n"
          "despite robustly null MR estimates — adiposity-related pleiotropy;\n"
          "cross-trait intercepts ≈ 0 exclude sample-overlap bias", size=7.1, gap=1.30)
    S.append(Section(b, LGREEN, GREEN, gap_before=GAP_GROUP_B))

    b = Block()
    b.add("CONCLUSION", size=7.8, weight="bold", color="#bcd3de")
    b.add("Genetically proxied sweetened-beverage intake showed no evidence of a\n"
          "causal association with atrial fibrillation. Observational associations are\n"
          "best explained by adiposity-related confounding; prevention should target\n"
          "established cardiometabolic risk factors.", size=7.0, color="white", gap=1.30)
    S.append(Section(b, INK, INK, gap_before="F", arrow=True))

    f = Block(pad_t=0, pad_b=0)
    f.add("Genetic nulls converge with randomized trial evidence (CRAVE, DECAF).",
          size=6.7, color=MUT, style="italic")
    f.add("Direct milk-tea measurement in prospective East Asian cohorts remains needed.",
          size=6.7, color=MUT, style="italic", gap=0.80)
    S.append(Section(f, gap_before=GAP_HEADER))
    return S


sections = build()
content = sum(s.height() for s in sections)
fixed = sum(s.gap_before for s in sections
            if s.gap_before in (GAP_HEADER, GAP_GROUP_A, GAP_GROUP_B))
n_flow = sum(1 for s in sections if s.gap_before == "F")
avail = YMAX - MARGIN_TOP - MARGIN_BOT
F = (avail - content - fixed) / n_flow
print(f"content={content:.2f}  header/group gaps={fixed:.2f}  "
      f"flow gaps={n_flow}  F={F:.2f} units ({F * PT_PER_UNIT:.1f} pt)")
assert F > ARROW_LEN + 0.6, "flow gap too small for a visible arrow"

y = YMAX - MARGIN_TOP
tops = []
for i, s in enumerate(sections):
    if i > 0:
        y -= F if s.gap_before == "F" else s.gap_before
    tops.append(y)
    y -= s.height()
print(f"stack bottom={y:.2f} (target margin {MARGIN_BOT})")


def draw_block(x, y_top, block):
    cur = y_top - block.pad_t
    for text, size, weight, color, style, g, ls in block.items:
        cur -= g
        ax.text(x, cur, text, fontsize=size, color=color, fontweight=weight,
                style=style, ha="center", va="top", linespacing=ls, zorder=4)
        cur -= line_h(text, size, ls)


def draw_box(x, y_top, w, h, face, edge):
    ax.add_patch(FancyBboxPatch((x, y_top - h), w, h,
                                boxstyle="round,pad=0,rounding_size=1.6",
                                facecolor=face, edgecolor=edge, linewidth=1.2, zorder=2))


def v_arrow(y_from, y_to):
    mid = (y_from + y_to) / 2
    ax.add_patch(FancyArrowPatch((XMAX / 2, mid + ARROW_LEN / 2),
                                 (XMAX / 2, mid - ARROW_LEN / 2),
                                 arrowstyle="-|>", mutation_scale=ARROW_HEAD,
                                 linewidth=1.35, color=MUT, zorder=3,
                                 shrinkA=0, shrinkB=0))


for i, s in enumerate(sections):
    ytop = tops[i]
    h = s.height()
    if s.blocks:
        boxw = (BOX_W - 4.0) / 2
        for blk, fc, ec, x in zip(s.blocks, s.faces, s.edges,
                                  [MARGIN_X, MARGIN_X + boxw + 4.0]):
            draw_box(x, ytop, boxw, h, fc, ec)
            draw_block(x + boxw / 2, ytop, blk)
    elif s.boxed:
        draw_box(MARGIN_X, ytop, BOX_W, h, s.face, s.edge)
        draw_block(XMAX / 2, ytop, s.block)
    else:
        draw_block(XMAX / 2, ytop, s.block)

    if s.arrow:
        v_arrow(tops[i - 1] - sections[i - 1].height(), ytop)

# ---------------------------------------------------------------- verification
fig.canvas.draw()
r = fig.canvas.get_renderer()
inv = ax.transData.inverted()
problems = []


def bbox_units(t):
    bb = t.get_window_extent(renderer=r)
    (x0, y0), (x1, y1) = inv.transform([[bb.x0, bb.y0], [bb.x1, bb.y1]])
    return x0, y0, x1, y1


for t in ax.texts:
    x0, y0, x1, y1 = bbox_units(t)
    if x0 < MARGIN_X + 0.3 or x1 > XMAX - MARGIN_X - 0.3:
        problems.append(f"text outside horizontal safe area: {t.get_text()[:45]!r} "
                        f"[{x0:.1f},{x1:.1f}]")

for i, s in enumerate(sections):
    if not s.boxed:
        continue
    ytop, h = tops[i], s.height()
    if s.blocks:
        boxw = (BOX_W - 4.0) / 2
        xb = [(MARGIN_X, MARGIN_X + boxw), (MARGIN_X + boxw + 4.0, XMAX - MARGIN_X)]
    else:
        xb = [(MARGIN_X, XMAX - MARGIN_X)]
    for t in ax.texts:
        x0, y0, x1, y1 = bbox_units(t)
        cy = (y0 + y1) / 2
        if not (ytop - h - 0.2 <= cy <= ytop + 0.2):
            continue
        if not any(x0 >= bx0 - 0.05 and x1 <= bx1 + 0.05 for bx0, bx1 in xb):
            problems.append(f"text wider than its box: {t.get_text()[:40]!r}")
        if y0 < ytop - h + 0.10 or y1 > ytop - 0.10:
            problems.append(f"text outside vertical box bounds: {t.get_text()[:45]!r}")

for i, s in enumerate(sections):
    for blk in (s.blocks or [s.block]):
        cur = tops[i] - blk.pad_t
        spans = []
        for text, size, weight, color, style, g, ls in blk.items:
            cur -= g
            spans.append((cur, cur - line_h(text, size, ls), text))
            cur -= line_h(text, size, ls)
        for (t1, b1, s1), (t2, b2, s2) in zip(spans, spans[1:]):
            if b1 < b2 - 1e-6:
                problems.append(f"block overlap: {s1[:25]!r} / {s2[:25]!r}")

print("VERIFY:", "PASS — no overlap, equal flow gaps, identical arrows"
      if not problems else f"{len(problems)} problem(s)")
for p in problems:
    print("  -", p)

out = (r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
       r"\06_升级分析_v4\figures\Graphical_Abstract_v53_300dpi.png")
fig.savefig(out, dpi=DPI, facecolor="white")
print("written:", out)
