# -*- coding: utf-8 -*-
"""Figure 1 (v53). Study-design flowchart — behavioural + biomarker MR arms.

Layout contract (all computed, nothing hand-placed):
  * one body font size for the whole figure, auto-fitted to the narrowest box;
    one title size per band, auto-fitted to the longest title in that band;
  * band height = header strip + one body block, so all boxes in a row are equal
    and bodies are top-aligned at a constant inset;
  * block heights follow matplotlib's rule (n_lines x linespacing x size), so no
    text can cross a border;
  * connectors are an orthogonal bus: equal vertical stubs, equal arrowheads,
    one horizontal per transition — no converging diagonals.
11.5 x 8.6 in @ 300 dpi (3450 x 2580 px).
"""
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.textpath import TextPath
from matplotlib.font_manager import FontProperties

OUTDIR = Path(r"C:/Users/64915/Documents/kimi/workspace/奶茶房颤MR_迁移包_20260822/06_升级分析_v4/figures")
OUTDIR.mkdir(parents=True, exist_ok=True)

W_IN, H_IN, DPI = 11.5, 8.6, 300
XMAX = 100.0
YMAX = 100.0 * H_IN / W_IN
MARGIN_X, MARGIN_TOP, MARGIN_BOT = 2.0, 1.25, 1.6
PT_PER_UNIT = W_IN * 72.0 / XMAX

C_DATA, C_INST, C_ANA, C_ROB, C_NOTE = "#2A6F7F", "#C08329", "#4A6FA5", "#7A4E7E", "#8A8A8A"
INK, ARROW = "#263238", "#7a8b93"

fig = plt.figure(figsize=(W_IN, H_IN), dpi=DPI)
ax = fig.add_axes([0, 0, 1, 1])
ax.set_xlim(0, XMAX)
ax.set_ylim(0, YMAX)
ax.axis("off")

LS = 1.25
BUS_FRAC = 0.30   # bus sits at 30% of the gap: stub 30%, arrow 70%
STRIP = 3.30
PAD_TOP, PAD_BOT = 1.75, 1.65
BODY_SIZE, TITLE_SIZE = 9.0, 10.3
_FP = {w: FontProperties(family="DejaVu Sans", weight=w) for w in ("normal", "bold")}


def width_units(text, size, weight="normal"):
    return max(TextPath((0, 0), ln, size=size, prop=_FP[weight]).get_extents().width
               for ln in text.split("\n")) * 1.10 / PT_PER_UNIT


def fit_size(text, size, max_w, weight="normal", floor=5.8):
    while size > floor and width_units(text, size, weight) > max_w:
        size -= 0.1
    return round(size, 1)


def line_h(n_lines, size, ls=LS):
    return n_lines * ls * size / PT_PER_UNIT


class Box:
    def __init__(self, x, w, title, body, color, pad_x=2.4):
        self.x, self.w, self.title, self.body, self.color = x, w, title, body, color
        self.pad_x = pad_x
        self.n = body.count("\n") + 1
        self.y = self.h = self.title_fs = self.body_fs = None

    def height(self):
        return STRIP + PAD_TOP + line_h(self.n, self.body_fs) + PAD_BOT

    @property
    def cx(self):
        return self.x + self.w / 2

    def draw(self):
        ax.add_patch(FancyBboxPatch((self.x, self.y - self.h), self.w, self.h,
                                    boxstyle="round,pad=0,rounding_size=1.1",
                                    facecolor="white", edgecolor=self.color,
                                    linewidth=1.3, zorder=2))
        ax.add_patch(FancyBboxPatch((self.x, self.y - STRIP), self.w, STRIP,
                                    boxstyle="round,pad=0,rounding_size=1.1",
                                    facecolor=self.color, edgecolor="none",
                                    alpha=0.13, zorder=2))
        ax.text(self.cx, self.y - STRIP / 2, self.title, ha="center", va="center",
                fontsize=self.title_fs, fontweight="bold", color=self.color, zorder=4)
        ax.text(self.cx, self.y - STRIP - PAD_TOP, self.body, ha="center", va="top",
                fontsize=self.body_fs, color=INK, zorder=4, linespacing=LS)


# ------------------------------------------------------------------ content
ax.text(50, YMAX - 0.10,
        "Study design: sweetened beverage consumption and atrial fibrillation "
        "(Mendelian randomization)",
        ha="center", va="top", fontsize=13.0, fontweight="bold", color=INK)

B1 = [
    Box(2, 30, "Exposure GWAS",
        "UK Biobank beverages (7 phenotypes)\n"
        "2 at P < $5\\times10^{-8}$, 5 at P < $5\\times10^{-6}$\n"
        "(MRC IEU / OpenGWAS, EUR)\n"
        "N = 64,949–447,485\n"
        "Plasma metabolites (Chen 2023\n"
        "atlas): caffeine, paraxanthine,\n"
        "theobromine\n"
        "N ≈ 8,000 (EUR)",
        C_DATA),
    Box(35, 30, "Outcome GWAS: atrial fibrillation",
        "Nielsen 2018 (EUR, primary)\n"
        "60,620 cases / 970,216\n"
        "FinnGen R13 (EUR, co-primary)\n"
        "67,783 / 241,269\n"
        "AFGen 2018 (EUR, sensitivity)\n"
        "55,114 / 482,295\n"
        "BioBank Japan (EAS, contextual)\n"
        "8,180 / 28,612",
        C_DATA),
    Box(68, 30, "Covariate & positive controls",
        "BMI: GIANT (EUR)\n"
        "N = 681,275\n"
        "(MVMR positive control)\n"
        "Alcohol: GSCAN drinks/week\n"
        "N = 335,394\n"
        "UK Biobank intake frequency\n"
        "N = 462,346\n"
        "(lifestyle positive control)",
        C_DATA),
]
B2 = [Box(10, 80, "Instrument selection and harmonization",
          "Independent SNPs (r² < 0.001, 10,000 kb); P < $5\\times10^{-8}$ for coffee/tea "
          "intake, P < $5\\times10^{-6}$ for five sub-phenotypes\n"
          "Locus-lead variants for plasma metabolites (relaxed threshold); "
          "palindromic-SNP exclusion; identical lists across outcome panels\n"
          "Per-variant F > 20 (beverages) or 30–49 (metabolites); harmonised to each "
          "outcome panel",
          C_INST)]
B3 = [
    Box(2, 22.5, "Univariable MR",
        "Random-effects IVW\n(beverages + metabolites)\n"
        "MR-Egger · weighted median\nweighted mode · MR-PRESSO\n"
        "Wald ratio (single instrument)",
        C_ANA, pad_x=1.9),
    Box(26.5, 22.5, "European meta-analysis",
        "Fixed-effect pooling of\nNielsen 2018 + FinnGen R13\n"
        "Benjamini–Hochberg FDR\nacross 7 primary tests\nper beverage exposure",
        C_ANA, pad_x=1.9),
    Box(51, 22.5, "East Asian contextual",
        "BioBank Japan (EAS)\n8,180 cases / 28,612\n"
        "IVW estimates with\nsensitivity methods\ncontextual replication",
        C_ANA, pad_x=1.9),
    Box(75.5, 22.5, "Multivariable MR",
        "Coffee intake + sugar added\nto tea + BMI; direct effects\n"
        "conditioned on the other\nexposures; conditional F\nreported (Table 4)",
        C_ANA, pad_x=1.9),
]
B4 = [
    Box(2, 47, "Robustness and pleiotropy assessment",
        "Cochran's Q · MR-Egger intercept · MR-PRESSO · radial IVW · MR-RAPS\n"
        "CAUSE · MRlap · contamination-mixture · LDSC rg · Steiger directionality\n"
        "reverse MR (111 AF instruments) · alcohol positive lifestyle control",
        C_ROB, pad_x=2.2),
    Box(51, 47, "Pre-specified conditional analyses",
        "Colocalization and two-step mediation MR as probes of the nominal\n"
        "coffee signal: CYP1A1–CYP1A2, AHR and FTO loci\n"
        "Adiposity (BMI) mediation quantified (Table S16)",
        C_NOTE, pad_x=2.2),
]
BANDS = [B1, B2, B3, B4]

# ------------------------------------------------------------------ typography
# one body size for the whole figure, limited by the narrowest box
body_fs = min(fit_size(b.body, BODY_SIZE, b.w - 2 * b.pad_x) for b in sum(BANDS, []))
for b in sum(BANDS, []):
    b.body_fs = body_fs
# one title size per band, limited by the longest title in that band
for row in BANDS:
    tfs = min(fit_size(b.title, TITLE_SIZE, b.w - 3.4, "bold") for b in row)
    for b in row:
        b.title_fs = tfs
print(f"body size (all boxes) = {body_fs} pt")
for row in BANDS:
    print(f"  band titles = {row[0].title_fs} pt  "
          f"({' / '.join(b.title for b in row)})")

# ------------------------------------------------------------------ rhythm
heights = [max(b.height() for b in row) for row in BANDS]
title_h = 1.25 * 13.0 / PT_PER_UNIT
avail = YMAX - MARGIN_TOP - MARGIN_BOT
gap = (avail - title_h - sum(heights)) / 4
print(f"band heights={['%.2f' % h for h in heights]}  gap={gap:.2f} units "
      f"({gap * PT_PER_UNIT:.1f} pt)")
assert gap > 2.6, "vertical gap too small"

y = YMAX - MARGIN_TOP - title_h
tops = []
for row, h in zip(BANDS, heights):
    y -= gap
    tops.append(y)
    for b in row:
        b.y, b.h = y, h
        b.draw()
    y -= h
print(f"stack bottom={y:.2f} (margin {MARGIN_BOT})")


def bus(src_bottom, dst_top, xs_src, xs_dst):
    mid = src_bottom - BUS_FRAC * (src_bottom - dst_top)
    for x in xs_src:
        ax.plot([x, x], [src_bottom, mid], color=ARROW, lw=1.2, zorder=1,
                solid_capstyle="butt")
    ax.plot([min(xs_src + xs_dst), max(xs_src + xs_dst)], [mid, mid],
            color=ARROW, lw=1.2, zorder=1, solid_capstyle="butt")
    for x in xs_dst:
        ax.add_patch(FancyArrowPatch((x, mid), (x, dst_top), arrowstyle="-|>",
                                     mutation_scale=10, linewidth=1.25,
                                     color=ARROW, zorder=1, shrinkA=0, shrinkB=0))


bus(tops[0] - heights[0], tops[1], [b.cx for b in B1], [B2[0].cx])
bus(tops[1] - heights[1], tops[2], [B2[0].cx], [b.cx for b in B3])
bus(tops[2] - heights[2], tops[3], [b.cx for b in B3], [b.cx for b in B4])

# ------------------------------------------------------------------ verify
fig.canvas.draw()
r = fig.canvas.get_renderer()
inv = ax.transData.inverted()
problems = []


def bb(t):
    b = t.get_window_extent(renderer=r)
    (x0, y0), (x1, y1) = inv.transform([[b.x0, b.y0], [b.x1, b.y1]])
    return x0, y0, x1, y1


pairs = []
for b in sum(BANDS, []):
    pairs += [(b.title, b, "title"), (b.body, b, "body")]
for t, (src, b, kind) in zip(list(ax.texts)[1:], pairs):
    x0, y0, x1, y1 = bb(t)
    if x0 < b.x + 0.05 or x1 > b.x + b.w - 0.05:
        problems.append(f"{kind} wider than box: {src[:36]!r} "
                        f"({x0:.1f}–{x1:.1f} vs {b.x:.1f}–{b.x + b.w:.1f})")
    if y0 < b.y - b.h + 0.10:
        problems.append(f"{kind} below box bottom: {src[:36]!r} "
                        f"({y0:.2f} vs {b.y - b.h:.2f})")
    if kind == "title" and (y0 < b.y - STRIP or y1 > b.y):
        problems.append(f"title outside strip: {src[:30]!r}")

# equal body line counts per band (visual balance)
for row, ytop in zip(BANDS, tops):
    counts = {b.n for b in row}
    if len(counts) > 1:
        problems.append(f"unequal line counts in band at y={ytop:.1f}: {sorted(counts)}")

print("VERIFY:", "PASS — text inside boxes, uniform sizes, balanced rows"
      if not problems else f"{len(problems)} problem(s)")
for p in problems:
    print("  -", p)

out = OUTDIR / "Figure1_Study_Design_v53_300dpi.png"
fig.savefig(out, dpi=DPI, facecolor="white")
print("saved:", out)
