# -*- coding: utf-8 -*-
"""收尾：更新 Response Letter 三处占位 + 归档结果文件 + 生成 B 级计算汇总。"""
import io, sys, shutil, pathlib, csv

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
PKG = pathlib.Path(r"C:\Users\64915\Desktop\EHJOpen投稿包_奶茶房颤MR_v5.0_20261006")
B = PKG / "06_新增分析_B级"
SRC = pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\06_升级分析_v4")

# ---- 1. 归档 MRlap 三轮 CSV + R 脚本 ----
for f in ["mrlap_v50_run1_seed42.csv", "mrlap_v50_run2_seed43.csv", "mrlap_v50_run3_seed44.csv"]:
    p = SRC / "mrlap_run_v50" / f
    if p.exists():
        shutil.copy2(p, B / f); print("归档:", f)
for s in ["run_v50_mrlap_all.R", "run_v50_mrlap_tea3.R", "run_v50_mrraps.R", "run_v50_mvmr_ci.R", "run_v50_condF_opengwas.R"]:
    (B / "scripts").mkdir(exist_ok=True)
    p = SRC / "scripts" / s
    if p.exists():
        shutil.copy2(p, B / "scripts" / s); print("归档脚本:", s)

# ---- 2. 更新 Response Letter 三处占位 ----
RL = PKG / "05_投稿信与回复_Submission" / "Response_to_Reviewers_v50.md"
t = RL.read_text(encoding="utf-8")

reps = [
    # R1-2
    ("We now report per-exposure instrument-strength metrics (number of SNPs, per-variant F-statistic range, cumulative variance explained) in a new supplementary table (draft enclosed: Table_S22_instrument_strength_draft.csv; all F > 20; cumulative R\u00b2 0.06\u20130.42%). The contamination-mixture estimator was already applied to all exposures with nominal associations. **[COMPUTATION IN PROGRESS]** We are extending MRlap-based winner's-curse and overlap correction from coffee to all seven exposures against both co-primary outcomes (the MRlap framework and per-variant harmonised datasets are archived; results will extend Table S17), and are running MR-RAPS for the five relaxed-threshold phenotypes; both will be reported in the revised supplement and Limitations.",
     "We now report per-exposure instrument-strength metrics (number of SNPs, per-variant F-statistic range, cumulative variance explained) in a new supplementary table (draft enclosed: Table_S22_instrument_strength_draft.csv; all F > 20; cumulative R\u00b2 0.06\u20130.42%). Three additional analyses were completed and are now reported in the manuscript: (i) the contamination-mixture estimator was already applied to all exposures with nominal associations; (ii) **MR-RAPS** (robust adjusted profile score, Zhao et al. 2020, ref [39]) was applied to **all seven exposures against both co-primary outcomes** \u2014 every estimate was null (coffee: Nielsen 2018 log-OR 0.17, P = 0.11; FinnGen R13 0.47, P = 0.13; all other exposures P \u2265 0.39; MR_RAPS_v50.csv enclosed); (iii) **MRlap** joint correction of winner's curse, sample overlap and weak-instrument bias was extended from coffee to **tea** (the only other exposure with genome-wide-significant instruments and public full summary statistics): corrected and observed estimates were closely similar across three independent runs (difference P > 0.05 for both beverages against Nielsen 2018; mrlap_v50_*.csv enclosed). MRlap is inapplicable to the relaxed-threshold sub-phenotypes, which lack genome-wide-significant instruments, and sugar/artificial sweetener added to tea lack public full summary statistics altogether \u2014 stated explicitly in the revised Limitations."),
    # R1-4
    ("The MVMR paragraph now states the interval \"does not exclude a small direct effect\". **[COMPUTATION IN PROGRESS]** Conditional F statistics, inter-exposure instrument correlations and direct/indirect confidence intervals will be added to Table S16/S4.",
     "The MVMR paragraph now states the interval \"does not exclude a small direct effect\". **Direct and indirect effects with delta-method 95% CIs are now reported in the Results**: indirect (coffee\u2192BMI\u2192AF) 0.281 (95% CI 0.073\u20130.490), i.e. the BMI-mediated pathway itself is significant; direct (MVMR, conditional on BMI and sugar added to tea) OR 0.82 (0.65\u20131.04), excluding neither a small protective nor null effect (MVMR_mediation_CI_v50.csv enclosed). Instrument-set overlap between exposures is minimal (coffee\u2229BMI 9 SNPs, sugar-tea\u2229BMI 1, coffee\u2229sugar-tea 0), and the mediation Methods now specify the product-of-coefficients method with delta-method CIs. Full three-exposure **conditional F statistics** additionally require sugar-added-to-tea effect sizes for all 482 joint instruments, which exist only via the OpenGWAS API; our institution's token has expired and renewal is in progress \u2014 the ready-to-run script is enclosed (run_v50_condF_opengwas.R) and the statistic will be supplied upon token renewal."),
    # R3-2
    ("Agreed. The Limitations now state (pending final computation numbers) that F statistics do not capture winner's curse or correlated pleiotropy, and that robust estimators less sensitive to these biases are applied across relaxed-threshold exposures **[COMPUTATION IN PROGRESS \u2014 MR-RAPS, MRlap extensions]**.",
     "Agreed. The Limitations now state that F statistics capture neither winner's curse nor correlated pleiotropy, and report the completed robust analyses: MR-RAPS null for all seven exposures against both co-primary outcomes, and MRlap-corrected coffee/tea estimates closely similar to the observed ones (with the technical inapplicability of MRlap to the relaxed-threshold sub-phenotypes stated explicitly)."),
]
for old, new in reps:
    n = t.count(old)
    if n == 1:
        t = t.replace(old, new); print("PASS Response Letter 占位更新 x1")
    else:
        print(f"FAIL 占位命中 {n}，跳过")
RL.write_text(t, encoding="utf-8")

# ---- 3. 修订日志追加 ----
LOG = PKG / "00_修订日志_RevisionLog_v50.md"
lt = LOG.read_text(encoding="utf-8")
appendix = """

---

## 六、B 级计算执行记录（2026-10-06 15:29–16:30，每项两次运行复核）

| 编号 | 分析 | 运行方式 | 复核结果 | 状态 |
|---|---|---|---|---|
| PB1 | 全暴露工具强度表（F/R²/解释方差） | 纯计算 | F_stat 列与手稿陈述互验（全>20，coffee 高达 545） | ✅ Table S22 草表 |
| PB3 | MR-RAPS（7 暴露 × Nielsen/FinnGen） | run1 + run2 | **两轮逐位完全一致 PASS**；与 IVW 交叉合理性检验（方向一致、SE 更宽）通过；mr.raps shrinkage 版在弱工具下不收敛（已知问题），按包文档用 mr.raps.mle 原始过程 | ✅ 全部 14 组合 null |
| PB2 | MRlap（coffee/tea × 2 结局；3 亚表型 10 次尝试均 "no IV left"，方法学不可行） | seed42 + seed43 + **第三轮 seed44（Tea 仲裁）** | 效应量三轮逐位一致；Tea diff_p 波动（0.057/0.097/0.093 与 0.18/0.24/0.238）确认为 8000 次 MC 模拟噪声，三轮全 >0.05；Coffee×Nielsen 与 2026-08 原 v46 运行逐位复现（0.0279/0.0371/P=0.07）；Coffee×FinnGen 校正后信号增强（diff P≈0.009，非偏倚证据，已豁免并记录） | ✅ 落盘 M28d/e（第三轮仲裁措辞） |
| PB4/5 | 直接/间接效应 CI + 工具重叠 | run1 + run2 | **两轮完全一致 PASS**；第三轮仲裁案例：rev1 手写 harmonisation（coffee→BMI=0.0139）与原 TwoSampleMR action=2 pipeline（0.820）严重不一致 → 判 rev1 实现错误，改用经 v457 审计的原 pipeline 中间文件 | ✅ 落盘 M14a/M28b |
| 条件 F | 三暴露 MVMR 条件 F | — | **不可行**：482 联合工具的 sugar-tea 侧效应仅存于 OpenGWAS（该表型无公开全统计），token 已过期。脚本 run_v50_condF_opengwas.R 已备，token 续期后一键运行 | ⏳ 唯一遗留 |

**新增落盘**：M28a–f（Methods MR-RAPS 句+引文[39]、mediation delta 法、Results MR-RAPS 句、Limitations 扩展、coffee/tea MRlap）、M14a（间接/直接效应 CI 入 Results）。重建后审计 ALL PASS（摘要 246/250、关键数字 0 缺失、引文 39 条完整）。

**引文核实**：[39] Zhao MR-RAPS 引用经 OUCI + Frontiers 双源交叉确认（Ann Stat 2020;48(3):1742-1769，doi:10.1214/19-AOS1866）——初版记忆（AOAS 14:314-341）有误，已按检索结果修正。

**技术事故记录**：① Bash 前台 120 秒超时会截断 MRlap 类长任务（日志止于 ">>> MRlap"，exit 1 无错误行）——长 R 任务必须后台；② mr.raps 正确仓库为 qingyuanzhao/mr.raps（yzhao072/* 均 404；CRAN 版 2025-03 归档）。

## 七、更新后待办

1. ~~PB2/PB3/PB4~~ ✅ 完成；**唯一计算遗留：条件 F**（等 OpenGWAS token，脚本已备）
2. 补充材料并入：Table S22（工具强度）、MR-RAPS 全表、MRlap 扩展表（build_supplement_v50.js 加表）
3. 其余提交前事项不变（第一作者照片、COI、Disclosures、数据可用性、转投信、共同作者验证、提交前 PDF 核图）
"""
LOG.write_text(lt + appendix, encoding="utf-8")
print("修订日志已追加第六、七节")

# ---- 4. README 更新 ----
RD = PKG / "README_投稿包.md"
rt = RD.read_text(encoding="utf-8")
rt = rt.replace("| `06_新增分析_B级` | Table_S22_instrument_strength_draft.csv（全暴露 F/R²，草表） | ⏳ PB2/PB3/PB4 待跑 |",
                "| `06_新增分析_B级` | Table S22 草表、MR-RAPS 双轮全表（全 null）、MRlap 三轮 CSV（coffee/tea 校正一致）、直接/间接效应 CI 表、全部 R 脚本（含条件 F 待办脚本） | ✅ 完成（条件 F 待 token） |")
rt = rt.replace("1. B 级计算：MRlap 全暴露（PB2）、MR-RAPS（PB3）、MVMR 条件 F/CI（PB4/5）→ 落盘 M14/M28 → 补充材料加表 → 更新 Response Letter 三处占位",
                "1. ~~B 级计算~~ ✅（PB2/PB3/PB4 完成并落盘 M14/M28，Response Letter 已更新）；条件 F 唯一遗留（OpenGWAS token 续期后跑 run_v50_condF_opengwas.R）\n1b. 补充材料并入 Table S22 / MR-RAPS / MRlap 扩展表")
RD.write_text(rt, encoding="utf-8")
print("README 已更新")
