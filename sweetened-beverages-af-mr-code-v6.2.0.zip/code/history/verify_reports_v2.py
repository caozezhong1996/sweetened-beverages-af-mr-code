# -*- coding: utf-8 -*-
"""Second verification batch."""
import csv
import glob
import io
import os
import re
import sys

from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
M = r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
PKG = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013"

man = Document(os.path.join(PKG, "Manuscript.docx"))
sup = Document(os.path.join(PKG, "Supplement.docx"))
mp = [p.text.strip() for p in man.paragraphs if p.text.strip()]
sp = [p.text.strip() for p in sup.paragraphs if p.text.strip()]
full = "\n".join(mp)

print("V5 S24 标题:")
for p in sp:
    if p.startswith("Table S24."):
        print("  ", p[:150])

print("\nV6 补充表在正文的引用次数:")
for s in ("S1", "S3", "S4", "S9"):
    print(f"  Table {s}: {len(re.findall(rf'Table {s}\\b', full))} 次")

print("\nV7 唯一工具变异:")
all_snp = set()
per = {}
for tag in ["Sugar_added_to_tea", "Sugar_added_to_coffee", "Fizzy_drink_intake_SSB",
            "Low_calorie_drink_intake_ASB", "Artificial_sweetener_added_to_tea",
            "Coffee_intake", "Tea_intake"]:
    p = os.path.join(M, "06_升级分析_v4", "results", f"dat_{tag}_ebi_a_GCST006414.csv")
    if not os.path.exists(p):
        print("  missing", tag)
        continue
    snps = {r["SNP"] for r in csv.DictReader(open(p, encoding="utf-8"))
            if str(r.get("mr_keep", "TRUE")).upper() != "FALSE"}
    per[tag] = len(snps)
    all_snp |= snps
print("  各暴露:", per)
print("  求和:", sum(per.values()), " 唯一:", len(all_snp))

print("\nV8 MR-RAPS 符号:")
cand = glob.glob(os.path.join(M, "**", "*raps*"), recursive=True)
print("  候选:", cand[:6])
s23 = [t for t in sup.tables if "MR-RAPS" in " ".join(c.text for c in t.rows[0].cells)]
if s23:
    t = s23[0]
    hdr = [c.text.strip() for c in t.rows[0].cells]
    print("  表头:", hdr)
    for r in t.rows[1:]:
        c = [x.text.strip() for x in r.cells]
        print("   ", c)

print("\nV9 BBJ 代理表述:")
for p in mp:
    if "four proxies" in p:
        print("  ", p[:300])

print("\nV10 功效/MDE（Table S12 附近文本）:")
for i, p in enumerate(sp):
    if "minimum detectable" in p.lower() or "power" in p.lower():
        print("  ", p[:200])
for t in sup.tables:
    h = " ".join(c.text for c in t.rows[0].cells)
    if "power" in h.lower() or "MDE" in h or "detectable" in h:
        print("  表头:", h)
        for r in t.rows[1:5]:
            print("   ", [c.text.strip() for c in r.cells])

print("\nV11 编号首次出现顺序:")
order = []
for m in re.finditer(r"\[([0-9,\s–-]+)\]", full):
    for part in m.group(1).split(","):
        part = part.strip()
        if re.fullmatch(r"\d+", part):
            n = int(part)
            if n not in order:
                order.append(n)
print("  ", order)
