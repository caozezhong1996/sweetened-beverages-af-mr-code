# -*- coding: utf-8 -*-
"""Graphical abstract v54 — content fixed after the manuscript audit.

Content changes vs v53 (see GA内容审核_20261025.md):
  P0-1  "null in MR-RAPS (P >= 0.11)" removed — contradicted Table S23 (min P 0.032)
  P0-2  order is now DATA -> DESIGN -> FINDINGS -> CONCLUSION
  P0-3  "best explained" -> "likely reflect" (manuscript: "most likely reflects")
  P1-2  "7 beverages" -> "7 beverage phenotypes"
  P1-3  "sweetener in tea" -> "sweetener added to tea"
  P1-4  metabolite result added (caffeine/paraxanthine null, P >= 0.31 — abstract wording)
  P1-5  power caveat + "than at beverage avoidance" restored
  P1-6  "fails every consistency test" -> "Not robust to sensitivity analyses"
  P2-1  single separator (middle dot); em dash only in headers
  P2-2  "Genetic correlation does not imply causation"
  P2-3  KEY FINDINGS is a bar (a shape), so the arrow points at a box, not at text
  P2-4  group gap widened
  P2-5  body type enlarged (audit: 6.7-8.6 pt was too small for a 12.5 cm canvas);
        lines are wrapped to measured width so a larger size cannot overflow
12.5 x 18 cm @ 300 dpi.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.textpath import TextPath
from matplotlib.font_manager import FontProperties

W_CM, H_CM, DPI = 12.5, 18.0, 300
XMAX, YMAX = 100.0, 144.0
MARGIN_X, MARGIN_TOP, MARGIN_BOT = 4.0, 2.6, 2.6
BOX_W = XMAX - 2 * MARGIN_X
GAP_HEADER, GAP_GROUP_A, GAP_GROUP_B = 2.6, 1.4, 2.6
ARROW_HEAD = 9.0
BAR_H = 4.4

S_TITLE, S_SUB = 8.6, 7.3
S_HDR, S_BODY, S_BOLD = 8.2, 8.05, 8.15
S_ROW, S_NOTE = 7.75, 7.15

fig = plt.figure(figsize=(W_CM / 2.54, H_CM / 2.54), dpi=DPI)
ax = fig.add_axes([0, 0, 1, 1])
ax.set_xlim(0, XMAX)
ax.set_ylim(0, YMAX)
ax.axis("off")

PT_PER_UNIT = (W_CM / 2.54 * 72.0) / XMAX
LS = 1.25
FULL_W = BOX_W - 7.0            # 85 units of usable text width
HALF_W = (BOX_W - 4.0) / 2 - 3.6

INK, MUT = "#1f313a", "#5b6f79"
BLUE, LBLUE = "#2f6f8f", "#e3eef4"
GREEN, LGREEN = "#2e7d5b", "#e5f2ec"
AMBER, LAMBER = "#b3641c", "#f9eee0"
GREY = "#eef3f6"

_FP = {w: FontProperties(family="DejaVu Sans", weight=w) for w in ("normal", "bold")}


def width_units(text, size, weight="normal"):
    return TextPath((0, 0), text, size=size, prop=_FP[weight]).get_extents().width \
        * 1.03 / PT_PER_UNIT


def wrap(text, size, max_w, weight="normal"):
    """Greedy wrap to measured width; keeps explicit paragraph breaks."""
    out = []
    for para in text.split("\n"):
        words, line = para.split(), ""
        for w in words:
            trial = (line + " " + w).strip()
            if line and width_units(trial, size, weight) > max_w:
                out.append(line)
                line = w
            else:
                line = trial
        out.append(line)
    return "\n".join(out)


def line_h(text, size, ls=LS):
    return (text.count("\n") + 1) * ls * size / PT_PER_UNIT


class Block:
    def __init__(self, pad_t=1.35, pad_b=1.35, max_w=FULL_W, center=True):
        self.items, self.pad_t, self.pad_b = [], pad_t, pad_b
        self.max_w, self.center = max_w, center

    def add(self, text, size=None, weight="normal", color=INK,
            style="normal", gap=0.0, ls=LS):
        s = size or S_BODY
        t = wrap(text, s, self.max_w, weight)
        self.items.append((t, s, weight, color, style, gap, ls))
        return self

    def content_h(self):
        return sum(g + line_h(t, s, ls) for t, s, w, c, st, g, ls in self.items)

    def height(self):
        return self.pad_t + self.content_h() + self.pad_b


class Section:
    def __init__(self, block, face=None, edge=None, gap_before=GAP_HEADER,
                 arrow=False, blocks=None, faces=None, edges=None, bar=False):
        self.block, self.face, self.edge = block, face, edge
        self.gap_before, self.arrow = gap_before, arrow
        self.blocks, self.faces, self.edges = blocks, faces, edges
        self.bar = bar

    @property
    def boxed(self):
        return self.face is not None or self.blocks is not None or self.bar

    def height(self):
        if self.bar:
            return BAR_H
        if self.blocks:
            return max(b.height() for b in self.blocks)
        return self.block.height() if self.boxed else self.block.content_h()


def build():
    S = []

    t = Block(pad_t=0, pad_b=0, max_w=XMAX - 2 * MARGIN_X)
    t.add("Sweetened Beverage Consumption and Risk of Atrial Fibrillation",
          size=S_TITLE, weight="bold")
    t.add("Two-sample and multivariable Mendelian randomization with East Asian context",
          size=S_SUB, color=MUT, style="italic", gap=1.0)
    S.append(Section(t, gap_before=0.0))

    # ---- DATA (exposures + outcome together, as in Figure 1) ----
    b = Block()
    b.add("DATA — 7 beverage phenotypes + 3 plasma metabolites", size=S_HDR,
          weight="bold", color=BLUE)
    b.add("Beverages (UK Biobank; N = 64,949–447,485)", gap=1.15)
    b.add("sugar added to tea · sugar added to coffee · fizzy drinks (SSB)")
    b.add("low-calorie drinks (ASB) · sweetener added to tea · coffee · tea")
    b.add("Metabolites (Chen 2023; N ≈ 8,000)", gap=0.85)
    b.add("caffeine · paraxanthine · theobromine")
    b.add("AF: Nielsen 2018 (60,620 cases) · non-overlapping FinnGen R13 (67,783)",
          gap=0.85, size=7.7)
    b.add("AFGen 2018 (55,114) · BioBank Japan (8,180; East Asian)", size=7.7)
    S.append(Section(b, LBLUE, BLUE, gap_before=GAP_HEADER))

    # ---- DESIGN ----
    b = Block()
    b.add("DESIGN", size=S_HDR, weight="bold", color=MUT)
    b.add("Two-sample MR: IVW, MR-Egger, weighted median, MR-PRESSO\n"
          "MVMR with BMI · colocalization · LDSC · reverse MR · alcohol control",
          gap=1.2)
    S.append(Section(b, GREY, MUT, gap_before="F", arrow=True))

    # ---- section bar ----
    k = Block(pad_t=0, pad_b=0)
    k.add("KEY FINDINGS", size=8.2, weight="bold", color=BLUE)
    S.append(Section(k, gap_before="F", arrow=True, bar=True))

    # ---- findings ----
    g = Block(pad_t=1.45, pad_b=1.45, max_w=HALF_W + 8)
    g.add("Sweetened beverages", size=S_ROW, weight="bold", color=GREEN)
    g.add("→ No genetic evidence of a\ncausal association with AF",
          size=S_BOLD, weight="bold", color=GREEN, gap=0.95)
    g.add("Meta-analytic OR 0.82–0.97;\nall P ≥ 0.06; null across\ncohorts and estimators",
          size=S_NOTE, gap=1.15)
    a = Block(pad_t=1.45, pad_b=1.45, max_w=HALF_W + 8)
    a.add("Coffee nominal signal (OR 1.34)", size=S_ROW, weight="bold", color=AMBER)
    a.add("→ Not robust to\nsensitivity analyses",
          size=S_BOLD, weight="bold", color=AMBER, gap=0.95)
    a.add("BMI-adjusted OR 0.82;\ncolocalizes with AF only at FTO;\ncaffeine/paraxanthine null (P ≥ 0.31)",
          size=S_NOTE, gap=1.15)
    S.append(Section(None, gap_before=GAP_GROUP_A, blocks=[g, a],
                     faces=[LGREEN, LAMBER], edges=[GREEN, AMBER]))

    # ---- genetic correlation ----
    b = Block()
    b.add("Genetic correlation does not imply causation", size=S_HDR,
          weight="bold", color=GREEN)
    b.add("SSB and ASB share genetic architecture with AF (rg = 0.24–0.31)\n"
          "despite null MR estimates — adiposity-related pleiotropy;\n"
          "cross-trait intercepts ≈ 0 exclude sample-overlap bias", gap=1.2)
    S.append(Section(b, LGREEN, GREEN, gap_before=GAP_GROUP_B))

    # ---- conclusion ----
    b = Block()
    b.add("CONCLUSION", size=S_HDR, weight="bold", color="#bcd3de")
    b.add("No evidence that genetically proxied sweetened-beverage intake\n"
          "causes AF; moderate-to-large effects are excluded. Observational\n"
          "associations likely reflect adiposity-related confounding, so\n"
          "prevention is better directed at cardiometabolic risk factors than\n"
          "at beverage avoidance. Direct milk-tea studies in East Asian\n"
          "cohorts remain needed.", color="white", gap=1.2)
    S.append(Section(b, INK, INK, gap_before="F", arrow=True))

    f = Block(pad_t=0, pad_b=0)
    f.add("Genetic nulls converge with randomized trial evidence (CRAVE, DECAF).",
          size=S_NOTE, color=MUT, style="italic")
    S.append(Section(f, gap_before=GAP_HEADER))
    return S


sections = build()
content = sum(s.height() for s in sections)
fixed = sum(s.gap_before for s in sections
            if s.gap_before in (GAP_HEADER, GAP_GROUP_A, GAP_GROUP_B))
n_flow = sum(1 for s in sections if s.gap_before == "F")
avail = YMAX - MARGIN_TOP - MARGIN_BOT
F = (avail - content - fixed) / n_flow
ARROW_LEN = min(4.2, F - 0.85)
print(f"content={content:.2f}  fixed={fixed:.2f}  flow gaps={n_flow}  "
      f"F={F:.2f} u ({F * PT_PER_UNIT:.1f} pt)  arrow={ARROW_LEN:.2f} u "
      f"({ARROW_LEN * PT_PER_UNIT:.1f} pt)")
assert 3.4 < F < 7.0, "flow gap out of range — retune type sizes"

y = YMAX - MARGIN_TOP
tops = []
for i, s in enumerate(sections):
    if i > 0:
        y -= F if s.gap_before == "F" else s.gap_before
    tops.append(y)
    y -= s.height()
print(f"stack bottom={y:.2f} (target {MARGIN_BOT})")


def draw_block(x, y_top, block):
    cur = y_top - block.pad_t
    for text, size, weight, color, style, g, ls in block.items:
        cur -= g
        ax.text(x, cur, text, fontsize=size, color=color, fontweight=weight,
                style=style, ha="center", va="top", linespacing=ls, zorder=4)
        cur -= line_h(text, size, ls)


def draw_box(x, y_top, w, h, face, edge, r=1.6):
    ax.add_patch(FancyBboxPatch((x, y_top - h), w, h,
                                boxstyle=f"round,pad=0,rounding_size={r}",
                                facecolor=face, edgecolor=edge, linewidth=1.2, zorder=2))


def v_arrow(y_from, y_to):
    mid = (y_from + y_to) / 2
    ax.add_patch(FancyArrowPatch((XMAX / 2, mid + ARROW_LEN / 2),
                                 (XMAX / 2, mid - ARROW_LEN / 2),
                                 arrowstyle="-|>", mutation_scale=ARROW_HEAD,
                                 linewidth=1.4, color=MUT, zorder=3,
                                 shrinkA=0, shrinkB=0))


for i, s in enumerate(sections):
    ytop = tops[i]
    h = s.height()
    if s.bar:
        draw_box(MARGIN_X, ytop, BOX_W, h, LBLUE, BLUE, r=1.2)
        ax.text(XMAX / 2, ytop - h / 2, s.block.items[0][0], ha="center", va="center",
                fontsize=s.block.items[0][1], fontweight="bold", color=BLUE, zorder=4)
    elif s.blocks:
        boxw = (BOX_W - 4.0) / 2
        for blk, fc, ec, x in zip(s.blocks, s.faces, s.edges,
                                  [MARGIN_X, MARGIN_X + boxw + 4.0]):
            draw_box(x, ytop, boxw, h, fc, ec)
            draw_block(x + boxw / 2, ytop, blk)
    elif s.boxed:
        draw_box(MARGIN_X, ytop, BOX_W, h, s.face, s.edge)
        draw_block(XMAX / 2, ytop, s.block)
    else:
        draw_block(XMAX / 2, ytop, s.block)

    if s.arrow:
        v_arrow(tops[i - 1] - sections[i - 1].height(), ytop)

# ------------------------------------------------------------------ verification
fig.canvas.draw()
r = fig.canvas.get_renderer()
inv = ax.transData.inverted()
problems = []


def bbox_units(t):
    bb = t.get_window_extent(renderer=r)
    (x0, y0), (x1, y1) = inv.transform([[bb.x0, bb.y0], [bb.x1, bb.y1]])
    return x0, y0, x1, y1


for i, s in enumerate(sections):
    for blk in (s.blocks or [s.block]):
        for text, size, weight, color, style, g, ls in blk.items:
            for ln in text.split("\n"):
                w = width_units(ln, size, weight)
                lim = HALF_W + 0.2 if s.blocks else (FULL_W + 0.2 if s.boxed else XMAX - 2 * MARGIN_X)
                if w > lim:
                    problems.append(f"line too wide: {ln[:44]!r} ({w:.1f})")

for t in ax.texts:
    x0, y0, x1, y1 = bbox_units(t)
    if x0 < MARGIN_X + 0.2 or x1 > XMAX - MARGIN_X - 0.2:
        problems.append(f"text outside safe area: {t.get_text()[:42]!r} "
                        f"[{x0:.1f},{x1:.1f}]")

for i, s in enumerate(sections):
    if not s.boxed:
        continue
    ytop, h = tops[i], s.height()
    if s.blocks:
        boxw = (BOX_W - 4.0) / 2
        xb = [(MARGIN_X, MARGIN_X + boxw), (MARGIN_X + boxw + 4.0, XMAX - MARGIN_X)]
    else:
        xb = [(MARGIN_X, XMAX - MARGIN_X)]
    for t in ax.texts:
        x0, y0, x1, y1 = bbox_units(t)
        cy = (y0 + y1) / 2
        if not (ytop - h - 0.2 <= cy <= ytop + 0.2):
            continue
        if not any(x0 >= bx0 - 0.05 and x1 <= bx1 + 0.05 for bx0, bx1 in xb):
            problems.append(f"text wider than its box: {t.get_text()[:40]!r}")
        if y0 < ytop - h + 0.08 or y1 > ytop - 0.08:
            problems.append(f"text outside vertical box bounds: {t.get_text()[:45]!r}")

for i, s in enumerate(sections):
    if s.bar:
        continue
    for blk in (s.blocks or [s.block]):
        cur = tops[i] - blk.pad_t
        spans = []
        for text, size, weight, color, style, g, ls in blk.items:
            cur -= g
            spans.append((cur, cur - line_h(text, size, ls), text))
            cur -= line_h(text, size, ls)
        for (t1, b1, s1), (t2, b2, s2) in zip(spans, spans[1:]):
            if b1 < b2 - 1e-6:
                problems.append(f"block overlap: {s1[:25]!r} / {s2[:25]!r}")

# balance of the two finding boxes
gs = sections[4].blocks
print(f"finding boxes: green {gs[0].height():.2f} u / amber {gs[1].height():.2f} u "
      f"(row {sections[4].height():.2f} u)")

print("\nVERIFY:", "PASS — no overlap, widths fit, equal flow gaps, identical arrows"
      if not problems else f"{len(problems)} problem(s)")
for p in problems:
    print("  -", p)

out = (r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
       r"\06_升级分析_v4\figures\Graphical_Abstract_v54_300dpi.png")
fig.savefig(out, dpi=DPI, facecolor="white")
print("written:", out)
