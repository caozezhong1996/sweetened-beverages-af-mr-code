# -*- coding: utf-8 -*-
"""Compare the two MR-RAPS passes with each other and with Table S23."""
import csv
import io
import re
import sys

from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

SUP = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\supplement_v52_JAHA.docx"


def key(name):
    s = name.lower().replace("_", " ").replace("-", " ")
    s = re.sub(r"[()]", "", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def load(path):
    out = {}
    for r in csv.DictReader(open(path, encoding="utf-8")):
        out[(key(r["exposure"]), r["outcome"])] = (
            int(r["nsnp"]), float(r["b"]), float(r["se"]), float(r["p"]))
    return out


p1 = load("raps_rerun_14_pass1.csv")
p2 = load("raps_rerun_14_pass2.csv")

print("cells pass1:", len(p1), " pass2:", len(p2))
same = all(p1[k] == p2[k] for k in p1)
print("two-pass determinism:", "PASS (bit-identical)" if same else "FAIL")
if not same:
    for k in p1:
        if p1[k] != p2[k]:
            print("  differs:", k, p1[k], p2[k])

# Table S23
doc = Document(SUP)
tbl = next(t for t in doc.tables if "MR-RAPS" in " ".join(c.text for c in t.rows[0].cells))
rows = []
for r in tbl.rows[1:]:
    c = [x.text.strip() for x in r.cells]
    rows.append((c[0], c[1], int(c[2]), float(c[3]), float(c[4]), float(c[5])))

print(f"\n{'cell':<50}{'n':>4}{'logOR':>10}{'P':>10}{'|db|':>10}{'|dP|':>10}  verdict")
print("-" * 104)
bad = 0
for expo, out, n, b, se, p in rows:
    k = (key(expo), out)
    if k not in p1:
        print(f"{expo[:30]+' x '+out:<50}  NOT IN RERUN  {k}")
        bad += 1
        continue
    rn, rb, rse, rp = p1[k]
    db, dp = abs(rb - b), abs(rp - p)
    ok = rn == n and db < 5e-3 and dp < 5e-3
    bad += 0 if ok else 1
    print(f"{(expo[:30] + ' x ' + out):<50}{rn:>4}{rb:>10.4f}{rp:>10.4f}"
          f"{db:>10.1e}{dp:>10.1e}  {'ok' if ok else 'MISMATCH'}")

print("-" * 104)
print(f"reproduced: {len(rows) - bad}/{len(rows)} cells; "
      f"{'ALL MATCH Table S23' if bad == 0 else f'{bad} mismatch'}")
