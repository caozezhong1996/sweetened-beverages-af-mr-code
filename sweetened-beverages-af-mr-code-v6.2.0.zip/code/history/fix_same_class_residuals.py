import io
import sys
from pathlib import Path
from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
PKG = Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")


def replace(name, old, new, expected=1):
    path = PKG / name
    doc = Document(str(path))
    hits = 0
    for p in doc.paragraphs:
        if old in p.text:
            full = p.text.replace(old, new)
            hits += full.count(new) - p.text.count(new)
            for run in p.runs:
                run.text = ""
            p.runs[0].text = full
    assert hits == expected, (name, old, hits, expected)
    doc.save(str(path))
    print("PASS", name, old[:70])


replace("Manuscript.docx", "to verify pipeline sensitivity against the alcohol positive control", "to evaluate directional consistency with the alcohol positive control")
replace("Manuscript.docx", "and an independent coffee GWAS (field 1498)", "and a second UK Biobank coffee GWAS (field 1498)")
replace("Manuscript.docx", "A placebo test confirmed that the convergence is not simply the consequence of losing instruments:", "A placebo test argued against simple random-deletion convergence:")
replace("Cover_Letter.docx", "detected its established effect, confirming analytical sensitivity.", "was directionally consistent with its established effect, offering qualified support for analytical sensitivity.")
replace("Highlights.docx", "Null estimates exclude moderate-to-large effects, but not small effects of observational size.", "Null estimates exclude effects above their 95% confidence upper bounds (about 17% for most exposures), but not observational-magnitude effects.")
