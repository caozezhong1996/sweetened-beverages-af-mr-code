# -*- coding: utf-8 -*-
import io
import pathlib
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

ADD = """

---

## 第三轮（2026-10-27）：Yuan 2025 并为主结局（方案 A，不并入 meta）

### 定案
原 meta 是预设定（Nielsen + FinnGen R13），**不改**。Yuan 2025 作为修订期新增的**独立 co-primary** 并列报告。
理由：并入后糖加茶合并 P 变成 0.044（跨过 0.05），与「甜饮料无因果证据」主结论相互拉扯；
且回溯性改动预设定分析集在方法学上站不住。

### 改动清单
| 位置 | 改动 |
|---|---|
| 摘要 M&R | 四个来源改为 primary + 两个无重叠 co-primary（FinnGen、Yuan）+ BBJ 东亚；加 Yuan 甜饮料全空（0.76–1.04, P ≥ 0.083）与咖啡体脂剔除结果；**248/250 词** |
| 摘要 Conclusions | 唯一的咖啡信号由体脂位点携带 |
| Methods 结局数据 | Yuan 明写为 co-primary；说明公开版仅 8 个发现队列、不含 UKB（UKB 36,075 例只在不公开的更大版本里）；说明不并入预设定 meta 的理由 |
| Methods 新增小节 | Adiposity-locus sensitivity（±500 kb、724 个 BMI 位点、明示 post hoc） |
| Results 仪器 | 133 个唯一工具中 128（96%）在 Yuan 面板可得，8–30 个/暴露 |
| Results 甜饮料 | 加 Yuan 五表型全空一句；other three sources → other four sources (all P > 0.08) |
| Results 咖啡 | 加 Yuan 1.79（P = 0.0022）；加「估计随样本量单调上升而非向零收缩，是偏倚随把握度累积的特征」；加 Yuan 的 WM/Egger/RAPS 全空与 Q P = 1.5×10⁻³⁰ |
| Results 新增段 | **Adiposity-locus instruments carry the coffee signal**：FTO rs1421085 与 TMEM18 rs13387939 的 Wald OR 9.95 / 10.67（其余中位 1.2）；剔除后 1.79→1.26（P = 0.18）、1.58→1.39（P = 0.096）、1.26→1.39（P = 0.028）；三来源估计由 1.26–1.79 收敛到 1.26–1.39 |
| Discussion 主发现 | three European sources → four（含 192,851 例无 UKB 面板）；咖啡段改为被体脂位点携带 |
| Discussion 咖啡 | 加 Wald 位点证据，并如实保留唯一反例：Nielsen 剔除后仍 P = 0.028，不能排除小的非体脂效应 |
| Discussion BMI 对照 | 加「估计收敛」作为体脂解释的佐证 |
| Clinical Perspective | 四个来源；咖啡条目改为体脂位点携带 |
| Introduction / 对比段 / Strengths | largest AF GWAS 4 处改写（Yuan 现在才是最大的） |
| 预设偏离段 | Three deviations → Five deviations（加体脂敏感性与新增 co-primary） |
| Table 1 | 加 Yuan 行（192,851 / 1,239,541，GWAS Catalog CC0） |
| Table 2 | 加第 4 列 Yuan；列序改为 Nielsen / FinnGen / Yuan / AFGen / BBJ / meta / SNPs；合并列保持不变 |
| 表宽 | 四张表全部超栏宽（最大 20.25 cm vs 可用 15.92）→ 归一化到 15.88 cm |
| Supplement | 新增 Table S26（Yuan 全估计面板）与 S27（三队列体脂敏感性 21 行）；Contents 补 S25–S27 |
| Cover Letter | 四个来源、咖啡段、sixteen times → up to fifty times、four outcome sources → five、25 tables → 27 |
| Highlights | 咖啡条目改为「剔除体脂位点后归零（1.79→1.26）」 |

### 顺带修掉的两个真 bug
1. **表 2 表头只传了 7 个单元格**（数据行有 8 个）——加列时才暴露，已改为直接传 `T2.header`。
2. **投稿信补丁第一次写错**：同一段里两处替换都用「原始文本」重写 runs[0]，后一次覆盖前一次，
   结果只生效一处。改为按段落累积替换后重跑。

### 机器校验（全部 PASS）
摘要 248/250；引文 46 条连续；表 2 八列且 Yuan 列 7/7 逐格回源；表 1 含 Yuan 行；四表宽度 ≤ 15.92 cm；
正文引用的 Table S2–S27 全部存在；S26/S27 行数与咖啡三行回源一致；过时表述清零；四份 docx 元数据正确。

### 仍未做
- **Figure 2 未重画**：仍是 11×12 in 原稿，印刷缩到 17.4 cm 后正文仅 4.3–5.5 pt；且尚无 Yuan 列。
  图注已改为「Yuan 数据见 Table 2 与 Table S26」，不作虚假陈述。投稿前必须重画。
- 补充材料另有 11 张表超宽（最大 22.7 cm），属既有缺陷，未动。
- 奶茶框架（标题/摘要首句）、Author Contributions 仍待定。
"""

p = pathlib.Path(r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版"
                 r"\JAHA_v525_改稿留档\审读意见_20261026\修正记录_20261026.md")
t = p.read_text(encoding="utf-8")
if "第三轮" in t:
    print("skip — already present")
else:
    p.write_text(t + ADD, encoding="utf-8")
    print("appended; lines:", len((t + ADD).splitlines()))
