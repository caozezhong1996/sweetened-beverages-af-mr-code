# -*- coding: utf-8 -*-
"""build_supplement_v45.js -> v50: S17 扩展(tea) + S22/S23 新表 + Contents 更新。
双轮复核记录：
S17b: R1=茶侧全套量与三 seed 批跑一致(diff P 0.057/0.097/0.093 均>0.05); R2=列结构与 S17 兼容, note 与手稿 M28d/M28e 表述一致。双 PASS。
S22: R1=nsnp 与 Table 2 完全一致(14/34/8/17/15/17/32, 已验证); R2=F=(β/se)² 与 dat 文件 F_stat 列互验。双 PASS。
S23: R1=两轮运行逐位一致; R2=coffee 数字与手稿 Results 句一致(0.17/P=0.11; 0.47/P=0.13)。双 PASS。
"""
import io, sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
SRC = r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\04_docx构建脚本\build_supplement_v45.js"
DST = r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\04_docx构建脚本\build_supplement_v50.js"
t = open(SRC, encoding="utf-8").read()

E = []

# 1. 加载新 TSV
E.append(("加载S17b/S22/S23",
 'const T21 = readTsv(path.join(DIR, "S21_coloc_tea.tsv"));',
 'const T21 = readTsv(path.join(DIR, "S21_coloc_tea.tsv"));\nconst T17B = readTsv(path.join(DIR, "S17b_mrlap_tea.tsv"));\nconst T22 = readTsv(path.join(DIR, "S22_instrument_strength.tsv"));\nconst T23 = readTsv(path.join(DIR, "S23_mrraps.tsv"));',
 1))

# 2. Contents 更新（S17 描述 + S22/S23 插入）
E.append(("Contents S17 描述",
 "Table S17 MRlap correction for sample overlap, winner's curse and weak-instrument bias;",
 "Table S17 MRlap correction for sample overlap, winner's curse and weak-instrument bias (coffee), continued for tea intake;",
 1))
E.append(("Contents 加 S22/S23",
 "Figure S1 leave-one-out and funnel plots (separate PNG);",
 "Table S22 instrument-strength metrics for all beverage exposures; Table S23 MR-RAPS robust adjusted profile score estimates for all exposures against both co-primary outcomes; Figure S1 leave-one-out and funnel plots (separate PNG);",
 1))

# 3. S17 之后插入 S17b（tea 扩展）
E.append(("S17b 插入",
 '''children.push(note("MRlap (Mounier & Kutalik, 2023; manuscript ref 26) approximates sample overlap by cross-trait LDSC (GenomicSEM implementation) and derives a corrected causal estimate under a spike-and-slab genetic-architecture model; both traits entered as Z-scores from the same munged files used for the LDSC analysis (Tables S10-S11), so effects are per SD and only sign and precision are interpreted. The corrected effect (0.037, SE 0.023) did not differ significantly from the observed IVW effect (0.028, SE 0.018; difference P = 0.070), and the cross-trait intercept (-0.010, SE 0.006) matched the independent LDSC diagnostic (-0.011, SE 0.008; Table S11), jointly excluding material bias from sample overlap, winner's curse and weak instruments. HapMap-3 SNP list: w_hm3.snplist (MHC retained); 8,000 simulations were used for the variance of the corrected effect."));''',
 '''children.push(note("MRlap (Mounier & Kutalik, 2023; manuscript ref 26) approximates sample overlap by cross-trait LDSC (GenomicSEM implementation) and derives a corrected causal estimate under a spike-and-slab genetic-architecture model; both traits entered as Z-scores from the same munged files used for the LDSC analysis (Tables S10-S11), so effects are per SD and only sign and precision are interpreted. The corrected effect (0.037, SE 0.023) did not differ significantly from the observed IVW effect (0.028, SE 0.018; difference P = 0.070), and the cross-trait intercept (-0.010, SE 0.006) matched the independent LDSC diagnostic (-0.011, SE 0.008; Table S11), jointly excluding material bias from sample overlap, winner's curse and weak instruments. HapMap-3 SNP list: w_hm3.snplist (MHC retained); 8,000 simulations were used for the variance of the corrected effect."));

children.push(caption("Table S17 (continued). MRlap correction for sample overlap, winner's curse and weak-instrument bias: tea intake and atrial fibrillation (both co-primary outcomes)"));
children.push(makeTable(
  [1400, 4000, 2200, 1000, 1000],
  ["Outcome", "Quantity", "Estimate", "SE", "P"],
  T17B.rows.map((r) => [r[0] === "Nielsen2018" ? "Nielsen 2018" : (r[0] === "FinnGenR13" ? "FinnGen R13" : r[0]), r[1], r[2], r[3], r[4]]), 18));
children.push(note("Extension of the MRlap analysis from coffee to tea (the only other exposure with genome-wide-significant instruments and public full summary statistics), requested in revision. Corrected and observed tea estimates were closely similar against both co-primary outcomes; across three independent runs the difference test gave P = 0.057-0.097 (Nielsen 2018) and P = 0.18-0.24 (FinnGen R13), the residual variability reflecting the 8,000-simulation variance estimation. MRlap is not applicable to the five relaxed-threshold sub-phenotypes, whose instruments (P < 5 × 10⁻⁶) do not survive the genome-wide-significance threshold MRlap requires; for those exposures, MR-RAPS (Table S23) and the contamination-mixture estimator (Table S14) serve as the weak-instrument-robust alternatives."));''',
 1))

# 4. S21 之后插入 S22/S23
E.append(("S22/S23 插入（S21 note 之后、const doc 之前）",
 "const doc = new Document({",
 '''children.push(caption("Table S22. Instrument-strength metrics for all beverage exposures (primary Nielsen 2018 outcome instrument sets)"));
children.push(makeTable(
  [2600, 1600, 900, 1100, 1100, 1100, 1200],
  T22.header, T22.rows, 18));
children.push(note("Per-variant F statistics computed as (beta/se)² from the harmonized instrument sets used against the primary outcome (identical to Table 2 SNP counts); cumulative R² as 2·EAF·(1−EAF)·beta² summed over instruments. All per-variant F statistics exceed 20; however, F statistics capture neither winner's curse nor correlated pleiotropy, which are addressed by MR-RAPS (Table S23) and MRlap (Table S17), respectively discussed in the manuscript Limitations."));

children.push(caption("Table S23. MR-RAPS (robust adjusted profile score) estimates for all beverage exposures against both co-primary outcomes"));
children.push(makeTable(
  [2800, 1700, 900, 1500, 1000, 1100],
  T23.header, T23.rows, 18));
children.push(note("MR-RAPS (Zhao et al., 2020; manuscript ref 39) provides inference robust to many weak and pleiotropic instruments; over-dispersion was allowed with the Tukey loss function (the original MR-RAPS procedure, mr.raps.mle; the weight-shrinkage variant did not converge for these short instrument sets, consistent with its documented behaviour with few weak instruments). Every exposure was null against both co-primary outcomes, including coffee (Nielsen 2018 log-OR 0.17, P = 0.11; FinnGen R13 0.47, P = 0.13), further supporting the interpretation that the nominal IVW coffee signal is not robust."));

const doc = new Document({''',
 1))

fail = 0
for name, old, new, exp in E:
    n = t.count(old)
    if n == exp:
        t = t.replace(old, new); print(f"PASS {name}")
    else:
        print(f"FAIL {name}: 命中 {n} != {exp}"); fail += 1
if not fail:
    open(DST, "w", encoding="utf-8", newline="\n").write(t)
    print("build_supplement_v50.js 已写出")

# ---- 手稿两处微调（表引用补全）----
MS = r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\04_docx构建脚本\build_manuscript_v50.js"
m = open(MS, encoding="utf-8").read()
ME = [
    ("M28c 补表引", "were null for every exposure against both co-primary outcomes, including coffee",
     "were null for every exposure against both co-primary outcomes (Table S23), including coffee", 1),
    ("M28d 补表引", "although all F statistics exceeded 20, F statistics capture neither winner's curse nor correlated pleiotropy",
     "although all F statistics exceeded 20 (Table S22), F statistics capture neither winner's curse nor correlated pleiotropy", 1),
]
mf = 0
for name, old, new, exp in ME:
    n = m.count(old)
    if n == exp:
        m = m.replace(old, new); print(f"PASS {name}")
    else:
        print(f"FAIL {name}: 命中 {n}"); mf += 1
if not mf:
    open(MS, "w", encoding="utf-8", newline="\n").write(m)
    print("手稿表引用已补全")
