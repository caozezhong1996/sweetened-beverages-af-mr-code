suppressMessages({library(data.table); library(TwoSampleMR)})
d0 <- fread("C:/a3work/dat_Coffee_intake_finngen_R13.csv")
cat("cols:", paste(names(d0), collapse = ", "), "\n")
cat("nrow:", nrow(d0), "\n")
print(head(d0[, .(SNP, beta.exposure, se.exposure, effect_allele.exposure,
                  other_allele.exposure, eaf.exposure, beta.outcome, se.outcome,
                  effect_allele.outcome, other_allele.outcome, eaf.outcome, mr_keep)], 3))
r <- tryCatch({
  ex <- format_data(as.data.frame(d0), type = "exposure", snp_col = "SNP",
                    beta_col = "beta.exposure", se_col = "se.exposure",
                    effect_allele_col = "effect_allele.exposure",
                    other_allele_col = "other_allele.exposure",
                    eaf_col = "eaf.exposure", pval_col = "pval.exposure")
  "format_data(exposure) OK"
}, error = function(x) paste("ERR:", conditionMessage(x)))
cat(r, "\n")
