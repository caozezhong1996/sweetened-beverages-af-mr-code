# -*- coding: utf-8 -*-
"""Move the JAHA version records from the wrong master into the paper's own archive."""
import io
import shutil
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

WRONG = Path(r"C:\Users\64915\Desktop\维护母版_心脏—胃肠_改稿只在这里\奶茶房颤MR_JAHA")
ARCH = Path(r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版")
DEST = ARCH / "JAHA_v525_改稿留档"

DEST.mkdir(parents=True, exist_ok=True)
(WRONG / "旧版图件").mkdir(exist_ok=True)

# 1) figures
src_figs = WRONG / "旧版图件"
dst_figs = DEST / "旧版图件"
dst_figs.mkdir(exist_ok=True)
for f in sorted(src_figs.glob("*.png")):
    d = dst_figs / f.name
    if d.exists():
        print("  skip (exists):", f.name)
        continue
    shutil.move(str(f), str(d))
    print(f"  moved {f.name}")

# 2) docs
for f in ("投稿包_版本沿革与校验.md", "README_母版.md"):
    s = WRONG / f
    if not s.exists():
        print("  skip (absent):", f)
        continue
    d = DEST / f
    if d.exists():
        print("  skip (exists):", f)
        continue
    shutil.move(str(s), str(d))
    print(f"  moved {f}")

# 3) drop the wrong (now empty) folder
left = [p for p in WRONG.rglob("*") if p.is_file()]
if left:
    print("  !! files still inside the wrong folder:", [p.name for p in left])
else:
    shutil.rmtree(WRONG)
    print("  removed empty wrong folder:", WRONG)

print("\n--- archive now ---")
for p in sorted(ARCH.rglob("*")):
    if p.is_file():
        print(f"  {(p.stat().st_size/1024):7.0f} KB  {p.relative_to(ARCH)}")
