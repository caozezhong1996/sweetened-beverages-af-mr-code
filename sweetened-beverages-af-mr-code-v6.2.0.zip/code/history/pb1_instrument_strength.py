# -*- coding: utf-8 -*-
"""PB1（R1-2）：全暴露工具强度表——每 SNP 的 R²(=2·EAF·(1-EAF)·β²)、累计解释方差、F 统计量范围。
数据源：03_结果数据_mr_results/dat_*.csv（暴露侧信息与结局无关，取每暴露首个文件）。
输出：桌面投稿包 06_新增分析_B级/Table_S22_instrument_strength_draft.csv
"""
import io, sys, csv, glob, os
from collections import OrderedDict

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
D = r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\03_结果数据_mr_results"
OUT = r"C:\Users\64915\Desktop\EHJOpen投稿包_奶茶房颤MR_v5.0_20261006\06_新增分析_B级\Table_S22_instrument_strength_draft.csv"
os.makedirs(os.path.dirname(OUT), exist_ok=True)

# 每暴露取第一个存在的 dat 文件（暴露侧列一致）
files = {}
for p in sorted(glob.glob(os.path.join(D, "dat_*.csv"))):
    base = os.path.basename(p)[4:-4]
    for suf in ["_ebi_a_GCST006061", "_finn_b_I9_AF", "_bbj_a_71"]:
        if base.endswith(suf):
            base = base[: -len(suf)]
            break
    files.setdefault(base, p)

rows = []
for expo in sorted(files):
    p = files[expo]
    with open(p, encoding="utf-8") as f:
        rd = list(csv.DictReader(f))
    n = 0
    r2_sum = 0.0
    fs = []
    for r in rd:
        try:
            beta = abs(float(r["beta.exposure"]))
            se = float(r["se.exposure"])
            eaf = float(r["eaf.exposure"])
            npp = float(r["samplesize.exposure"])
        except (KeyError, ValueError):
            continue
        if not (0 < eaf < 1) or se == 0:
            continue
        r2 = 2 * eaf * (1 - eaf) * beta ** 2
        f_stat = (beta / se) ** 2
        r2_sum += r2
        fs.append(f_stat)
        n += 1
    fs.sort()
    rows.append(OrderedDict([
        ("exposure", expo),
        ("SNPs_used", n),
        ("N_exposure_GWAS", int(max(float(r["samplesize.exposure"]) for r in rd if r.get("samplesize.exposure")))),
        ("min_F", round(min(fs), 1)),
        ("median_F", round(fs[len(fs) // 2], 1)),
        ("max_F", round(max(fs), 1)),
        ("sum_R2_percent", round(r2_sum * 100, 3)),
        ("instrument_threshold", "P<5e-8" if expo in ("Coffee intake", "Tea intake") else "P<5e-6"),
    ]))

with open(OUT, "w", encoding="utf-8", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader()
    w.writerows(rows)

print(f"{'exposure':<38}{'SNPs':>5}{'minF':>8}{'medF':>8}{'maxF':>8}{'sumR2%':>9}")
for r in rows:
    print(f"{r['exposure']:<38}{r['SNPs_used']:>5}{r['min_F']:>8}{r['median_F']:>8}{r['max_F']:>8}{r['sum_R2_percent']:>9}")
print("\n输出:", OUT)
