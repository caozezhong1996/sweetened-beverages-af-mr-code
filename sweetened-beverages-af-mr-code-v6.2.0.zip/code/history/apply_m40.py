# -*- coding: utf-8 -*-
"""M40: "组件≠复合物"论证段落盘（Discussion, [92] 段之前）。
双轮复核：
R1（审稿人意图）: 直接回应 R2-1 点名的三个复合物特征（糖浓度/来源、奶脂含量、boba 高 GI）——逐一对上；
  rg–MR 分离 + FTO 共定位是本稿数据自证"组件推断脆弱性"，比纯文字承认更有力。PASS
R2（全局一致性）: 与既有 [92] 段互补不重复（该段讲"非安全结论+急性 bolus"，本段讲"组件不可外推+数据证据"）；
  rg 0.24–0.31 与 Table S11 舍入一致；FTO 与 Results（PP.H4 0.894）一致；[30] 首现于前文咖啡段列表引用，
  此处复用合法；无新引用、无重编号；+140 词。PASS → 执行
"""
import io, sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
P = r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\04_docx构建脚本\build_manuscript_v50.js"
t = open(P, encoding="utf-8").read()

NEW_BLOCK = '''  mix([
    T`Most fundamentally, the component-proxy design estimates the marginal, lifelong effects of individual ingredients rather than the effect of the composite beverage: a null for sugar, caffeine and tea does not entail a null for milk tea, which additionally entails possible sugar\u2013caffeine interaction, non-instrumented constituents (non-dairy creamer with its saturated and trans-fatty-acid load; tapioca toppings of high glycaemic index), and an acute per-serving character that lies outside a per-category lifelong estimand. The present data themselves illustrate why component-level inference is fragile: fizzy- and low-calorie-drink intake share genetic architecture with AF (rg = 0.24\u20130.31) despite null MR estimates, and the nominal coffee signal colocalized with AF only through the adiposity locus FTO. Component-level nulls with pleiotropically entangled architectures therefore cannot certify the safety of a composite beverage they do not instrument; the acute time window and dose\u2013response shape are questions for randomized ambulatory-monitoring designs [30].`,
  ]),
'''

anchor = "  mix([\n    T`Current genetic evidence does not support sweetened beverage intake as a direct causal determinant of AF;"
n = t.count(anchor)
print("锚点命中:", n)
if n == 1:
    t = t.replace(anchor, NEW_BLOCK + anchor)
    open(P, "w", encoding="utf-8", newline="\n").write(t)
    print("M40 已落盘")
else:
    print("命中数异常，不落盘")
