# -*- coding: utf-8 -*-
"""Graphical abstract v53: add the UK Biobank-free outcome and the adiposity-locus
result; drop the retired 'East Asian contextual analysis' subtitle."""
import io
import pathlib
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

SRC = pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
                   r"\06_升级分析_v4\scripts\graphical_abstract_v52.py")
DST = SRC.with_name("graphical_abstract_v53.py")

t = SRC.read_text(encoding="utf-8")

E = [
    # 1. subtitle
    ('"A two-sample and multivariable Mendelian randomization study\\nwith East Asian contextual analysis"',
     '"A two-sample and multivariable Mendelian randomization study\\nwith a UK Biobank-free co-primary outcome"'),
    # 2. outcome box: five sources
    ('"OUTCOME — atrial fibrillation, four GWAS sources"',
     '"OUTCOME — atrial fibrillation, five GWAS sources"'),
    ('"Nielsen 2018 (60,620 cases; primary)  ·  FinnGen R13 (67,783; co-primary)\\n"\n'
     '               "AFGen 2018 (55,114; sensitivity)  ·  BioBank Japan (8,180; East Asian contextual)",\n'
     '    size=7.8)',
     '"Nielsen 2018 (60,620; primary)  ·  FinnGen R13 (67,783; co-primary)\\n"\n'
     '               "Yuan 2025, UKB-free (192,851; co-primary)  ·  AFGen 2018 (55,114)\\n"\n'
     '               "BioBank Japan (8,180; East Asian contextual)",\n'
     '    size=7.2)'),
    # 3. coffee box
    ('txt(74, 68.6, "Coffee nominal signal (OR 1.34)", size=7.9, weight="bold", color=AMBER)\n'
     'txt(74, 65.9, "→ fails every consistency test", size=7.9, weight="bold", color=AMBER)\n'
     'txt(74, 60.8, "Attenuated by BMI (OR 0.82);\\ncolocalizes with AF only at FTO\\n(adiposity), not CYP1A1–CYP1A2 / AHR",\n'
     '    size=7.4)',
     'txt(74, 68.6, "Coffee signal (OR 1.34) is adiposity", size=7.6, weight="bold", color=AMBER)\n'
     'txt(74, 65.9, "→ not a caffeine-handling pathway", size=7.6, weight="bold", color=AMBER)\n'
     'txt(74, 61.4, "Excluding variants near 724 BMI loci\\n"\n'
     '              "abolished it: 1.79 → 1.26 (P = 0.18);\\n"\n'
     '              "sources converge on 1.26–1.39",\n'
     '    size=7.2)'),
    # 4. green box: mention the UKB-free panel
    ('"Meta-analytic OR 0.82–0.97, all P ≥ 0.06;\\nnull across cohorts, estimators, ancestries"',
     '"Meta-analytic OR 0.82–0.97, all P ≥ 0.06;\\nUKB-free 0.76–1.04; null across estimators"'),
    # 5. output filename
    ('Graphical_Abstract_v52_300dpi.png', 'Graphical_Abstract_v53_300dpi.png'),
]

ok = True
for i, (old, new) in enumerate(E, 1):
    c = t.count(old)
    print(("PASS  " if c == 1 else f"FAIL x{c}  ") + f"G{i} " + old.split("\n")[0][:58])
    if c != 1:
        ok = False
        continue
    t = t.replace(old, new)

if ok:
    DST.write_text(t, encoding="utf-8", newline="\n")
    print("\nwritten", DST.name)
else:
    print("\nABORTED")
