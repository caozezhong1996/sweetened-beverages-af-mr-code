# -*- coding: utf-8 -*-
"""A5 sensitivity v2: exclude ALL adiposity (BMI-locus) instruments, random-effects IVW."""
import csv
import io
import math
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

R = r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\06_升级分析_v4\results"

step1 = list(csv.DictReader(open(R + r"\mediation_step1_dat_coffee_bmi_v46.csv", encoding="utf-8")))
cof = list(csv.DictReader(open(R + r"\dat_Coffee_intake_ebi_a_GCST006414.csv", encoding="utf-8")))
pos = {r["SNP"]: (str(r.get("chr", "")).replace("chr", ""), int(float(r.get("pos", 0) or 0)))
       for r in cof if r.get("pos")}

bmi = list(csv.DictReader(open(R + r"\tmp_bmi_instruments_v46.csv", encoding="utf-8")))
hdr = list(bmi[0].keys())
print("BMI 工具表列:", hdr[:10])
cpos = [i for i in bmi if i.get("chr") and i.get("pos")]
print("BMI 工具数（含位置）:", len(cpos))

WINDOW = 500_000
windows = {}
for r in cpos:
    c = str(r["chr"]).replace("chr", "")
    p = int(float(r["pos"]))
    windows.setdefault(c, []).append((p - WINDOW, p + WINDOW))

def near_bmi(snp):
    if snp not in pos:
        return False, None
    c, p = pos[snp]
    for lo, hi in windows.get(c, []):
        if lo <= p <= hi:
            return True, (c, p)
    return False, (c, p)

flag = [(r["SNP"], near_bmi(r["SNP"])) for r in step1]
adipo = [s for s, (f, _) in flag if f]
print(f"\n落在 BMI 位点 ±500 kb 内的咖啡工具（{len(adipo)}）：{adipo}")

def re_ivw(rows):
    num = den = 0.0
    for r in rows:
        bx, sy = float(r["beta.exposure"]), float(r["se.outcome"])
        by = float(r["beta.outcome"])
        w = 1 / sy ** 2
        num += w * bx * by
        den += w * bx * bx
    b = num / den
    se_fe = math.sqrt(1 / den)
    q = sum((float(r["beta.outcome"]) - b * float(r["beta.exposure"])) ** 2 / float(r["se.outcome"]) ** 2
            for r in rows)
    n = len(rows)
    phi = max(1.0, q / (n - 1))
    return b, se_fe * math.sqrt(phi), q, n, phi

b2, se2 = 0.3428, 0.0265
total, total_se = 0.2347, 0.1120

def pval(z):
    return 2 * (1 - 0.5 * (1 + math.erf(abs(z) / math.sqrt(2))))

for tag, rows in (("全部 17 个工具（现状）", step1),
                  ("剔除 FTO 区域（1 个）", [r for r in step1 if r["SNP"] not in {"rs1421085"}]),
                  ("剔除全部 BMI 位点工具", [r for r in step1 if r["SNP"] not in adipo])):
    if len(rows) < 3:
        print(f"\n--- {tag}: 工具不足（n={len(rows)}）")
        continue
    b1, se1, q, n, phi = re_ivw(rows)
    ind, ind_se = b1 * b2, math.sqrt((b2 * se1) ** 2 + (b1 * se2) ** 2)
    direct = total - ind
    print(f"\n--- {tag} (n={n}) ---")
    print(f"  step1 coffee→BMI : beta={b1:+.4f}  SE(RE)={se1:.4f}  P={pval(b1/se1):.3g}  Q={q:.1f}  phi={phi:.1f}")
    print(f"  间接效应         : {ind:+.4f}  SE={ind_se:.4f}  95%CI [{ind-1.96*ind_se:+.3f}, {ind+1.96*ind_se:+.3f}]"
          f"  {'跨零' if ind-1.96*ind_se < 0 < ind+1.96*ind_se else '不跨零'}")
    print(f"  中介比例         : {ind/total*100:.0f}%")
    print(f"  直接效应         : {direct:+.4f}  OR={math.exp(direct):.3f}")
