# -*- coding: utf-8 -*-
import io, re, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

PROPOSED = [
    ("TITLE", "Sweetened Beverage Consumption and Risk of Atrial Fibrillation"),
    ("SUB", "Two-sample and multivariable Mendelian randomization with East Asian context"),
    ("DATA h", "DATA — 7 beverage phenotypes + 3 plasma metabolites"),
    ("DATA 1", "Beverages (UK Biobank, N = 64,949–447,485): sugar added to tea or coffee, fizzy drinks (SSB), low-calorie drinks (ASB), sweetener added to tea, coffee, tea"),
    ("DATA 2", "Plasma metabolites (Chen 2023, N ≈ 8,000): caffeine · paraxanthine · theobromine"),
    ("DATA 3", "Atrial fibrillation: Nielsen 2018 (60,620 cases) · non-overlapping FinnGen R13 (67,783) · AFGen 2018 · BioBank Japan"),
    ("DESIGN h", "DESIGN"),
    ("DESIGN", "Two-sample MR (IVW, MR-Egger, weighted median, MR-PRESSO) · multivariable MR with BMI · colocalization · LDSC · reverse MR · alcohol positive control"),
    ("KF", "KEY FINDINGS"),
    ("F1 h", "Sweetened beverages"),
    ("F1 b", "→ No genetic evidence of a causal association with AF"),
    ("F1 n", "Meta-analytic OR 0.82–0.97; all P ≥ 0.06"),
    ("F2 h", "Coffee nominal signal (OR 1.34)"),
    ("F2 b", "→ Not robust to sensitivity analyses"),
    ("F2 n", "BMI-adjusted OR 0.82; colocalizes with AF only at FTO;\nplasma caffeine and paraxanthine null (P ≥ 0.31)"),
    ("F3 h", "Genetic correlation does not imply causation"),
    ("F3 n", "SSB and ASB share genetic architecture with AF (rg = 0.24–0.31) despite null MR estimates —\nadiposity-related pleiotropy; cross-trait intercepts ≈ 0 exclude sample-overlap bias"),
    ("CONC h", "CONCLUSION"),
    ("CONC", "No evidence that genetically proxied sweetened-beverage intake causes AF; moderate-to-large\neffects are excluded. Observational associations likely reflect adiposity-related confounding, so\nprevention is better directed at cardiometabolic risk factors than at beverage avoidance.\nDirect milk-tea studies in East Asian cohorts remain needed."),
]

tot = 0
for tag, s in PROPOSED:
    n = len([w for w in re.split(r"\s+", s.replace("\n", " ")) if re.search(r"[A-Za-z0-9]", w)])
    tot += n
    print(f"{tag:<10}{n:>4}  {s[:70]}")
print("-" * 60)
print("proposed total words:", tot)

CURRENT = {
    "title": "Sweetened Beverage Consumption and Risk of Atrial Fibrillation",
    "sub": "Two-sample and multivariable Mendelian randomization with East Asian context",
}
print("\ncurrent 236 -> proposed", tot, f"({tot - 236:+d})")
