# -*- coding: utf-8 -*-
"""摘要控词修复：252→≤250。双轮复核记录：
R1(审稿人意图): PP.H4 具体数值在正文 Results 与 Table S8 完整保留，摘要删括号不损失任何审稿人要求的信息。
R2(全局一致性): 摘要 Results 其余数字不变；不与任何其他修改冲突。
结论: 双 PASS → 执行。
"""
import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

P = r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\04_docx构建脚本\build_manuscript_v50.js"
t = open(P, encoding="utf-8").read()

edits = [
    ("M38 摘要压缩 PP.H4 括号",
     "and colocalization only at the adiposity locus FTO (PP.H4 ≥ 0.894), not at caffeine-metabolism loci (PP.H4 ≤ 0.008).",
     "and colocalization only at the adiposity locus FTO, not at caffeine-metabolism loci.", 1),
]
fail = 0
for name, old, new, exp in edits:
    n = t.count(old)
    if n == exp:
        t = t.replace(old, new)
        print(f"PASS {name}")
    else:
        print(f"FAIL {name}: 命中 {n} != {exp}，不落盘")
        fail += 1
if not fail:
    open(P, "w", encoding="utf-8", newline="\n").write(t)
    print("已写回。")
