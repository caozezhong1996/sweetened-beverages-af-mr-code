# -*- coding: utf-8 -*-
"""Apply the verified P1 fixes to the manuscript build script (source of truth)."""
import io
import re
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

JS = Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
          r"\04_docx构建脚本\build_manuscript_v51_JAHA.js")
t = JS.read_text(encoding="utf-8")
orig_len = len(t)

E = []

# ---------- A3: 结局数据陈述（事实错误） ----------
E.append((
 "A larger cross-population meta-analysis was recently published [16], but its summary statistics are not public (GCST90624413); our sources are therefore the largest publicly usable European-ancestry resources.",
 "A larger cross-population meta-analysis was recently published [16]. Its European-ancestry summary statistics are now publicly available (GCST90624413; 192,851 cases and 1,239,541 controls; CC0 licence). Nielsen 2018 was retained as the primary outcome for comparability with previous Mendelian randomization studies, and FinnGen R13 provided an independent, overlap-free co-primary outcome."))

E.append((
 "(Per-variant summary statistics not publicly available; GWAS Catalog GCST90624413, checked 22 August 2026.)",
 "(GWAS Catalog GCST90624413; full summary statistics publicly available under CC0.)"))

# ---------- A2 + C6: 工具集表述与 F 阈值 ----------
E.append((
 "Instrument strength used per-variant F statistics (F > 10 required). Identical instrument lists were used across outcome sources.",
 "Instrument strength used per-variant F statistics (F > 20 required, chosen to limit weak-instrument bias for sub-phenotypes instrumented at P < 5 × 10⁻⁶). The same index variants were used across outcome sources; for BioBank Japan, four proxy variants were substituted where the index variant was unavailable, giving 36 variants."))

E.append((
 "with identical instrument lists across outcome sources. All per-variant F statistics exceeded 20",
 "with the same index variants harmonised to every outcome panel (BioBank Japan required four proxies; Table 2). All per-variant F statistics exceeded 20"))

# ---------- C7: Methods 预设定判据 ----------
E.append((
 "For exposures showing a nominal IVW association (P < 0.05) against the primary outcome, MR-PRESSO was applied to detect horizontal pleiotropy and outlier instruments.",
 "For exposures showing a nominal IVW association (P < 0.05) against the primary outcome, MR-PRESSO was applied to detect horizontal pleiotropy and outlier instruments. A nominal association was required to satisfy all of the following pre-specified criteria before a causal interpretation was considered: Cochran's Q P > 0.05; a concordant weighted-median estimate with P < 0.05; a significant MR-PRESSO outlier-corrected estimate; an MR-Egger intercept P > 0.05; and colocalization at a locus not driven solely by adiposity."))

# ---------- A4: 上界与观察值的对撞 ----------
E.append((
 "Meta-analytic upper confidence bounds (1.01–1.17) exclude effects of the magnitude reported observationally (1.1–1.2).",
 "Meta-analytic upper confidence bounds (1.01–1.17) overlap the point estimates reported observationally (1.1–1.2) for fizzy (1.17) and low-calorie drinks (1.11); effects of that magnitude cannot be excluded. The two estimands are not directly convertible (a per-category increment versus high-versus-low consumption)."))

# ---------- A7: MR-RAPS 最小 P ----------
E.append((
 "all other tests were null (P ≥ 0.51)",
 "all other tests were null (the smallest of the remaining P values was 0.49)"))

# ---------- A8: F 值表号悬空 ----------
E.append((
 "Metabolite instruments (2–7 locus-lead variants; per-variant F 30–49; Table S25)",
 "Metabolite instruments (2–7 locus-lead variants; per-variant F 29.8–48.7)"))

# ---------- B1: 图注中的版本化文件名 ----------
E.append((" (file: Figure2_Forest_v41_300dpi.png)", ""))
E.append((" (file: FigureS1_LOO_Funnel_v43_300dpi.png)", ""))
E.append((" (file: FigureS2_LDSC_rg_v45_300dpi.png)", ""))

# ---------- B8: replication -> contextual ----------
E.append(("East Asian replication used BioBank Japan statistics",
          "The East Asian contextual analysis used BioBank Japan statistics"))
E.append(("East Asian replication estimates were imprecise",
          "East Asian contextual estimates were imprecise"))

# ---------- C1: 不归因于体质，只说不来自咖啡因通路 ----------
E.append((
 "The only nominal signal (coffee intake) was attributable to adiposity rather than caffeine pathways: it attenuated after body-mass-index adjustment and colocalized with atrial fibrillation only at the FTO locus, not at caffeine-metabolism loci.",
 "The only nominal signal (coffee intake) was not attributable to caffeine-handling pathways: it attenuated after body-mass-index adjustment and colocalized with atrial fibrillation only at the FTO locus, not at caffeine-metabolism loci. The coffee instrument set also tracks adiposity liability, the direction of which is not identifiable here."))

# ---------- C2: converge -> compatible ----------
E.append((
 "Null genetic estimates converge with randomized trial evidence.",
 "The genetic estimate is compatible with no harm but is not concordant in direction with the protective effect reported in DECAF."))

# ---------- C5: rg 限定来源 ----------
E.append((
 "positive genetic correlations with AF (rg = 0.24–0.31; FDR q < 0.05)",
 "positive genetic correlations with AF against FinnGen R13 (rg = 0.24–0.31; FDR q < 0.05)"))

# ---------- 摘要压缩（为上面新增腾字数） ----------
E.append((
 "was not robust: weighted-median estimates were null, outlier robustness was source-dependent, the estimate attenuated in multivariable models with weak conditional instruments (OR 0.82; P = 0.099), and colocalization was confined to the adiposity locus FTO.",
 "was not robust: weighted-median and outlier-robust estimates were inconsistent, it attenuated with body-mass-index adjustment (OR 0.82; P = 0.099), and colocalization was confined to the FTO locus."))
E.append((
 "Plasma caffeine and paraxanthine instruments were unassociated with AF (P ≥ 0.31).",
 "Plasma caffeine and paraxanthine instruments were null (P ≥ 0.31)."))

# ---------- A1: 删除重复的 [47] ----------
m47 = re.search(r"\n\s*T`47\. Zheng J[^\n]*`,\s*", t)
if not m47:
    print("!! 未找到 47 号文献行")
else:
    t = t[:m47.start()] + "\n" + t[m47.end():]
    print("删除重复文献 [47]")

ok = True
for old, new in E:
    c = t.count(old)
    if c != 1:
        print(f"[FAIL x{c}] {old[:70]}")
        ok = False
        continue
    t = t.replace(old, new)
    print(f"[ok] {old[:64]}")

# [47] -> [31]（正文引用）
c47 = t.count("[47]")
t = t.replace("[47]", "[31]")
print(f"[ok] 正文 [47]→[31]：{c47} 处")

if ok:
    JS.write_text(t, encoding="utf-8", newline="\n")
    print(f"\n写入完成：{orig_len} → {len(t)} 字符")
else:
    print("\n有替换未命中，未写入")
