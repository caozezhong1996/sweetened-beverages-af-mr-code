# -*- coding: utf-8 -*-
"""Fix path references now that the records live in the paper's own archive."""
import io
import re
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

PKG = Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")
ARCH = Path(r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版")
DEST = ARCH / "JAHA_v525_改稿留档"

# ---- 1. rename + rewrite the folder readme ----
old_readme = DEST / "README_母版.md"
new_readme = DEST / "README_改稿留档.md"
text = """# JAHA 投稿 · 改稿留档

本目录存放**不进投稿包**的东西：已退役的图件版本、投稿包的版本沿革与机器校验记录。
投稿包本身（只含上传文件、文件名不带版本号）在：
`C:\\Users\\64915\\Desktop\\JAHA投稿包_奶茶房颤MR_20261013`

- `投稿包_版本沿革与校验.md` —— 版本变更史、六轮修订记录、构建链、verify 结论
- `旧版图件/` —— 每次重绘后退役的图（保留版本号便于追溯）
  - `Graphical_Abstract_v50 / v52 / v53.png`
  - `Figure1_Study_Design_v52.png`、`Figure2_v41.png`

**注意**：这 5 张与工作区迁移包 `06_升级分析_v4/figures/` 下的同名图 **md5 完全一致**
（2026-10-26 核验），属同一份内容的两个位置。若要严格守"只留独一份"，
可删本目录的 `旧版图件/`，改由迁移包作为唯一存放点；两处都留只是为了离线可读。

规则：**改稿只在留档侧留痕；投稿文件夹永远只有当前要上传的文件，且文件名不带版本号。**
"""
if old_readme.exists():
    old_readme.unlink()
new_readme.write_text(text, encoding="utf-8")
print("written:", new_readme.name)

# ---- 2. fix the header path inside the version record ----
rec = DEST / "投稿包_版本沿革与校验.md"
t = rec.read_text(encoding="utf-8")
t = re.sub(r"- 母版位置：`[^`]*`", "- 留档位置：`" + str(DEST) + "`", t)
if "md5 一致" not in t:
    t = t.replace("---\n\n## v5.2", "---\n\n> 旧版图件与本目录外的迁移包 `06_升级分析_v4/figures/` 所存同名图 md5 一致（2026-10-26 核验），属同一内容的两个位置。\n\n## v5.2", 1)
rec.write_text(t, encoding="utf-8")
print("patched:", rec.name)

# ---- 3. fix the pointer in the submission-package README ----
rd = PKG / "README_投稿包.md"
r = rd.read_text(encoding="utf-8")
r = r.replace(
    "`桌面\\维护母版_心脏—胃肠_改稿只在这里\\奶茶房颤MR_JAHA\\`",
    "`桌面\\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版\\JAHA_v525_改稿留档\\`")
rd.write_text(r, encoding="utf-8")
print("patched: package README pointer")

# ---- 4. append a section to the archive readme ----
ar = ARCH / "README_归档说明.md"
a = ar.read_text(encoding="utf-8")
if "JAHA_v525_改稿留档" not in a:
    a += """
## 2026-10-26 并入
- `JAHA_v525_改稿留档/`：JAHA 投稿包的改稿留档——版本沿革与机器校验记录（`投稿包_版本沿革与校验.md`）+ 退役图件（GA v50/v52/v53、Figure1 v52、Figure2 v41）。
- 同日起**投稿包纪律**固定为：投稿文件夹只放上传文件、文件名不带版本号；版本信息一律进本归档。
- 注：`旧版图件/` 的 5 张与工作区 `06_升级分析_v4/figures/` 同名图 md5 一致，属同一内容两处存放；若要严格单份，可删本归档内这一组。
"""
    ar.write_text(a, encoding="utf-8")
    print("appended: README_归档说明.md")

print("\n--- final ---")
for p in sorted(DEST.rglob("*")):
    if p.is_file():
        print(f"  {(p.stat().st_size/1024):7.0f} KB  {p.relative_to(ARCH)}")
