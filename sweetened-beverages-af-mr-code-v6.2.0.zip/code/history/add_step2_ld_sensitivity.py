# -*- coding: utf-8 -*-
from docx import Document
import pathlib, csv
PKG = pathlib.Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")
res = next(csv.DictReader(open(r"C:\a3work\step2_ld_clumped_ivw.csv", encoding="utf-8")))
assert res["n_mr"] == "321"
sup = Document(str(PKG / "Supplement.docx"))
t16 = next(t for t in sup.tables if t.rows[0].cells[0].text == "Component" and any(r.cells[0].text == "Total effect" for r in t.rows[1:]))
assert not any("LD-clumped" in r.cells[0].text for r in t16.rows)
row = t16.add_row()
vals = ["Step 2 sensitivity (M->Y)", "BMI -> AF (Nielsen 2018), LD clumped r2 < 0.001, 10,000 kb", "IVW", res["n_mr"], f"{float(res['b']):.4f}", f"{float(res['se']):.4f}", "3.2e-30"]
for c,v in zip(row.cells,vals): c.text=v
step2 = next(r for r in t16.rows if r.cells[0].text == "Step 2 (M->Y)")
step2._tr.addnext(row._tr)
p = next(p for p in sup.paragraphs if p.text.startswith("Network (two-step) mediation MR"))
old = "Step 2 used 701 BMI instruments (P < 5 × 10⁻⁸) selected by 1-Mb window pruning; this is distance pruning, not LD clumping, and residual linkage disequilibrium may make its confidence interval anti-conservative."
new = "Step 2 used 701 BMI instruments (P < 5 × 10⁻⁸) selected by 1-Mb window pruning; this is distance pruning, not LD clumping. A sensitivity analysis using genuine EUR LD clumping (r² < 0.001 within 10,000 kb) retained 321 instruments and gave a similar BMI–AF estimate with a wider standard error (β = 0.3506, SE = 0.0307), supporting the direction of Step 2 but not the mediation interpretation."
assert old in p.text
text = p.text.replace(old,new)
for r in p.runs: r.text=""
p.runs[0].text=text
sup.save(str(PKG / "Supplement.docx"))

man = Document(str(PKG / "Manuscript.docx"))
p = next(p for p in man.paragraphs if p.text.startswith("Two-step mediation MR was"))
old = "Because the total and indirect estimates are unstable, mediated proportions are not reported and these analyses do not establish mediation (Table S16)."
new = "A genuine LD-clumped Step 2 sensitivity gave a similar BMI–AF estimate with a wider standard error (β = 0.351, SE = 0.031; 321 SNPs). Because the total and indirect estimates are unstable, mediated proportions are not reported and these analyses do not establish mediation (Table S16)."
assert old in p.text
text=p.text.replace(old,new)
for r in p.runs: r.text=""
p.runs[0].text=text
man.save(str(PKG / "Manuscript.docx"))
print("LD sensitivity added to S16 and Results")
