# -*- coding: utf-8 -*-
import io
import pathlib
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

ADD = """

---

## 第六轮（2026-10-27）：奶茶框架定案 —— 方案 B

### 先纠正一个前提
审之前说"标题讲奶茶"，实际查证：**标题里没有 milk tea**；奶茶只出现在正文，20 处，
且 Introduction 已明写 "motivated—but were not directly evaluated in—the present analysis"，
Discussion 明写 "does not entail a null for milk tea"。所以"文不对题"的风险比原先判断的小。

真正的软肋是**副标题 "With East Asian Contextual Analysis"**：BBJ 那一臂 8,180 例、
CI 0.21–2.11，是全文最弱的部分，却写进标题；而新增的 UKB-free 192,851 例 co-primary 反而没露面。

### 定案：B（保留钩子，结论降为成分级先验）+ 换副标题
不放宽到 A（删奶茶），理由是奶茶是唯一差异化叙事；也不选 C（不改），因为副标题一行就能修。

改动：
| 位置 | 改前 | 改后 |
|---|---|---|
| 标题（手稿/补充/投稿信/元数据） | …Mendelian Randomization Study **With East Asian Contextual Analysis** | …Mendelian Randomization Study |
| 摘要 Conclusions | "small ones are not." | "small ones are not, **and component-level nulls cannot certify the safety of composite milk-tea beverages**." |
| 摘要 M&R（腾字数） | 153 词 | 145 词（AF data / 去掉 "East Asian context" / 合并估计量句 / 若干压缩） |

摘要 248 → **249 / 250**（新增 12 词、压缩 11 词）。

### 踩到一个真坑
为了改标题重建了投稿信 → **投稿信被 JS 构建脚本回滚**，之前直接改在 docx 上的 A3 内容全部丢失。
根因：那 4 处（四个来源 / 咖啡段 / up to fifty / five outcome sources / twenty-seven）当初是
用 python-docx 直接改 docx 的，没进 JS 源头。
已把这 4 处补进 `build_cover_letter_v51_JAHA.js` 并重建，现在重建不会再退化。

**规则：docx 是产物，改稿一律改 JS 构建脚本；直接改 docx 只允许用于"构建器不支持"的内容**
（例如本次的 docx 核心属性元数据，那本来就要在最后一次重建之后做）。
"""

p = pathlib.Path(r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版"
                 r"\JAHA_v525_改稿留档\审读意见_20261026\修正记录_20261026.md")
t = p.read_text(encoding="utf-8")
if '第六轮' in t:
    print("skip")
else:
    p.write_text(t + ADD, encoding="utf-8")
    print("revision log updated")

MEM = """

## 奶茶框架定案（17:50–18:10）

- 方案 **B**：保留奶茶钩子，摘要结论加 "component-level nulls cannot certify the safety of
  composite milk-tea beverages"；**副标题删掉 "With East Asian Contextual Analysis"**。
- 标题现为 "Sweetened Beverage Consumption and Risk of Atrial Fibrillation: A Two-Sample and
  Multivariable Mendelian Randomization Study"（15 词），手稿/补充材料/投稿信/元数据四处同步。
- 摘要 249/250。
- **重要教训**：为改标题重建投稿信，导致之前直接改在 docx 上的 A3 内容被 JS 回滚。
  已补进 `build_cover_letter_v51_JAHA.js`。**改稿只改 JS 构建脚本，docx 是产物**；
  只有构建器覆盖不到的东西（核心属性元数据）才在最后一步用 python-docx 补。
"""

m = pathlib.Path(r"C:\Users\64915\WorkBuddy\2026-10-06-13-49-21\.workbuddy\memory\2026-10-27.md")
t2 = m.read_text(encoding="utf-8")
if "奶茶框架定案" in t2:
    print("memory skip")
else:
    m.write_text(t2 + MEM, encoding="utf-8")
    print("memory updated")
