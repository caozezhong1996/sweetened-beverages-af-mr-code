exp <- read.csv("C:/a3work/dat_Coffee_intake_ebi_a_GCST006414.csv", stringsAsFactors=FALSE, check.names=FALSE)
y <- read.delim("C:/a3work/yuan2025_instruments.tsv", stringsAsFactors=FALSE, check.names=FALSE)
y <- y[y$exposure == "Coffee_intake" & y$SNP %in% exp$SNP, ]
comp <- function(a) chartr("ACGT", "TGCA", a)
m <- match(y$SNP, exp$SNP)
ea <- exp$effect_allele.exposure[m]; oa <- exp$other_allele.exposure[m]
by <- rep(NA_real_, nrow(y))
by[y$ea.out == ea & y$oa.out == oa] <- y$beta.out[y$ea.out == ea & y$oa.out == oa]
by[y$ea.out == oa & y$oa.out == ea] <- -y$beta.out[y$ea.out == oa & y$oa.out == ea]
by[y$ea.out == comp(ea) & y$oa.out == comp(oa)] <- y$beta.out[y$ea.out == comp(ea) & y$oa.out == comp(oa)]
by[y$ea.out == comp(oa) & y$oa.out == comp(ea)] <- -y$beta.out[y$ea.out == comp(oa) & y$oa.out == comp(ea)]
stopifnot(!anyNA(by))
d <- data.frame(SNP=y$SNP, chr=as.integer(exp$chr[m]), pos=as.integer(exp$pos[m]), bx=as.numeric(exp$beta.exposure[m]), by=by, se=as.numeric(y$se.out))
loci <- read.csv("C:/a3work/tmp_bmi_instruments_v46.csv", stringsAsFactors=FALSE)
near <- vapply(seq_len(nrow(d)), function(i) any(loci$chr == d$chr[i] & abs(loci$pos-d$pos[i]) <= 500000), logical(1))
ivw <- function(z) {
  w <- 1/z$se^2; b <- sum(w*z$bx*z$by)/sum(w*z$bx^2); se0 <- sqrt(1/sum(w*z$bx^2)); q <- sum(w*(z$by-b*z$bx)^2); se <- se0*max(1,sqrt(q/(nrow(z)-1))); p <- 2*pnorm(-abs(b/se))
  c(n=nrow(z), OR=exp(b), lo=exp(b-1.96*se), hi=exp(b+1.96*se), P=p)
}
cat("ALL\n"); print(ivw(d))
cat("EXPOSURE-GRCh37 CLEAN\n"); print(ivw(d[!near,]))
cat("DROPPED\n"); print(d$SNP[near])
