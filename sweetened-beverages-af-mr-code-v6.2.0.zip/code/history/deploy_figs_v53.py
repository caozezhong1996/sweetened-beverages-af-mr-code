# -*- coding: utf-8 -*-
"""Deploy the three rebuilt figures and archive the previous versions."""
import io
import os
import shutil
import sys

from PIL import Image

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

FIGSRC = (r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
          r"\06_升级分析_v4\figures")
PKG = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\figures"
ARCH = (r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版"
        r"\JAHA_v525_改稿留档\旧版图件")

JOBS = [
    ("Figure1_Study_Design_v54_300dpi.png", "Figure1_Study_Design.png", "Figure1_Study_Design_v53.png"),
    ("FigureS1_LOO_Funnel_v53_300dpi.png", "FigureS1_LOO_Funnel.png", "FigureS1_LOO_Funnel_v45.png"),
    ("FigureS2_LDSC_rg_v53_300dpi.png", "FigureS2_LDSC_rg.png", "FigureS2_LDSC_rg_v45.png"),
]

COL = 15.92
os.makedirs(ARCH, exist_ok=True)
for src_name, dst_name, arch_name in JOBS:
    src = os.path.join(FIGSRC, src_name)
    dst = os.path.join(PKG, dst_name)
    if not os.path.exists(src):
        print(f"MISSING {src}")
        continue
    if os.path.exists(dst):
        shutil.move(dst, os.path.join(ARCH, arch_name))
        print(f"archived {dst_name} -> 旧版图件/{arch_name}")
    shutil.copy2(src, dst)
    im = Image.open(dst)
    dpi = im.info.get("dpi", (300, 300))[0]
    w, h = im.size[0] / dpi * 2.54, im.size[1] / dpi * 2.54
    print(f"deployed {dst_name:<28} {w:5.2f} x {h:5.2f} cm @{dpi:.0f} dpi  "
          f"{'OK' if w <= COL + 0.1 else 'STILL WIDE'}")

print("\npackage figures:")
for f in sorted(os.listdir(PKG)):
    im = Image.open(os.path.join(PKG, f))
    dpi = im.info.get("dpi", (300, 300))[0]
    print(f"  {f:<28}{im.size[0]/dpi*2.54:5.2f} x {im.size[1]/dpi*2.54:5.2f} cm")
