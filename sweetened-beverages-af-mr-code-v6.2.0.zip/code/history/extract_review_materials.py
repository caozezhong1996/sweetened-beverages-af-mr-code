import io
import sys
from pathlib import Path
from docx import Document
from docx.oxml.ns import qn

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
ROOT = Path(r"C:\Users\64915\WorkBuddy\2026-10-06-13-49-21")
PKG = Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")


def docx_text(path):
    doc = Document(str(path))
    out = []
    for child in doc.element.body.iterchildren():
        if child.tag == qn("w:p"):
            text = "".join(node.text or "" for node in child.iter(qn("w:t"))).strip()
            if text:
                out.append(text)
        elif child.tag == qn("w:tbl"):
            out.append("[TABLE]")
            for row in child.iter(qn("w:tr")):
                cells = [
                    "".join(node.text or "" for node in cell.iter(qn("w:t"))).strip()
                    for cell in row.iter(qn("w:tc"))
                ]
                out.append(" | ".join(cells))
            out.append("[/TABLE]")
    return "\n".join(out) + "\n"


jobs = {
    "current_review_1.txt": Path(r"C:\Users\64915\WorkBuddy\2026-10-28-13-07-32\审读报告_JAHA_甜饮料房颤MR_20261028.docx"),
    "current_review_2.txt": Path(r"C:\Users\64915\WorkBuddy\2026-10-28-13-07-21\outputs\JAHA_奶茶房颤MR_编辑与审稿人双视角审查报告.docx"),
    "current_manuscript.txt": PKG / "Manuscript.docx",
    "current_supplement.txt": PKG / "Supplement.docx",
    "current_cover_letter.txt": PKG / "Cover_Letter.docx",
    "current_highlights.txt": PKG / "Highlights.docx",
}
for name, path in jobs.items():
    text = docx_text(path)
    (ROOT / name).write_text(text, encoding="utf-8", newline="\n")
    print(name, len(text), "chars")

md_path = Path(r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版\JAHA_v525_改稿留档\审读意见_20261028\审读报告_JAHA投稿包_20261028.md")
text = md_path.read_text(encoding="utf-8")
(ROOT / "current_review_3.txt").write_text(text, encoding="utf-8", newline="\n")
print("current_review_3.txt", len(text), "chars")
