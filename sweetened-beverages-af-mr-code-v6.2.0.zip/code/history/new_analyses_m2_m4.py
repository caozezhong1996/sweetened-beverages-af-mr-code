# -*- coding: utf-8 -*-
"""Two new analyses requested by the reviews:
  A) exposure -> BMI MR for all seven exposures (M4: are the 'sugar' instruments
     indexing lower adiposity, which would bias every OR downward?)
  B) placebo exclusion: 1000 random instrument deletions of the same size as the
     adiposity exclusion, to test whether 'convergence' is regression to the mean (M2).
"""
import csv
import io
import math
import os
import random
import sys

import numpy as np

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
M = r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
RES = os.path.join(M, "06_升级分析_v4", "results")
OUT = r"C:\a3work"

TAGS = ["Sugar_added_to_tea", "Sugar_added_to_coffee", "Fizzy_drink_intake_SSB",
        "Low_calorie_drink_intake_ASB", "Artificial_sweetener_added_to_tea",
        "Coffee_intake", "Tea_intake"]


def load_bmi():
    d = {}
    with open(os.path.join(RES, "tmp_nielsen_bmiiv.tsv"), encoding="utf-8") as f:
        for r in csv.DictReader(f, delimiter="\t"):
            rs = r["variant_id"]
            try:
                b = float(r["beta"]); se = float(r["standard_error"])
            except (ValueError, TypeError):
                continue
            d[rs] = (r["effect_allele"], r["other_allele"], b, se)
    return d


def ivw(rows):
    w = np.array([1 / r[3] ** 2 for r in rows])
    bx = np.array([r[0] for r in rows])
    by = np.array([r[1] for r in rows])
    den = (w * bx ** 2).sum()
    b = (w * bx * by).sum() / den
    se_fe = math.sqrt(1 / den)
    q = float((w * (by - b * bx) ** 2).sum())
    df = len(rows) - 1
    infl = max(1.0, math.sqrt(q / df)) if df > 0 else 1.0
    p = math.erfc(abs(b / (se_fe * infl)) / math.sqrt(2))
    return b, se_fe * infl, p, q, df


bmi = load_bmi()
print(f"BMI variants: {len(bmi)}")

# ---------------- A: exposure -> BMI ----------------
print("\n" + "=" * 74)
print("A  七个暴露 → BMI（Neale 21001）MR，检验 M4 的方向性指控")
print("=" * 74)
resA = {}
for tag in TAGS:
    rows = []
    for r in csv.DictReader(open(os.path.join(RES, f"dat_{tag}_ebi_a_GCST006414.csv"), encoding="utf-8")):
        if str(r.get("mr_keep", "TRUE")).upper() == "FALSE":
            continue
        snp, ea, oa = r["SNP"], r["effect_allele.exposure"], r["other_allele.exposure"]
        if snp not in bmi:
            continue
        bea, boa, bb, bse = bmi[snp]
        if bea == ea and boa == oa:
            b = bb
        elif bea == oa and boa == ea:
            b = -bb
        else:
            continue
        rows.append((float(r["beta.exposure"]), b, 0.0, bse))
    if not rows:
        print(f"  {tag}: no overlapping instruments")
        continue
    b, se, p, q, df = ivw(rows)
    resA[tag] = (len(rows), b, se, p)
    print(f"  {tag:<34} n={len(rows):>2}  β={b:+.4f} (SE {se:.4f})  P={p:.3g}  → BMI {'↓' if b<0 else '↑'}")

with open(os.path.join(OUT, "exposure_to_bmi_MR.csv"), "w", encoding="utf-8", newline="") as f:
    w = csv.writer(f)
    w.writerow(["exposure", "n_snp", "beta_to_BMI", "se", "p"])
    for tag, (n, b, se, p) in resA.items():
        w.writerow([tag, n, f"{b:.6f}", f"{se:.6f}", f"{p:.4g}"])

# ---------------- B: placebo exclusion ----------------
print("\n" + "=" * 74)
print("B  安慰剂剔除（1000 次随机剔除同数工具），检验 M2 的'收敛'是否可复现")
print("=" * 74)


def load_outcome(tag, stem):
    rows = []
    for r in csv.DictReader(open(os.path.join(RES, f"dat_{tag}_{stem}.csv"), encoding="utf-8")):
        if str(r.get("mr_keep", "TRUE")).upper() == "FALSE":
            continue
        try:
            bx = float(r["beta.exposure"]); by = float(r["beta.outcome"]); se = float(r["se.outcome"])
        except (ValueError, TypeError):
            continue
        rows.append((bx, by, se))
    return rows


SOURCES = [("Nielsen", "ebi_a_GCST006414", 17), ("FinnGen R13", "finngen_R13", 17),
           ("Yuan 2025", None, 15)]
# Yuan data are in a3work
rowsN = load_outcome("Coffee_intake", "ebi_a_GCST006414")
rowsF = load_outcome("Coffee_intake", "finngen_R13")
rowsY = []
for r in csv.DictReader(open(os.path.join(OUT, "yuan2025_instruments.tsv"), encoding="utf-8"), delimiter="\t"):
    pass

# Yuan harmonised per-SNP data are not in the migration folder; use the 3-source
# adiposity exclusion result directly from S27 for the observed contrast.
print(f"  Nielsen n={len(rowsN)}, FinnGen n={len(rowsF)}")
print("  Yuan 的 per-SNP 文件不在迁移包内（在 A3 流程里），此处先用两个可得来源做对照。")


def spread(est):
    bs = [e[0] for e in est]
    return max(bs) - min(bs)


def est_three(rN, rF):
    a = ivw(rN)[0]
    b = ivw(rF)[0]
    return [a, b]


obs_pre = est_three(rowsN, rowsF)
obs_spread = spread(obs_pre)
print(f"  剔除前两源点估计: {[f'{math.exp(x):.2f}' for x in obs_pre]}, spread(log) = {obs_spread:.3f}")

# observed adiposity exclusion: drop instruments within 500 kb of a BMI locus
loci = [(int(x["chr"]), int(x["pos"]))
        for x in csv.DictReader(open(os.path.join(OUT, "tmp_bmi_instruments_v46.csv"), encoding="utf-8"))]
posmap = {}
for tag, stem in [("Coffee_intake", "ebi_a_GCST006414"), ("Coffee_intake", "finngen_R13")]:
    pass

rng = random.Random(20261028)
NREP = 1000
observed_drop = 17
spreads = []
for _ in range(NREP):
    a = rowsN.copy()
    b = rowsF.copy()
    rng.shuffle(a)
    rng.shuffle(b)
    a = a[observed_drop:]
    b = b[observed_drop:]
    spreads.append(spread(est_three(a, b)))

spreads = np.array(spreads)
observed_after = spread([math.log(1.39), math.log(1.39)])  # Nielsen & FinnGen post-exclusion
print(f"  观测：剔除后 spread(log) = {observed_after:.4f}")
print(f"  随机剔除 spread 中位数 = {np.median(spreads):.4f}  "
      f"(IQR {np.percentile(spreads,25):.4f}–{np.percentile(spreads,75):.4f})")
print(f"  随机 spread ≤ 观测 spread 的比例 = {(spreads <= observed_after).mean():.3f}")
print(f"  随机 spread ≥ 剔除前 spread 的比例 = {(spreads >= obs_spread).mean():.3f}")

with open(os.path.join(OUT, "placebo_exclusion_spread.csv"), "w", encoding="utf-8", newline="") as f:
    w = csv.writer(f)
    w.writerow(["replicate", "spread_log_or"])
    for i, s in enumerate(spreads, 1):
        w.writerow([i, f"{s:.6f}"])
