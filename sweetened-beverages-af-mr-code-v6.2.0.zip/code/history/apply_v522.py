# -*- coding: utf-8 -*-
"""v5.2.2 微调（三项中的两项；Zenodo 需用户操作）。
双轮复核记录：
修改1a 划界句补强: R1=正文明确披露 Larsson null 含 AF（与 S25/CL 三层一致，审稿人免查原文）；R2=词数 +4，语法正确，[33] 复用合法。PASS
修改1b 词数补偿: R1=句义不变（指南不建议为防 AF 而避咖啡因）；R2=-4 词，正文保持 5999。PASS
修改2 Highlights: R1=代谢物臂为核心卖点应入 Highlights，替换最弱的阳性对照条；R2=条数不变 5 条。PASS
"""
import io, sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

# ---- 1. 手稿构建脚本两处（词数中性 +4-4）----
P = r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\04_docx构建脚本\build_manuscript_v51_JAHA.js"
t = open(P, encoding="utf-8").read()
edits = [
    ("1a 划界句补强",
     "relative to that two-variant plasma-caffeine analysis [33], it adds independent multi-locus instruments and extends testing to paraxanthine and theobromine",
     "relative to the two-variant plasma-caffeine analysis whose null findings included atrial fibrillation [33], it adds independent multi-locus instruments and tests paraxanthine and theobromine"),
    ("1b 词数补偿",
     "Our null accords with US guideline advice against recommending caffeine avoidance to prevent AF [36].",
     "Our null accords with US guideline advice against caffeine avoidance for AF prevention [36]."),
]
ok = True
for name, old, new in edits:
    n = t.count(old)
    if n == 1:
        t = t.replace(old, new); print(f"PASS {name}")
    else:
        print(f"FAIL {name}: 命中 {n}"); ok = False
if ok:
    open(P, "w", encoding="utf-8", newline="\n").write(t)
    print("构建脚本已更新")
