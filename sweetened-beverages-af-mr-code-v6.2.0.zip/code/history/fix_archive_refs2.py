# -*- coding: utf-8 -*-
"""Steps 2-4: patch the version-record header, the package README pointer, the archive readme."""
import io
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

PKG = Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")
ARCH = Path(r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版")
DEST = ARCH / "JAHA_v525_改稿留档"

OLD_LINE = "- 母版位置：`C:\\Users\\64915\\Desktop\\维护母版_心脏—胃肠_改稿只在这里\\奶茶房颤MR_JAHA`"
NEW_LINE = ("- 留档位置：`" + str(DEST) + "`（本归档内）\n"
            "- 说明：`旧版图件/` 的 5 张与工作区迁移包 `06_升级分析_v4/figures/` 同名图 md5 一致"
            "（2026-10-26 核验），属同一内容的两个位置；若严格单份，删本归档内这一组即可。")

rec = DEST / "投稿包_版本沿革与校验.md"
t = rec.read_text(encoding="utf-8")
assert OLD_LINE in t, "header line not found"
rec.write_text(t.replace(OLD_LINE, NEW_LINE), encoding="utf-8")
print("patched:", rec.name)

rd = PKG / "README_投稿包.md"
r = rd.read_text(encoding="utf-8")
old_ptr = "`桌面\\维护母版_心脏—胃肠_改稿只在这里\\奶茶房颤MR_JAHA\\`"
new_ptr = "`桌面\\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版\\JAHA_v525_改稿留档\\`"
assert old_ptr in r, "package README pointer not found"
rd.write_text(r.replace(old_ptr, new_ptr), encoding="utf-8")
print("patched: package README")

ar = ARCH / "README_归档说明.md"
a = ar.read_text(encoding="utf-8")
if "JAHA_v525_改稿留档" not in a:
    a += """
## 2026-10-26 并入
- `JAHA_v525_改稿留档/`：JAHA 投稿包的改稿留档——版本沿革与机器校验记录
  （`投稿包_版本沿革与校验.md`）+ 退役图件（GA v50/v52/v53、Figure1 v52、Figure2 v41）。
- 同日起**投稿包纪律**固定为：投稿文件夹只放上传文件、文件名不带版本号；版本信息一律进本归档。
- 注：`旧版图件/` 的 5 张与工作区 `06_升级分析_v4/figures/` 同名图 md5 一致，属同一内容两处存放；
  若要严格单份，删本归档内这一组即可。
"""
    ar.write_text(a, encoding="utf-8")
    print("appended: README_归档说明.md")

print("\n--- 归档内新增目录 ---")
for p in sorted(DEST.rglob("*")):
    if p.is_file():
        print(f"  {(p.stat().st_size/1024):7.0f} KB  {p.relative_to(ARCH)}")
