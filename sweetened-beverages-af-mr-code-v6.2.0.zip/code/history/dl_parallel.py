#!/usr/bin/env python
"""Segmented parallel download for GCST90624413 (resumable, per-chunk retry).

Chunks are written to a parts/ dir, then concatenated in order into the target
file. Already-complete chunks are skipped on re-run.
"""
import io, os, sys, time, threading, queue, urllib.request

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

D = r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\06_升级分析_v4\downloads\yuan2025"
TARGET = os.path.join(D, "GCST90624413.tsv.gz")
PARTS = os.path.join(D, "parts")
URL = ("https://ftp.ebi.ac.uk/pub/databases/gwas/summary_statistics/"
       "GCST90624001-GCST90625000/GCST90624413/GCST90624413.tsv.gz")

CHUNK = 8 * 1024 * 1024        # 8 MB per chunk
THREADS = 12
RETRIES = 6


def total_size():
    req = urllib.request.Request(URL, method="HEAD")
    with urllib.request.urlopen(req, timeout=60) as r:
        return int(r.headers["Content-Length"])


def part_path(i):
    return os.path.join(PARTS, f"c{i:05d}.bin")


def want_len(i, start, total):
    return min(CHUNK, total - start)


def fetch(i, start, end, total):
    need = end - start + 1
    p = part_path(i)
    if os.path.exists(p) and os.path.getsize(p) == need:
        return need, 0.0
    last = None
    for attempt in range(RETRIES):
        try:
            req = urllib.request.Request(URL, headers={"Range": f"bytes={start}-{end}"})
            with urllib.request.urlopen(req, timeout=120) as r:
                data = r.read()
            if len(data) == need:
                with open(p, "wb") as f:
                    f.write(data)
                return len(data), 0.0
            last = f"short {len(data)}/{need}"
        except Exception as e:
            last = f"{type(e).__name__}: {e}"
        time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(f"chunk {i} failed: {last}")


def main():
    os.makedirs(PARTS, exist_ok=True)
    total = total_size()
    n = (total + CHUNK - 1) // CHUNK
    print(f"total = {total/1e6:.1f} MB, {n} chunks x {CHUNK//1024//1024} MB, {THREADS} threads")

    q = queue.Queue()
    for i in range(n):
        s = i * CHUNK
        q.put((i, s, min(s + CHUNK, total) - 1))
    done = {"bytes": 0, "chunks": 0, "err": []}
    lock = threading.Lock()
    t0 = time.time()

    def worker():
        while True:
            try:
                i, s, e = q.get_nowait()
            except queue.Empty:
                return
            try:
                got, _ = fetch(i, s, e, total)
                with lock:
                    done["bytes"] += got
                    done["chunks"] += 1
                    if done["chunks"] % 10 == 0 or done["chunks"] == n:
                        el = time.time() - t0
                        print(f"  {done['chunks']}/{n} chunks  {done['bytes']/1e6:.0f} MB  "
                              f"{done['bytes']/max(el,1e-9)/1e6:.2f} MB/s", flush=True)
            except Exception as ex:
                with lock:
                    done["err"].append(str(ex))
                print("  ERR", ex, flush=True)

    ths = [threading.Thread(target=worker, daemon=True) for _ in range(THREADS)]
    for t in ths:
        t.start()
    for t in ths:
        t.join()

    if done["err"]:
        print(f"FAILED: {len(done['err'])} chunks missing; re-run to resume")
        return 1

    print("concatenating ...")
    tmp = TARGET + ".tmp"
    with open(tmp, "wb") as out:
        for i in range(n):
            with open(part_path(i), "rb") as f:
                while True:
                    b = f.read(1 << 22)
                    if not b:
                        break
                    out.write(b)
    got = os.path.getsize(tmp)
    print(f"assembled {got/1e6:.1f} MB (expected {total/1e6:.1f})")
    if got != total:
        print("SIZE MISMATCH - not replacing target")
        return 1
    os.replace(tmp, TARGET)
    print(f"OK -> {TARGET}  elapsed {time.time()-t0:.0f}s")
    return 0


if __name__ == "__main__":
    sys.exit(main())
