# -*- coding: utf-8 -*-
"""统计手稿摘要词数（EHJ Open 要求 ≤250 词）。"""
import re
from docx import Document

path = r"C:\Users\64915\Desktop\EJPC投稿包_奶茶房颤MR_v4.5.6_20260826\01_手稿_Manuscript\Manuscript_v456_Sweetened_Beverages_AF_MR.docx"
doc = Document(path)
paras = [p.text.strip() for p in doc.paragraphs if p.text.strip()]

# 摘要是段落 6-9（Aim/Methods/Results/Conclusions）
abstract_parts = {}
labels = ["Aim", "Methods", "Results", "Conclusions"]
idx = 6
for lab in labels:
    text = paras[idx]
    # 去掉 "Label: " 前缀
    body = re.sub(r"^[A-Za-z]+:\s*", "", text)
    words = body.split()
    abstract_parts[lab] = len(words)
    print(f"{lab}: {len(words)} words")
    idx += 1

total = sum(abstract_parts.values())
print(f"\n摘要总词数: {total} (EHJ Open 上限 250)")
print(f"{'超标' if total > 250 else '达标，余量 ' + str(250 - total) + ' 词'}")

# 标题页检查：是否有字数统计
print("\n【标题页/字数统计检查】")
for i, p in enumerate(paras[:6]):
    print(f"[{i}] {p[:200]}")
