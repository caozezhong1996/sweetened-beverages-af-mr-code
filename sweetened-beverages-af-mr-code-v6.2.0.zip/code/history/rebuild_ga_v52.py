# -*- coding: utf-8 -*-
"""GA v52 从 v50 源重建（一次性目标态，避免补丁叠加）：
- EXPOSURES 标题含代谢物；框 y112/h22；标题131.5/副标128.5/body121.5/斜体行114.5/箭头112
- 不加独立代谢物结果行（避免与 CONCLUSION 重叠）
- 底部两行：收敛 (CRAVE, DECAF) + Direct measurement
"""
import io, sys, pathlib, subprocess, shutil

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
S = pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\06_升级分析_v4\scripts")
t = (S / "graphical_abstract_v50.py").read_text(encoding="utf-8")
E = [
    ('txt(50, 128.8, "EXPOSURES — 7 beverage phenotypes", size=7.8, weight="bold", color=BLUE)',
     'txt(50, 131.5, "EXPOSURES — 7 beverages + 3 plasma metabolites", size=7.8, weight="bold", color=BLUE)'),
    ('txt(50, 126.1, "(UK Biobank GWAS, N = 64,949–447,485)", size=7.0, color=BLUE)',
     'txt(50, 128.5, "(UK Biobank GWAS, N = 64,949–447,485)", size=7.0, color=BLUE)'),
    ('txt(50, 120.4, "Sugar added to tea', 'txt(50, 121.5, "Sugar added to tea'),
    ('box(4, 116, 92, 15, LBLUE, BLUE)',
     'box(4, 112, 92, 22, LBLUE, BLUE)\ntxt(50, 114.5, "Plasma caffeine · paraxanthine · theobromine (Chen 2023 atlas; N ≈ 8,000)", size=7.2, color=BLUE, style="italic")'),
    ('arrow(50, 116, 50, 110.5)', 'arrow(50, 112, 50, 110.5)'),
    ('txt(50, 18.5, "Direct measurement of milk-tea consumption in prospective East Asian cohorts remains needed.",',
     'txt(50, 19.5, "Genetic nulls converge with randomized trial evidence (CRAVE, DECAF).",\n    size=7.0, color=MUT, style="italic")\ntxt(50, 15.8, "Direct measurement of milk-tea consumption in prospective East Asian cohorts remains needed.",'),
    ("Graphical_Abstract_v50_300dpi.png", "Graphical_Abstract_v52_300dpi.png"),
]
ok = True
for old, new in E:
    n = t.count(old)
    if n == 1:
        t = t.replace(old, new); print("PASS", old[:45])
    else:
        print("FAIL", n, old[:45]); ok = False
if not ok:
    sys.exit(1)
(S / "graphical_abstract_v52.py").write_text(t, encoding="utf-8", newline="\n")
r = subprocess.run([r"C:\Users\64915\.workbuddy\binaries\python\envs\default\Scripts\python.exe",
                    str(S / "graphical_abstract_v52.py")], capture_output=True, text=True)
print("exit", r.returncode)
if r.returncode == 0:
    shutil.copy2(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\06_升级分析_v4\figures\Graphical_Abstract_v52_300dpi.png",
                 r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\figures\Graphical_Abstract_v52_300dpi.png")
    print("GA v52 重建完成")
else:
    print(r.stderr[-300:])
