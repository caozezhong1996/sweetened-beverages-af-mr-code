suppressMessages(library(data.table))
caf <- c("rs117968677", "rs2472297", "rs4410790")
N <- 428860
z <- qnorm(0.975) + qnorm(0.8)
for (oc in c("ebi_a_GCST006414", "finngen_R13")) {
  d <- fread(paste0("C:/a3work/dat_Coffee_intake_", oc, ".csv"))
  d <- d[mr_keep == TRUE & SNP %in% caf]
  stopifnot(nrow(d) == 3)
  w <- 1 / d$se.outcome^2
  b <- sum(w * d$beta.exposure * d$beta.outcome) / sum(w * d$beta.exposure^2)
  se0 <- sqrt(1 / sum(w * d$beta.exposure^2))
  Q <- sum(w * (d$beta.outcome - d$beta.exposure * b)^2)
  se <- se0 * sqrt(max(1, Q / (nrow(d) - 1)))
  r2 <- sum(d$beta.exposure^2 / (d$beta.exposure^2 + N * d$se.exposure^2))
  Fv <- (d$beta.exposure / d$se.exposure)^2
  original <- fread("C:/a3work/upgrade_v43_caffeine_subgroup_mr.csv")
  original <- original[outcome_source == oc & subgroup == "Caffeine-metabolism loci (AHR + CYP1A1-CYP1A2 windows)" & method == "Inverse variance weighted"]
  stopifnot(abs(b - original$b) < 1e-10, abs(se - original$se) < 1e-10)
  cat(oc, "R2%=", sprintf("%.4f", 100*r2),
      " Fmin/median/mean=", sprintf("%.1f/%.1f/%.1f", min(Fv), median(Fv), mean(Fv)),
      " OR=", sprintf("%.2f", exp(b)),
      " P=", sprintf("%.3g", 2*pnorm(-abs(b/se))),
      " MDE=", sprintf("%.2f", exp(z*se)),
      " matches original b/se\n")
}
cat("INDEPENDENT R VERIFICATION PASS\n")
