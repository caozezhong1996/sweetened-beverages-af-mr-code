# -*- coding: utf-8 -*-
"""Graphical abstract v56 — 与新叙事一致（体脂位点承载咖啡信号）。
12.5 x 18 cm @300 dpi，沿用 v53 的坐标系统与配色。"""
import pathlib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

W_CM, H_CM, DPI = 12.5, 18.0, 300
fig = plt.figure(figsize=(W_CM / 2.54, H_CM / 2.54), dpi=DPI)
ax = fig.add_axes([0, 0, 1, 1])
ax.set_xlim(0, 100)
ax.set_ylim(0, 144)
ax.axis("off")

INK = "#1f313a"
MUT = "#5b6f79"
BLUE = "#2f6f8f"
LBLUE = "#e3eef4"
GREEN = "#2e7d5b"
LGREEN = "#e5f2ec"
AMBER = "#b3641c"
LAMBER = "#f9eee0"
GREY = "#eef3f6"


def box(x, y, w, h, fc, ec, lw=1.2, r=1.6):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle=f"round,pad=0,rounding_size={r}",
                                facecolor=fc, edgecolor=ec, linewidth=lw))


def txt(x, y, s, size=8.2, color=INK, weight="normal", ha="center", va="center", style="normal"):
    ax.text(x, y, s, fontsize=size, color=color, fontweight=weight, ha=ha, va=va,
            style=style, linespacing=1.35)


def arrow(x1, y1, x2, y2, color=MUT):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=14,
                                 linewidth=1.6, color=color))


# ---------------- title ----------------
txt(50, 140.0, "Adiposity Loci Account for the\nCoffee–Atrial Fibrillation Signal",
    size=8.8, weight="bold")
txt(50, 134.7, "Two-sample MR  ·  locus-level colocalization  ·  UK Biobank-free replication",
    size=6.2, color=MUT, style="italic")

# ---------------- exposures ----------------
box(4, 112, 92, 22, LBLUE, BLUE)
txt(50, 114.5, "Plasma caffeine · paraxanthine · theobromine (Chen 2023 atlas; N ≈ 8,000)",
    size=7.2, color=BLUE, style="italic")
txt(50, 131.5, "EXPOSURES — 7 beverages + 3 plasma metabolites", size=7.8, weight="bold", color=BLUE)
txt(50, 128.5, "(UK Biobank GWAS, N = 64,949–447,485)", size=7.0, color=BLUE)
txt(50, 121.5, "Sugar added to tea  ·  Sugar added to coffee  ·  Fizzy drinks (SSB)\n"
               "Low-calorie drinks (ASB)  ·  Artificial sweetener in tea\n"
               "Coffee intake  ·  Tea intake", size=8.0)

# ---------------- framework ----------------
arrow(50, 112, 50, 110.5)
box(4, 97.5, 92, 13, GREY, MUT)
txt(50, 108.2, "CAUSAL-INFERENCE FRAMEWORK", size=8.0, weight="bold", color=MUT)
txt(50, 103.1, "Two-sample MR (IVW, MR-Egger, weighted median, MR-PRESSO)\n"
               "Multivariable MR with BMI  ·  Locus-level colocalization  ·  Cross-trait LDSC\n"
               "Reverse MR  ·  Alcohol positive and sugar-in-tea negative controls",
    size=7.0)

arrow(50, 97.5, 50, 92)

# ---------------- outcome ----------------
box(4, 79, 92, 13, LBLUE, BLUE)
txt(50, 88.9, "OUTCOME — atrial fibrillation, five GWAS sources", size=8.0, weight="bold", color=BLUE)
txt(50, 83.45, "Nielsen 2018 (60,620; primary)  ·  FinnGen R13 (67,783; replication)\n"
               "Yuan 2025, UKB-free (192,851; replication)  ·  AFGen 2018 (55,114)\n"
               "BioBank Japan (8,180; East Asian contextual)",
    size=7.2)

# ---------------- findings ----------------
txt(50, 74.5, "KEY FINDINGS", size=8.6, weight="bold")

box(4, 55.5, 44, 16, LGREEN, GREEN)
txt(26, 68.9, "Sweetened beverages", size=7.9, weight="bold", color=GREEN)
txt(26, 65.7, "→ No causal association with AF", size=7.1, weight="bold", color=GREEN)
txt(26, 61.0, "Meta-analytic OR 0.82–0.97;\nUKB-free 0.76–1.04;\nnull across nine estimators",
    size=6.9)

box(52, 55.5, 44, 16, LAMBER, AMBER)
txt(74, 69.2, "Coffee signal is adiposity-linked", size=6.9, weight="bold", color=AMBER)
txt(74, 66.5, "→ not a caffeine effect", size=6.9, weight="bold", color=AMBER)
txt(74, 60.6, "Colocalizes with AF at FTO (0.894)\nreplication 0.906; no AF signal\nat CYP1A1–CYP1A2 or AHR (PP.H4 ≤ 0.008)",
    size=6.2)

box(4, 40.5, 92, 12, LGREEN, GREEN)
txt(50, 50.2, "Genetic correlation ≠ causation", size=7.9, weight="bold", color=GREEN)
txt(50, 45.0, "SSB and ASB share genetic architecture with AF (rg 0.24–0.31, FDR q < 0.05)\n"
              "despite null MR estimates; ASB has no published MR estimate; intercepts ≈ 0",
    size=7.0)

# ---------------- conclusion ----------------
arrow(50, 40.5, 50, 35.5)
box(4, 21.0, 92, 14.5, INK, INK)
txt(50, 33.4, "CONCLUSION", size=8.0, weight="bold", color="#bcd3de")
txt(50, 26.8, "The recurring coffee–AF genetic signal is attributable to adiposity-linked variation,\n"
              "not to coffee or caffeine. No sweetened beverage showed a causal association with AF;\n"
              "component-level nulls do not certify composite milk-tea safety.",
    size=7.0, color="white")

txt(50, 19.3, "After adiposity-locus exclusion the coffee estimates were 1.26–1.39, mutually indistinguishable.",
    size=6.6, color=MUT, style="italic")
txt(50, 15.6, "Power to detect OR 1.10 was 13–47%; observational-magnitude effects are not excluded.\n"
              "Direct measurement of milk-tea consumption in prospective East Asian cohorts remains needed.",
    size=6.6, color=MUT, style="italic")

out = pathlib.Path(r"C:\Users\64915\WorkBuddy\2026-10-30-20-42-58\Graphical_Abstract_v56.png")
fig.savefig(out, dpi=DPI)
print("written:", out)

from PIL import Image
im = Image.open(out)
print("pixel size:", im.size, "expected:", (round(W_CM / 2.54 * DPI), round(H_CM / 2.54 * DPI)))
