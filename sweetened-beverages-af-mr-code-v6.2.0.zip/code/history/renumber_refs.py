# -*- coding: utf-8 -*-
"""Renumber references to order of appearance (AHA style), with verification."""
import io
import pathlib
import re
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
BASE = pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
                    r"\04_docx构建脚本")
MAN = BASE / "build_manuscript_v51_JAHA.js"
SUP = BASE / "build_supplement_v51_JAHA.js"
CL = BASE / "build_cover_letter_v51_JAHA.js"

src = MAN.read_text(encoding="utf-8")
marker = "  ...[\n"
i = src.find(marker)
assert i > 0, "reference array not found"
prefix, refblock = src[:i], src[i:]

# ---- extract the reference texts ----
refs = {}
for m in re.finditer(r"T`(\d+)\.\s([^`]+)`", refblock):
    refs[int(m.group(1))] = m.group(2).strip()
assert len(refs) == 46, len(refs)
print("references found:", len(refs))

CIT = re.compile(r"\[([0-9,\s–-]+)\]")


def expand(group):
    out = []
    for part in group.split(","):
        part = part.strip()
        if re.fullmatch(r"\d+", part):
            out.append(int(part))
        elif re.fullmatch(r"\d+\s*[–-]\s*\d+", part):
            a, b = re.split(r"\s*[–-]\s*", part)
            out.extend(range(int(a), int(b) + 1))
    # JS arrays such as column widths are not citations
    if any(n < 1 or n > 99 for n in out):
        return []
    return out


# ---- first-appearance order ----
order = []
for m in CIT.finditer(prefix):
    for n in expand(m.group(1)):
        if n not in order:
            order.append(n)
print("first-appearance order:", order)
missing = [n for n in range(1, 47) if n not in order]
print("never cited:", missing)

# keep only cited references; uncited ones are appended in original order
newnums = {old: k + 1 for k, old in enumerate(order)}
for old in missing:
    newnums[old] = len(newnums) + 1
assert len(newnums) == 46


def remap_group(group):
    ns = sorted({newnums[n] for n in expand(group)})
    return "[" + ",".join(str(n) for n in ns) + "]"


new_prefix = CIT.sub(lambda m: remap_group(m.group(1)), prefix)

# ---- rebuild the reference array ----
lines = []
for old, new in sorted(newnums.items(), key=lambda kv: kv[1]):
    lines.append(f"    T`{new}. {refs[old]}`,")
new_refblock = marker + "\n".join(lines) + refblock[refblock.find("\n].map"):]
MAN.write_text(new_prefix + new_refblock, encoding="utf-8", newline="\n")
print("manuscript renumbered")

# ---- apply the same mapping to supplement and cover letter ----
for path in (SUP, CL):
    t = path.read_text(encoding="utf-8")
    t2 = CIT.sub(lambda m: remap_group(m.group(1)), t)
    # also "manuscript ref 42" style mentions
    t2 = re.sub(r"manuscript ref (\d+)", lambda m: f"manuscript ref {newnums[int(m.group(1))]}", t2)
    path.write_text(t2, encoding="utf-8", newline="\n")
    print(path.name, "updated")

# ---- verify on the rewritten source ----
src2 = MAN.read_text(encoding="utf-8")
j = src2.find(marker)
p2, r2 = src2[:j], src2[j:]
order2 = []
for m in CIT.finditer(p2):
    for n in expand(m.group(1)):
        if n not in order2:
            order2.append(n)
print("\nnew first-appearance order:", order2)
print("sequential:", order2 == sorted(order2))
refs2 = [int(m.group(1)) for m in re.finditer(r"T`(\d+)\.\s", r2)]
print("new ref numbers:", refs2[:5], "...", refs2[-3:], "count", len(refs2))
print("ref list sequential:", refs2 == list(range(1, 47)))
# spot-check three mappings
for old in (2, 8, 29, 40, 46):
    new = newnums[old]
    print(f"  old {old} -> new {new}: {refs[old][:70]}")
