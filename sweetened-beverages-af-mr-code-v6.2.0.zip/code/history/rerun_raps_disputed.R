# -*- coding: utf-8 -*-
# Re-run the disputed MR-RAPS cells: which FinnGen input reproduces Table S23?
suppressMessages({library(data.table); library(mr.raps)})

M <- "C:/Users/64915/Documents/kimi/workspace/奶茶房颤MR_迁移包_20260822"
F1 <- file.path(M, "03_结果数据_mr_results")     # dat_*_finn_b_I9_AF.csv
F2 <- file.path(M, "06_升级分析_v4/results")      # dat_*_finngen_R13.csv  + Nielsen GCST006414

run <- function(path) {
  if (!file.exists(path)) return(c(n = NA, b = NA, se = NA, p = NA, raw = NA))
  d <- fread(path)
  if ("mr_keep" %in% names(d)) d <- d[mr_keep %in% c(TRUE, "TRUE")]
  ok <- complete.cases(d$beta.exposure, d$se.exposure, d$beta.outcome, d$se.outcome)
  d <- d[ok, ]
  fit <- tryCatch(mr.raps.mle(b_exp = d$beta.exposure, se_exp = d$se.exposure,
                              b_out = d$beta.outcome, se_out = d$se.outcome,
                              over.dispersion = TRUE, loss.function = "tukey"),
                  error = function(e) NULL)
  if (is.null(fit)) return(c(n = nrow(d), b = NA, se = NA, p = NA, raw = NA))
  c(n = nrow(d), b = fit$beta.hat, se = fit$beta.se, p = fit$beta.p.value, raw = NA)
}

pairs <- list(
  c("Coffee_intake", "Coffee intake"),
  c("Sugar_added_to_tea", "Sugar added to tea"),
  c("Tea_intake", "Tea intake"),
  c("Fizzy_drink_intake_SSB", "Fizzy (SSB)")
)

cat(sprintf("%-22s %-24s %4s %9s %9s %9s\n", "exposure", "outcome file", "n", "logOR", "SE", "P"))
for (pr in pairs) {
  e <- pr[1]
  tag <- pr[2]
  cases <- list(
    c("Nielsen GCST006414", file.path(F2, sprintf("dat_%s_ebi_a_GCST006414.csv", e))),
    c("FinnGen finn_b_I9_AF", file.path(F1, sprintf("dat_%s_finn_b_I9_AF.csv", e))),
    c("FinnGen finngen_R13", file.path(F2, sprintf("dat_%s_finngen_R13.csv", e)))
  )
  for (cs in cases) {
    r <- run(cs[2])
    cat(sprintf("%-22s %-24s %4s %9.4f %9.4f %9.4g\n", tag, cs[1],
                ifelse(is.na(r["n"]), "-", sprintf("%d", as.integer(r["n"]))),
                r["b"], r["se"], r["p"]))
  }
  cat("\n")
}

# determinism: run the same file twice
cat("--- determinism check (coffee x finngen_R13, two calls) ---\n")
p <- file.path(F2, "dat_Coffee_intake_finngen_R13.csv")
for (i in 1:2) {
  r <- run(p)
  cat(sprintf("  call %d: b=%.10f se=%.10f p=%.10f\n", i, r["b"], r["se"], r["p"]))
}
