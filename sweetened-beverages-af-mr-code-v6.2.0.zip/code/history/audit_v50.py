# -*- coding: utf-8 -*-
"""v5.0 修订稿审计：摘要词数、修改落盘抽查、关键数字完整性。"""
import io, sys, re
from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
P = r"C:\Users\64915\Desktop\EHJOpen投稿包_奶茶房颤MR_v5.0_20261006\01_手稿_Manuscript\Manuscript_v50_Sweetened_Beverages_AF_MR_revised.docx"
doc = Document(P)
paras = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
full = "\n".join(paras)

print("=== 1. 标题与新措辞落盘抽查 ===")
checks = [
    ("新标题 East Asian Contextual Analysis", "Study With East Asian Contextual Analysis" in full),
    ("标题旧词已消失 Cross-Ancestry Replication", "Cross-Ancestry Replication" not in full),
    ("no evidence of a causal association（≥3处）", full.count("no evidence of a causal association") >= 3),
    ("残留 'not causally associated' 应为0", full.count("not causally associated") == 0),
    ("East Asian contextual analysis 已落盘", "East Asian contextual analysis" in full),
    ("co-primary, overlap-free 已落盘", "co-primary, overlap-free" in full),
    ("To our knowledge 落盘", "To our knowledge, no prospective cohort" in full),
    ("中介 >100% 解释落盘", "proportions exceeding 100%" in full),
    ("引用[38]正文", "artificial sweeteners to cardiometabolic disease [38]" in full),
    ("引文38条目", "38. Fan J, Hu Y, Zhang J" in full),
    ("most defensible 已改", "most defensible" not in full.lower()),
    ("On balance 新句", "On balance, the genetic evidence does not establish" in full),
    ("prespecified 已统一", "prespecified" not in full),
    ("单类别单位说明", "per one-category increment" in full),
    ("阴性对照解释扩展", "shared adiposity pleiotropy rather than a beverage-specific effect" in full),
    ("source-dependent 讨论强化", "null after outlier correction in Nielsen 2018 but retained in FinnGen R13" in full),
    ("新颖性统领句", "unified multi-exposure framework" in full),
    ("Beyond previous single-beverage MR", "Beyond previous single-beverage MR analyses [8,29]" in full),
]
ok = True
for name, passed in checks:
    print(("  PASS " if passed else "  FAIL ") + name)
    ok = ok and passed

print("\n=== 2. 摘要词数（≤250）===")
ai = paras.index("Abstract")
labels = ["Aim", "Methods", "Results", "Conclusions", "Keywords"]
absp = {}
for j in range(ai + 1, ai + 6):
    t = paras[j]
    for lab in labels:
        if t.startswith(lab + ":") and lab not in absp:
            absp[lab] = re.sub(r"^[A-Za-z]+:\s*", "", t)
total = sum(len(v.split()) for k, v in absp.items() if k != "Keywords")
for k in ["Aim", "Methods", "Results", "Conclusions"]:
    print(f"  {k}: {len(absp[k].split())} 词")
print(f"  合计（不含 Keywords）: {total} / 250 {'PASS' if total <= 250 else 'FAIL — 超标'}")

print("\n=== 3. 关键数字完整性抽查 ===")
nums = ["60,620", "970,216", "67,783", "241,269", "8,180", "28,612", "64,949", "447,485",
        "OR 1.34", "1.11–1.62", "0.82", "0.099", "120%", "−23% to 263%", "0.281",
        "rg = 0.239", "0.313", "1.47", "2.34", "1.19, 1.01–1.40", "P = 0.035",
        "PP.H4 = 0.894", "0.923", "1,081,418", "111 independent", "1.15", "1.53"]
miss = [n for n in nums if n not in full]
print(f"  28 个关键数字，缺失 {len(miss)}: {miss if miss else '无 — 全部在位'}")

print("\n=== 4. 正文词数（不含摘要/参考文献/表格）===")
try:
    intro_i = next(i for i, p in enumerate(paras) if p == "Introduction")
    decl_i = next(i for i, p in enumerate(paras) if p == "Declarations")
    body = " ".join(paras[intro_i:decl_i])
    body = re.sub(r"^\d+\.\s.*$", "", body)  # 粗略
    print(f"  Introduction→Declarations 之间: {len(body.split())} 词（含图表注，v457 基线约 5087）")
except Exception as e:
    print("  词数统计异常:", e)

print("\n总判定:", "ALL PASS" if ok and total <= 250 and not miss else "存在 FAIL 项，见上")
