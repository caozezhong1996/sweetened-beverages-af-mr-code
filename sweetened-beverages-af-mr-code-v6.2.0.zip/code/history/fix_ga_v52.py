# -*- coding: utf-8 -*-
"""GA v52 视觉修正第三轮：
A EXP 框 y114/h20，标题131.5/副标128.5/body 中心121.5/代谢物行115.4（消重叠）
B 独立代谢物结果行移至 CONCLUSION 下方 y22.8（避箭头路径与框内挤压），改 MUT italic
C 底部收敛行缩短为 "(CRAVE, DECAF)" 防超宽
"""
import io, sys, pathlib, subprocess, shutil

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
p = pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\06_升级分析_v4\scripts\graphical_abstract_v52.py")
t = p.read_text(encoding="utf-8")
E = [
    ("EXP 框加高至20",
     'box(4, 113.5, 92, 17.5, LBLUE, BLUE)\ntxt(50, 116.4, "Plasma caffeine · paraxanthine · theobromine (Chen 2023 atlas; N ≈ 8,000)", size=7.2, color=BLUE, style="italic")',
     'box(4, 114, 92, 20, LBLUE, BLUE)\ntxt(50, 115.4, "Plasma caffeine · paraxanthine · theobromine (Chen 2023 atlas; N ≈ 8,000)", size=7.2, color=BLUE, style="italic")'),
    ("EXP 标题上移",
     'txt(50, 128.8, "EXPOSURES — 7 beverages + 3 plasma metabolites", size=7.8, weight="bold", color=BLUE)',
     'txt(50, 131.5, "EXPOSURES — 7 beverages + 3 plasma metabolites", size=7.8, weight="bold", color=BLUE)'),
    ("EXP 副标上移",
     'txt(50, 126.1, "(UK Biobank GWAS, N = 64,949–447,485)", size=7.0, color=BLUE)',
     'txt(50, 128.5, "(UK Biobank GWAS, N = 64,949–447,485)", size=7.0, color=BLUE)'),
    ("EXP body 中心上移",
     'txt(50, 120.4, "Sugar added to tea  ·  Sugar added to coffee  ·  Fizzy drinks (SSB)\\n"',
     'txt(50, 121.5, "Sugar added to tea  ·  Sugar added to coffee  ·  Fizzy drinks (SSB)\\n"'),
    ("EXP 箭头起点随框底",
     'arrow(50, 113.5, 50, 110.5)',
     'arrow(50, 114, 50, 110.5)'),
    ("独立代谢物行移至结论框下+改样式",
     'txt(50, 38.2, "Plasma caffeine & paraxanthine: no genetic evidence of an association with AF (P ≥ 0.31)",\\n    size=7.4, color=GREEN, weight="bold")',
     'txt(50, 22.8, "Plasma caffeine & paraxanthine: no genetic evidence of an association with AF (P ≥ 0.31)",\\n    size=7.0, color=MUT, style="italic")'),
    ("底部收敛行缩短",
     'txt(50, 19.5, "Genetic nulls converge with randomized trial evidence on susceptibility, acute exposure and recurrence.",\\n    size=7.0, color=MUT, style="italic")',
     'txt(50, 19.5, "Genetic nulls converge with randomized trial evidence (CRAVE, DECAF).",\\n    size=7.0, color=MUT, style="italic")'),
]
ok = True
for name, old, new in E:
    n = t.count(old)
    if n == 1:
        t = t.replace(old, new); print(f"PASS {name}")
    else:
        print(f"FAIL {name}: 命中 {n}"); ok = False
if not ok:
    sys.exit(1)
p.write_text(t, encoding="utf-8", newline="\n")
r = subprocess.run([r"C:\Users\64915\.workbuddy\binaries\python\envs\default\Scripts\python.exe", str(p)],
                   capture_output=True, text=True)
print("exit", r.returncode, r.stdout.strip()[-80:])
if r.returncode == 0:
    shutil.copy2(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\06_升级分析_v4\figures\Graphical_Abstract_v52_300dpi.png",
                 r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\figures\Graphical_Abstract_v52_300dpi.png")
    print("GA 已更新")
