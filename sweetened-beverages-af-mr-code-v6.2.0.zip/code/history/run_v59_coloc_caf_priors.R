#!/usr/bin/env Rscript
suppressMessages({library(data.table); library(ieugwasr); library(coloc)})
if (Sys.getenv("OPENGWAS_JWT") == "") stop("OPENGWAS_JWT not set")
outdir <- "C:/a3work/coloc_caf_v59"
dir.create(outdir, recursive = TRUE, showWarnings = FALSE)
regions <- list(
  list(name = "CYP1A1-CYP1A2", query = "15:74777880-75277880"),
  list(name = "AHR", query = "7:17034577-17534577")
)
get_region <- function(id, q) {
  d <- associations(variants = q, id = id)
  if (is.null(d) || nrow(d) == 0) stop("empty region: ", id, " ", q)
  as.data.frame(d)
}
rows <- list()
for (rg in regions) {
  cat("===", rg$name, "===\n")
  d1 <- get_region("ukb-b-5237", rg$query)
  Sys.sleep(1)
  d2 <- get_region("ebi-a-GCST006414", rg$query)
  fwrite(d1, file.path(outdir, paste0(rg$name, "_coffee.tsv")), sep = "\t")
  fwrite(d2, file.path(outdir, paste0(rg$name, "_Nielsen.tsv")), sep = "\t")
  m <- merge(d1, d2, by = "rsid", suffixes = c(".coffee", ".af"))
  ok <- (m$ea.coffee == m$ea.af & m$nea.coffee == m$nea.af) |
        (m$ea.coffee == m$nea.af & m$nea.coffee == m$ea.af)
  m <- m[ok, ]
  flip <- m$ea.coffee == m$nea.af & m$nea.coffee == m$ea.af
  m$beta.af[flip] <- -m$beta.af[flip]
  m <- m[!is.na(m$beta.coffee) & !is.na(m$beta.af) & m$se.coffee > 0 & m$se.af > 0, ]
  m <- m[!duplicated(m$rsid), ]
  cat("harmonized SNPs:", nrow(m), "\n")
  stopifnot(nrow(m) >= 50)
  ds1 <- list(snp = m$rsid, beta = m$beta.coffee, varbeta = m$se.coffee^2,
              N = 428860, type = "quant", MAF = pmin(m$eaf.coffee, 1 - m$eaf.coffee))
  ds2 <- list(snp = m$rsid, beta = m$beta.af, varbeta = m$se.af^2,
              N = 1030836, type = "cc", s = 60620/1030836,
              MAF = pmin(m$eaf.af, 1 - m$eaf.af))
  for (p12 in c(1e-6, 5e-6, 1e-5, 2.5e-5, 5e-5)) {
    pp <- coloc.abf(dataset1 = ds1, dataset2 = ds2, p12 = p12)$summary
    rows[[length(rows) + 1]] <- data.frame(
      locus = rg$name, outcome = "Nielsen 2018", p12 = p12,
      nsnp = pp["nsnps"], PP.H0 = pp["PP.H0.abf"], PP.H1 = pp["PP.H1.abf"],
      PP.H2 = pp["PP.H2.abf"], PP.H3 = pp["PP.H3.abf"], PP.H4 = pp["PP.H4.abf"])
  }
}
out <- rbindlist(rows)
fwrite(out, file.path(outdir, "coloc_caf_priorscan_v59.tsv"), sep = "\t")
print(out, digits = 4)
cat("CAF PRIOR SCAN DONE\n")
