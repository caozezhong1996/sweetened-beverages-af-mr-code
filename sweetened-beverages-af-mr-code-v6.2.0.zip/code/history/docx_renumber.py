# -*- coding: utf-8 -*-
"""Apply the last abstract trim and renumber references directly in the DOCX
(safer than editing the JS, where array indices look like citations)."""
import io
import re
import sys

from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
PATH = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\Manuscript.docx"
d = Document(PATH)

# ---------- 1. abstract trim ----------
old = ("Excluding instruments within 500 kb of body-mass-index loci collapsed the between-source spread "
       "from 1.26–1.79 to 1.39–1.48 but left a residual association (pooled OR 1.41, 1.16–1.72; P = 0.0007), "
       "so adiposity explains the heterogeneity rather than the whole signal.")
new = ("Excluding adiposity-locus instruments collapsed between-source spread from 1.26–1.79 to 1.39–1.48 "
       "but left a residual association (pooled OR 1.41; P = 0.0007), so adiposity explains the heterogeneity "
       "rather than the whole signal.")
hit = 0
for p in d.paragraphs:
    if old in p.text:
        txt = p.text.replace(old, new)
        for r in p.runs:
            r.text = ""
        p.runs[0].text = txt
        hit += 1
assert hit == 1, "abstract M&R sentence not found"
print("abstract trimmed")

# ---------- 2. renumber references ----------
paras = list(d.paragraphs)
ref_start = next(i for i, p in enumerate(paras) if p.text.strip() == "References")
body = paras[:ref_start]
refs = paras[ref_start:]

CIT = re.compile(r"\[([0-9,\s–-]+)\]")


def expand(g):
    out = []
    for part in g.split(","):
        part = part.strip()
        if re.fullmatch(r"\d+", part):
            out.append(int(part))
        elif re.fullmatch(r"\d+\s*[–-]\s*\d+", part):
            a, b = re.split(r"\s*[–-]\s*", part)
            out.extend(range(int(a), int(b) + 1))
    return out


order = []
for p in body:
    for m in CIT.finditer(p.text):
        for n in expand(m.group(1)):
            if n not in order:
                order.append(n)
print("citation order (first 12):", order[:12])
newnums = {old: i + 1 for i, old in enumerate(order)}
for old in range(1, 47):
    if old not in newnums:
        newnums[old] = len(newnums) + 1


def remap(text):
    def sub(m):
        ns = sorted({newnums[n] for n in expand(m.group(1))})
        return "[" + ",".join(str(n) for n in ns) + "]"
    return CIT.sub(sub, text)


for p in body:
    txt = p.text
    new_txt = remap(txt)
    if new_txt != txt:
        for r in p.runs:
            r.text = ""
        p.runs[0].text = new_txt

# reference list
ref_entries = [p for p in refs if re.match(r"^\d+\.\s", p.text.strip())]
print("reference entries:", len(ref_entries))
by_old = {}
for p in ref_entries:
    m = re.match(r"^(\d+)\.\s(.*)$", p.text.strip(), re.S)
    by_old[int(m.group(1))] = (p, m.group(2))

for old, (p, text) in by_old.items():
    new = newnums[old]
    for r in p.runs:
        r.text = ""
    p.runs[0].text = f"{new}. {text}"

d.save(PATH)
print("renumbered and saved")

# ---------- verify ----------
d2 = Document(PATH)
mp = [p.text.strip() for p in d2.paragraphs if p.text.strip()]
full = "\n".join(mp)
ai = mp.index("Abstract")
tot = 0
for j in range(ai + 1, ai + 8):
    lab = mp[j].split(":")[0]
    if lab in ("Background", "Methods and Results", "Conclusions"):
        tot += len([w for w in mp[j].split() if re.search(r"[A-Za-z0-9]", w)]) - 1
print("abstract words:", tot)
body2 = full.split("References")[0]
order2 = []
for m in CIT.finditer(body2):
    for n in expand(m.group(1)):
        if n not in order2:
            order2.append(n)
print("sequential:", order2 == sorted(order2), "first 12:", order2[:12])
refs2 = [int(m.group(1)) for m in re.finditer(r"(?m)^(\d+)\.\s", full)]
print("ref list count:", len(refs2), "sequential:", refs2 == list(range(1, 47)))
