# -*- coding: utf-8 -*-
"""Sync the cover letter with the A3 co-primary outcome (cumulative per paragraph)."""
import io
import sys
from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
CL = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\Cover_Letter.docx"

REPL = [
    ("and estimated their effects on AF in the largest available European-ancestry GWAS (Nielsen 2018; 60,620 cases; primary), "
     "in FinnGen release R13 (67,783 cases), which shares no participants with UK Biobank and served as a co-primary, "
     "overlap-free outcome, in AFGen 2018 (sensitivity), and in BioBank Japan (East Asian contextual arm).",
     "and estimated their effects on AF in four European-ancestry sources—Nielsen 2018 (60,620 cases; primary), FinnGen release R13 "
     "(67,783 cases) and the UK Biobank-free European arm of Yuan 2025 (192,851 cases), the last two serving as overlap-free "
     "co-primary outcomes—with AFGen 2018 as a sensitivity source and BioBank Japan as an East Asian contextual arm."),
    ("The single nominal signal—for coffee intake (European meta-analytic OR 1.34, 1.11–1.62; P = 0.002)—failed every "
     "pre-specified robustness criterion and was dissected mechanistically: it attenuated after multivariable adjustment for "
     "body mass index (OR 0.82; P = 0.099), colocalized with AF only at the adiposity locus FTO and not at caffeine-metabolism "
     "loci, and was compatible with correlated pleiotropy in genome-wide CAUSE analysis.",
     "The single recurring signal—for coffee intake (European meta-analytic OR 1.34, 1.11–1.62; P = 0.002; UK Biobank-free "
     "OR 1.79, 1.23–2.60)—failed every pre-specified robustness criterion and was dissected mechanistically: it attenuated "
     "after multivariable adjustment for body mass index (OR 0.82; P = 0.099), colocalized with AF only at the adiposity locus "
     "FTO and not at caffeine-metabolism loci, was compatible with correlated pleiotropy in genome-wide CAUSE analysis, and was "
     "carried by adiposity-locus instruments—removing variants within 500 kb of body-mass-index loci abolished it in both "
     "overlap-free sources and made the three source-specific estimates converge on 1.26–1.39."),
    ("at roughly sixteen times the outcome case count of prior beverage–AF MR work",
     "at up to fifty times the outcome case count of prior beverage–AF MR work"),
    ("plus cis estimation, four outcome sources including an overlap-free co-primary and an East Asian contextual arm, "
     "twenty-five supplementary tables",
     "plus cis estimation, five outcome sources including two overlap-free co-primary outcomes and an East Asian contextual arm, "
     "twenty-seven supplementary tables"),
]

d = Document(CL)
counts = [0] * len(REPL)
changed = 0
for p in d.paragraphs:
    txt = p.text
    new = txt
    for k, (old, rep) in enumerate(REPL):
        if old in new:
            counts[k] += 1
            new = new.replace(old, rep)
    if new != txt:
        for r in p.runs:
            r.text = ""
        p.runs[0].text = new
        changed += 1

ok = all(c >= 1 for c in counts)
for (old, _), c in zip(REPL, counts):
    print(("PASS" if c >= 1 else f"FAIL x{c}"), old[:66])
print("paragraphs changed:", changed)

if ok:
    d.save(CL)
    print("saved")
else:
    print("NOT saved")
