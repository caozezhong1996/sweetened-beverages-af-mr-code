import io
import shutil
import sys
from pathlib import Path
from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
PKG = Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")
ARC = Path(r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版\JAHA_v525_改稿留档\审读意见_20261028")
path = PKG / "Manuscript.docx"
shutil.copy2(path, ARC / "全文通读前备份_Manuscript.docx")
doc = Document(str(path))


def paragraphs():
    for p in doc.paragraphs:
        yield p
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    yield p


def rep(old, new, expected=1):
    hits = 0
    for p in paragraphs():
        if old in p.text:
            full = p.text.replace(old, new)
            for run in p.runs:
                run.text = ""
            p.runs[0].text = full
            hits += 1
    assert hits == expected, (old[:90], hits, expected)
    print("PASS", old[:78])


rep(
    "• The recurring coffee signal was not attributable to caffeine-handling pathways: adiposity-locus exclusion collapsed between-source spread to 1.39–1.48 but left a residual association (pooled OR 1.41; P = 0.0007); colocalization occurred at FTO, not at caffeine-metabolism loci.",
    "• No caffeine-handling effect was detected, although subgroup precision was limited and all three caffeine-window instruments lay near BMI loci; adiposity-locus exclusion collapsed between-source spread to 1.39–1.48 but left a residual association (pooled OR 1.41; P = 0.0007); colocalization occurred at FTO, not at caffeine-metabolism loci.",
)
rep(
    "Meta-analytic upper confidence bounds (1.01–1.17) overlap the point estimates reported observationally (1.1–1.2) for fizzy (1.17) and low-calorie drinks (1.11); effects of that magnitude cannot be excluded. The two estimands are not directly convertible (a per-category increment versus high-versus-low consumption).",
    "Meta-analytic upper confidence bounds were 1.01–1.17 on the per-category scale, so larger per-category effects can be bounded but not directly compared with cohort hazard ratios. Observational-magnitude effects cannot be excluded; the two estimands are not directly convertible (a per-category increment versus high-versus-low consumption).",
)
rep(
    "The point estimate therefore rose with outcome sample size (1.26 → 1.58 → 1.79) instead of shrinking toward the null, which is the behaviour expected of a bias that accumulates with power rather than of a causal effect. The association nevertheless failed every pre-specified consistency criterion:",
    "The point estimate rose with outcome sample size (1.26 → 1.58 → 1.79); this ordering is descriptive and does not distinguish bias from a true effect. The association nevertheless failed every pre-specified consistency criterion:",
)
rep(
    "Genome-wide CAUSE analysis (1,081,418 shared variants) corroborated the null interpretation: a correlated-pleiotropy model explained the coffee–AF genetic overlap as well as a causal model (P = 0.53),",
    "Genome-wide CAUSE analysis (1,081,418 shared variants) did not distinguish correlated pleiotropy from causation: a correlated-pleiotropy model explained the coffee–AF genetic overlap as well as a causal model (P = 0.53),",
)
rep(
    "Two-step mediation MR was consistent with an adiposity pathway, although its direction is not identifiable at these loci: coffee intake increased BMI (β = 0.82 SD; P = 0.007), BMI increased AF (β = 0.343 per SD; P = 2 × 10⁻³⁸),",
    "Two-step mediation MR was consistent with an adiposity pathway, although its direction is not identifiable at these loci: coffee instruments were positively associated with BMI (β = 0.82 SD; P = 0.007), and BMI instruments were positively associated with AF (β = 0.343 per SD; P = 2 × 10⁻³⁸),",
)
rep("Adiposity-locus instruments carry the coffee signal", "Adiposity-locus instruments explain coffee-signal heterogeneity")
rep("Multivariable MR: attenuation of the coffee signal by adiposity", "Multivariable MR: exploratory attenuation of the coffee signal")
rep(
    "consistent with confounding through adiposity-related pathways, though the interval does not exclude a small direct effect.",
    "compatible with adiposity-related pathways but not diagnostic of mediation; the interval does not exclude a small direct effect.",
)
rep("Positive control; robust direct effect", "Positive control; expected direction")
rep("Univariable nominal signal attenuated to null", "Attenuated; exploratory because conditional F < 10")
rep("except sugar added to tea (I² = 67%);", "except sugar added to tea (I² = 67%).")
rep("vanished after BMI adjustment", "attenuated after BMI adjustment")
rep("PP.H4 = 0.894; replicated at 0.906", "PP.H4 = 0.894; FinnGen R13 0.906")
rep(
    "the nominal coffee signal colocalized with AF only through the adiposity locus FTO.",
    "the nominal coffee signal colocalized with AF at the adiposity locus FTO, not at the caffeine-metabolism loci.",
)
rep(
    "with F > 20 overlap bias should be minimal, and the LDSC intercept for coffee × Nielsen 2018 (−0.011) was null whereas it detected known coffee–tea overlap (−0.318).",
    "overlap bias remains possible and F > 20 does not eliminate it; the LDSC intercept for coffee × Nielsen 2018 (−0.011) was null, but this does not exclude residual overlap, whereas the diagnostic detected known coffee–tea overlap (−0.318).",
)

doc.save(str(path))
print("saved", path)
