# -*- coding: utf-8 -*-
"""Trim the abstract to <=250 words after the A3 integration."""
import io
import pathlib
import re
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
P = pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
                 r"\04_docx构建脚本\build_manuscript_v51_JAHA.js")
src = P.read_text(encoding="utf-8")

OLD = ("T`Methods and Results: Seven beverage phenotypes were instrumented in UK Biobank (N = 64,949–447,485). "
       "AF statistics came from Nielsen 2018 (60,620; primary) and two overlap-free co-primary sources, FinnGen R13 (67,783) "
       "and the UK Biobank-free European arm of Yuan 2025 (192,851), plus BioBank Japan (8,180; East Asian context). "
       "Estimates were complemented by robust estimators, multivariable MR, colocalization and LD-score regression. "
       "No sweetened-beverage exposure showed evidence of a causal association with AF (European meta-analytic odds ratios "
       "0.82–0.97, all P ≥ 0.06; UK Biobank-free panel 0.76–1.04, all P ≥ 0.083). A coffee association recurred in every source "
       "(meta-analytic OR 1.34, 1.11–1.62; UK Biobank-free OR 1.79, 1.23–2.60) but was carried by adiposity-locus instruments: "
       "excluding variants within 500 kb of body-mass-index loci reduced it to 1.26 (0.90–1.75) in the UK Biobank-free panel and "
       "1.39 (0.94–2.04) in FinnGen R13, all three source-specific estimates converging on 1.26–1.39. Sweetened-beverage traits "
       "nonetheless showed positive genetic correlations with AF (rg = 0.24–0.31; FDR q < 0.05). Caffeine and paraxanthine "
       "instruments were null (P ≥ 0.31); theobromine showed a nominal inverse association (P = 0.029) that did not survive "
       "Bonferroni correction.`")

NEW = ("T`Methods and Results: Seven beverage phenotypes were instrumented in UK Biobank (N = 64,949–447,485). "
       "AF statistics came from Nielsen 2018 (60,620; primary), two overlap-free co-primary sources (FinnGen R13, 67,783; "
       "UK Biobank-free Yuan 2025, 192,851) and BioBank Japan (8,180; East Asian context). Robust estimators, multivariable MR, "
       "colocalization and LD-score regression were applied. No sweetened-beverage exposure showed evidence of a causal "
       "association with AF (European meta-analytic odds ratios 0.82–0.97, P ≥ 0.06; UK Biobank-free panel 0.76–1.04, P ≥ 0.083). "
       "A coffee association recurred in every source (meta-analytic OR 1.34, 1.11–1.62; UK Biobank-free 1.79, 1.23–2.60) but "
       "was carried by adiposity-locus instruments: excluding variants within 500 kb of body-mass-index loci reduced it to "
       "1.26 (0.90–1.75) in Yuan 2025 and 1.39 (0.94–2.04) in FinnGen R13, converging all three estimates on 1.26–1.39. "
       "Sweetened-beverage traits nonetheless showed positive genetic correlations with AF (rg = 0.24–0.31; FDR q < 0.05). "
       "Caffeine and paraxanthine instruments were null (P ≥ 0.31); theobromine's nominal inverse association (P = 0.029) "
       "did not survive Bonferroni correction.`")

c = src.count(OLD)
print("abstract block count:", c)
if c != 1:
    print("ABORT"); sys.exit(1)
src = src.replace(OLD, NEW)
P.write_text(src, encoding="utf-8", newline="\n")


def n(s):
    s = re.sub(r"^(Background|Methods and Results|Conclusions):", "", s)
    return len([w for w in s.split() if re.search(r"[A-Za-z0-9]", w)])


print("new M&R words:", n(NEW[2:-1]))
print("written")
