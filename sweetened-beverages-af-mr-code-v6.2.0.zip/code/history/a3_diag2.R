# Coffee-specific pleiotropy diagnostics on the Yuan 2025 outcome.
suppressMessages({library(data.table); library(TwoSampleMR); library(MRPRESSO)})
RES <- "C:/a3work"

expo <- fread(file.path(RES, "dat_Coffee_intake_ebi_a_GCST006414.csv"))
expo <- expo[mr_keep %in% c(TRUE, "TRUE")]
ex <- format_data(as.data.frame(expo), type = "exposure", snp_col = "SNP",
                  beta_col = "beta.exposure", se_col = "se.exposure",
                  effect_allele_col = "effect_allele.exposure",
                  other_allele_col = "other_allele.exposure",
                  eaf_col = "eaf.exposure", pval_col = "pval.exposure")
yo <- fread(file.path(RES, "yuan2025_instruments.tsv"))[exposure == "Coffee_intake"]
out <- format_data(as.data.frame(yo), type = "outcome", snp_col = "SNP",
                   beta_col = "beta.out", se_col = "se.out",
                   effect_allele_col = "ea.out", other_allele_col = "oa.out",
                   eaf_col = "eaf.out", pval_col = "pval.out")
d <- harmonise_data(ex, out, action = 2)
d <- d[d$mr_keep %in% c(TRUE, "TRUE"), ]
d$OR_wald <- exp(d$beta.outcome / d$beta.exposure)
d$F <- (d$beta.exposure / d$se.exposure)^2
d <- as.data.table(d)

cat("=== per-SNP Wald ratios (coffee -> AF, Yuan 2025) ===\n")
print(d[order(-OR_wald), .(SNP, ea = effect_allele.exposure, oa = other_allele.exposure,
                           bx = round(beta.exposure, 4), by = round(beta.outcome, 4),
                           OR_wald = round(OR_wald, 2), F = round(F, 1))], nrows = 30)

eg <- mr_egger_regression(d$beta.exposure, d$beta.outcome, d$se.exposure, d$se.outcome)
cat(sprintf("\nEgger slope b=%.3f se=%.3f P=%.3f | intercept=%.4f se=%.4f P=%.3f\n",
            eg$b[1], eg$se[1], eg$pval[1], eg$b[2], eg$se[2], eg$pval[2]))

set.seed(20261027)
pr <- mr_presso(BetaOutcome = "beta.outcome", BetaExposure = "beta.exposure",
                SdOutcome = "se.outcome", SdExposure = "se.exposure",
                OUTCOME = "outcome", EXPOSURE = "exposure", data = as.data.frame(d),
                NbDistribution = 5000, SignifThreshold = 0.05)
cat("\n=== MR-PRESSO ===\n")
print(pr$`Main MR results`)
cat("Global test P:", pr$`MR-PRESSO results`$`Global Test`$`P-value`, "\n")
cat("Outliers:", paste(pr$`MR-PRESSO results`$`Distortion Test`$`Outliers Indices`, collapse = ","), "\n")

# leave-one-out extremes
loo <- mr_leaveoneout(d)
cat("\n=== leave-one-out (most influential) ===\n")
loo$OR <- exp(loo$b); loo$lo <- exp(loo$b - 1.96 * loo$se); loo$hi <- exp(loo$b + 1.96 * loo$se)
print(as.data.table(loo)[order(p)][1:5, .(SNP, OR = round(OR, 2), lo = round(lo, 2),
                                          hi = round(hi, 2), p = signif(p, 3))])
cat("\nLOO range of IVW OR:", sprintf("%.2f - %.2f", min(loo$OR), max(loo$OR)), "\n")

fwrite(d[, .(SNP, ea = effect_allele.exposure, oa = other_allele.exposure,
             eaf_exp = eaf.exposure, bx = beta.exposure, sx = se.exposure,
             ea_out = effect_allele.outcome, oa_out = other_allele.outcome,
             by = beta.outcome, sy = se.outcome, OR_wald, F)],
       file.path(RES, "diag_coffee_yuan.csv"))
cat("\nwrote diag_coffee_yuan.csv\n")
