# -*- coding: utf-8 -*-
"""Repair section 5 of the checklist (backticks were eaten by shell substitution)."""
import io
import pathlib
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

P = pathlib.Path(r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版"
                 r"\JAHA_v525_改稿留档\审读意见_20261026\投稿前自检清单_20261027.md")

SECTION5 = """## 五、视觉复核（2026-10-27 晚：LibreOffice 渲染 + Chrome 截图）

前四节都是 XML / 文本层校验，看不到排版。这一轮补了真渲染：

**管线一（版式）**：`soffice --headless --convert-to pdf` → `pymupdf` 逐页栅格化 → 逐图目检。
**管线二（node 视觉）**：node 直接读投稿包内 5 张 PNG 的 IHDR / pHYs 头，算出物理尺寸并生成图表页 HTML，
再用 Chrome 无头截图核对 —— 尺寸来自文件头，不是人工填写。

### 目检抓到并修掉的 4 个问题

| # | 问题 | 修法 |
|---|---|---|
| 1 | **Table 2 八列挤在 15.88 cm 内不可读**：表头占 6 行，`0.72–` 与 `1.17` 被拆到两行 | 改为 **6 列**（primary + 两个 co-primary + meta + SNPs），AFGen / BioBank Japan 移入 Table S2；字号降至 9 pt；`P = x` 用不换行空格绑定，只在逗号处换行 |
| 2 | **Table 1 的 "OpenGWAS" 被折成 "OpenGWA/S"** | 单元格左右边距 90 → 70 twips；Access 列加宽到 1250 twips |
| 3 | **表格行跨页断开**（metabolites 行被切成两页） | 所有表行加 `cantSplit`，跨页时整行下移；表头自动重复 |
| 4 | **Table S26 脚注事实错误**：写"只有咖啡和茶异质"，实际糖加茶（Q P = 5.2×10⁻¹⁸）与甜味剂（3.8×10⁻⁶）也是 P < 0.001 | 改为四个暴露并列，并注明其余暴露 Q P ≥ 0.026 |

### 渲染后确认

- 手稿 **27 页**、补充材料 18 页、投稿信 3 页、Highlights 1 页
- 逐页检测：**除页码页脚外，无任何内容越出版心**（右界 523 pt / 下界 770 pt）
- Table 2 跨页时表头自动重复；行不再被切断
- 5 张图经 node 从投稿包实际文件读尺寸：17.40 / 17.40 / 17.40 / 17.40 / 12.50 cm，全部 ≤ 上限
- 图文摘要已换新版：5 个结局来源 + 体脂剔除结果

### 三套机器校验复跑（在上述排版修改之后）

- 结构 / 编号 / 文件：**49 项，48 PASS + 1 良性 WARN，0 FAIL**
- 数字一致性：**28 项全 PASS**（Table 2 改 6 列后探针已适配）
- 图表尺寸：**全 PASS**

> 提醒：**XML 层全绿不等于能印**。表 2 的不可读、OpenGWAS 折行、行跨页，这三样只有渲染出来才看得见。
> 以后改完表格或图，务必跑一次 `soffice → pdf → png` 目检。
"""

t = P.read_text(encoding="utf-8")
i = t.find("## 五、视觉复核")
assert i > 0, "section 5 not found"
P.write_text(t[:i] + SECTION5, encoding="utf-8")
print("section 5 replaced;", len(SECTION5.splitlines()), "lines")
