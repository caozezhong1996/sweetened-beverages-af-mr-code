import io
import shutil
import sys
from pathlib import Path
from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
path = Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\Supplement.docx")
backup = Path(r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版\JAHA_v525_改稿留档\审读意见_20261028\修改前备份_Supplement.docx")
shutil.copy2(path, backup)
doc = Document(str(path))
replacements = {
    "Table S19. Independent coffee-exposure GWAS replication (Neale lab UK Biobank field 1498) and cross-GWAS fixed-effect meta-analysis (Nielsen 2018 outcome)": "Table S19. Coffee-exposure phenotype-definition sensitivity analysis using a second UK Biobank GWAS (Neale lab field 1498), with an exploratory cross-GWAS fixed-effect estimate (Nielsen 2018 outcome)",
    "Neale 1498 replication": "Neale 1498 sensitivity",
    "The replication point estimate is directionally concordant but the smaller instrument set limits power; the fixed-effect cross-GWAS meta-analysis (OR 1.23, 1.04-1.44; P = 0.013) is more precise than either source alone.": "The point estimate is directionally concordant but the smaller instrument set limits power. Because 19 of 24 instruments overlap the primary loci and both exposure GWAS derive from UK Biobank, this is not independent replication; the fixed-effect estimate is shown for completeness only and is not interpreted as independent evidence or as a valid gain in precision.",
}
counts = {key: 0 for key in replacements}
for p in doc.paragraphs:
    for old, new in replacements.items():
        if old in p.text:
            full = p.text.replace(old, new)
            for run in p.runs:
                run.text = ""
            p.runs[0].text = full
            counts[old] += 1
for table in doc.tables:
    for row in table.rows:
        for cell in row.cells:
            for p in cell.paragraphs:
                for old, new in replacements.items():
                    if old in p.text:
                        full = p.text.replace(old, new)
                        for run in p.runs:
                            run.text = ""
                        p.runs[0].text = full
                        counts[old] += 1
assert counts["Table S19. Independent coffee-exposure GWAS replication (Neale lab UK Biobank field 1498) and cross-GWAS fixed-effect meta-analysis (Nielsen 2018 outcome)"] == 1
assert counts["Neale 1498 replication"] == 4, counts
assert counts["The replication point estimate is directionally concordant but the smaller instrument set limits power; the fixed-effect cross-GWAS meta-analysis (OR 1.23, 1.04-1.44; P = 0.013) is more precise than either source alone."] == 1
doc.save(str(path))
print("S19 updated", counts)
