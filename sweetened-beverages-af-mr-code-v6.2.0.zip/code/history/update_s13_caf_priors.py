import csv
import io
import shutil
import sys
from pathlib import Path
from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
SRC = Path(r"C:\a3work\coloc_caf_v59\coloc_caf_priorscan_v59.tsv")
ROOT = Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822")
RES = ROOT / "06_升级分析_v4" / "results"
PKG = Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")
ARC = Path(r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版\JAHA_v525_改稿留档\审读意见_20261028")

with SRC.open(encoding="utf-8") as f:
    rows = list(csv.DictReader(f, delimiter="\t"))
assert len(rows) == 10
shutil.copy2(SRC, RES / "coloc_caf_priorscan_v59.tsv")

# Independent acceptance check: default-prior posteriors reproduce the archived primary analysis.
with (RES / "upgrade_coloc_coffee_loci_Nielsen.csv").open(encoding="utf-8") as f:
    old = {r["region"]: r for r in csv.DictReader(f)}
for r in rows:
    if float(r["p12"]) != 1e-5:
        continue
    o = old[r["locus"]]
    assert int(r["nsnp"]) == int(o["nsnp"])
    for key in ("PP.H0", "PP.H1", "PP.H2", "PP.H3", "PP.H4"):
        assert abs(float(r[key]) - float(o[key])) < 1e-6, (r["locus"], key, r[key], o[key])
print("PASS default-prior replication for CYP1A1-CYP1A2 and AHR")

for name in ("Manuscript.docx", "Supplement.docx"):
    shutil.copy2(PKG / name, ARC / f"p12扫描前备份_{name}")


def replace(doc, old, new, expected=1):
    hits = 0
    for p in doc.paragraphs:
        if old in p.text:
            full = p.text.replace(old, new)
            for run in p.runs:
                run.text = ""
            p.runs[0].text = full
            hits += 1
    assert hits == expected, (old[:80], hits, expected)


def p12_text(x):
    return {1e-6: "10⁻⁶", 5e-6: "5 × 10⁻⁶", 1e-5: "10⁻⁵", 2.5e-5: "2.5 × 10⁻⁵", 5e-5: "5 × 10⁻⁵"}[float(x)]


def pp(x):
    x = float(x)
    return f"{x:.3f}" if x >= 0.001 else f"{x:.1e}"


sup = Document(str(PKG / "Supplement.docx"))
prior = next(t for t in sup.tables if t.rows[0].cells[0].text == "Locus" and len(t.rows[0].cells) > 2 and t.rows[0].cells[2].text == "p12")
assert len(prior.rows) == 11, len(prior.rows)
for r in rows:
    cells = prior.add_row().cells
    values = [r["locus"], r["outcome"], p12_text(r["p12"]), r["nsnp"], pp(r["PP.H1"]), pp(r["PP.H3"]), pp(r["PP.H4"])]
    for cell, value in zip(cells, values):
        cell.text = value

replace(
    sup,
    "Table S13. Full colocalization posterior probabilities at caffeine-metabolism and FTO loci and prior-sensitivity scan at FTO (coffee intake vs atrial fibrillation)",
    "Table S13. Full colocalization posterior probabilities and prior-sensitivity scans at caffeine-metabolism and FTO loci (coffee intake vs atrial fibrillation)",
)
old_note = next(p for p in sup.paragraphs if p.text.startswith("The coloc.abf default prior is p12"))
for run in old_note.runs:
    run.text = ""
old_note.runs[0].text = (
    "The coloc.abf default prior is p12 = 10⁻⁵. The shared-causal-variant conclusion at FTO held for p12 ≥ 5 × 10⁻⁶ in both outcome sources "
    "(PP.H4 ≥ 0.81) and weakened under the most stringent prior (p12 = 10⁻⁶; PP.H4 = 0.46–0.49). "
    "The coffee-specific pattern at CYP1A1–CYP1A2 and AHR persisted across the same grid (PP.H1 ≥ 0.901 and PP.H4 ≤ 0.041), "
    "so no association with AF was detected at these caffeine-handling loci under any tested prior. "
    "Default-prior posteriors for all four locus–outcome analyses are shown above; the Nielsen 2018 FTO region was rebuilt from local full summary statistics "
    "(1,740 harmonized SNPs; PP.H4 = 0.894 at the default prior)."
)
contents = sup.paragraphs[2].text.replace(
    "Table S13 full colocalization posteriors and FTO prior-sensitivity scan",
    "Table S13 full colocalization posteriors and prior-sensitivity scans at all three loci",
)
for run in sup.paragraphs[2].runs:
    run.text = ""
sup.paragraphs[2].runs[0].text = contents
sup.save(str(PKG / "Supplement.docx"))
print("Supplement S13 updated")

man = Document(str(PKG / "Manuscript.docx"))
replace(
    man,
    "prior sensitivity at FTO was assessed by varying the colocalization prior p12 from 10⁻⁶ to 5 × 10⁻⁵; default-prior posteriors for all locus–outcome analyses are reported in Table S13.",
    "prior sensitivity at all three loci was assessed by varying the colocalization prior p12 from 10⁻⁶ to 5 × 10⁻⁵; default-prior and full posterior probabilities are reported in Table S13.",
)
replace(
    man,
    "The FTO result was prior-sensitive (PP.H4 > 0.8 for p12 ≥ 5 × 10⁻⁶, but 0.457 at p12 = 10⁻⁶; Table S13) and is therefore treated as locus-level rather than pathway-proof evidence.",
    "The coffee-specific pattern at CYP1A1–CYP1A2 and AHR persisted across the p12 grid (PP.H1 ≥ 0.901 and PP.H4 ≤ 0.041), whereas the FTO result was prior-sensitive (PP.H4 > 0.8 for p12 ≥ 5 × 10⁻⁶, but 0.457 at p12 = 10⁻⁶; Table S13) and is therefore treated as locus-level rather than pathway-proof evidence.",
)
man.save(str(PKG / "Manuscript.docx"))
print("Manuscript prior-sensitivity text updated")

plan_path = ARC / "Analysis_plan_and_deviations_archive_20261028.docx"
plan = Document(str(plan_path))
replace(plan, "CYP1A1–CYP1A2, AHR and FTO; default posteriors; FTO p12 scan", "CYP1A1–CYP1A2, AHR and FTO; default posteriors and p12 scans at all three loci")
plan.save(str(plan_path))
print("Analysis archive updated")
