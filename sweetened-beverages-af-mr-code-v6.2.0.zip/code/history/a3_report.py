#!/usr/bin/env python
"""Report Yuan 2025 (UKB-free, co-primary) results side by side with the
Nielsen 2018 primary estimates, and draft the manuscript table rows."""
import csv, io, os, sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

RES = r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\06_升级分析_v4\results"
MRF = os.path.join(RES, "yuan2025_mr.csv")

ORDER = ["Sugar added to tea", "Sugar added to coffee", "Fizzy drinks (SSB)",
         "Low-calorie drinks (ASB)", "Sweetener added to tea", "Coffee intake", "Tea intake"]


def f(x, n=2):
    try:
        return f"{float(x):.{n}f}"
    except (TypeError, ValueError):
        return "-"


rows = list(csv.DictReader(open(MRF, encoding="utf-8")))
by = {}
for r in rows:
    by.setdefault(r["exposure"], {})[r["method"]] = r

print("=" * 108)
print("Yuan 2025 (GCST90624413; 192,851 cases / 1,239,541 controls; UKB-free)")
print("=" * 108)
head = ("{:<24}{:>4}{:>26}{:>9}{:>10}{:>9}{:>10}{:>9}{:>10}").format(
    "Exposure", "n", "IVW-FE OR (95% CI)", "P", "IVW-RE P", "WM P", "Egger P", "RAPS P", "PRESSO P")
print(head)
print("-" * len(head))

summary = []
for e in ORDER:
    m = by.get(e)
    if not m:
        print(f"{e:<24}  -- no result --")
        continue
    ivw = m.get("Inverse variance weighted", {})
    re_ = m.get("Inverse variance weighted (multiplicative random effects)", {})
    wm = m.get("Weighted median", {})
    eg = m.get("MR-Egger", {})
    ra = m.get("MR-RAPS", {})
    pr = m.get("MR-PRESSO", {})
    ci = ""
    if ivw.get("lo") and ivw.get("hi"):
        ci = f"{f(ivw['OR'])} ({f(ivw['lo'])}-{f(ivw['hi'])})"
    print("{:<24}{:>4}{:>26}{:>9}{:>10}{:>9}{:>10}{:>9}{:>10}".format(
        e, ivw.get("nsnp", ""), ci, f(ivw.get("p"), 3), f(re_.get("p"), 3),
        f(wm.get("p"), 3), f(eg.get("p"), 3), f(ra.get("p"), 3), f(pr.get("p"), 3)))
    summary.append(dict(exposure=e, n=ivw.get("nsnp"), OR=ivw.get("OR"), lo=ivw.get("lo"),
                        hi=ivw.get("hi"), p=ivw.get("p"), p_re=re_.get("p"), p_wm=wm.get("p"),
                        p_egg=eg.get("p"), p_raps=ra.get("p"), p_presso=pr.get("p")))

print()
print("=" * 108)
print("Table 1 new column: 'Yuan 2025 (EUR, 192,851 cases), OR (95% CI)'")
print("=" * 108)
for s in summary:
    cell = f"{f(s['OR'])} ({f(s['lo'])}-{f(s['hi'])})"
    print(f"  {s['exposure']:<24} {cell:<26} P = {f(s['p'],3):<8} SNPs = {s['n']}")

print()
n_sig = sum(1 for s in summary if s["p"] and float(s["p"]) < 0.05)
n_bonf = sum(1 for s in summary if s["p"] and float(s["p"]) < 0.05 / 7)
print(f"nominal P<0.05: {n_sig}/{len(summary)}    Bonferroni P<{0.05/7:.4f}: {n_bonf}/{len(summary)}")
