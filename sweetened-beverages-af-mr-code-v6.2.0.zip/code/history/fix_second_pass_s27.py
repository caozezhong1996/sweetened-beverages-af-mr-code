# -*- coding: utf-8 -*-
from docx import Document
import pathlib, io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
PKG = pathlib.Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")
def replace(doc, old, new):
    hits=[p for p in doc.paragraphs if old in p.text]
    assert len(hits)==1,(old,len(hits))
    p=hits[0]; text=p.text.replace(old,new)
    for r in p.runs:r.text=""
    p.runs[0].text=text
sup=Document(str(PKG/"Supplement.docx"))
replace(sup,"(Neale lab UK Biobank field 21001), which removed 3–19 variants per exposure (median 5).","(Yengo et al. 2018, GCST006900), which removed 3–19 variants per exposure (median 5).")
replace(sup,"confirming that the analytical pipeline detects an established lifestyle causal effect; intake frequency per se was null throughout, consistent with cumulative quantity rather than frequency driving AF risk.","providing directional context rather than proof of analytical sensitivity; intake frequency was null throughout, but the different phenotype definitions and instrument sets preclude attributing this contrast to cumulative quantity rather than frequency.")
sup.save(str(PKG/"Supplement.docx"))
cl=Document(str(PKG/"Cover_Letter.docx"))
replace(cl,"Biomarker-level MR of plasma caffeine, paraxanthine and theobromine returned null estimates.","Plasma caffeine and paraxanthine instruments were null; theobromine's nominal inverse association did not survive multiplicity correction.")
cl.save(str(PKG/"Cover_Letter.docx"))
hl=Document(str(PKG/"Highlights.docx"))
replace(hl,"Plasma caffeine, paraxanthine and theobromine instruments likewise showed no association with atrial fibrillation.","Plasma caffeine and paraxanthine were null; theobromine's nominal inverse association did not survive correction.")
hl.save(str(PKG/"Highlights.docx"))
print("Second-pass source, biomarker and control wording corrected")
