# -*- coding: utf-8 -*-
"""Final verification: documents + tables + figures at print size."""
import io
import os
import re
import sys

from docx import Document
from PIL import Image

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

PKG = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013"
FIG = os.path.join(PKG, "figures")
fails = []


def chk(ok, label, detail=""):
    print(("PASS  " if ok else "FAIL  ") + label + (("  " + detail) if detail else ""))
    if not ok:
        fails.append(label)


man = Document(os.path.join(PKG, "Manuscript.docx"))
sup = Document(os.path.join(PKG, "Supplement.docx"))
mp = [p.text.strip() for p in man.paragraphs if p.text.strip()]
mfull = "\n".join(mp)

# --- 1 documents ---
ai = mp.index("Abstract")
words = sum(len([w for w in mp[j].split() if re.search(r"[A-Za-z0-9]", w)]) - 1
            for j in range(ai + 1, ai + 8)
            if mp[j].split(":")[0] in ("Background", "Methods and Results", "Conclusions"))
chk(words <= 250, f"摘要 {words}/250 词")
nums = [int(m.group(1)) for m in re.finditer(r"(?m)^(\d+)\.\s", mfull)]
chk(nums == list(range(1, len(nums) + 1)), f"参考文献 {len(nums)} 条连续")

# --- 2 tables ---
for doc, name in [(man, "手稿"), (sup, "补充材料")]:
    avail = (doc.sections[0].page_width.cm - doc.sections[0].left_margin.cm
             - doc.sections[0].right_margin.cm)
    over = []
    for i, t in enumerate(doc.tables):
        w = sum(c.width.cm if c.width else 0 for c in t.rows[0].cells)
        if w > avail + 0.05:
            over.append(f"表{i}({w:.1f})")
    chk(not over, f"{name} {len(doc.tables)} 张表均 <= {avail:.2f} cm",
        ", ".join(over) if over else "")

t2 = man.tables[1]
chk(len(t2.columns) == 6 and all(len(r.cells) == 6 for r in t2.rows), "表2 六列且每行六格")
chk("Yuan 2025" in t2.rows[0].cells[3].text, "表2 第4列为 Yuan 2025")
chk(any("Yuan" in r.cells[1].text for r in man.tables[0].rows), "表1 含 Yuan 数据源行")

# --- 3 figures at print size ---
TEXT_W_CM = 17.40
print()
for f in sorted(os.listdir(FIG)):
    im = Image.open(os.path.join(FIG, f))
    dpi = im.info.get("dpi", (300, 300))[0]
    w_cm, h_cm = im.size[0] / dpi * 2.54, im.size[1] / dpi * 2.54
    scale = min(1.0, TEXT_W_CM / w_cm)
    flag = "OK" if w_cm <= TEXT_W_CM + 0.1 else f"需缩 {scale:.2f}x"
    print(f"      {f:<28}{w_cm:5.2f} x {h_cm:5.2f} cm @{dpi:.0f} dpi  {flag}")

f2 = Image.open(os.path.join(FIG, "Figure2_Forest.png"))
dpi2 = f2.info["dpi"][0]
chk(abs(f2.size[0] / dpi2 * 2.54 - 17.40) < 0.02, "Figure 2 = 17.40 cm 宽，无需缩放")
for fn in ["Figure1_Study_Design.png", "FigureS1_LOO_Funnel.png", "FigureS2_LDSC_rg.png"]:
    im = Image.open(os.path.join(FIG, fn)); dd = im.info["dpi"][0]
    chk(abs(im.size[0] / dd * 2.54 - 17.40) < 0.02, fn + " = 17.40 cm 宽")

print()
print("=" * 62)
print("全部通过" if not fails else f"{len(fails)} 项未通过: {fails}")
