# -*- coding: utf-8 -*-
"""Append Tables S26 (Yuan 2025 estimator panel) and S27 (adiposity-locus
sensitivity) to build_supplement_v51_JAHA.js, and update the Contents line."""
import csv
import io
import os
import pathlib
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

D = r"C:\a3work"
SP = pathlib.Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
                  r"\04_docx构建脚本\build_supplement_v51_JAHA.js")

ORDER = ["Sugar added to tea", "Sugar added to coffee", "Fizzy drinks (SSB)",
         "Low-calorie drinks (ASB)", "Sweetener added to tea", "Coffee intake", "Tea intake"]
LAB = {"Fizzy drinks (SSB)": "Fizzy drink intake (SSB)",
       "Low-calorie drinks (ASB)": "Low-calorie drink intake (ASB)",
       "Sweetener added to tea": "Artificial sweetener added to tea"}


def f2(x):
    try:
        return f"{float(x):.2f}"
    except (TypeError, ValueError):
        return "-"


def fp(x):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return "-"
    return "<0.001" if v < 0.001 else f"{v:.3f}"


# ---- data ----
mr = list(csv.DictReader(open(os.path.join(D, "yuan2025_mr.csv"), encoding="utf-8")))
by = {}
for r in mr:
    by.setdefault(r["exposure"], {})[r["method"]] = r
ad = list(csv.DictReader(open(os.path.join(D, "yuan2025_adipo_sensitivity.csv"), encoding="utf-8")))
adx = {r["exposure"]: r for r in ad}
allc = list(csv.DictReader(open(os.path.join(D, "adiposity_sensitivity_all_cohorts.csv"), encoding="utf-8")))

# ---- Table S26 rows ----
s26 = []
for e in ORDER:
    m = by[e]
    ivw = m["Inverse variance weighted"]
    adipo = adx[e]
    s26.append([
        LAB.get(e, e), ivw["nsnp"],
        f"{f2(ivw['OR'])} ({f2(ivw['lo'])}-{f2(ivw['hi'])})", fp(ivw["p"]),
        fp(m["Weighted median"]["p"]), fp(m["MR Egger"]["p"]), fp(m["MR-RAPS"]["p"]),
        fp(adipo["Qp"]),
    ])

# ---- Table S27 rows ----
s27 = []
for src in ["Nielsen", "FinnGen R13", "Yuan 2025"]:
    for e in ORDER:
        r = next((x for x in allc if x["outcome"] == src and x["exposure"] == e), None)
        if not r:
            continue
        s27.append([
            src, LAB.get(e, e), r["n"],
            f"{f2(r['OR'])} ({f2(r['lo'])}-{f2(r['hi'])})", fp(r["p"]),
            r["n_clean"],
            f"{f2(r['OR_clean'])} ({f2(r['lo_clean'])}-{f2(r['hi_clean'])})", fp(r["p_clean"]),
        ])


def js_rows(rows):
    out = []
    for r in rows:
        cells = ", ".join('"' + str(c).replace('"', '\\"') + '"' for c in r)
        out.append(f"    [{cells}],")
    return "\n".join(out)


WIDTHS = "[2200, 700, 1900, 900, 1150, 1050, 950, 1056]"

block = f'''
children.push(caption("Table S26. Yuan 2025 co-primary outcome (GWAS Catalog GCST90624413; 192,851 cases and 1,239,541 controls; UK Biobank-free): all estimators for the seven beverage exposures"));
children.push(makeTable(
  {WIDTHS},
  ["Exposure", "SNPs (n)", "IVW OR (95% CI)", "P", "Weighted median P", "MR-Egger P", "MR-RAPS P", "Cochran Q P"],
  [
{js_rows(s26)}
  ], 18));
children.push(note("The released Yuan 2025 summary statistics (European-ancestry arm; eight discovery cohorts; 35,840,705 variants; CC0 licence) exclude UK Biobank and therefore share no participants with the UK Biobank exposure GWAS. Of the 133 unique instrument variants used in this study, 128 (96%) were present in this panel; the five absent variants (rs17245213, rs34060476, rs61928609, rs61928618, rs977474) are not covered by its imputation reference. Estimates are random-effects inverse-variance-weighted odds ratios per unit higher genetically instrumented intake, harmonised with the same allele convention as every other outcome source. This outcome is reported alongside, not within, the pre-specified Nielsen+FinnGen meta-analysis, because it was released after that analysis was defined. Heterogeneity was substantial for coffee and tea intake (Cochran Q P < 0.001), reflecting the adiposity-locus instruments analysed in Table S27."));

children.push(caption("Table S27. Adiposity-locus sensitivity: random-effects IVW estimates before and after removing instruments within 500 kb of a genome-wide-significant body-mass-index locus"));
children.push(makeTable(
  [1500, 2600, 700, 2000, 800, 700, 2000, 800],
  ["Outcome source", "Exposure", "SNPs (all)", "OR (95% CI), all", "P", "SNPs (kept)", "OR (95% CI), adiposity loci removed", "P"],
  [
{js_rows(s27)}
  ], 18));
children.push(note("Instruments were removed if they lay within 500 kb of any of 724 genome-wide-significant body-mass-index loci (GIANT consortium, ieu-b-40), which removed 3-19 variants per exposure (median 5). All estimates are random-effects inverse-variance-weighted. This analysis was introduced during revision, after mediation, multivariable and colocalization results indicated that the coffee estimate was carried by adiposity variants; it is therefore a post hoc robustness analysis. Removing adiposity-locus instruments abolished the coffee association in both overlap-free co-primary outcomes and reduced the between-source spread of the three coffee estimates from 1.26-1.79 to 1.26-1.39. In Nielsen 2018 the adiposity-excluded coffee estimate remained nominally significant (OR 1.39, 1.04-1.86; P = 0.028), so a small adiposity-independent effect cannot be excluded from that source. No sweetened-beverage estimate became significant under the same exclusion."));

'''

src = SP.read_text(encoding="utf-8")
anchor = "const doc = new Document({"
assert src.count(anchor) == 1, src.count(anchor)
src = src.replace(anchor, block.strip("\n") + "\n\n" + anchor)

# ---- Contents line ----
old = "Table S24 Sanderson–Windmeijer conditional F statistics for the multivariable MR instrument set;"
assert src.count(old) == 1
new = ("Table S24 Sanderson–Windmeijer conditional F statistics for the multivariable MR instrument set; "
       "Table S25 biomarker Mendelian randomization for plasma caffeine metabolites; "
       "Table S26 all estimators against the UK Biobank-free Yuan 2025 co-primary outcome; "
       "Table S27 adiposity-locus sensitivity before and after removing instruments within 500 kb of BMI loci;")
src = src.replace(old, new)

SP.write_text(src, encoding="utf-8", newline="\n")
print("S26 rows:", len(s26), " S27 rows:", len(s27))
print("written", SP)
