import csv
import io
import math
import os
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
ROOT = Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822")
RES = ROOT / "06_升级分析_v4" / "results"
OUT = ROOT / "06_升级分析_v4" / "supplement_tables" / "S29_caffeine_diagnostics.tsv"
A3 = Path(r"C:\a3work")
CAF = {"rs117968677", "rs2472297", "rs4410790"}
NEXP = 428860
Z = 1.959963984540054 + 0.841621233572914

loci_path = A3 / "tmp_bmi_instruments_v46.csv"
if not loci_path.exists():
    loci_path = RES / "tmp_bmi_instruments_v46.csv"
with loci_path.open(encoding="utf-8") as f:
    loci = [(int(r["chr"]), int(r["pos"])) for r in csv.DictReader(f)]
assert len(loci) == 724, len(loci)


def near_bmi(chrom, pos):
    return any(c == chrom and abs(pos - p) <= 500000 for c, p in loci)


def ivw(rows):
    weights = [1.0 / (r["se.outcome"] ** 2) for r in rows]
    bx = [r["beta.exposure"] for r in rows]
    by = [r["beta.outcome"] for r in rows]
    den = sum(w * x * x for w, x in zip(weights, bx))
    beta = sum(w * x * y for w, x, y in zip(weights, bx, by)) / den
    se_fixed = math.sqrt(1.0 / den)
    q = sum(w * (y - x * beta) ** 2 for w, x, y in zip(weights, bx, by))
    inflation = max(1.0, q / (len(rows) - 1)) if len(rows) > 1 else 1.0
    se = se_fixed * math.sqrt(inflation)
    z = beta / se
    p = math.erfc(abs(z) / math.sqrt(2.0))
    return beta, se, p


def diag(rows, source):
    assert len(rows) >= 1, (source, len(rows))
    r2s = []
    fs = []
    for r in rows:
        assert int(r["samplesize.exposure"]) == NEXP
        b, s = r["beta.exposure"], r["se.exposure"]
        r2 = b * b / (b * b + NEXP * s * s)
        r2s.append(r2)
        fs.append((b / s) ** 2)
    b, se, p = ivw(rows)
    return {
        "source": source,
        "n_caf": len(rows),
        "r2_pct": 100 * sum(r2s),
        "f_min": min(fs),
        "f_median": sorted(fs)[len(fs) // 2],
        "f_mean": sum(fs) / len(fs),
        "method": "IVW" if len(rows) > 1 else "Wald ratio",
        "ids": ",".join(r["SNP"] for r in rows),
        "or": math.exp(b),
        "lo": math.exp(b - 1.96 * se),
        "hi": math.exp(b + 1.96 * se),
        "p": p,
        "mde": math.exp(Z * se),
        "caf_bmi_overlap": sum(near_bmi(int(r["chr"]), int(r["pos"])) for r in rows),
    }


def position_map():
    with (RES / "dat_Coffee_intake_ebi_a_GCST006414.csv").open(encoding="utf-8") as f:
        return {r["SNP"]: (int(r["chr"]), int(r["pos"])) for r in csv.DictReader(f)}


POS = position_map()


def read_dat(path, expected_outcome):
    with path.open(encoding="utf-8") as f:
        rows = []
        for r in csv.DictReader(f):
            if r["mr_keep"] != "TRUE":
                continue
            assert r["id.exposure"] == "ukb-b-5237"
            assert r["id.outcome"] == expected_outcome
            chrom, pos = (int(r["chr"]), int(r["pos"])) if "chr" in r else POS[r["SNP"]]
            rows.append({
                "SNP": r["SNP"],
                "chr": chrom,
                "pos": pos,
                "beta.exposure": float(r["beta.exposure"]),
                "se.exposure": float(r["se.exposure"]),
                "beta.outcome": float(r["beta.outcome"]),
                "se.outcome": float(r["se.outcome"]),
                "samplesize.exposure": int(r["samplesize.exposure"]),
            })
    return rows


results = []
for tag, filename, expected, label in [
    ("Nielsen", "dat_Coffee_intake_ebi_a_GCST006414.csv", "ebi-a-GCST006414", "Nielsen 2018"),
    ("FinnGen", "dat_Coffee_intake_finngen_R13.csv", "finngen_R13_I9_AF", "FinnGen R13"),
]:
    rows = read_dat(RES / filename, expected)
    caf = [r for r in rows if r["SNP"] in CAF]
    noncaf = [r for r in rows if r["SNP"] not in CAF]
    d = diag(caf, label)
    d["noncaf_n"] = len(noncaf)
    d["noncaf_bmi_overlap"] = sum(near_bmi(r["chr"], r["pos"]) for r in noncaf)
    results.append(d)

# Yuan: outcomes are GRCh38; exposure betas come from the asserted Nielsen-side GRCh37 dat file.
exp_rows = read_dat(RES / "dat_Coffee_intake_ebi_a_GCST006414.csv", "ebi-a-GCST006414")
exp = {r["SNP"]: r for r in exp_rows}
yuan_rows = []
with (A3 / "yuan2025_instruments.tsv").open(encoding="utf-8") as f:
    for r in csv.DictReader(f, delimiter="\t"):
        if r["exposure"] != "Coffee_intake" or r["SNP"] not in CAF:
            continue
        e = exp[r["SNP"]]
        yuan_rows.append({
            "SNP": r["SNP"], "chr": int(r["chr"]), "pos": int(r["pos"]),
            "beta.exposure": e["beta.exposure"], "se.exposure": e["se.exposure"],
            "beta.outcome": float(r["beta.out"]), "se.outcome": float(r["se.out"]),
            "samplesize.exposure": NEXP,
        })
d = diag(yuan_rows, "Yuan 2025")
with (A3 / "yuan2025_instruments.tsv").open(encoding="utf-8") as f:
    all_yuan = [r for r in csv.DictReader(f, delimiter="\t") if r["exposure"] == "Coffee_intake"]
noncaf_yuan = [r for r in all_yuan if r["SNP"] not in CAF]
d["noncaf_n"] = len(noncaf_yuan)
# Use the exposure-side GRCh37 coordinates for the GRCh37 BMI locus list, never Yuan's GRCh38 positions.
d["noncaf_bmi_overlap"] = sum(near_bmi(exp[r["SNP"]]["chr"], exp[r["SNP"]]["pos"]) for r in noncaf_yuan)
results.append(d)

header = ["Outcome", "Method", "Caffeine SNPs", "Cumulative R2 (%)", "F min / median / mean", "OR (95% CI)", "P", "MDE OR (80% power)", "Caffeine SNPs near BMI loci", "Non-caffeine SNPs", "Non-caffeine SNPs near BMI loci"]
lines = ["\t".join(header)]
for d in results:
    lines.append("\t".join([
        d["source"], d["method"], str(d["n_caf"]), f"{d['r2_pct']:.4f}",
        f"{d['f_min']:.1f} / {d['f_median']:.1f} / {d['f_mean']:.1f}",
        f"{d['or']:.2f} ({d['lo']:.2f}-{d['hi']:.2f})", f"{d['p']:.3g}",
        f"{d['mde']:.2f}", str(d["caf_bmi_overlap"]), str(d["noncaf_n"]), str(d["noncaf_bmi_overlap"]),
    ]))
OUT.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
print("\n".join(lines))
print("WROTE", OUT)
