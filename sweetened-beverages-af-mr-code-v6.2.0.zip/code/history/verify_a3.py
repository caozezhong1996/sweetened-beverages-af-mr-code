# -*- coding: utf-8 -*-
"""End-to-end verification of the A3 integration."""
import csv
import io
import os
import re
import sys
from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

PKG = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013"
D = r"C:\a3work"
fails = []


def chk(cond, label, detail=""):
    print(("PASS  " if cond else "FAIL  ") + label + (("  " + detail) if detail else ""))
    if not cond:
        fails.append(label)


man = Document(os.path.join(PKG, "Manuscript.docx"))
sup = Document(os.path.join(PKG, "Supplement.docx"))
mp = [p.text.strip() for p in man.paragraphs if p.text.strip()]
mfull = "\n".join(mp)
sfull = "\n".join(p.text for p in sup.paragraphs if p.text.strip())

# ---- 1. abstract ----
ai = mp.index("Abstract")
words = 0
for j in range(ai + 1, ai + 8):
    if mp[j].split(":")[0] in ("Background", "Methods and Results", "Conclusions"):
        words += len([w for w in mp[j].split() if re.search(r"[A-Za-z0-9]", w)]) - 1
chk(words <= 250, f"摘要 {words}/250 词")

# ---- 2. references ----
nums = [int(m.group(1)) for m in re.finditer(r"(?m)^(\d+)\.\s", mfull)]
chk(nums == list(range(1, len(nums) + 1)), f"参考文献 {len(nums)} 条且连续")

# ---- 3. Table 2 ----
t2 = man.tables[1]
chk(len(t2.columns) == 8, f"表2 列数 {len(t2.columns)}")
chk(all(len(r.cells) == 8 for r in t2.rows), "表2 每行 8 格")
hdr = [c.text.strip() for c in t2.rows[0].cells]
chk("Yuan 2025" in hdr[3], "表2 第4列为 Yuan 2025", hdr[3][:40])
chk("Nielsen 2018 + FinnGen R13" in hdr[6], "表2 合并列仍为 Nielsen+FinnGen", hdr[6][:40])

# cross-check Table 2 Yuan column against the analysis output
mr = list(csv.DictReader(open(os.path.join(D, "yuan2025_mr.csv"), encoding="utf-8")))
by = {}
for r in mr:
    by.setdefault(r["exposure"], {})[r["method"]] = r
name = {"Sugar added to tea": "Sugar added to tea", "Sugar added to coffee": "Sugar added to coffee",
        "Fizzy drinks (SSB)": "Fizzy drink intake (SSB)",
        "Low-calorie drinks (ASB)": "Low-calorie drink intake (ASB)",
        "Sweetener added to tea": "Artificial sweetener added to tea",
        "Coffee intake": "Coffee intake", "Tea intake": "Tea intake"}
bad = []
for e, lab in name.items():
    row = next(r for r in t2.rows[1:] if r.cells[0].text.strip() == lab)
    cell = row.cells[3].text.strip()
    ivw = by[e]["Inverse variance weighted"]
    want = f"{float(ivw['OR']):.2f} ({float(ivw['lo']):.2f}–{float(ivw['hi']):.2f})"
    if not cell.startswith(want):
        bad.append(f"{lab}: 表='{cell}' vs 计算='{want}'")
chk(not bad, "表2 Yuan 列逐格回源", "; ".join(bad) if bad else "7/7 一致")

# ---- 4. Table 1 ----
rows1 = [[c.text.strip() for c in r.cells] for r in man.tables[0].rows]
yuan1 = [r for r in rows1 if "Yuan" in r[1]]
chk(len(yuan1) == 1 and "192,851" in yuan1[0][2], "表1 含 Yuan 数据源行", yuan1[0][1][:40] if yuan1 else "缺失")
chk(not any("not public" in x for x in mfull.split()), "无 'not public' 残留")

# ---- 5. table widths ----
avail = man.sections[0].page_width.cm - man.sections[0].left_margin.cm - man.sections[0].right_margin.cm
for i, t in enumerate(man.tables):
    w = sum(c.width.cm if c.width else 0 for c in t.rows[0].cells)
    chk(w <= avail + 0.05, f"表{i+1} 宽度 {w:.2f} <= {avail:.2f} cm")

# ---- 6. supplement cross-refs ----
cited = sorted({int(m.group(1)) for m in re.finditer(r"Table S(\d+)", mfull)})
have = sorted({int(m.group(1)) for m in re.finditer(r"Table S(\d+)\.", sfull)})
missing = [c for c in cited if c not in have]
chk(not missing, f"正文引用的 Table S{cited[0]}-S{cited[-1]} 均存在", f"缺失 {missing}" if missing else "")

t26 = [t for t in sup.tables
       if "MR-RAPS P" in " ".join(c.text for c in t.rows[0].cells)
       and "Weighted median P" in " ".join(c.text for c in t.rows[0].cells)]
t27 = [t for t in sup.tables if "SNPs (kept)" in " ".join(c.text for c in t.rows[0].cells)]
chk(len(t26) == 1 and len(t26[0].rows) == 8, "Table S26 存在且 7 行暴露",
    f"{len(t26)} 张表 / {len(t26[0].rows) if t26 else 0} 行")
chk(len(t27) == 1 and len(t27[0].rows) == 22, "Table S27 存在且 21 行（3 来源 x 7 暴露）")

# supplement table widths
savail = sup.sections[0].page_width.cm - sup.sections[0].left_margin.cm - sup.sections[0].right_margin.cm
over = []
for i, t in enumerate(sup.tables):
    w = sum(c.width.cm if c.width else 0 for c in t.rows[0].cells)
    if w > savail + 0.05:
        over.append(f"表{i}({w:.1f}cm)")
chk(True, f"补充材料可用宽 {savail:.2f} cm；超宽表: {', '.join(over) if over else '无'}")

# S27 numerical spot check against the source CSV
allc = list(csv.DictReader(open(os.path.join(D, "adiposity_sensitivity_all_cohorts.csv"), encoding="utf-8")))
r27 = t27[0].rows
pairs = [("Yuan 2025", "Coffee intake"), ("FinnGen R13", "Coffee intake"), ("Nielsen", "Coffee intake")]
bad = []
for src, e in pairs:
    ref = next(x for x in allc if x["outcome"] == src and x["exposure"] == e)
    row = next(r for r in r27[1:] if r.cells[0].text.strip() == src and r.cells[1].text.strip() == e)
    want = f"{float(ref['OR']):.2f} ({float(ref['lo']):.2f}-{float(ref['hi']):.2f})"
    got = row.cells[3].text.strip()
    w2 = f"{float(ref['OR_clean']):.2f} ({float(ref['lo_clean']):.2f}-{float(ref['hi_clean']):.2f})"
    g2 = row.cells[6].text.strip()
    if got != want or g2 != w2:
        bad.append(f"{src}/{e}: {got}|{g2} vs {want}|{w2}")
chk(not bad, "Table S27 咖啡三行回源", "; ".join(bad) if bad else "3/3 一致")

# ---- 7. key claims present, stale claims gone ----
must = ["192,851", "1.79 (1.23–2.60)", "1.26–1.39", "adiposity-locus instruments",
        "Table S26", "Table S27", "UK Biobank-free"]
chk(all(k in mfull for k in must), "关键论断齐全", ", ".join(k for k in must if k not in mfull) or "")
stale = ["three European outcome sources", "other three sources", "identical instrument lists",
         "the largest available European-ancestry AF GWAS"]
chk(not any(s in mfull for s in stale), "过时表述已清除",
    ", ".join(s for s in stale if s in mfull) or "")

# ---- 8. metadata ----
meta_ok = all(Document(os.path.join(PKG, f + ".docx")).core_properties.author == "Cao Zezhong"
              for f in ["Manuscript", "Supplement", "Cover_Letter", "Highlights"])
chk(meta_ok, "四份 docx 元数据 author=Cao Zezhong")

print()
print("=" * 60)
print("全部通过" if not fails else f"{len(fails)} 项未通过: {fails}")
