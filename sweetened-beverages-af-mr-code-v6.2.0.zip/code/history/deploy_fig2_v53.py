# -*- coding: utf-8 -*-
"""Deploy Figure 2 v53 into the submission package; archive the v52 file."""
import io
import os
import shutil
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

SRC = (r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
       r"\06_升级分析_v4\figures\Figure2_Forest_v53_300dpi.png")
PKG_FIG = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\figures"
ARCH = (r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版"
        r"\JAHA_v525_改稿留档\旧版图件")

print("package figures before:")
for f in sorted(os.listdir(PKG_FIG)):
    print("  ", f, f"{os.path.getsize(os.path.join(PKG_FIG, f))/1024:.0f} KB")

old = os.path.join(PKG_FIG, "Figure2_Forest.png")
if os.path.exists(old):
    os.makedirs(ARCH, exist_ok=True)
    dst = os.path.join(ARCH, "Figure2_Forest_v52.png")
    shutil.move(old, dst)
    print(f"\narchived  Figure2_Forest.png -> {dst}")

shutil.copy2(SRC, old)
print(f"deployed  {os.path.basename(SRC)} -> {old}  ({os.path.getsize(old)/1024:.0f} KB)")

from PIL import Image
im = Image.open(old)
print(f"\ncheck: {im.size[0]}x{im.size[1]} px  = "
      f"{im.size[0]/600*2.54:.2f} x {im.size[1]/600*2.54:.2f} cm  dpi={im.info.get('dpi')}")

print("\npackage figures after:")
for f in sorted(os.listdir(PKG_FIG)):
    print("  ", f, f"{os.path.getsize(os.path.join(PKG_FIG, f))/1024:.0f} KB")
