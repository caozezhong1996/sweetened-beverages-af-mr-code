# -*- coding: utf-8 -*-
"""Re-verify the 9 low-scoring references through PubMed (esearch + esummary)."""
import io
import json
import re
import sys
import time
import urllib.parse
import urllib.request

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
EUTILS = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils"

data = json.load(open(r"C:\Users\64915\WorkBuddy\2026-10-06-13-49-21\ref_check.json",
                      encoding="utf-8"))
by_n = {d["n"]: d for d in data}
LOW = [4, 9, 12, 13, 14, 15, 17, 19, 37]


def norm(s):
    return set(re.findall(r"[a-z0-9]+", s.lower()))


def sim(a, b):
    A, B = norm(a), norm(b)
    return len(A & B) / len(A | B) if A and B else 0.0


def get(url):
    req = urllib.request.Request(url, headers={"User-Agent": "refcheck/4"})
    with urllib.request.urlopen(req, timeout=20) as r:
        return r.read().decode("utf-8", "replace")


for n in LOW:
    title = by_n[n]["title"]
    q = urllib.parse.urlencode({"db": "pubmed", "term": f'{title}[Title]', "retmode": "json",
                                "retmax": 3})
    try:
        js = json.loads(get(f"{EUTILS}/esearch.fcgi?{q}"))
        ids = js["esearchresult"].get("idlist", [])
        if not ids:
            print(f"NOTFOUND [{n}] {title[:70]}")
            continue
        s = json.loads(get(f"{EUTILS}/esummary.fcgi?db=pubmed&retmode=json&id={','.join(ids)}"))
        best = max(s["result"][i]["title"] for i in ids)
        sc = sim(title, best)
        flag = "OK" if sc >= 0.70 else "REVIEW"
        yr = s["result"][ids[0]].get("pubdate", "")[:4]
        jr = s["result"][ids[0]].get("source", "")
        print(f"{flag:<7}[{n}] {sc:.2f}  {best[:74]}")
        print(f"         {jr} {yr}  PMID {ids[0]}")
    except Exception as e:
        print(f"ERR    [{n}] {type(e).__name__}: {e}")
    time.sleep(0.4)
