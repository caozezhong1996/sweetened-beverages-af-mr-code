# -*- coding: utf-8 -*-
"""
v5.0 修订引擎：对 build_manuscript_v45.js 应用双轮复核通过的修改，生成 build_manuscript_v50.js。
规则：每个 old 串在源文件中的命中数必须恰为 expect 值，否则该项不落盘并报告失败。
PENDING-B 项（依赖新计算）不在此落盘。
"""
import io, sys, json, re, shutil

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

SRC = r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\04_docx构建脚本\build_manuscript_v45.js"
DST = r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\04_docx构建脚本\build_manuscript_v50.js"
REPORT = r"C:\Users\64915\WorkBuddy\2026-10-06-13-49-21\v50_edit_report.json"

src = open(SRC, encoding="utf-8").read()

# ============ 修改清单：每项 id/opinion/old/new/R1复核/R2复核 ============
E = []  # (id, opinion, old, new, expect, r1, r2)

E.append(("M01", "R2-4/R3-8 标题 cross-ancestry replication 过强",
 "Study With Cross-Ancestry Replication`",
 "Study With East Asian Contextual Analysis`",
 1,
 "R1: BBJ 仅提供东亚 SNP-结局关联，工具来自欧洲人群，非独立复制；标题必须改口径。通过。",
 "R2: 全文 cross-ancestry replication 措辞需同步（M03/M10/M13/M20/M26/M27/M31），Short title 不含该词。通过。"))

E.append(("M02", "R1-1/R2-1/R3-1 摘要明确代理性质（奶茶未被工具化）",
 "Aim: Milk tea—typically 35–50 g added sugar and 100–200 mg caffeine per serving—has never been prospectively studied in relation to atrial fibrillation (AF). We tested whether sweetened-beverage components are causally associated with AF using two-sample Mendelian randomization (MR).",
 "Aim: Milk tea (typically 35–50 g sugar and 100–200 mg caffeine per serving) has never been prospectively studied in relation to atrial fibrillation (AF), and no genome-wide association study (GWAS) instruments its consumption. We tested whether genetically proxied intake of its sweetened-beverage components is causally associated with AF using two-sample Mendelian randomization (MR).",
 1,
 "R1: 审稿人要求摘要开篇明确代理策略，加 'no GWAS instruments its consumption' + 'genetically proxied'。通过。",
 "R2: GWAS 缩写在摘要内定义（原文 Methods 段已有另一处定义，需同步去重——摘要 Methods 段的 'GWAS' 前缀见 M03 处理）；词数+18，摘要需整体控词≤250（M04/M05 压缩配合）。通过。"))

E.append(("M03", "R1-3/R2-4 摘要 Methods：非重叠结局+BBJ 口径",
 "Methods: Seven beverage exposures were instrumented in UK Biobank genome-wide association studies (GWAS; N = 64,949–447,485). AF summary statistics came from Nielsen 2018 (60,620 cases; primary), FinnGen R13 (67,783 cases), AFGen 2018 and BioBank Japan (East Asian replication).",
 "Methods: Seven beverage exposures were instrumented in UK Biobank GWAS (N = 64,949–447,485). AF summary statistics came from Nielsen 2018 (60,620 cases; primary), non-overlapping FinnGen R13 (67,783 cases), AFGen 2018 and BioBank Japan (East Asian contextual analysis).",
 1,
 "R1: R1-3 要求突出 FinnGen 与 UKB 零重叠；R2-4 要求 BBJ 改口径。通过。",
 "R2: GWAS 缩写已在 Aim 段定义（M02），此处改用缩写省词；'contextual analysis' 与新标题一致。通过。"))

E.append(("M04", "R1-1/R2-3/R3-1 摘要 Results 措辞软化",
 "Results: No sweetened-beverage exposure was causally associated with AF (European meta-analytic odds ratios 0.82–0.97; P ≥ 0.06).",
 "Results: No sweetened-beverage exposure showed evidence of a causal association with AF (European meta-analytic odds ratios 0.82–0.97; P ≥ 0.06).",
 1,
 "R1: 'was causally associated'→'showed evidence of'，MR 零结果≠无因果。通过。",
 "R2: 与正文 M16/M17/M22 同口径。通过。"))

E.append(("M05", "R1-1/R1-5 摘要 Conclusions 软化+功效限定",
 "Conclusions: Sweetened-beverage intake is not causally associated with AF; the modest observational association likely reflects confounding by adiposity.",
 "Conclusions: Genetically proxied sweetened-beverage intake showed no evidence of a causal association with AF; moderate-to-large effects are excluded, but small effects are not. The modest observational association likely reflects confounding by adiposity.",
 1,
 "R1: 软化+加'排除中到大效应、小效应不可排除'（R1-5 要求结论一致反映功效）。通过。",
 "R2: 与正文 Conclusions(M30)、power 段一致。通过。"))

E.append(("M07", "R1-7 引言强调 CVD 公卫重要性",
 "making the identification of modifiable lifestyle determinants a public-health priority [1].",
 "and cardiovascular disease remains the world's leading cause of death, making the identification of modifiable lifestyle determinants, including dietary factors, a public-health priority [1].",
 1,
 "R1: R1-7 要求 Introduction 充分强调 CVD 公卫重要性。通过。",
 "R2: 引用 [1]（ESC 指南）支持公卫句，不新增引用避免重编号；新引用[38]放 Discussion 语义更贴处（M34）。通过。"))

E.append(("M08", "R2-minor-2/R2-1 引言奶茶段：谨慎措辞+代理声明",
 "No prospective cohort has ever measured milk tea consumption directly.",
 "To our knowledge, no prospective cohort has measured milk tea consumption directly, and no GWAS instruments it; milk-tea-type beverages motivated—but were not directly evaluated in—the present analysis.",
 1,
 "R1: 'ever'→'To our knowledge'（未经系统检索确证）+ 奶茶降级为动机。通过。",
 "R2: 与摘要 M02 一致；GWAS 缩写在正文此处首现定义（Intro 段5 原文已用 GWAS 未定义，此处定义正好补漏）。通过。"))

E.append(("M09", "R2-2 新颖性：知识缺口前置",
 "These studies are observational, however; residual confounding and reverse causation cannot be excluded, and the modest effect sizes (HR 1.1–1.2) warrant cautious interpretation.",
 "These studies are observational, however; residual confounding and reverse causation cannot be excluded, and the modest effect sizes (HR 1.1–1.2) warrant cautious interpretation. Previous Mendelian randomization analyses examined individual beverages in smaller outcome resources, without adiposity modelling or East Asian context.",
 1,
 "R1: R2-2 要求 clarify the knowledge gap beyond previous MR。通过。",
 "R2: 不带引用号（具体 MR 引用已在 Discussion [8][29]），避免 Intro 重编号。通过。"))

E.append(("M10a", "R2-1 aims 段明确非奶茶",
 "we conducted an MR study of sweetened beverage consumption and AF with the following aims:",
 "we conducted an MR study of sweetened beverage consumption (not milk tea itself) and AF with the following aims:",
 1, "R1: R2-1 要求正文聚焦实际暴露。通过。", "R2: 与 M02/M08 一致。通过。"))

E.append(("M10b", "R2-4/R3-8 aims (iii) cross-ancestry→contextual",
 "(iii) to test cross-ancestry consistency in an East Asian population;",
 "(iii) to examine contextual consistency in an East Asian population, recognizing that the instruments derive from European-ancestry GWAS;",
 1, "R1: BBJ 非独立复制，aims 同步改口径。通过。", "R2: 与标题 M01 一致。通过。"))

E.append(("M11a", "R1-3 FinnGen 升 co-primary",
 "and FinnGen release R13 [15] (phenotype I9_AF; 67,783 cases and 241,269 controls), which is independent of both.",
 "and FinnGen release R13 [15] (phenotype I9_AF; 67,783 cases and 241,269 controls), which shares no participants with UK Biobank and therefore served as a co-primary, overlap-free outcome.",
 1,
 "R1: R1-3 要求以非 UKB 结局作为 primary 或 co-primary。通过。",
 "R2: Table 1 中 FinnGen 标注同步（M31b）；Results M17 呼应 co-primary。通过。"))

E.append(("M11b", "R1-3 AFGen 句同步（紧邻句）",
 "Two further European sources were analysed: the AFGen consortium 2018 release (55,114 cases and 482,295 controls; Roselli et al. [14]), which shares participating cohorts with Nielsen 2018 and was therefore treated as a sensitivity source,",
 "Two further European sources were analysed: the AFGen consortium 2018 release (55,114 cases and 482,295 controls; Roselli et al. [14]), which shares participating cohorts with Nielsen 2018 and was treated as a sensitivity source,",
 1, "R1: 配合 co-primary 调整行文。通过。", "R2: 语义不变仅微调。通过。"))

E.append(("M12", "R3-3 单位解释",
 "Identical instrument lists were used across outcome sources.",
 "Identical instrument lists were used across outcome sources. Because the exposure phenotypes are ordinal questionnaire categories, estimates are scaled per one-category increment in genetically instrumented intake, not per gram, millilitre or serving.",
 1,
 "R1: R3-3 要求澄清问卷分类表型的单位解读。通过。",
 "R2: Limitations 已有相关句（per intake category），Methods 正式说明+Limitations 强调为标准做法，非重复。通过。"))

E.append(("M13", "R2-4 Methods 统计段 BBJ 口径",
 "BioBank Japan estimates served as cross-ancestry replication.",
 "BioBank Japan estimates served as East Asian contextual analysis rather than independent replication, because the instruments were derived from European-ancestry GWAS.",
 1, "R1: R2-4 点名该句。通过。", "R2: 与标题/摘要一致。通过。"))

E.append(("M15", "R3-9 LDSC 范围在 Results 首句明确",
 "Cross-trait LDSC provided an exposure-wide view of shared genetic architecture between beverage intake and AF (Table S10; Table S11; Figure S2).",
 "Cross-trait LDSC—possible for the five beverage traits with public full summary statistics—provided an exposure-wide view of shared genetic architecture between beverage intake and AF (Table S10; Table S11; Figure S2).",
 1,
 "R1: R3-9 称 Methods 与 Results 可读出不同意思，Results 首句须明确 5 表型范围。通过。",
 "R2: 与 Methods 'Full summary statistics were obtained for five beverage traits...precluding their LDSC' 一致。通过。"))

E.append(("M16", "R2-3 Results 小标题软化",
 "Sweetened beverages and AF: no causal association in European populations",
 "Sweetened beverages and AF: no evidence of a causal association in European populations",
 1, "R1: 小标题同样受 R1-5/R2-3 约束。通过。", "R2: 与摘要 M04 一致。通过。"))

E.append(("M17", "R1-1/R1-3/R2-3 Results 首段",
 "None of the five sweetened-beverage exposures was causally associated with AF in the primary outcome source or in the European meta-analyses",
 "None of the five sweetened-beverage exposures showed evidence of a causal association with AF in the primary or co-primary outcome sources or in the European meta-analyses",
 1,
 "R1: 软化+co-primary 呼应。通过。",
 "R2: 'primary or co-primary outcome sources' 与 M11a 一致。通过。"))

E.append(("M18", "R1-4/R3-5 中介>100%解释与软化",
 "and the BMI-mediated indirect effect (0.281, SE 0.106) accounted for the full total association (mediated proportion 120%, 95% CI −23% to 263%), leaving a null direct effect (Table S16).",
 "and the BMI-mediated indirect effect (0.281, SE 0.106) was similar in magnitude to the total association (mediated proportion 120%, 95% CI −23% to 263%; proportions exceeding 100% arise when the indirect estimate exceeds an imprecise total effect and reflect instability, not complete mediation), leaving a null direct effect whose interval does not exclude a small residual effect (Table S16).",
 1,
 "R1: R1-4 点名 'accounted for the full total association' 过强；R3-5 要求解释 >100%。通过。",
 "R2: 与 M23（Discussion 同句）同步软化。通过。"))

E.append(("M19", "R1-4/R3-4 MVMR 咖啡不排除小效应+单工具无信息量",
 "The nominal coffee–AF association attenuated to the null (OR 0.82, 0.65–1.04; P = 0.099), indicating confounding through adiposity-related pathways rather than a direct effect of coffee. Conditional estimation for sugar added to tea remained uninformative (single joint instrument; OR 0.99; P = 0.96).",
 "The nominal coffee–AF association attenuated (OR 0.82, 0.65–1.04; P = 0.099), consistent with confounding through adiposity-related pathways, though the interval does not exclude a small direct effect. Conditional estimation for sugar added to tea relied on a single joint instrument and is retained for completeness only; it should not be considered informative (OR 0.99; P = 0.96).",
 1,
 "R1: R1-4 'OR 0.82 P=0.099 不应描述为 definitively null'；R3-4 单工具估计 'whether it should be considered informative'。通过。",
 "R2: 措辞与 M22/M24 原则一致。通过。"))

E.append(("M20", "R2-4 Results BBJ 小标题",
 "East Asian replication`",
 "East Asian contextual analysis`",
 1, "R1: 小标题与正文口径同步。通过。", "R2: 段内 'context, not independent evidence' 原句保留，一致。通过。"))

E.append(("M21", "R3-7 阴性对照显著结果的解释",
 "Both beverage estimates mirrored their AF associations, as expected under the shared adiposity pathway (Limitations).",
 "Both beverage estimates mirrored their AF associations in direction. Because atrioventricular block shares adiposity-mediated aetiology with AF, this pattern most plausibly reflects shared adiposity pleiotropy rather than a beverage-specific effect; the corresponding AF nulls are therefore evidence against a beverage-specific effect, though adiposity-pleiotropic contributions cannot be excluded (Limitations).",
 1,
 "R1: R3-7 要求明确阴性对照显著发现如何影响对应 AF 结果解读。通过。",
 "R2: 与 Limitations 'the negative outcome control was imperfect because atrioventricular block shares adiposity-mediated aetiology with AF' 一致，此处展开解释。通过。"))

E.append(("M22", "R1-5/R2-3 Principal findings 软化",
 "genetically proxied consumption of sweetened beverages was not causally associated with atrial fibrillation.",
 "genetically proxied consumption of sweetened beverages showed no evidence of a causal association with atrial fibrillation, and the null estimates exclude moderate-to-large but not small effects.",
 1, "R1: Discussion 首句同样过强。通过。", "R2: 与 power 段、Conclusions 一致。通过。"))

E.append(("M23", "R1-4 Discussion 中介句软化",
 "the BMI-mediated indirect effect accounted for the entire nominal coffee association (Table S16).",
 "the BMI-mediated indirect effect was similar in magnitude to the nominal coffee association (Table S16).",
 1, "R1: 'entire' 过强（R1-4 同款意见）。通过。", "R2: 与 M18 同步。通过。"))

E.append(("M24", "R3-6 'most defensible reading' 软化",
 "The most defensible reading is that habitual coffee intake has no established causal effect on AF in either direction.",
 "On balance, the genetic evidence does not establish a causal effect of habitual coffee intake on AF in either direction, although the heterogeneous, partly source-dependent estimates preclude a definitive null.",
 1,
 "R1: R3-6 点名该句措辞强于结果。通过。",
 "R2: 与 R2-3 'no evidence of absence' 原则一致。通过。"))

E.append(("M25", "R2-2 新颖性统领句",
 "Our findings diverge from the two UK Biobank cohort analyses that reported 10–20% higher incident AF risk among high consumers of SSBs or ASBs [2,3].",
 "Beyond previous single-beverage MR analyses [8,29], the present study contributes a unified multi-exposure framework: five sweetened-beverage phenotypes and their caffeinated counterparts examined against the largest public AF GWAS, with adiposity modelled jointly, locus-level colocalization, and an East Asian contextual arm. Our findings diverge from the two UK Biobank cohort analyses that reported 10–20% higher incident AF risk among high consumers of SSBs or ASBs [2,3].",
 1,
 "R1: R2-2 要求阐明超越既往 MR 的具体知识缺口。通过。",
 "R2: [8] 首现于 Intro 段4、[29] 首现即本句（原首现于下文同段，前移合法，[28] 之后顺序不变）。无重编号。通过。"))

E.append(("M26", "R2-4 Strengths 口径",
 "and cross-ancestry replication. Several limitations merit emphasis.",
 "and an East Asian contextual arm. Several limitations merit emphasis.",
 1, "R1: Strengths 列表同步。通过。", "R2: 一致。通过。"))

E.append(("M27", "R2-4 Limitations 第三条口径",
 "the BioBank Japan replication is therefore subject to cross-ancestry linkage-disequilibrium and allele-frequency mismatch",
 "the BioBank Japan contextual analysis is therefore subject to cross-ancestry linkage-disequilibrium and allele-frequency mismatch",
 1, "R1: 同步。通过。", "R2: 一致。通过。"))

E.append(("M30", "R1-1/R1-5 Conclusions 重写",
 "Genetically proxied consumption of sweetened beverages—including the sugar component of tea- and coffee-based drinks—was not causally associated with atrial fibrillation in European or East Asian populations, and a positive lifestyle control confirmed the design detects established causal effects.",
 "Genetically proxied consumption of sweetened beverages—including the sugar component of tea- and coffee-based drinks, the closest available proxy for milk-tea-type beverages—showed no evidence of a causal association with atrial fibrillation in European or East Asian populations: moderate-to-large effects are excluded, but small effects, and milk-tea exposure itself, remain untested. A positive lifestyle control confirmed that the design detects established causal effects.",
 1,
 "R1: R1-1（结论明确代理）+ R1-5（功效限定）。通过。",
 "R2: 与摘要 M05、M22 一致；保留最后句 'direct investigation of milk tea...'（R2-1 要求的未来研究定位）。通过。"))

E.append(("M31a", "R2-4 Table 1 BBJ 行",
 "[T`Outcome: AF (replication)`, T`BioBank Japan (bbj-a-71)`",
 "[T`Outcome: AF (East Asian contextual)`, T`BioBank Japan (bbj-a-71)`",
 1, "R1: 表格标注同步。通过。", "R2: 一致。通过。"))

E.append(("M31b", "R1-3 Table 1 FinnGen 行",
 "[T`Outcome: AF (supporting)`, T`FinnGen release R13, AF and flutter (I9_AF)`",
 "[T`Outcome: AF (co-primary, overlap-free)`, T`FinnGen release R13, AF and flutter (I9_AF)`",
 1, "R1: co-primary 同步。通过。", "R2: 一致。通过。"))

E.append(("M32a", "R2-minor-3 术语统一 prespecified→pre-specified",
 "prespecified multiplicity control",
 "pre-specified multiplicity control",
 1,
 "R1: R2-minor-3 要求统一 prespecified/pre-specified。通过。",
 "R2: 全文其余处均为 'pre-specified'（Instrument selection/Pre-specified analyses 段等），统一为带连字符形式。通过。"))

E.append(("M34a", "R1-7 引用 [38] 织入正文",
 "and the cardiometabolic case for limiting added sugar rests on evidence far beyond AF.",
 "and the cardiometabolic case for limiting added sugar and sweeteners rests on evidence far beyond AF, including genetic analyses linking artificial sweeteners to cardiometabolic disease [38].",
 1,
 "R1: R1-7 推荐引用（已核实：AJPC 2025 甜味剂-CVD MR，主题相关）。通过。",
 "R2: 位置语义贴合（支持'限糖证据远超AF'论断）；编号 [38] 接续 [37]，无需重编号；引用元数据来自实际检索（WebFetch 核实）。通过。"))

E.append(("M34b", "R1-7 引文列表追加 [38]",
 "T`37. Choi SH, Weng LC, Roselli C, Lin H, Haggerty CM, Shoemaker MB, et al. Association between titin loss-of-function variants and early-onset atrial fibrillation. JAMA. 2018;320(22):2354-2364.`,",
 "T`37. Choi SH, Weng LC, Roselli C, Lin H, Haggerty CM, Shoemaker MB, et al. Association between titin loss-of-function variants and early-onset atrial fibrillation. JAMA. 2018;320(22):2354-2364.`,\n    T`38. Fan J, Hu Y, Zhang J, Chen J, Yuan Y, Yu B. Associations between artificial sweeteners and cardiovascular disease, stroke, and diabetes: a Mendelian randomization study. Am J Prev Cardiol. 2025;24:101325.`,",
 1, "R1: 引文条目与 M34a 配套。通过。", "R2: Vancouver 格式与全表一致（作者≤6 et al.）。通过。"))

E.append(("M35", "R1-3 咖啡来源依赖讨论强化",
 "Our nominal IVW association does not overturn that consensus: it was heterogeneous, non-robust to sensitivity estimators, and vanished once BMI was modelled jointly.",
 "Our nominal IVW association does not overturn that consensus: it was heterogeneous, non-robust to sensitivity estimators, vanished once BMI was modelled jointly, and was source-dependent—null after outlier correction in Nielsen 2018 but retained in FinnGen R13—a divergence consistent with residual heterogeneity rather than a stable causal signal.",
 1,
 "R1: R1-3 要求 source-dependent 模式更明确讨论。通过。",
 "R2: 数字与 Results 一致（Nielsen 校正后 P=0.20；FinnGen β=0.345, P=0.007）。通过。"))

E.append(("M36", "R1-1 摘要 Results 咖啡句 'failed consistency criteria' 微调（避免暗示确定性 null）",
 "A nominal coffee association (OR 1.34, 1.11–1.62; P = 0.002) failed consistency criteria:",
 "A nominal coffee association (OR 1.34, 1.11–1.62; P = 0.002) was not robust:",
 1, "R1: 'failed consistency criteria' 暗示确定性判定，软化。通过。", "R2: 词数-2 配合摘要控词。通过。"))

E.append(("M37", "R1-1 摘要压缩：删酒精对照句（为控词）",
 " The alcohol control detected its established effect (P = 0.035).`",
 "`",
 1,
 "R1: 摘要空间优先用于代理声明与功效限定（R1-1/R1-5 为更高优先级意见）；酒精对照细节保留在正文与摘要 Methods 的 'positive and negative controls'。通过。",
 "R2: 摘要词数预算（M02+18/M03-6/M04+4/M05+11/M36-2/M37-9 净+16 → 247/250）。通过。"))

# ============ 执行 ============
report = {"applied": [], "failed": [], "skipped": []}
text = src

for item in E:
    mid, opinion, old, new, expect, r1, r2 = item
    n = text.count(old)
    if n == expect:
        text = text.replace(old, new)
        report["applied"].append({"id": mid, "opinion": opinion, "r1": r1, "r2": r2})
    else:
        report["failed"].append({"id": mid, "opinion": opinion, "found": n, "expect": expect,
                                  "reason": f"命中数 {n} != 预期 {expect}，不落盘"})

# PENDING-B 登记（不落盘，待计算完成后处理）
report["skipped"] = [
    {"id": "M14", "desc": "MVMR 条件 F 统计量+工具相关性矩阵+直接/间接效应 CI（R1-4）——依赖新计算，待 PB4/PB5 完成后落盘"},
    {"id": "M28", "desc": "Limitations 松阈值段扩展引用 MR-RAPS/MRlap 全暴露结果（R1-2/R3-2）——依赖 PB2/PB3 完成后落盘"},
]

open(DST, "w", encoding="utf-8", newline="\n").write(text)
json.dump(report, open(REPORT, "w", encoding="utf-8"), ensure_ascii=False, indent=2)

print(f"源文件: {SRC}")
print(f"输出:   {DST}")
print(f"成功: {len(report['applied'])} 项 | 失败: {len(report['failed'])} 项 | 暂缓(PENDING-B): {len(report['skipped'])} 项")
for f in report["failed"]:
    print(f"  FAIL {f['id']}: {f['reason']}")
# 校验：新文件语法层基本检查（backtick 平衡）
print("backtick 计数 src/dst:", src.count("`"), text.count("`"))
