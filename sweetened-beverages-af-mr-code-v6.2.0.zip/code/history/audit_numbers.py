# -*- coding: utf-8 -*-
"""Numeric consistency: abstract vs Table 2 vs Results text; Highlights length."""
import io
import os
import re
import sys

from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
PKG = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013"
rows = []


def rec(ok, item, detail=""):
    rows.append(ok)
    print(("PASS  " if ok else "FAIL  ") + item + (f"   [{detail}]" if detail else ""))


man = Document(os.path.join(PKG, "Manuscript.docx"))
mp = [p.text.strip() for p in man.paragraphs if p.text.strip()]
full = "\n".join(mp)
t2 = man.tables[1]
hdr = [c.text.strip() for c in t2.rows[0].cells]

def col(idx):
    out = {}
    for r in t2.rows[1:]:
        c = [x.text.strip() for x in r.cells]
        m = re.match(r"^([\d.]+) \(([\d.]+)[–-]([\d.]+)\),\s*P[\s ]*=[\s ]*([\d.]+)$", c[idx])
        if m:
            out[c[0]] = (float(m.group(1)), float(m.group(2)), float(m.group(3)), float(m.group(4)))
    return out

nielsen, finn, yuan, meta = col(1), col(2), col(3), col(4)
SWEET = ["Sugar added to tea", "Sugar added to coffee", "Fizzy drink intake (SSB)",
         "Low-calorie drink intake (ASB)", "Artificial sweetener added to tea"]

print("=== 表2 各列解析 ===")
for name, d in [("Nielsen", nielsen), ("FinnGen", finn), ("Yuan", yuan), ("meta", meta)]:
    print(f"  {name:<10}{len(d)} 行")
print()

# 1. abstract: European meta range and P floor for sweetened beverages
lo = min(meta[k][0] for k in SWEET); hi = max(meta[k][0] for k in SWEET)
pmin = min(meta[k][3] for k in SWEET)
rec(abs(lo - 0.82) < 0.005 and abs(hi - 0.97) < 0.005, "摘要 0.82–0.97 与表2 meta 列一致",
    f"{lo:.2f}–{hi:.2f}")
rec(abs(pmin - 0.06) < 0.001, "摘要 P ≥ 0.06 与表2 最小 P 一致", f"{pmin}")

# 2. abstract: UKB-free range
lo = min(yuan[k][0] for k in SWEET); hi = max(yuan[k][0] for k in SWEET)
pmin = min(yuan[k][3] for k in SWEET)
rec(abs(lo - 0.76) < 0.005 and abs(hi - 1.04) < 0.005, "摘要 UKB-free 0.76–1.04 与表2 Yuan 列一致",
    f"{lo:.2f}–{hi:.2f}")
rec(abs(pmin - 0.083) < 0.001, "摘要 P ≥ 0.083 与表2 Yuan 最小 P 一致", f"{pmin}")

# 3. coffee numbers in text
txt_coffee = next(p for p in mp if p.startswith("Coffee intake was nominally associated"))
for label, src, key in [("Nielsen", nielsen, "Coffee intake"), ("FinnGen", finn, "Coffee intake"),
                        ("Yuan", yuan, "Coffee intake")]:
    orv, l, h, p = src[key]
    ok = (f"{orv:.2f}" in txt_coffee) and (f"{l:.2f}–{h:.2f}" in txt_coffee)
    rec(ok, f"Results 咖啡段 {label} {orv:.2f} ({l:.2f}–{h:.2f})")

# 4. adiposity-sensitivity numbers in the new paragraph
para = next((p for p in mp if p.startswith("To separate the coffee signal")), "")
for probe in ["1.79", "1.26", "0.90–1.75", "1.39", "1.04–1.86", "0.94–2.04",
              "1.26–1.39", "2.1%", "15–17", "724", "not pooled"]:
    rec(probe in para, f"体脂敏感性段含 {probe}")
for probe in ["1.48", "1.01–2.18", "1.39–1.48", "0.9%", "1.41", "0.0007"]:
    rec(probe not in para, f"体脂敏感性段已移除 {probe}")

# 5. figure legends match figure content
fig1 = next(p for p in mp if p.startswith("Figure 1."))
fig2 = next(p for p in mp if p.startswith("Figure 2."))
figs1 = next(p for p in mp if p.startswith("Figure S1."))
rec("Yuan 2025" in fig1, "Figure 1 图注提到 Yuan")
rec(all(k in fig2 for k in ["Nielsen 2018", "FinnGen R13", "Yuan 2025", "AFGen 2018", "BioBank Japan"]),
    "Figure 2 图注覆盖全部 6 个面板")
rec(all(k in figs1 for k in ["five selected", "coffee intake vs Nielsen 2018, FinnGen R13 and Yuan 2025", "sugar added to tea",
                             "sugar added to coffee vs AFGen"]) and "every exposure–source" not in figs1,
    "Figure S1 图注覆盖 5 个选定组合且不宣称穷举")

# 6. Highlights
hl = Document(os.path.join(PKG, "Highlights.docx"))
bul = [p.text.strip() for p in hl.paragraphs if p.text.strip() and p.text.strip() != "Highlights"]
rec(3 <= len(bul) <= 5, f"Highlights {len(bul)} 条（要求 3–5）")
long = [(b[:40], len(b)) for b in bul if len(b) > 200]
rec(not long, "Highlights 每条 <=200 字符", str(long) if long else
    f"最长 {max(len(b) for b in bul)} 字符")

# 7. cover letter no longer uses the supplementary workload as a selling point
cl = Document(os.path.join(PKG, "Cover_Letter.docx"))
clt = " ".join(p.text for p in cl.paragraphs)
rec("twenty-seven supplementary tables" not in clt and "workload that distinguishes" not in clt,
    "投稿信不以补充表数量/工作量作卖点")

print()
print(f"合计 {len(rows)} 项：PASS {sum(rows)}，FAIL {len(rows)-sum(rows)}")
