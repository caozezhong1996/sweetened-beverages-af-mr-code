import csv
import io
import shutil
import sys
from pathlib import Path
from docx import Document
from docx.shared import Pt

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
PKG = Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")
ARC = Path(r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版\JAHA_v525_改稿留档\审读意见_20261028")
ROOT = Path(r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822")
RES = ROOT / "06_升级分析_v4" / "results"
TABS = ROOT / "06_升级分析_v4" / "supplement_tables"

for name in ("Manuscript.docx", "Supplement.docx"):
    shutil.copy2(PKG / name, ARC / f"低成本三项前备份_{name}")


def replace_paragraph(doc, old, new, expected=1):
    hits = 0
    for p in doc.paragraphs:
        if old in p.text:
            full = p.text.replace(old, new)
            for run in p.runs:
                run.text = ""
            p.runs[0].text = full
            hits += 1
    assert hits == expected, (old[:80], hits, expected)


def replace_whole(doc, prefix, new):
    matches = [p for p in doc.paragraphs if p.text.startswith(prefix)]
    assert len(matches) == 1, (prefix, len(matches))
    p = matches[0]
    for run in p.runs:
        run.text = ""
    p.runs[0].text = new


def format_table(table, size=7.5):
    table.autofit = True
    for row in table.rows:
        for cell in row.cells:
            for p in cell.paragraphs:
                for run in p.runs:
                    run.font.size = Pt(size)


def add_table(doc, headers, rows, size=7.5):
    table = doc.add_table(rows=1, cols=len(headers))
    if doc.tables and doc.tables[0].style is not None:
        table.style = doc.tables[0].style
    for i, text in enumerate(headers):
        table.rows[0].cells[i].text = text
    for values in rows:
        cells = table.add_row().cells
        for i, text in enumerate(values):
            cells[i].text = str(text)
    format_table(table, size)
    return table


print("Manuscript already updated")

sup = Document(str(PKG / "Supplement.docx"))
# Update the one-paragraph contents list and correct older S13/S19 descriptions.
contents = sup.paragraphs[2].text
contents = contents.replace(
    "Table S13 colocalization prior-sensitivity scan at the FTO locus",
    "Table S13 full colocalization posteriors and FTO prior-sensitivity scan",
)
contents = contents.replace(
    "Table S19 independent coffee-exposure GWAS replication and cross-GWAS meta-analysis",
    "Table S19 coffee-exposure phenotype-definition sensitivity analysis",
)
contents = contents.replace(
    "; Figure S1 leave-one-out",
    "; Table S28 cohort-level sample-overlap map; Table S29 caffeine-pathway instrument diagnostics; Figure S1 leave-one-out",
)
for run in sup.paragraphs[2].runs:
    run.text = ""
sup.paragraphs[2].runs[0].text = contents

replace_paragraph(
    sup,
    "Table S13. Colocalization prior-sensitivity scan at the FTO locus (coffee intake vs atrial fibrillation): posterior probabilities as the coloc.abf prior p12 is varied",
    "Table S13. Full colocalization posterior probabilities at caffeine-metabolism and FTO loci and prior-sensitivity scan at FTO (coffee intake vs atrial fibrillation)",
)
replace_paragraph(
    sup,
    "Prior scans at CYP1A1–CYP1A2 and AHR were not repeated: those loci supported a coffee-specific signal (PP.H1 ≥ 0.93), a conclusion driven by the absence of an AF association and insensitive to p12, and their caffeine-pathway instruments were additionally null in subgroup MR (Table S4).",
    "Prior scans at CYP1A1–CYP1A2 and AHR were not repeated; their default-prior posteriors are shown above, and no prior-sensitivity claim is made for those loci. Their caffeine-pathway instruments were additionally null in subgroup MR (Table S4), with limited precision quantified in Table S29.",
)

# Insert the default-prior full H0–H4 table immediately before the existing FTO scan.
prior_table = next(t for t in sup.tables if t.rows[0].cells[0].text == "Locus" and len(t.rows[0].cells) > 2 and t.rows[0].cells[2].text == "p12")
label = sup.add_paragraph("Default-prior posterior probabilities (coloc.abf, p12 = 10⁻⁵):")
prior_table._tbl.addprevious(label._p)
default_rows = []
for source_file, outcome in [
    ("upgrade_coloc_coffee_loci_Nielsen.csv", "Nielsen 2018"),
    ("upgrade_coloc_FTO_FinnGenR13.csv", "FinnGen R13"),
]:
    with (RES / source_file).open(encoding="utf-8") as f:
        for r in csv.DictReader(f):
            default_rows.append([
                r["region"], outcome, r["nsnp"],
                f"{float(r['PP.H0']):.2e}", f"{float(r['PP.H1']):.3f}",
                f"{float(r['PP.H2']):.2e}", f"{float(r['PP.H3']):.3f}", f"{float(r['PP.H4']):.3f}",
            ])
default_table = add_table(sup, ["Locus", "Outcome", "SNPs", "PP.H0", "PP.H1", "PP.H2", "PP.H3", "PP.H4"], default_rows)
prior_table._tbl.addprevious(default_table._tbl)

# Append S28 sample-overlap map.
sup.add_page_break()
title = sup.add_paragraph("Table S28. Cohort-level sample-overlap map for exposure, outcome and covariate GWAS")
title.runs[0].bold = True
overlap_rows = [
    ["UKB beverage exposures ↔ Nielsen 2018 AF", "Yes", "Nielsen included UK Biobank (application 24460).", "Primary MR is not free of exposure–outcome overlap; MRlap/LDSC are sensitivity diagnostics, not proof of absence."],
    ["UKB beverage exposures ↔ FinnGen R13 AF", "No expected", "Separate Finnish recruitment; no UK Biobank component.", "Outcome replication without UKB exposure overlap."],
    ["UKB beverage exposures ↔ Yuan 2025 public discovery", "No", "The eight discovery cohorts exclude UK Biobank; UKB was a separate replication set (36,075 cases), not part of GCST90624413.", "UKB-exposure-free outcome replication; does not imply independence from other AF outcomes."],
    ["UKB beverage exposures ↔ AFGen 2018", "Not fully quantified", "AFGen used UK Biobank at least for PheWAS and shares cohort structure with Nielsen; discovery overlap is not assumed to be zero.", "Retained as sensitivity only, not as an independent replication."],
    ["UKB beverage exposures ↔ BioBank Japan", "No expected", "Distinct Japanese cohorts.", "Contextual analysis only because instruments are European-derived."],
    ["UKB beverage exposures ↔ GIANT BMI (ieu-b-40)", "Yes", "Yengo 2018 combined earlier GIANT statistics with approximately 450,000 UK Biobank participants.", "MVMR and mediation are not free of shared-sample effects."],
    ["Primary UKB beverage GWAS ↔ Neale coffee 1498 / BMI 21001", "Yes", "Same UK Biobank population; 19 of 24 Neale coffee instruments overlap primary loci.", "Phenotype-definition sensitivity, not independent replication."],
    ["Nielsen 2018 AF ↔ AFGen 2018", "Yes", "AFGen summary statistics were inputs to Nielsen 2018.", "Not meta-analyzed together."],
    ["Yuan 2025 ↔ FinnGen R13", "Yes", "Yuan discovery includes FinnGen R12; R13 subsumes R12.", "Outcome estimates are not mutually independent."],
    ["Yuan 2025 ↔ AFGen 2018", "Yes", "Yuan discovery includes the AFGen consortium.", "Outcome estimates are not mutually independent."],
    ["Yuan 2025 ↔ Nielsen 2018", "Possible indirect overlap", "Potential shared structure through AFGen; not quantified from public metadata.", "No claim of outcome independence."],
    ["Nielsen 2018 ↔ FinnGen R13", "No direct overlap expected", "Distinct cohort contributions.", "Retained in the analysis-plan European meta-analysis."],
    ["Chen metabolite GWAS ↔ UKB beverage exposures", "No expected", "Separate European metabolite cohorts (approximately 8,000 participants).", "Biologically distinct replication, but low-powered."],
]
add_table(sup, ["Dataset pair", "Overlap", "Evidence", "Analytic consequence"], overlap_rows, size=7.2)
sup.add_paragraph(
    "Sources: Nielsen et al. 2018 (UK Biobank application 24460 and AFGen input); Yuan et al. 2025 and its 3 October 2025 Author Correction "
    "(eight discovery cohorts including FinnGen R12 and AFGen; 192,851 cases); GWAS Catalog GCST90624413 (CC0, discovery countries exclude the United Kingdom); "
    "Yengo et al. 2018 (approximately 450,000 UK Biobank participants); Table S19 for Neale instrument overlap. “No expected” denotes no known shared cohort, not a proof of zero individual-level overlap."
)

# Append S29 caffeine diagnostics.
sup.add_page_break()
title = sup.add_paragraph("Table S29. Caffeine-pathway instrument strength, outcome precision and adiposity-locus overlap")
title.runs[0].bold = True
with (TABS / "S29_caffeine_diagnostics.tsv").open(encoding="utf-8") as f:
    rows = list(csv.DictReader(f, delimiter="\t"))
main_rows = []
for r in rows:
    main_rows.append([
        r["Outcome"], r["Method"], r["Caffeine SNPs"], r["Cumulative R2 (%)"], r["F min / median / mean"],
        r["OR (95% CI)"], r["P"], r["MDE OR (80% power)"],
    ])
add_table(sup, ["Outcome", "Method", "SNPs", "R² (%)", "F min/median/mean", "OR (95% CI)", "P", "MDE OR"], main_rows, size=7.5)
overlap_rows29 = []
for r in rows:
    overlap_rows29.append([
        r["Outcome"],
        f"{r['Caffeine SNPs near BMI loci']} / {r['Caffeine SNPs']}",
        f"{r['Non-caffeine SNPs near BMI loci']} / {r['Non-caffeine SNPs']}",
    ])
add_table(sup, ["Outcome", "Caffeine-window SNPs near BMI loci / recovered", "Other SNPs near BMI loci / retained"], overlap_rows29, size=7.5)
sup.add_paragraph(
    "Caffeine-window instruments were rs117968677, rs2472297 and rs4410790. Only rs117968677 was recovered in Yuan 2025, so a single Wald ratio is reported and is not comparable with the three-SNP IVW subgroup. "
    "R² is the sum of β²/(β² + N·SE²) with N = 428,860; F = β²/SE². MDE OR = exp[(z0.975 + z0.80) × SE], using random-effects IVW SE for the three-SNP subsets. "
    "All three caffeine-window instruments lie within 500 kb of a BMI locus, so this subgroup is not adiposity-free. BMI-locus matching used exposure-side GRCh37 coordinates; Yuan GRCh38 coordinates were not directly compared with the GRCh37 BMI list. "
    "The Yuan non-caffeine row includes the two caffeine-window SNPs not recovered in that outcome."
)
sup.save(str(PKG / "Supplement.docx"))
print("Supplement updated with S13/S28/S29")
