# -*- coding: utf-8 -*-
import io
import pathlib
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

ADD = """

### 补记：6 条文献全部核验通过（2026-10-28）

此前 40/46 自动匹配，剩 6 条（13/14/15/17/19/37）模糊检索命中错。本轮改用 **DOI 精确解析**，逐字段核对：

| # | DOI | 结果 |
|---|---|---|
| 13 | 10.1038/s41588-018-0171-3 | Nielsen JB 等, *Nat Genet* 2018;50(9):1234-1239 ✔ |
| 14 | 10.1038/s41588-018-0133-9 | Roselli C 等, *Nat Genet* 2018;50(9):1225-1233 ✔ |
| 15 | 10.1038/s41586-022-05473-8 | Kurki MI 等, *Nature* 2023;613(7944):508-518 ✔ |
| 17 | 10.1038/s41588-020-0640-3 | Ishigaki K 等, *Nat Genet* 2020;52(7):669-679 ✔ |
| 19 | 10.1038/s41588-018-0307-5 | Liu M 等, *Nat Genet* 2019;51(2):237-244 ✔ |
| 37 | 10.1001/jama.2018.18179 | Choi SH 等, *JAMA* 2018;320(22):2354-2364 ✔ |

**46 条参考文献全部可核验**：无虚构、无错配、无重复、无未被引用项。

两个技术点记一下：
1. **核文献用 DOI 直查，不要依赖模糊检索**。CrossRef `query.bibliographic` 对带副标题的标题排序很差，
   Jaccard 相似度会把同一篇压到 0.46。有 DOI 就直查 `/works/{doi}`，没有才退到 `query.title`。
2. **author 数组里可能有 group author**（无 family 字段），取第一作者时要跳过空项，
   否则会误报"第一作者不符"（[19] GSCAN 就踩到：`aus[0]` 是空的集体作者）。

至此投稿包人工待办只剩 2 项：EM 作者姓名栏拆分、是否填 excluded reviewer。
"""

p = pathlib.Path(r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版"
                 r"\JAHA_v525_改稿留档\审读意见_20261026\修正记录_20261026.md")
t = p.read_text(encoding="utf-8")
if "6 条文献全部核验通过" in t:
    print("skip")
else:
    p.write_text(t + ADD, encoding="utf-8")
    print("revision log updated")

MEM = """

## 6 条文献用 DOI 全部核实（10-28 中午）

- 13/14/15/17/19/37 六条此前的"未匹配"是 CrossRef 模糊检索排序问题，**不是查无此文**。
  改用 `/works/{doi}` 直查，标题/第一作者/期刊/年/卷/起页六项全对。
- **46 条参考文献全部可核验**（40 条标题匹配 + 6 条 DOI 直查）。
- 方法论：有 DOI 一律直查；`author` 数组要跳过 group author（family 为空），否则误报第一作者不符。
- 投稿包人工待办降到 2 项。
"""

m = pathlib.Path(r"C:\Users\64915\WorkBuddy\2026-10-06-13-49-21\.workbuddy\memory\2026-10-27.md")
t2 = m.read_text(encoding="utf-8")
if "6 条文献用 DOI 全部核实" in t2:
    print("memory skip")
else:
    m.write_text(t2 + MEM, encoding="utf-8")
    print("memory updated")
