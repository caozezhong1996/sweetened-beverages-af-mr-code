# -*- coding: utf-8 -*-
import csv, os, pathlib, re, sys, io
from docx import Document
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
ROOT = pathlib.Path(r"C:\Users\64915\WorkBuddy\2026-10-06-13-49-21")
PKG = pathlib.Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")
A3 = pathlib.Path(r"C:\a3work")

def set_para(p, text):
    if not p.runs:
        p.add_run(text)
    else:
        for r in p.runs: r.text = ""
        p.runs[0].text = text

def replace_prefix(doc, prefix, text):
    hits = [p for p in doc.paragraphs if p.text.startswith(prefix)]
    assert len(hits) == 1, (prefix, len(hits))
    set_para(hits[0], text)

def replace_in_paras(doc, old, new, expected=1):
    hits = [p for p in doc.paragraphs if old in p.text]
    assert len(hits) == expected, (old, len(hits))
    for p in hits: set_para(p, p.text.replace(old, new))

# ---------- Supplement: S27 and S16 ----------
sup = Document(str(PKG / "Supplement.docx"))
records = list(csv.DictReader(open(A3 / "S27_regenerated.csv", encoding="utf-8")))
order = {"Nielsen":0, "FinnGen R13":1, "Yuan 2025":2}
expo_order = ["Sugar added to tea", "Sugar added to coffee", "Fizzy drink intake (SSB)", "Low-calorie drink intake (ASB)", "Artificial sweetener added to tea", "Coffee intake", "Tea intake"]
records.sort(key=lambda r:(order[r["outcome"]], expo_order.index(r["exposure"])))
t27 = next(t for t in sup.tables if "SNPs (kept)" in " ".join(c.text for c in t.rows[0].cells))
assert len(t27.rows) == 22

def f2(x): return f"{float(x):.2f}"
def fp(x):
    v=float(x)
    return "<0.001" if v<0.001 else f"{v:.3f}"
for row, rec in zip(t27.rows[1:], records):
    vals=[rec["outcome"],rec["exposure"],rec["n"],f"{f2(rec['OR'])} ({f2(rec['lo'])}–{f2(rec['hi'])})",fp(rec["p"]),rec["n_clean"],f"{f2(rec['OR_clean'])} ({f2(rec['lo_clean'])}–{f2(rec['hi_clean'])})",fp(rec["p_clean"])]
    for cell,val in zip(row.cells,vals): cell.text=val
note27 = ("Instruments were removed if they lay within 500 kb of any of 724 genome-wide-significant body-mass-index loci "
"(Neale lab UK Biobank field 21001), which removed 3–19 variants per exposure (median 5). All estimates are random-effects "
"inverse-variance-weighted. Coordinates were matched on GRCh37 throughout: Yuan 2025 outcome positions are GRCh38, so "
"instrument positions were taken from the GRCh37 harmonised exposure datasets, with direct, swapped and complementary-strand "
"alleles aligned explicitly. This post hoc robustness analysis was introduced during revision. Removing adiposity-locus "
"instruments reduced the between-source spread of the coffee estimates from 1.26–1.79 to 1.26–1.39: Nielsen 2018 gave 1.39 "
"(1.04–1.86; P = 0.028), Yuan 2025 gave 1.26 (0.90–1.75; P = 0.178), and FinnGen R13 gave 1.39 (0.94–2.04; P = 0.096). "
"Because the outcome sources are not mutually independent, no pooled estimate or pooled P value is reported. A placebo test "
"(2,000 random deletions of the same size per source) produced a between-source log-OR range as small as the observed one in "
"2.1% of replicates, arguing against convergence by random deletion alone. Residual estimates nevertheless remain compatible "
"with other pleiotropy and do not establish an adiposity-independent causal effect. No sweetened-beverage estimate became "
"significant under the same exclusion (all P ≥ 0.057).")
replace_prefix(sup, "Instruments were removed if they lay within 500 kb", note27)

# Remove unstable mediated proportions and rewrite S16 interpretation.
t16 = next(t for t in sup.tables if t.rows[0].cells[0].text == "Component" and any(r.cells[0].text == "Total effect" for r in t.rows[1:]))
for row in list(t16.rows)[1:]:
    if row.cells[0].text.startswith("Proportion mediated"):
        t16._tbl.remove(row._tr)
note16 = ("Network (two-step) mediation MR (Burgess et al., 2015; manuscript ref 25) was used only as an exploratory mechanistic probe. "
"Step 1 used the 17 of 34 coffee instruments represented in the HapMap-2-based Yengo 2018 BMI meta-analysis (GCST006900; "
"SD-standardised units, verified against FTO anchor variants). The implausibly large per-category Step 1 coefficient suggests "
"that adiposity-associated pleiotropic instruments, rather than a literal physiological mediation pathway, contribute strongly "
"to this estimate. Step 2 used 701 BMI instruments (P < 5 × 10⁻⁸) selected by 1-Mb window pruning; this is distance pruning, "
"not LD clumping, and residual linkage disequilibrium may make its confidence interval anti-conservative. Indirect effects used "
"the product method with delta-method standard errors; covariance between steps was ignored. Because the total and indirect "
"estimates are unstable and their ratio is not interpretable, mediated proportions are not reported. The direct estimate and "
"all indirect estimates are exploratory and do not establish mediation. A sensitivity analysis repeated Step 1 against the "
"full-coverage Neale lab UK Biobank BMI GWAS (field 21001; 33 of 34 instruments), yielding 0.747 SD at 4.8 kg/m² per SD; the "
"same interpretive limitation applies.")
replace_prefix(sup, "Network (two-step) mediation MR", note16)
sup.save(str(PKG / "Supplement.docx"))

# ---------- Manuscript ----------
man = Document(str(PKG / "Manuscript.docx"))
abstract = {
"Background:": "Background: Milk tea is not directly instrumented in genome-wide association studies (GWAS). We examined whether genetically proxied intake of related sweetened-beverage components is causally associated with atrial fibrillation (AF).",
"Methods and Results:": "Methods and Results: Seven beverage phenotypes were instrumented in UK Biobank (N = 64,949–447,485). AF data came from Nielsen 2018 (primary), FinnGen R13, UK Biobank-free Yuan 2025 (192,851 cases) and BioBank Japan. No sweetened-beverage exposure showed a causal association (European meta-analytic ORs 0.82–0.97, P ≥ 0.06; UK Biobank-free 0.76–1.04, P ≥ 0.083). Coffee was associated in primary analyses, but excluding adiposity-locus instruments attenuated estimates to 1.26–1.39; the UK Biobank-free estimate was 1.26 (0.90–1.75), P = 0.178. Sweetened-beverage traits showed positive genetic correlations with AF (rg = 0.24–0.31; q < 0.05). Caffeine and paraxanthine instruments were null; theobromine's nominal inverse association did not survive correction.",
"Conclusions:": "Conclusions: Genetically proxied sweetened-beverage intake showed no evidence of a causal association with AF. Per-category OR upper bounds ranged from 1.01 to 1.17, but observational-magnitude effects were not excluded. Coffee findings were not robust across sensitivity analyses. Component-level nulls cannot certify composite milk-tea safety; direct studies remain needed."
}
for prefix,text in abstract.items(): replace_prefix(man,prefix,text)
replace_prefix(man,"• No caffeine-handling effect was detected", "• No caffeine-handling effect was detected, although subgroup precision was limited and all three caffeine-window instruments lay near BMI loci; adiposity-locus exclusion reduced the coffee estimates to 1.26–1.39, with no consistent residual association across sources; colocalization occurred at FTO, not at caffeine-metabolism loci.")
replace_prefix(man,"• The 95% confidence upper bounds exclude", "• Per-category OR upper bounds ranged from 1.01 to 1.17 across exposures, but observational-magnitude effects were not excluded. Component-level nulls cannot certify the safety of composite milk-tea beverages; direct prospective studies of milk tea intake in East Asian cohorts remain needed.")
med = ("Two-step mediation MR was exploratory and cannot identify direction at these loci. Coffee instruments were positively associated with BMI "
"(β = 0.82 SD; P = 0.007), an implausibly large per-category physiological effect that suggests substantial adiposity-associated pleiotropy. "
"The BMI-mediated indirect estimate was 0.281 (95% CI 0.073–0.490), and the difference-method direct estimate was null (OR 0.955, 0.705–1.292); "
"the MVMR estimate was likewise imprecise (OR 0.82, 0.65–1.04). Because the total and indirect estimates are unstable, mediated proportions are "
"not reported and these analyses do not establish mediation (Table S16). The MRlap overlap-corrected estimate did not differ measurably from the "
"observed estimate (difference P = 0.07; Table S17), but this comparison does not exclude residual overlap or other bias. A second coffee GWAS "
"from the same UK Biobank resource gave a concordant, non-significant estimate (OR 1.18, 0.93–1.50; P = 0.166; Table S19) and was treated as a "
"phenotype-definition sensitivity analysis, not independent replication. The Neale BMI sensitivity yielded the same implausibly large Step 1 "
"pattern (0.75 SD) and the same interpretive limitation.")
replace_prefix(man,"Two-step mediation MR was",med)
adipo = ("To separate the coffee signal from the adiposity it tracks, each exposure was re-estimated after removing every instrument lying within "
"500 kb of one of 724 genome-wide-significant BMI loci (Table S27). This removed 15–17 of the 30–34 coffee instruments, including rs1421085 "
"at FTO and rs13387939 at TMEM18, the two variants with the largest individual Wald ratios against AF in Yuan 2025 (OR 9.95 and 10.67). "
"The between-source spread decreased from 1.26–1.79 to 1.26–1.39 (log-odds range 0.348 to 0.099). Across 2,000 random deletions of the "
"same size per source, 2.1% produced an equally small range, arguing against random-deletion convergence alone. After exclusion the estimates "
"were 1.39 (1.04–1.86; P = 0.028) in Nielsen 2018, 1.26 (0.90–1.75; P = 0.178) in Yuan 2025 and 1.39 (0.94–2.04; P = 0.096) in FinnGen "
"R13. Because these outcome sources overlap, they were not pooled. Only Nielsen 2018 retained a nominal association; residual estimates were "
"inconsistent and may reflect other pleiotropy rather than an adiposity-independent causal effect. No sweetened-beverage estimate became "
"significant under the same exclusion (all P ≥ 0.057).")
replace_prefix(man,"To separate the coffee signal",adipo)
principal = ("In this two-sample and multivariable Mendelian randomization study using four European-ancestry AF sources, including the largest "
"public one (192,851 cases), genetically proxied consumption of sweetened beverages showed no evidence of a causal association with atrial "
"fibrillation. Per-category OR upper bounds ranged from 1.01 to 1.17, but observational-magnitude effects were not excluded. Three nominal "
"IVW signals emerged, but none met the robustness criteria: the inverse association for sugar added to coffee failed to replicate; the inverse "
"association for sugar added to tea in FinnGen R13 was attenuated in the meta-analysis; and the recurring coffee association was linked to "
"adiposity-locus instruments. Removing those instruments reduced the between-source spread from 1.26–1.79 to 1.26–1.39, with only Nielsen "
"2018 retaining a nominal residual association; the overlapping outcome estimates were not pooled. East Asian estimates were imprecise and "
"contextual. The positive lifestyle control provided directional context rather than validation of analytical sensitivity.")
replace_prefix(man,"In this two-sample and multivariable Mendelian randomization study",principal)
replace_in_paras(man,"Our own estimate is positive but non-robust, with an adiposity-excluded residual of about 1.4 that remains unexplained.","Our own estimate is positive but non-robust; after adiposity-locus exclusion, only Nielsen 2018 retained a nominal association, whereas FinnGen R13 and the UK Biobank-free Yuan 2025 estimate included the null.")
old = "The instrument-level analysis points the same way: FTO rs1421085 and TMEM18 rs13387939 produced the two largest Wald ratios against AF, and removing adiposity-locus variants collapsed the between-source spread while leaving residual associations of 1.39 (1.04–1.86; P = 0.028) in Nielsen 2018 and 1.48 (1.01–2.18; P = 0.044) in Yuan 2025; only FinnGen R13 became non-significant (P = 0.096). Adiposity therefore does not fully account for the coffee signal, and an adiposity-independent effect cannot be excluded."
new = "The instrument-level analysis points the same way: FTO rs1421085 and TMEM18 rs13387939 produced the two largest Wald ratios against AF. Removing adiposity-locus variants reduced the between-source spread; residual estimates were 1.39 (1.04–1.86; P = 0.028) in Nielsen 2018, 1.26 (0.90–1.75; P = 0.178) in Yuan 2025 and 1.39 (0.94–2.04; P = 0.096) in FinnGen R13. Thus only Nielsen 2018 retained a nominal residual association, and an adiposity-independent effect remains uncertain."
replace_in_paras(man,old,new)
mechanism = ("The BMI positive control (OR 1.47 per SD) reaffirms adiposity as an established causal determinant of AF and a plausible source of "
"confounding or pleiotropy, but the present design does not test how much of the observational SSB–AF association it explains. Two-step mediation "
"MR was exploratory; the implausible Step 1 magnitude and residual linkage disequilibrium in Step 2 preclude a literal mediation interpretation. "
"FTO colocalization provides locus-level corroboration rather than proof of an adiposity-mediated pathway. The reduction in between-source spread "
"after adiposity-locus exclusion (1.26–1.79 to 1.26–1.39), together with the placebo test (2.1% of 2,000 random exclusions achieved an equally "
"small spread), argues against simple random-deletion convergence. However, only Nielsen 2018 retained a nominal residual association, and no "
"pooled estimate was calculated because the outcome sources overlap. Positive genetic correlations of SSB and ASB intake with AF alongside null "
"MR estimates are compatible with shared heritable architecture; they do not establish that weight management should take precedence over "
"beverage-specific advice [1].")
replace_prefix(man,"The BMI positive control",mechanism)
replace_prefix(man,"Genetically proxied consumption of sweetened beverages", "Genetically proxied consumption of sweetened beverages—including the sugar component of tea- and coffee-based drinks, the closest available proxy for milk-tea-type beverages—showed no evidence of a causal association with atrial fibrillation in European or East Asian populations. Per-category OR upper bounds ranged from 1.01 to 1.17, but observational-magnitude effects and milk-tea exposure itself remain untested. The source of the modest observational associations is unresolved. Coffee findings were not robust across sensitivity analyses, with no consistent residual association after adiposity-locus exclusion; direct investigation of milk tea consumption in prospective East Asian cohorts remains needed.")
man.save(str(PKG / "Manuscript.docx"))

# ---------- Highlights ----------
hl = Document(str(PKG / "Highlights.docx"))
replace_in_paras(hl,"Null estimates exclude effects above their 95% confidence upper bounds (about 17% for most exposures), but not observational-magnitude effects.","Per-category OR upper bounds ranged from 1.01 to 1.17, but observational-magnitude effects were not excluded.")
replace_in_paras(hl,"Adiposity-locus instruments explain the between-source spread of the coffee estimate (1.26–1.79 to 1.39–1.48), not the whole signal (residual OR 1.41).","Adiposity-locus exclusion reduced coffee estimates to 1.26–1.39; no consistent residual association remained across sources.")
hl.save(str(PKG / "Highlights.docx"))

# ---------- Cover letter ----------
cl = Document(str(PKG / "Cover_Letter.docx"))
cover = ("Using public genome-wide association study (GWAS) summary statistics, we instrumented seven beverage phenotypes in UK Biobank "
"(N = 64,949–447,485) and estimated their effects on AF in four European-ancestry sources, with AFGen 2018 as a sensitivity source "
"and BioBank Japan as an East Asian contextual arm. No sweetened-beverage exposure showed evidence of a causal association with AF; "
"per-category OR upper bounds ranged from 1.01 to 1.17, but observational-magnitude effects were not excluded. The recurring coffee "
"signal failed the pre-specified robustness criteria. Multivariable estimates were exploratory because of weak conditional instruments; "
"colocalization occurred at FTO rather than caffeine-metabolism loci, and CAUSE did not distinguish correlated pleiotropy from causation. "
"Removing variants within 500 kb of BMI loci reduced between-source spread from 1.26–1.79 to 1.26–1.39; only Nielsen 2018 retained a "
"nominal residual association, and no pooled estimate was calculated because the outcome sources overlap. Biomarker-level MR of plasma "
"caffeine, paraxanthine and theobromine returned null estimates. Cross-trait LD score regression showed positive genetic correlations "
"between sweetened-beverage traits and AF despite null MR estimates, illustrating that shared genetic architecture does not imply causation.")
replace_prefix(cl,"Using public genome-wide association study",cover)
cl.save(str(PKG / "Cover_Letter.docx"))
print("S27, S16 and all narrative files updated")
