# -*- coding: utf-8 -*-
import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
p = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\README_投稿包.md"
t = open(p, encoding="utf-8").read()
t = t.replace(
    "# JAHA 投稿包 · 奶茶房颤MR · v5.2.4（2026-10-18，外部三审稿人报告修订完成，可投稿）",
    "# JAHA 投稿包 · 奶茶房颤MR · v5.2.5（2026-10-24，补引 [47] 后终审通过，可投稿）")
t = t.replace("摘要 249 词、NAA、Clinical Perspective、正文 5997 词、46 条参考文献",
              "摘要 249 词、NAA、Clinical Perspective、正文 5997 词、47 条参考文献")
t = t.replace("引用 1..46 全覆盖、46 条参考文献", "引用 1..47 全覆盖、47 条参考文献")
t += """
- v5.2.5 补引（2026-10-24）：新增 ref 47 = Zheng J, et al. Association of coffee consumption and caffeine metabolism with arrhythmias and cardiac morphology (Heart Rhythm 2025;22(9):e618-e630; PMID 39613205)——Discussion 咖啡段三阶段收敛句后一句引用（"morphology- and metabolite-based analyses concord [47]"），方向一致属收敛证据；同段三处压缩实现词数中性（正文保持 5997）。校验脚本期望值同步更新（1..47、47 entries、KEY 串）；verify_jaha.py ALL PASSED（摘要 249 / 正文 5997）。
"""
open(p, "w", encoding="utf-8").write(t)
print("README 已更新为 v5.2.5")
