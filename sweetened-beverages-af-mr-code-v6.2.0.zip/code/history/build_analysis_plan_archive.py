import io
import sys
from pathlib import Path
from docx import Document
from docx.shared import Pt, Cm

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
OUT = Path(r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版\JAHA_v525_改稿留档\审读意见_20261028\Analysis_plan_and_deviations_archive_20261028.docx")
doc = Document()
sec = doc.sections[0]
sec.left_margin = Cm(2.3)
sec.right_margin = Cm(2.3)
doc.styles["Normal"].font.name = "Arial"
doc.styles["Normal"].font.size = Pt(10)
doc.core_properties.title = "Analysis plan and deviations archive"
doc.core_properties.author = "Cao Zezhong"
doc.core_properties.comments = "Retrospectively assembled on 2026-10-28; not a prospective registration"

doc.add_heading("Analysis plan and deviations archive", level=0)
p = doc.add_paragraph()
p.add_run("Genetically Proxied Sweetened Beverage Intake and Atrial Fibrillation: A Two-Sample and Multivariable Mendelian Randomization Study").bold = True
doc.add_paragraph("Archive created: 2026-10-28")
doc.add_paragraph("Status: retrospectively assembled documentation; not a prospective registration and not a DOI-bearing protocol")

doc.add_heading("Purpose and evidentiary boundary", level=1)
doc.add_paragraph(
    "No standalone, verifiably pre-existing analysis-plan file was found in the migration package or the working directory. "
    "This document therefore records the analysis structure stated in the current manuscript and separates analyses described as part of the written plan from revision-stage additions. "
    "It does not prove the date on which any decision was made and must not be described as prospective registration, pre-registration, or an independently timestamped original protocol. "
    "No external upload has been performed and no DOI has been assigned."
)

doc.add_heading("Analysis structure stated in the manuscript", level=1)
rows = [
    ("Primary outcome", "Nielsen 2018 AF GWAS, 60,620 cases", "Primary"),
    ("Replication outcomes", "FinnGen R13 and UK Biobank-free Yuan 2025", "Replication; Yuan added after public release"),
    ("European meta-analysis", "Nielsen 2018 + FinnGen R13 only", "Specified in the manuscript analysis plan"),
    ("Exposures", "Seven beverage phenotypes in UK Biobank", "Primary exposure family"),
    ("Instrument thresholds", "P < 5×10⁻⁸ for coffee/tea; P < 5×10⁻⁶ for five beverage sub-phenotypes", "Relaxed threshold disclosed"),
    ("Primary estimator", "Random-effects IVW", "Primary"),
    ("Multiplicity", "Seven European meta-analytic IVW tests, Benjamini–Hochberg q = 0.05", "Primary family"),
    ("Sensitivity estimators", "MR-Egger, weighted median, weighted mode, MR-PRESSO, contamination mixture, MR-RAPS, CAUSE, MRlap", "Supportive"),
    ("Directionality", "Steiger testing/filtering and reverse MR", "Supportive"),
    ("Multivariable analysis", "Coffee, sugar added to tea and BMI; conditional F reported", "Exploratory because conditional F < 10"),
    ("Positive controls", "BMI and alcoholic drinks per week", "Directional calibration, not proof of sensitivity"),
    ("Negative outcome control", "Atrioventricular block", "Failed for sugar added to tea"),
    ("Colocalization", "CYP1A1–CYP1A2, AHR and FTO; default posteriors; FTO p12 scan", "Locus-level evidence, not pathway proof"),
    ("Mediation", "Two-step coffee–BMI–AF product method", "Exploratory; direction not identifiable"),
    ("Adiposity-locus exclusion", "Remove instruments within 500 kb of 724 BMI loci", "Post hoc revision-stage robustness analysis"),
    ("East Asian analysis", "BioBank Japan with European-derived instruments", "Contextual, not independent ancestry-specific replication"),
    ("Biomarker analysis", "Plasma caffeine, paraxanthine and theobromine", "Supportive, low-powered"),
]
table = doc.add_table(rows=1, cols=3)
table.style = "Table Grid"
for i, text in enumerate(("Analysis", "Specification", "Status / interpretation")):
    table.rows[0].cells[i].text = text
for row in rows:
    cells = table.add_row().cells
    for i, text in enumerate(row):
        cells[i].text = text
for row in table.rows:
    for cell in row.cells:
        for p in cell.paragraphs:
            for run in p.runs:
                run.font.size = Pt(8.5)

doc.add_heading("Revision-stage additions and deviations", level=1)
for text in [
    "Yuan 2025 was added after its summary statistics became public; it is reported alongside, not within, the Nielsen + FinnGen meta-analysis.",
    "The primary AF source was upgraded from AFGen 2018 to Nielsen 2018; AFGen remains a sensitivity source and is not pooled with Nielsen.",
    "The adiposity-locus exclusion, the three-locus colocalization probe, and the coffee–BMI mediation probe were performed during revision and are post hoc.",
    "The caffeine-pathway subgroup is descriptive. All three caffeine-window instruments lie near BMI loci, and Yuan recovered only one of the three; no pathway-absence claim is made.",
    "The study was not registered. Statements that criteria were defined before analysis are author statements, not independently verified timestamps.",
]:
    doc.add_paragraph(text, style="List Bullet")

doc.add_heading("Recommended use of this archive", level=1)
doc.add_paragraph(
    "This file may be uploaded to Zenodo or OSF as a transparent, retrospectively dated supplement to the code archive. "
    "After upload, record the new DOI and the exact upload date in the manuscript Data Availability statement. "
    "Do not describe the DOI as evidence of prospective registration. If an earlier protocol is subsequently found, archive that original file separately with its own version history."
)

doc.save(str(OUT))
print(OUT)
