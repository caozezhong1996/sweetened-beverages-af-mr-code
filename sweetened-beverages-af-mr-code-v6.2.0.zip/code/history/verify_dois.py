# -*- coding: utf-8 -*-
"""Resolve candidate DOIs directly and compare titles (exact, not fuzzy)."""
import io
import json
import re
import sys
import time
import urllib.request

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

CAND = {
    13: "10.1038/s41588-018-0171-3",
    14: "10.1038/s41588-018-0133-9",
    15: "10.1038/s41586-022-05473-8",
    17: "10.1038/s41588-020-0640-3",
    19: "10.1038/s41588-018-0307-5",
    37: "10.1001/jama.2018.18179",
}

for n, doi in CAND.items():
    try:
        req = urllib.request.Request(f"https://api.crossref.org/works/{doi}",
                                     headers={"User-Agent": "refcheck/5 (mailto:caozezhong1996@163.com)"})
        with urllib.request.urlopen(req, timeout=25) as r:
            m = json.load(r)["message"]
        title = (m.get("title") or [""])[0]
        jr = (m.get("container-title") or [""])[0]
        yr = (m.get("issued", {}).get("date-parts") or [[None]])[0][0]
        au = m.get("author") or []
        first = f"{au[0].get('family','')} {au[0].get('given','')[:1]}" if au else "?"
        print(f"[{n}] {title}")
        print(f"     {first} et al. {jr} {yr}  vol {m.get('volume')}  doi {doi}")
    except Exception as e:
        print(f"[{n}] ERR {type(e).__name__}: {e}  (doi {doi})")
    time.sleep(0.4)
