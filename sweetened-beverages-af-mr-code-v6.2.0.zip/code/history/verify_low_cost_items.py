import io
import re
import sys
from pathlib import Path
from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
PKG = Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")
ARC = Path(r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版\JAHA_v525_改稿留档\审读意见_20261028")
man = Document(str(PKG / "Manuscript.docx"))
sup = Document(str(PKG / "Supplement.docx"))
mt = "\n".join(p.text for p in man.paragraphs)
st = "\n".join(p.text for p in sup.paragraphs)

checks = [
    ("Manuscript cites overlap matrix", "overlap map is provided in Table S28" in mt),
    ("Manuscript cites caffeine diagnostics", "Table S29" in mt),
    ("Yuan correction documented", "3 October 2025 Author Correction" in mt and "16:8811" in mt),
    ("All three loci prior scans claimed in Methods", "prior sensitivity at all three loci" in mt),
    ("Caffeine R2/F/MDE in main text", "0.285% of exposure variance" in mt and "1.53 and 2.10" in mt),
    ("S28 title", "Table S28. Cohort-level sample-overlap map" in st),
    ("S29 title", "Table S29. Caffeine-pathway instrument strength" in st),
    ("S13 no unsupported p12-insensitivity", "insensitive to p12" not in st),
    ("S13 full posterior caption", "Full colocalization posterior probabilities" in st),
    ("Contents includes S28/S29", "Table S28 cohort-level" in st and "Table S29 caffeine-pathway" in st),
]
for label, ok in checks:
    print(("PASS " if ok else "FAIL ") + label)

s28 = next(t for t in sup.tables if t.rows[0].cells[0].text == "Dataset pair")
print("PASS S28 rows" if len(s28.rows) == 14 else f"FAIL S28 rows {len(s28.rows)}")
s29 = [t for t in sup.tables if t.rows[0].cells[0].text == "Outcome" and len(t.rows) == 4 and t.rows[0].cells[1].text in ("Method", "Caffeine-window SNPs near BMI loci / recovered")]
print("PASS S29 two tables" if len(s29) == 2 else f"FAIL S29 table count {len(s29)}")
main29 = next(t for t in s29 if t.rows[0].cells[1].text == "Method")
expected = [
    ["Nielsen 2018", "IVW", "3", "0.2850", "1.03 (0.76-1.38)", "0.861", "1.53"],
    ["FinnGen R13", "IVW", "3", "0.2850", "1.23 (0.73-2.07)", "0.436", "2.10"],
    ["Yuan 2025", "Wald ratio", "1", "0.0074", "0.60 (0.24-1.50)", "0.27", "3.74"],
]
for row, exp in zip(main29.rows[1:], expected):
    cells = [c.text for c in row.cells]
    got = [cells[0], cells[1], cells[2], cells[3], cells[5], cells[6], cells[7]]
    print("PASS values " + exp[0] if got == exp else f"FAIL values {exp[0]}: {got}")
full13 = next(t for t in sup.tables if t.rows[0].cells[0].text == "Locus" and t.rows[0].cells[1].text == "Outcome" and t.rows[0].cells[2].text == "SNPs")
print("PASS S13 four full-posterior rows" if len(full13.rows) == 5 else f"FAIL S13 rows {len(full13.rows)}")
prior13 = next(t for t in sup.tables if t.rows[0].cells[0].text == "Locus" and len(t.rows[0].cells) > 2 and t.rows[0].cells[2].text == "p12")
print("PASS S13 all-locus prior grid" if len(prior13.rows) == 21 else f"FAIL S13 prior rows {len(prior13.rows)}")

plan = Document(str(ARC / "Analysis_plan_and_deviations_archive_20261028.docx"))
pt = "\n".join(p.text for p in plan.paragraphs)
print("PASS retrospective boundary" if "not a prospective registration" in pt and "No external upload has been performed" in pt else "FAIL retrospective boundary")
