# -*- coding: utf-8 -*-
"""Second verification batch."""
import io
import re
import sys

from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

PKG = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013"
MS = Document(PKG + r"\Manuscript.docx")
SUP = Document(PKG + r"\Supplement.docx")
mp = [p.text.strip() for p in MS.paragraphs if p.text.strip()]
mf = "\n".join(mp)

print("=== Table 1 全部行（暴露 / 欧洲 meta OR / SNP 数）===")
t1 = MS.tables[0]
hdr = [c.text.strip() for c in t1.rows[0].cells]
print("  表头:", " | ".join(h[:22] for h in hdr))
for row in t1.rows[1:]:
    c = [x.text.strip() for x in row.cells]
    print("  ", " | ".join(x[:30] for x in c))

print("\n=== 补充材料：Table S25 是否有 F 列 ===")
for tb in SUP.tables:
    h = [c.text.strip() for c in tb.rows[0].cells]
    if any("F" in x for x in h) and any("Metabolite" in x or "caffeine" in x.lower() for x in h):
        print("  命中表头:", h); break
else:
    # 找 S25 表：列里含 Caffeine/Paraxanthine
    for tb in SUP.tables:
        txt = " ".join(c.text for r in tb.rows for c in r.cells)
        if "Paraxanthine" in txt and "Theobromine" in txt:
            print("  S25 表头:", [c.text.strip() for c in tb.rows[0].cells])
            for r in tb.rows[:6]:
                print("   ", " | ".join(c.text.strip()[:22] for c in r.cells))
            break

print("\n=== Table S16 直接效应 ===")
for tb in SUP.tables:
    txt = " ".join(c.text for r in tb.rows for c in r.cells)
    if "0.0464" in txt or ("direct" in txt.lower() and "indirect" in txt.lower()):
        print("  表头:", [c.text.strip() for c in tb.rows[0].cells])
        for r in tb.rows[:8]:
            print("   ", " | ".join(c.text.strip()[:24] for c in r.cells))
        break
else:
    print("  未定位到含 0.0464 的表")

print("\n=== C7 'failed every pre-specified consistency criterion' ===")
for m in re.finditer(r"[^.]*failed every[^.]*\.", mf):
    print("  正文:", m.group(0)[:240])
print("  Methods 是否列举判据:", "consistency criteri" in mf.lower())

print("\n=== docx 元数据 ===")
for name in ("Manuscript", "Supplement", "Cover_Letter", "Highlights"):
    d = Document(PKG + "\\" + name + ".docx")
    cp = d.core_properties
    print(f"  {name:<14} author={cp.author!r} title={cp.title!r} comments={cp.comments!r} created={cp.created}")

print("\n=== Declarations 小节 ===")
for p in mp:
    if re.match(r"^(Author Contributions|Acknowledg|Sources of Funding|Disclosures|Data Availability|Declaration)", p):
        print("  -", p[:90])
