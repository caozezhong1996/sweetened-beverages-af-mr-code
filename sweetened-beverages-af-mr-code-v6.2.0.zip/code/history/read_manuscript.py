# -*- coding: utf-8 -*-
"""快速提取手稿关键段落：标题、摘要、结论，用于核对审稿意见针对性。"""
import sys
from docx import Document

path = r"C:\Users\64915\Desktop\EJPC投稿包_奶茶房颤MR_v4.5.6_20260826\01_手稿_Manuscript\Manuscript_v456_Sweetened_Beverages_AF_MR.docx"
doc = Document(path)

paras = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
print("总段落数:", len(paras))
print("=" * 70)
print("【前 12 段（标题/作者/摘要开头）】")
for i, p in enumerate(paras[:12]):
    print(f"[{i}] {p[:300]}")
print("=" * 70)
print("【含 conclusion / conclusion 的段落】")
for i, p in enumerate(paras):
    low = p.lower()
    if "conclusion" in low or "conclusion" in low:
        print(f"[{i}] {p[:500]}")
        print("-" * 40)
print("=" * 70)
print("【含 'not causally' / 'no causal' / 'causal' 的段落（前10条）】")
cnt = 0
for i, p in enumerate(paras):
    if "causal" in p.lower():
        print(f"[{i}] {p[:400]}")
        print("-" * 40)
        cnt += 1
        if cnt >= 10:
            break
