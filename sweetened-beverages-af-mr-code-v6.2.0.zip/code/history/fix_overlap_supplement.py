import io
import sys
from pathlib import Path
from docx import Document

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
PKG = Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")


def replace(name, old, new):
    path = PKG / name
    doc = Document(str(path))
    hits = 0
    for p in doc.paragraphs:
        if old in p.text:
            full = p.text.replace(old, new)
            for run in p.runs:
                run.text = ""
            p.runs[0].text = full
            hits += 1
    assert hits == 1, (name, old, hits)
    doc.save(str(path))
    print("PASS", name, old[:70])


replace(
    "Supplement.docx",
    "quantitatively excluding material sample-overlap bias",
    "showing no detected sample-overlap bias within the precision of these estimates",
)
replace(
    "Supplement.docx",
    "jointly excluding material bias from sample overlap, winner's curse and weak instruments",
    "showing no detectable correction for these sources of bias, without excluding residual bias",
)
replace(
    "Manuscript.docx",
    "indicating negligible sample-overlap bias",
    "showing no detectable sample-overlap bias at this precision",
)
