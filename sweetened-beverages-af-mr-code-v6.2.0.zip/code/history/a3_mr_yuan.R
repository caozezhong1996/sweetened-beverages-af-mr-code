# A3 step B: harmonise the Yuan 2025 outcome (GCST90624413, UKB-free) against
# each of the 7 beverage exposures and run the same estimator panel used for the
# primary analyses (IVW-FE, IVW-RE, weighted median, MR-Egger, MR-RAPS, MR-PRESSO).
suppressMessages({
  library(data.table); library(TwoSampleMR); library(mr.raps); library(MRPRESSO)
})

RES <- "C:/a3work"   # ASCII staging: R cannot open the Chinese-char path
OUT <- "C:/a3work/yuan2025_mr.csv"

yuan <- fread(file.path(RES, "yuan2025_instruments.tsv"))
setnames(yuan, c("ea.out", "oa.out"), c("effect_allele.outcome", "other_allele.outcome"),
         skip_absent = TRUE)
if (!"other_allele.outcome" %in% names(yuan)) setnames(yuan, "oa.out", "other_allele.outcome")
if (!"effect_allele.outcome" %in% names(yuan)) setnames(yuan, "ea.out", "effect_allele.outcome")

exposures <- c("Sugar_added_to_tea", "Sugar_added_to_coffee", "Fizzy_drink_intake_SSB",
               "Low_calorie_drink_intake_ASB", "Artificial_sweetener_added_to_tea",
               "Coffee_intake", "Tea_intake")
label <- c(Sugar_added_to_tea = "Sugar added to tea",
           Sugar_added_to_coffee = "Sugar added to coffee",
           Fizzy_drink_intake_SSB = "Fizzy drinks (SSB)",
           Low_calorie_drink_intake_ASB = "Low-calorie drinks (ASB)",
           Artificial_sweetener_added_to_tea = "Sweetener added to tea",
           Coffee_intake = "Coffee intake", Tea_intake = "Tea intake")

rows <- list()
for (e in exposures) {
  expo <- fread(file.path(RES, sprintf("dat_%s_ebi_a_GCST006414.csv", e)))
  if ("mr_keep" %in% names(expo)) expo <- expo[mr_keep %in% c(TRUE, "TRUE")]
  ex <- format_data(as.data.frame(expo), type = "exposure",
                    snp_col = "SNP", beta_col = "beta.exposure", se_col = "se.exposure",
                    effect_allele_col = "effect_allele.exposure",
                    other_allele_col = "other_allele.exposure",
                    eaf_col = "eaf.exposure", pval_col = "pval.exposure")
  yo <- yuan[exposure == e]
  if (nrow(yo) == 0) { cat("!! no outcome rows for", e, "\n"); next }
  out <- format_data(as.data.frame(yo), type = "outcome",
                     snp_col = "SNP", beta_col = "beta.out", se_col = "se.out",
                     effect_allele_col = "effect_allele.outcome",
                     other_allele_col = "other_allele.outcome",
                     eaf_col = "eaf.out", pval_col = "pval.out")

  d <- harmonise_data(ex, out, action = 2)
  d <- d[d$mr_keep %in% c(TRUE, "TRUE"), ]
  if (nrow(d) < 3) { cat("!! too few SNPs for", e, ":", nrow(d), "\n"); next }

  res <- mr(d, method_list = c("mr_ivw", "mr_ivw_mre", "mr_weighted_median",
                               "mr_egger_regression"))
  add <- function(method, b, se, p, n) {
    rows[[length(rows) + 1]] <<- data.table(
      exposure = label[[e]], method = method, nsnp = n,
      b = b, se = se, p = p, OR = exp(b),
      lo = exp(b - 1.96 * se), hi = exp(b + 1.96 * se))
  }
  for (i in seq_len(nrow(res))) add(res$method[i], res$b[i], res$se[i], res$pval[i], res$nsnp[i])

  raps <- tryCatch({
    f <- mr.raps.mle(b_exp = d$beta.exposure, se_exp = d$se.exposure,
                     b_out = d$beta.outcome, se_out = d$se.outcome,
                     over.dispersion = TRUE, loss.function = "tukey")
    c(f$beta.hat, f$beta.se, f$beta.p.value)
  }, error = function(x) c(NA, NA, NA))
  add("MR-RAPS", raps[1], raps[2], raps[3], nrow(d))

  pr <- tryCatch({
    set.seed(20261027)
    suppressMessages(p <- mr_presso(BetaOutcome = "beta.outcome", BetaExposure = "beta.exposure",
                                    SdOutcome = "se.outcome", SdExposure = "se.exposure",
                                    OUTCOME = "outcome", EXPOSURE = "exposure",
                                    data = as.data.frame(d), NbDistribution = 2000,
                                    SignifThreshold = 0.05))
    c(p$`Main MR results`$`Causal Estimate`[1], p$`Main MR results`$`Sd`[1],
      p$`Main MR results`$`P-value`[1], p$`MR-PRESSO results`$`Global Test`$`P-value`)
  }, error = function(x) c(NA, NA, NA, NA))
  add("MR-PRESSO", pr[1], pr[2], pr[3], nrow(d))
  rows[[length(rows) + 1]] <- data.table(exposure = label[[e]], method = "MR-PRESSO global test",
    nsnp = nrow(d), b = NA, se = NA, p = pr[4], OR = NA, lo = NA, hi = NA)

  q <- mr_heterogeneity(d, method_list = "mr_ivw")
  ivw <- res[res$method == "Inverse variance weighted", ]
  cat(sprintf("%-24s n=%2d  IVW OR=%.2f (%.2f-%.2f) P=%.3g | RE P=%.3g | RAPS P=%.3g | Q P=%.3g\n",
              label[[e]], nrow(d), exp(ivw$b[1]), exp(ivw$b[1] - 1.96 * ivw$se[1]),
              exp(ivw$b[1] + 1.96 * ivw$se[1]), ivw$pval[1],
              res$pval[res$method == "Inverse variance weighted (multiplicative random effects)"][1],
              raps[3], q$Q_pval[1]))
}

if (!length(rows)) stop("no results produced")
dt <- rbindlist(rows, fill = TRUE)
fwrite(dt, OUT)
cat("\nwritten:", OUT, "\n")
