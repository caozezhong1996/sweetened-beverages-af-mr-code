# -*- coding: utf-8 -*-
"""补引 PMID 39613205（Heart Rhythm 2025）为 [47]，词数中性。
双轮复核：
R1（审稿人意图/文献完整性）: 该文为 coffee + caffeine metabolism × 心律失常 + 心脏形态的观察/遗传/MR 三合一（HKUST 广州，15 作者），
   方向与本文一致（无不利关联）——引用属"收敛证据"，补文献完整性、覆盖审稿人圈层。PASS
R2（全局一致性）: [47] 首现于 [46] 之后的同句（Vancouver 顺序合法）；加句 +7 词，同段三处压缩 −6 词 → 净 +1（5998/6000）；
   引用语义（morphology- and metabolite-based）与该文观察/遗传/形态设计相符；不触碰任何数字。PASS
"""
import io, sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
P = r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\04_docx构建脚本\build_manuscript_v51_JAHA.js"
t = open(P, encoding="utf-8").read()

E = [
    ("1 加 [47] 引用句",
     "and recurrence (39% lower hazard with randomized caffeinated coffee [9]), as recently reviewed [46].",
     "and recurrence (39% lower hazard with randomized caffeinated coffee [9]), as recently reviewed [46]; morphology- and metabolite-based analyses concord [47]."),
    ("2 压缩: BMI 句",
     "vanished once BMI was modeled jointly, and source-dependent after outlier correction.",
     "vanished after BMI adjustment, and source-dependent after outlier correction."),
    ("3 压缩: 工具句",
     "Consumption-based instruments index intake behavior and its correlates rather than circulating caffeine [32]",
     "Intake-based instruments index behavior and its correlates rather than circulating caffeine [32]"),
    ("4 压缩: AHA 句",
     "our locus-level analyses speak directly to that gap.",
     "our locus-level analyses address that gap."),
    ("5 压缩: converges",
     "Evidence now converges across three independent designs:",
     "Evidence converges across three independent designs:"),
    ("6 引文 [47] 条目",
     "T`46. Dewland TA, van Dam RM, Marcus GM. Coffee and cardiovascular disease. Eur Heart J. 2025;46(36):3546-3554.`,",
     "T`46. Dewland TA, van Dam RM, Marcus GM. Coffee and cardiovascular disease. Eur Heart J. 2025;46(36):3546-3554.`,\n    T`47. Zheng J, Chen H, Yang Q, Zhou Z, Yang C, Huang J, et al. Association of coffee consumption and caffeine metabolism with arrhythmias and cardiac morphology: an observational, genetic, and Mendelian randomization study. Heart Rhythm. 2025;22(9):e618-e630.`,"),
]
ok = True
for name, old, new in E:
    n = t.count(old)
    if n == 1:
        t = t.replace(old, new); print(f"PASS {name}")
    else:
        print(f"FAIL {name}: 命中 {n}"); ok = False
if ok:
    open(P, "w", encoding="utf-8", newline="\n").write(t)
    print("构建脚本已更新")
