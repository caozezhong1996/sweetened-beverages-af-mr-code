# -*- coding: utf-8 -*-
import docx, re, os, zipfile
B = r'C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013'
TITLE = 'Adiposity-Linked Pleiotropy in the Coffee–Atrial Fibrillation Signal: A Two-Sample Mendelian Randomization Study'
m = docx.Document(B+r'\Manuscript.docx')
s = docx.Document(B+r'\Supplement.docx')
c = docx.Document(B+r'\Cover_Letter.docx')
h = docx.Document(B+r'\Highlights.docx')
mp = [p.text for p in m.paragraphs]
sp = [p.text for p in s.paragraphs]
full = '\n'.join(mp)
for tb in m.tables:
    for r in tb.rows:
        for cell in r.cells: full += '\n' + cell.text
sfull = '\n'.join(sp)
for tb in s.tables:
    for r in tb.rows:
        for cell in r.cells: sfull += '\n' + cell.text
cfull = '\n'.join(p.text for p in c.paragraphs)

checks = []
def ck(label, cond, detail=''):
    checks.append((label, bool(cond), detail))

ck('主稿标题', mp[0] == TITLE)
ck('补充标题', sp[1] == TITLE)
ck('投稿信标题', TITLE in cfull)
ck('摘要248词', len(' '.join(mp[6:9]).split()) == 248, len(' '.join(mp[6:9]).split()))
ck('摘要结论降格', 'more compatible with adiposity-linked pleiotropy' in mp[8])
ck('共定位功效表述已修', 'does not depend on statistical power' not in full and 'remains dependent on regional association strength' in full)
ck('茶零口径已修', 'extend that literature causally' not in full and 'uninformative rather than confirmatory' in full)
ck('旧强标题清零', 'Largely Account' not in full + cfull + sfull)
ck('carried by 清零', 'carried by adiposity' not in full + cfull)
ck('补充目录含S30/S31', 'Table S30 per-variant' in sp[2] and 'Table S31 recovery' in sp[2])
ck('S9摘要词数', '246 words' in sfull and '231 words' not in sfull)
ck('S9软件版本', 'R 4.6.1, TwoSampleMR 0.7.9, MRPRESSO 1.0, coloc 5.2.3' in sfull)
ck('S9表范围', 'Tables S12–S31' in sfull)
ck('S9新引用', '[8]' in s.tables[8].rows[3].cells[3].text and '[7]' in s.tables[8].rows[3].cells[3].text)
ck('S9旧Multivariable清零', 'Two-Sample and Multivariable' not in sfull)
ck('主稿元数据', m.core_properties.title == TITLE)
ck('补充元数据', s.core_properties.title == 'Supplemental material: ' + TITLE)
ck('投稿信无功效绝对化', 'does not depend on statistical power' not in cfull)
ck('图文摘要新文案', 'caffeine pathway not excluded' in open('_gabs_v57.py',encoding='utf-8').read())
ck('图文摘要旧文案清零', 'null across nine estimators' not in open('_gabs_v57.py',encoding='utf-8').read())
# 主稿参考文献
i = next(i for i,t in enumerate(mp) if t.strip() == 'References')
refs = [t.strip() for t in mp[i+1:] if t.strip()]
BL = re.compile(r'\[([0-9,\s\u2013-]+)\]')
order=[]
for t in mp[:i]:
    for match in BL.finditer(t):
        for part in re.split(r'[,\s]+', match.group(1)):
            if not part: continue
            if re.search(r'[\u2013-]', part):
                a,b = re.split(r'[\u2013-]',part)
                if a.isdigit() and b.isdigit():
                    for n in range(int(a),int(b)+1):
                        if n not in order: order.append(n)
            elif part.isdigit():
                n=int(part)
                if n not in order: order.append(n)
ck('55条文献严格递增', len(refs)==55 and order==list(range(1,56)), '%d/%d' % (len(refs),len(order)))
# 补充表闭合
used = {int(x) for x in re.findall(r'Table S(\d+)', full)}
defined = {int(x) for x in re.findall(r'Table S(\d+)\.', sfull)}
ck('S1-S31双向闭合', used==defined==set(range(1,32)), 'used %d defined %d' % (len(used),len(defined)))
# 9 refs mapping
expected = [
('The contamination-mixture estimator','manuscript ref 31'),('CAUSE (Morrison et al.','manuscript ref 33'),
('Network (two-step) mediation MR','manuscript ref 28'),('MRlap (Mounier & Kutalik','manuscript ref 34'),
('Early-onset AF (onset before age 66)','manuscript ref 54'),('MR-RAPS (Zhao et al.','manuscript ref 32'),
('Conditional F statistics quantify','manuscript ref 27'),('Exposures were plasma caffeine','manuscript ref 25'),
('Exposures were plasma caffeine','manuscript ref 42')]
for anchor, ref in expected:
    ps = [p for p in sp if anchor in p]
    ck('表注 '+ref+' '+anchor[:20], len(ps)==1 and ref in ps[0])
ck('无占位符', '{{' not in full+sfull)
# 字数
def idx(x): return next(i for i,t in enumerate(mp) if t.strip()==x)
body = sum(len(mp[k].split()) for k in range(idx('Introduction'),idx('Declarations')))
ck('正文词数9233', body==9233, body)

fails = [x for x in checks if not x[1]]
for label, ok, detail in checks:
    print(('PASS' if ok else 'FAIL'), label, detail)
print('\nSUMMARY', len(checks)-len(fails), '/', len(checks), 'PASS')
if fails: raise SystemExit(1)
