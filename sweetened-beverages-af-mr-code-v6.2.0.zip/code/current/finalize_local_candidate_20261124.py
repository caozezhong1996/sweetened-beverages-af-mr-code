from pathlib import Path
import csv
import hashlib
import io
import json
import shutil
import zipfile
import xml.etree.ElementTree as ET

BASE = Path(r"C:\Users\64915\WorkBuddy\2026-10-30-20-42-58\_targeted_fix_20261124")
ROOT = BASE.parent
PKG = BASE / "package"
SUB = Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")
OUT = ROOT / "Zenodo_更新候选_20261124_定向修订.zip"
OLD = ROOT / "Zenodo_更新候选_20261122_叙事校准.zip"
W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NS = {"w": W}
EXPECTED = {
    "Manuscript.docx": "df2b92489432e9e247d23c1869da2a7b9ad767be7765e7aef854e447679d4722",
    "Cover_Letter.docx": "6910ad46cb7bd01b26c722ea79d0dafa37931589616ce701d5db93dcf83bf0cc",
    "Highlights.docx": "2bf1e7be1362c4b5eb2d6fe3e444182eb4bcf6ac65b96298c3099b4fc7811e7f",
    "Supplement.docx": "7b264eef245abaa6712d1f4c1fbafff6d9f286943704dd4107b257bec60fc882",
}
CURRENT_CODE = [
    "revision_texts_20261124.json",
    "apply_targeted_fix_20261124.py",
    "audit_targeted_fix_20261124.py",
    "round_B_node_audit_20261124.js",
    "round_C_render_audit_20261124.py",
    "finalize_local_candidate_20261124.py",
    "verify_local_candidate_node_20261124.js",
]


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha_file(path):
    return sha_bytes(path.read_bytes())


for name, expected in EXPECTED.items():
    if sha_file(SUB / name) != expected:
        raise RuntimeError(f"Current submission hash drifted: {name}")
    if name != "Highlights.docx" and sha_file(BASE / "output" / name) != expected:
        raise RuntimeError(f"Staged candidate hash drifted: {name}")

local_files = {p.relative_to(SUB).as_posix(): p for p in SUB.rglob("*") if p.is_file()}
if len(local_files) != 10:
    raise RuntimeError(f"Submission file count is {len(local_files)}, expected 10")
for rel, src in local_files.items():
    dst = PKG / "submission" / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

for stem in ("Manuscript", "Supplement"):
    shutil.copy2(BASE / "render" / f"{stem}.pdf", PKG / "verification" / f"{stem}_rendered.pdf")

for name in EXPECTED:
    with zipfile.ZipFile(SUB / name) as zf:
        root = ET.fromstring(zf.read("word/document.xml"))
    body = root.find("w:body", NS)
    paragraphs = []
    for p in body.findall("w:p", NS):
        paragraphs.append("".join(t.text or "" for t in p.findall(".//w:t", NS)))
    (PKG / "data" / "derived" / "nmr" / f"{Path(name).stem}.txt").write_text(
        "\n".join(paragraphs), encoding="utf-8"
    )

staged_files = {p.relative_to(PKG / "submission").as_posix(): p for p in (PKG / "submission").rglob("*") if p.is_file()}
if set(local_files) != set(staged_files):
    raise RuntimeError("Submission file-set mismatch")
for rel in local_files:
    if sha_file(local_files[rel]) != sha_file(staged_files[rel]):
        raise RuntimeError(f"Submission content mismatch: {rel}")
for name in CURRENT_CODE:
    if not (PKG / "code" / "current" / name).is_file():
        raise RuntimeError(f"Missing current code: {name}")
if (PKG / "code" / "current" / "apply_revision_20261115.py").exists():
    raise RuntimeError("Stale apply_revision_20261115.py remains in code/current")
if not (PKG / "code" / "history" / "apply_revision_20261115.py").is_file():
    raise RuntimeError("Historical apply_revision_20261115.py was not retained")

manifest_path = PKG / "MANIFEST.csv"
payload = sorted(
    (p for p in PKG.rglob("*") if p.is_file() and p != manifest_path),
    key=lambda p: p.relative_to(PKG).as_posix(),
)
buf = io.StringIO(newline="")
writer = csv.writer(buf, lineterminator="\n")
writer.writerow(["path", "bytes", "sha256"])
for path in payload:
    rel = path.relative_to(PKG).as_posix()
    writer.writerow([rel.replace("/", "\\"), path.stat().st_size, sha_file(path)])
manifest_path.write_text(buf.getvalue(), encoding="utf-8-sig", newline="")

with zipfile.ZipFile(OUT, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
    for path in sorted((p for p in PKG.rglob("*") if p.is_file()), key=lambda p: p.relative_to(PKG).as_posix()):
        zf.write(path, path.relative_to(PKG).as_posix())

with zipfile.ZipFile(OUT) as zf:
    bad_crc = zf.testzip()
    names = [name for name in zf.namelist() if not name.endswith("/")]
    rows = list(csv.DictReader(zf.read("MANIFEST.csv").decode("utf-8-sig").splitlines()))
    mismatches = []
    for row in rows:
        name = row["path"].replace("\\", "/")
        try:
            data = zf.read(name)
        except KeyError:
            mismatches.append({"path": name, "error": "missing"})
            continue
        if len(data) != int(row["bytes"]) or sha_bytes(data) != row["sha256"]:
            mismatches.append({"path": name, "error": "bytes_or_sha256"})
    archived_names = set(names)
    missing_from_manifest = sorted(
        name for name in archived_names if name != "MANIFEST.csv" and name.replace("/", "\\") not in {r["path"] for r in rows}
    )
    extra_in_manifest = sorted(
        row["path"] for row in rows if row["path"].replace("\\", "/") not in archived_names
    )
    submission_differences = [
        rel for rel, local in local_files.items()
        if zf.read("submission/" + rel) != local.read_bytes()
    ]
    verification = {
        stem: zf.read(f"verification/{stem}_rendered.pdf") == (BASE / "render" / f"{stem}.pdf").read_bytes()
        for stem in ("Manuscript", "Supplement")
    }
    archived_hashes = {name: sha_bytes(zf.read("submission/" + name)) for name in EXPECTED}
    nmr_checks = {
        name: zf.read("data/derived/nmr/" + Path(name).stem + ".txt") ==
        (PKG / "data" / "derived" / "nmr" / f"{Path(name).stem}.txt").read_bytes()
        for name in EXPECTED
    }

result = {
    "candidate": str(OUT),
    "candidate_bytes": OUT.stat().st_size,
    "candidate_sha256": sha_file(OUT),
    "old_public_candidate_sha256": sha_file(OLD) if OLD.exists() else None,
    "entries": len(names),
    "manifest_rows": len(rows),
    "bad_crc": bad_crc,
    "manifest_mismatches": mismatches,
    "missing_from_manifest": missing_from_manifest,
    "extra_in_manifest": extra_in_manifest,
    "submission_differences": submission_differences,
    "archived_document_hashes": archived_hashes,
    "verification_pdf_equals_fresh_render": verification,
    "nmr_exports_match_staged_current_text": nmr_checks,
    "current_revision_code_present": {name: f"code/current/{name}" in names for name in CURRENT_CODE},
    "old_revision_script_retired": "code/current/apply_revision_20261115.py" not in names and "code/history/apply_revision_20261115.py" in names,
    "ga_v66_source_present": "code/current/_gabs_v66.py" in names,
}
result["all_pass"] = all([
    result["entries"] == result["manifest_rows"] + 1,
    result["bad_crc"] is None,
    not mismatches,
    not missing_from_manifest,
    not extra_in_manifest,
    not submission_differences,
    archived_hashes == EXPECTED,
    all(verification.values()),
    all(nmr_checks.values()),
    all(result["current_revision_code_present"].values()),
    result["old_revision_script_retired"],
    result["ga_v66_source_present"],
])
(BASE / "review" / "candidate_python.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
)
print(json.dumps(result, ensure_ascii=False, indent=2))
if not result["all_pass"]:
    raise SystemExit(1)
