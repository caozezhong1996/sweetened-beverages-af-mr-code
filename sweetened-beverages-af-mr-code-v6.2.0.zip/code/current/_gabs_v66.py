# -*- coding: utf-8 -*-
"""Graphical abstract v66 (2026-11-22): the candidate FTO locus-level finding
is placed in the first (left) findings box and the bounded sweetened-beverage
result in the second (right) box. All wording, numerical results, fonts,
colours within each box, layout dimensions and canvas are unchanged from v65.
The unmodified v65 source was rerun before editing and reproduced the current
submission PNG with zero changed pixels.
v65 (2026-11-17): heading calibrated to candidate
colocalization; all numerical results, layout, fonts and canvas unchanged.
v64 (2026-11-15): removed the literature-search
statement from the findings panel; no result, estimate or layout changed.
v63 (2026-11-15): prior sensitivity and heterogeneity qualifiers added.
v62 (2026-11-12): the outcome box now labels the
listed numbers as case counts, and the rg line names R13 as the single
source behind the two FDR-significant correlations. The left findings
box keeps its v61 wording: the full three-way null classification needs
156.2 pt in a 155.9 pt box, so it stays in manuscript Results (P078).
v61 (2026-11-11: figure wording aligned with manuscript;
layout, fonts, colours and canvas unchanged from v60).

Original v60 — 排版优化（文案、配色、字号、画布规格与 v59 完全一致）

v59 的三个连接箭头长度为 1.5 / 5.5 / 5.0 单位（相差 3.67 倍），
且副标题 y=134.7 与 EXPOSURES 框顶 134 仅差 0.7 单位、被框线穿过。
v60:
  1) 三处「带箭头的间隙」统一为 4.0 单位，箭头长度均为 4.0；
     mutation_scale 14 -> 10，使箭头头与箭身比例一致。
  2) 下方各框按间隙重排，框内文字随框同步平移，文字仍在框内。
  3) 标题保持 140.0（上移会裁掉第一行），副标题 134.7 -> 135.4：
     夹在标题底部约 136.65 与框顶 134 之间，文字半高约 0.92 单位，两侧均不交叠。
"""
import pathlib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

W_CM, H_CM, DPI = 12.5, 18.0, 300
fig = plt.figure(figsize=(W_CM / 2.54, H_CM / 2.54), dpi=DPI)
ax = fig.add_axes([0, 0, 1, 1])
ax.set_xlim(0, 100)
ax.set_ylim(0, 144)
ax.axis("off")

INK = "#1f313a"
MUT = "#5b6f79"
BLUE = "#2f6f8f"
LBLUE = "#e3eef4"
GREEN = "#2e7d5b"
LGREEN = "#e5f2ec"
AMBER = "#b3641c"
LAMBER = "#f9eee0"
GREY = "#eef3f6"


def box(x, y, w, h, fc, ec, lw=1.2, r=1.6):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle=f"round,pad=0,rounding_size={r}",
                                facecolor=fc, edgecolor=ec, linewidth=lw))


def txt(x, y, s, size=8.2, color=INK, weight="normal", ha="center", va="center", style="normal"):
    ax.text(x, y, s, fontsize=size, color=color, fontweight=weight, ha=ha, va=va,
            style=style, linespacing=1.35)


GAP = 4.0
def arrow(src_bottom, dst_top, color=MUT):
    """统一长度的连接箭头；调用处保证 src_bottom - dst_top == GAP"""
    assert abs((src_bottom - dst_top) - GAP) < 1e-6, "arrow gap must be uniform"
    ax.add_patch(FancyArrowPatch((50, src_bottom), (50, dst_top), arrowstyle="-|>",
                                 mutation_scale=10, linewidth=1.6, color=color,
                                 shrinkA=0, shrinkB=0))


# ---------------- title（标题不动，副标题精调到标题与框之间的空档） ----------------
txt(50, 140.0, "Pleiotropy at the FTO Locus in the\nCoffee–Atrial Fibrillation Signal",
    size=8.8, weight="bold")
txt(50, 135.4, "Two-sample MR  ·  locus-level colocalization  ·  UK Biobank-free replication",
    size=6.5, color=MUT, style="italic")

# ---------------- exposures（位置不变：顶 134 / 底 112） ----------------
box(4, 112, 92, 22, LBLUE, BLUE)
txt(50, 114.5, "Plasma caffeine · paraxanthine · theobromine (Chen 2023 atlas; N ≈ 8,000)",
    size=7.2, color=BLUE, style="italic")
txt(50, 131.5, "EXPOSURES — 7 beverages + 3 plasma metabolites", size=7.8, weight="bold", color=BLUE)
txt(50, 128.5, "(UK Biobank GWAS, N = 64,949–447,485)", size=7.0, color=BLUE)
txt(50, 121.5, "Sugar added to tea  ·  Sugar added to coffee  ·  Fizzy drinks (SSB)\n"
               "Low-calorie drinks (ASB)  ·  Artificial sweetener added to tea\n"
               "Coffee intake  ·  Tea intake", size=8.0)

# 箭头 1：112 -> 108（GAP 4.0）
arrow(112, 108)

# ---------------- framework（顶 108 / 底 95，整体 -2.5） ----------------
box(4, 95, 92, 13, GREY, MUT)
txt(50, 105.7, "CAUSAL-INFERENCE FRAMEWORK", size=8.0, weight="bold", color=MUT)
txt(50, 100.6, "Two-sample MR (IVW, MR-Egger, weighted median, MR-PRESSO)\n"
               "Multivariable MR with BMI  ·  Locus-level colocalization  ·  Cross-trait LDSC\n"
               "Reverse MR  ·  Alcohol positive and sugar-in-tea negative controls",
    size=7.0)

# 箭头 2：95 -> 91（GAP 4.0）
arrow(95, 91)

# ---------------- outcome（顶 91 / 底 78，整体 -1） ----------------
box(4, 78, 92, 13, LBLUE, BLUE)
txt(50, 87.9, "OUTCOME — atrial fibrillation, five sources (case counts)", size=8.0, weight="bold", color=BLUE)
txt(50, 82.45, "Nielsen 2018 (60,620; primary)  ·  FinnGen R13 (67,783; replication)\n"
               "Yuan 2025, UKB-free (192,851; replication)  ·  AFGen 2018 (55,114)\n"
               "BioBank Japan (8,180; East Asian contextual)",
    size=7.2)

# ---------------- findings（顶 72 / 底 56，整体 +0.5） ----------------
txt(50, 75.5, "KEY FINDINGS", size=8.6, weight="bold")

box(4, 56, 44, 16, LAMBER, AMBER)
txt(26, 69.7, "Candidate FTO colocalization", size=6.9, weight="bold", color=AMBER)
txt(26, 67.0, "→ caffeine pathway not excluded", size=6.9, weight="bold", color=AMBER)
txt(26, 61.1, "FTO default-prior 0.894/0.906;\nprior-sensitive; AFGen inconclusive;\ncaffeine loci: no AF signal (≤ 0.008)",
    size=6.2)

box(52, 56, 44, 16, LGREEN, GREEN)
txt(74, 69.4, "Sweetened beverages", size=7.9, weight="bold", color=GREEN)
txt(74, 66.2, "→ No robust causal evidence", size=7.1, weight="bold", color=GREEN)
txt(74, 61.5, "Meta-analytic OR 0.82–0.97;\nUKB-free 0.76–1.04;\nheterogeneity qualifies some nulls",
    size=6.9)

# genetic correlation（顶 53 / 底 41，整体 +0.5）
box(4, 41, 92, 12, LGREEN, GREEN)
txt(50, 50.7, "Genetic correlation ≠ causation", size=7.9, weight="bold", color=GREEN)
txt(50, 45.5, "SSB and ASB share genetic architecture with AF (rg 0.24–0.31 in R13; FDR q < 0.05)\n"
              "despite null MR estimates; cross-trait intercepts ≈ 0",
    size=7.0)

# 箭头 3：41 -> 37（GAP 4.0）
arrow(41, 37)

# ---------------- conclusion（顶 37 / 底 22.5，整体 +1.5） ----------------
box(4, 22.5, 92, 14.5, INK, INK)
txt(50, 34.9, "CONCLUSION", size=8.0, weight="bold", color="#bcd3de")
txt(50, 28.3, "The coffee–AF signal is more compatible with adiposity-linked pleiotropy than with\n"
              "caffeine metabolism, although neither was excluded. No robust sweetened-beverage\n"
              "association was detected; component-level nulls do not certify milk-tea safety.",
    size=7.0, color="white")

txt(50, 19.3, "After exclusion: coffee OR 1.26–1.39; sources were also compatible before exclusion.",
    size=6.6, color=MUT, style="italic")
txt(50, 15.6, "European-meta power for OR 1.10: 13–47%; observational-magnitude effects remain unexcluded.\n"
              "Direct measurement of milk-tea consumption in prospective East Asian cohorts remains needed.",
    size=6.6, color=MUT, style="italic")

out = pathlib.Path(r"C:\Users\64915\WorkBuddy\2026-10-30-20-42-58\_narrative_adjust_20261122\Graphical_Abstract_v66.png")
fig.savefig(out, dpi=DPI)
print("written:", out)

from PIL import Image
im = Image.open(out)
print("pixel size:", im.size, "expected:", (round(W_CM / 2.54 * DPI), round(H_CM / 2.54 * DPI)))
