# -*- coding: utf-8 -*-
"""第七轮改后终检"""
import docx, os, re, hashlib

B = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013"
A = r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版\JAHA_v20261101_标题降格前备份"
NEW_T = "Pleiotropy at the FTO Locus in the Coffee\u2013Atrial Fibrillation Signal: A Two-Sample Mendelian Randomization Study"
OLD_T = "Adiposity-Linked Pleiotropy in the Coffee\u2013Atrial Fibrillation Signal: A Two-Sample Mendelian Randomization Study"

res = []
def ck(name, cond, note=""):
    res.append((cond, name, note))
    print(("PASS " if cond else "FAIL ") + name + (("  [" + str(note) + "]") if note != "" else ""))

m = docx.Document(os.path.join(B, "Manuscript.docx"))
mp = [p.text for p in m.paragraphs]
full = "\n".join(mp)
for tb in m.tables:
    for r in tb.rows:
        for c in r.cells:
            full += "\n" + c.text

s = docx.Document(os.path.join(B, "Supplement.docx"))
sp = [p.text for p in s.paragraphs]
sfull = "\n".join(sp)
for tb in s.tables:
    for r in tb.rows:
        for c in r.cells:
            sfull += "\n" + c.text

c = docx.Document(os.path.join(B, "Cover_Letter.docx"))
cfull = "\n".join(p.text for p in c.paragraphs)
rd = open(os.path.join(B, "README_投稿包.md"), encoding="utf-8").read()

# 1 标题
ck("1 手稿标题=new", mp[0].strip() == NEW_T, mp[0].strip()[:60])
ck("2 补充标题=new", sp[1].strip() == NEW_T)
ck("3 投稿信标题=new", NEW_T in cfull)
ck("4 README 标题=new", NEW_T in rd)
ck("5 核心属性=new", docx.Document(os.path.join(B, "Manuscript.docx")).core_properties.title == NEW_T)
ck("6 旧标题清零", all(OLD_T not in x for x in (full, sfull, cfull, rd)))

# 2 词数
def idx(x):
    return next(i for i, t in enumerate(mp) if t.strip() == x)
abst = len(" ".join(mp[6:9]).split())
body = sum(len(mp[k].split()) for k in range(idx("Introduction"), idx("Declarations")))
ck("7 摘要<=250", abst <= 250, abst)
ck("8 正文词数", body > 9000, body)

# 3 参考文献
i_ref = idx("References")
refs = [t.strip() for t in mp[i_ref + 1:] if t.strip()]
order, first = [], {}
for pi, t in enumerate(mp[:i_ref]):
    for mt in re.finditer(r"\[([0-9,\s\u2013-]+)\]", t):
        for part in re.split(r"[,\s]+", mt.group(1)):
            if not part:
                continue
            if re.search(r"[\u2013-]", part):
                a, b = re.split(r"[\u2013-]", part)
                if not (a.isdigit() and b.isdigit()):
                    continue
                nums = range(int(a), int(b) + 1)
            elif part.isdigit():
                nums = [int(part)]
            else:
                continue
            for n in nums:
                if n not in first:
                    first[n] = pi
                    order.append(n)
ck("9 参考文献 57 条严格递增", len(refs) == 57 and order == list(range(1, 58)), "%d/%d" % (len(refs), len(order)))

# 4 补充表闭合
def_s = {int(x) for x in re.findall(r"Table S(\d+)\.", sfull)}
used = {int(x) for x in re.findall(r"Table S(\d+)", full)}
ck("10 S1-S31 双向闭合", min(def_s) == 1 and max(def_s) == 31 and used <= def_s,
   "def %d used %d" % (len(def_s), len(used)))

# 5 本轮六处
ck("11 可解释零=三", "three provide interpretable null estimates" in full and "four provide interpretable" not in full)
ck("12 糖加咖啡归入 qualified", "sugar added to coffee showed significant within-source heterogeneity" in full)
ck("13 Q=2.87 全精度", "Cochran Q = 2.87" in full and "Q = 2.97" not in full)
ck("14 I2=30%", "I\u00b2 = 30%" in full and "I\u00b2 = 33%" not in full)
ck("15 咖啡因位点仅 Nielsen", "assessed against Nielsen 2018 only" in full)
ck("16 不依赖重叠来源", "no conclusion here rests on the overlapping source" in full)
ck("17 摘要 nominal", "Coffee intake showed a nominal association" in full)
ck("18 摘要 pre-specified 一致性", "did not meet pre-specified consistency criteria" in full)
ck("19 摘要 FTO 主语", "Colocalization supported a shared FTO variant" in full)

# 6 未破坏项
ck("20 摘要仍含 AFGen 0.362", "inconclusive in AFGen (0.362)" in mp[7])
ck("21 摘要仍含 ASB 定位", "to our knowledge" in mp[6] and "artificially sweetened" in mp[6])
ck("22 摘要仍含 13-47%", "13\u201347%" in mp[7])
ck("23 摘要仍含 1.21-1.38", "1.21\u20131.38" in mp[7])
ck("24 S9 摘要词数同步", ("%d words" % abst) in sfull, "%d words" % abst)
ck("25 README 摘要词数", ("\u6458\u8981 **%d** \u8bcd" % abst) in rd or ("\u6458\u8981 %d \u5b57" % abst) in rd, abst)
ck("26 README 正文词数", "{:,}".format(body) in rd, "{:,}".format(body))

# 7 图
g = os.path.join(B, "figures", "Graphical_Abstract.png")
gb = os.path.join(A, "figures", "Graphical_Abstract.png")
h = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()[:16]
ck("27 图文摘要已更新", h(g) != h(gb), h(g))

# 8 段落数与占位符
ck("28 无占位符", full.count("{{") == 0)
ck("29 段落数", len(mp) > 170, len(mp))

print("\n%d/%d PASS" % (sum(1 for r in res if r[0]), len(res)))
