import docx
from copy import deepcopy
from docx.shared import Pt, Cm
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

SUP = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\Supplement.docx"

ITEMS = [
    ("1a", "Title and abstract: indicate Mendelian randomization in the title or abstract",
     "Title; Abstract, Background",
     "“…: A Two-Sample and Multivariable Mendelian Randomization Study”; “We asked whether genetically proxied sweetened-beverage intake is causally associated with atrial fibrillation (AF)…”"),
    ("1b", "Title and abstract: provide a structured summary of design, methods, results and conclusions",
     "Abstract (Background / Methods and Results / Conclusions), 231 words",
     "Structured under three headings; reports instrument source, four outcome sources, meta-analytic ORs, power, colocalization and the failed negative control."),
    ("2", "Introduction: scientific background and rationale",
     "Introduction, paragraphs 1–4",
     "“Two MR analyses nonetheless report positive estimates, for SSBs (OR 1.023) [6] and for coffee (OR 1.281) [5]. Whether such positive genetic estimates reflect the beverage or the biology it tracks is the question this study addresses.”"),
    ("3", "Introduction: state specific objectives and pre-specified hypotheses",
     "Introduction, final paragraph",
     "“aiming (i) to estimate causal effects of sweetened-beverage intake …; (ii) to determine, at locus level, whether the recurring coffee signal is attributable to caffeine metabolism or to adiposity; (iii) to quantify how far observational-magnitude effects can be excluded given the realized precision; and (iv) to examine consistency in an East Asian population.”"),
    ("4", "Methods: describe the study design and data sources",
     "Methods — Study design and reporting; Data sources; Table 1",
     "“The design rests on the three core MR assumptions: (1) the genetic instruments are robustly associated with the exposure; (2) they share no common cause with the outcome; and (3) they affect the outcome only through the exposure.”"),
    ("5", "Methods: state and justify the three core instrumental-variable assumptions, and how each was assessed",
     "Methods — Study design; Instrument selection; Statistical analysis",
     "Assumption 1: per-variant F statistics and cumulative R². Assumption 2: negative outcome control against atrioventricular block (Table S18); cross-trait LDSC intercepts (Table S11). Assumption 3: MR-Egger intercepts, Cochran Q, MR-PRESSO, CAUSE, contamination mixture (Tables S3, S4, S14, S15)."),
    ("6", "Methods: describe the data sources, and the ancestry of participants",
     "Methods — Data sources; Table 1",
     "“Instruments for seven beverage phenotypes were obtained from the UK Biobank GWAS pipeline of the MRC Integrative Epidemiology Unit … distributed through OpenGWAS”; “All participants were of European ancestry.”"),
    ("7", "Methods: describe the eligibility criteria and the setting of contributing studies",
     "Methods — Data sources; Table 1; Table S28",
     "Case and control counts given for each of the five outcome sources (Nielsen 2018, FinnGen R13, Yuan 2025, AFGen 2018, BioBank Japan); cohort-level overlap map in Table S28."),
    ("8", "Methods: define exposures, outcomes, and covariates",
     "Methods — Data sources; Table 1",
     "“intake of sugar added to tea, sugar added to coffee, fizzy drink intake (representing SSB consumption), low-calorie drink intake (representing ASB consumption) and artificial sweetener added to tea (each N = 64,949), coffee intake (N = 428,860) and tea intake (N = 447,485).”"),
    ("9", "Methods: describe how each variable was measured, and the units and scaling of the estimates",
     "Methods — Instrument selection; Statistical analysis",
     "“Because the exposure phenotypes are ordinal questionnaire categories, estimates are scaled per one-category increment in genetically instrumented intake, not per gram, milliliter or serving.”"),
    ("10", "Methods: describe the approach to addressing potential sources of bias, including pleiotropy and sample overlap",
     "Methods — Statistical analysis; Genetic correlation and overlap diagnostics",
     "“Heterogeneity was assessed with Cochran's Q statistic and directional pleiotropy with the MR-Egger intercept”; MRlap; CAUSE; “A negative outcome control repeated the pipeline against atrioventricular block (I9_AVBLOCK; Table S18).”"),
    ("11", "Methods: explain how the study size was arrived at, and report statistical power",
     "Methods — Statistical analysis; Results — Statistical power; Table S12",
     "“Statistical power was quantified from the realized standard error of each IVW estimate (minimum detectable odds ratio at 80% power, two-sided α = 0.05)”; “power to detect the observational effect size (OR 1.10) was 13–47%.”"),
    ("12", "Methods: describe all quantitative variables and the transformations used",
     "Methods — Statistical analysis; Table S27 footnote",
     "Log-odds scaling of binary outcomes; ORs per unit higher genetically instrumented intake; Steiger filtering of palindromic variants; GRCh37 coordinate harmonisation for the adiposity-locus analysis."),
    ("13a", "Methods: state the main statistical methods, including the software used",
     "Methods — Statistical analysis",
     "“Random-effects inverse-variance-weighted (IVW) regression was the primary method, complemented by MR-Egger, weighted-median and weighted-mode estimators.” Software: R 4.6.0, TwoSampleMR, MRPRESSO, coloc."),
    ("13b", "Methods: describe all sensitivity analyses",
     "Methods — Statistical analysis; Results; Tables S12–S29",
     "MR-PRESSO, radial IVW, contamination mixture, MR-RAPS, MRlap, CAUSE, Steiger filtering, reverse MR, leave-one-out and funnel plots, early-onset AF, a second coffee GWAS, and the adiposity-locus exclusion (Table S27)."),
    ("13c", "Methods: describe all subgroup and additional analyses",
     "Methods — Multivariable MR; Genetic correlation; Results — Locus-level colocalization",
     "MVMR with BMI (Table 4; Table S24); two-step mediation MR (Table S16); locus-level colocalization at CYP1A1–CYP1A2, AHR and FTO (Tables S8, S13, S21); caffeine-pathway subgroup MR (Tables S4, S29)."),
    ("14", "Results: report the numbers of individuals and variants at each stage",
     "Results — Genetic instruments; Tables S1, S31",
     "“Between 8 and 34 independent SNPs per exposure were analyzed against the primary outcome (median 17; Table S1)”; “Of the 133 unique instrument variants (137 exposure–instrument pairs), 128 (96%) were present in the UK Biobank-free Yuan 2025 panel.”"),
    ("15", "Results: report the main results, with unadjusted estimates where appropriate",
     "Results — Sweetened beverages and AF; Table 2; Figure 2",
     "“None of the five sweetened-beverage exposures showed evidence of a causal association with AF … IVW odds ratios … were 0.91 (95% CI 0.72–1.17) for sugar added to tea … (all P ≥ 0.40).”"),
    ("16", "Results: report all other analyses, including sensitivity and subgroup analyses",
     "Results — Nominal associations that were not robust; Adiposity-locus exclusion; Locus-level colocalization; Tables 3–4, S2–S29",
     "Reported in full, including the failed negative control: “the inverse association for sugar added to tea (P = 0.001) did”; “only four of the five sweetened-beverage phenotypes provide interpretable null estimates.”"),
    ("17", "Discussion: summarise the key results with reference to the objectives",
     "Discussion — Principal findings",
     "“…genetically proxied sweetened-beverage intake showed no causal association with atrial fibrillation across four European outcome files—at most two independent clusters … The study's positive contribution is locus-level.”"),
    ("18", "Discussion: discuss limitations, taking into account sources of potential bias",
     "Discussion — Strengths and limitations",
     "“a structural limitation is that the four European outcome files correspond to at most two independent clusters”; “the F statistics meet the selection-implied floor without providing independent evidence of strength”; “the FinnGen I9_AF endpoint pools AF with atrial flutter”. Also reports the two sweetener estimates that moved away from the null after exclusion."),
    ("19", "Discussion: give a cautious overall interpretation, considering the study's limitations and other evidence",
     "Discussion — Clinical and public-health implications; Conclusions",
     "“Current genetic evidence does not support sweetened beverage intake as a direct causal determinant of AF … It offers no direct evidence implicating milk-tea-type beverages in AF etiology but cannot exclude effects of observational magnitude.”"),
    ("20", "Other information: state the source of funding and the role of the funders",
     "Declarations — Sources of Funding",
     "“None. This research received no specific grant from any funding agency in the public, commercial or not-for-profit sectors.”"),
]

doc = docx.Document(SUP)

# 1) 更新标题
title_p = None
for p in doc.paragraphs:
    if p.text.strip().startswith("Table S9."):
        title_p = p
        break
assert title_p is not None, "S9 title not found"
if title_p.runs:
    title_p.runs[0].text = "Table S9. STROBE-MR checklist"
    for r in title_p.runs[1:]:
        r.text = ""

# 2) 定位紧随其后的旧表
nxt = title_p._p.getnext()
old_tbl_el = None
while nxt is not None:
    if nxt.tag.endswith("}tbl"):
        old_tbl_el = nxt
        break
    if nxt.tag.endswith("}p") and "".join(nxt.itertext()).strip():
        break
    nxt = nxt.getnext()
print("old table located:", old_tbl_el is not None)

# 3) 建新表并填充
head = ["Item", "STROBE-MR requirement", "Location in manuscript", "Reported (quoted or summarised)"]
widths = [1.1, 4.7, 3.9, 7.3]
tb = doc.add_table(rows=1, cols=4)
_t = tb._tbl
_t.remove(_t.tblPr)
_t.insert(0, deepcopy(doc.tables[0]._tbl.tblPr))

for i, h in enumerate(head):
    c = tb.rows[0].cells[i]
    c.text = ""
    par = c.paragraphs[0]
    par.paragraph_format.space_after = Pt(0)
    run = par.add_run(h)
    run.bold = True
    run.font.size = Pt(7.5)
    c.width = Cm(widths[i])
trPr = tb.rows[0]._tr.get_or_add_trPr()
th = OxmlElement("w:tblHeader")
th.set(qn("w:val"), "true")
trPr.append(th)

for it in ITEMS:
    cells = tb.add_row().cells
    for i, v in enumerate(it):
        cells[i].text = ""
        par = cells[i].paragraphs[0]
        par.paragraph_format.space_after = Pt(0)
        par.paragraph_format.line_spacing = 1.0
        run = par.add_run(v)
        run.font.size = Pt(7)
        cells[i].width = Cm(widths[i])

# 4) 移到标题段之后，删除旧表
title_p._p.addnext(tb._tbl)
if old_tbl_el is not None:
    old_tbl_el.getparent().remove(old_tbl_el)

doc.save(SUP)
print("saved; tables now:", len(doc.tables))

d2 = docx.Document(SUP)
for p in d2.paragraphs:
    if p.text.strip().startswith("Table S9."):
        print("title:", p.text)
# 找到 S9 后的表并检查
nxt = next(p for p in d2.paragraphs if p.text.strip().startswith("Table S9."))._p.getnext()
while nxt is not None and not nxt.tag.endswith("}tbl"):
    nxt = nxt.getnext()
for tb2 in d2.tables:
    if tb2._tbl is nxt:
        print("S9 table rows:", len(tb2.rows), "cols:", len(tb2.columns))
        print("first data row:", [c.text[:26] for c in tb2.rows[1].cells])
        break
