# -*- coding: utf-8 -*-
"""第九轮终检：GA 右框 / Supplement 页眉 / 未破坏项"""
import docx, os, re, zipfile, hashlib

B = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013"
A = r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版\JAHA_v20261106_GA与页眉同步前备份"
res = []
def ck(name, cond, note=""):
    res.append(cond)
    print(("PASS " if cond else "FAIL ") + name + (("  [" + str(note) + "]") if note != "" else ""))

m = docx.Document(os.path.join(B, "Manuscript.docx"))
ps = [p.text for p in m.paragraphs]
full = "\n".join(ps)
for tb in m.tables:
    for r in tb.rows:
        for c in r.cells: full += "\n" + c.text

s = docx.Document(os.path.join(B, "Supplement.docx"))
sfull = "\n".join(p.text for p in s.paragraphs)

print("=" * 86)
print("A. 两处同步")
print("=" * 86)
NEW_HDR = "Pleiotropy at the FTO locus in the coffee\u2013AF signal \u2014 Supplementary Materials"
OLD_HDR = "Sweetened beverages and atrial fibrillation \u2014 Supplementary Materials"
hdr_now = [sec.header.paragraphs[0].text for sec in s.sections]
ck("1 页眉=new", all(t == NEW_HDR for t in hdr_now), hdr_now[0])
ck("2 旧页眉清零", OLD_HDR not in sfull)
# GA 脚本
g59 = open(r"C:\Users\64915\WorkBuddy\2026-10-30-20-42-58\_gabs_v59.py", encoding="utf-8").read()
ck("3 GA v59 含 AFGen 0.362", "inconclusive (0.362)" in g59 and "AFGen" in g59)
ck("4 GA v59 无旧两源断句", "Colocalizes with AF at FTO (0.894)" not in g59)
ck("5 GA 输出名 v59", "Graphical_Abstract_v59.png" in g59)
# 成品图哈希变化
h = lambda p: hashlib.sha256(open(p, "rb").read()).hexdigest()[:16]
g_new = os.path.join(B, "figures", "Graphical_Abstract.png")
g_old = os.path.join(A, "figures", "Graphical_Abstract.png")
ck("6 投稿包 GA 已替换", h(g_new) != h(g_old), h(g_new))
ck("7 归档脚本已保存", os.path.exists(r"C:\Users\64915\WorkBuddy\2026-10-30-20-42-58\proj_orig_20261006\build_gabstract_v59.py"))

print()
print("=" * 86)
print("B. 未破坏既有结论")
print("=" * 86)
def idx(x): return next(i for i, t in enumerate(ps) if t.strip() == x)
i_ref = idx("References")
refs = [t.strip() for t in ps[i_ref + 1:] if t.strip()]
order, first = [], {}
for pi, t in enumerate(ps[:i_ref]):
    for mt in re.finditer(r"\[([0-9,\s\u2013-]+)\]", t):
        for part in re.split(r"[,\s]+", mt.group(1)):
            if not part: continue
            if re.search(r"[\u2013-]", part):
                a, b = re.split(r"[\u2013-]", part)
                if not (a.isdigit() and b.isdigit()): continue
                nums = range(int(a), int(b) + 1)
            elif part.isdigit(): nums = [int(part)]
            else: continue
            for n in nums:
                if n not in first: first[n] = pi; order.append(n)
ck("8 57 条严格 1-57", len(refs) == 57 and order == list(range(1, 58)), "%d/%d" % (len(refs), len(order)))
abst = len(" ".join(ps[6:9]).split())
body = sum(len(ps[k].split()) for k in range(idx("Introduction"), idx("Declarations")))
ck("9 摘要 249", abst == 249, abst)
ck("10 正文 9508", body == 9508, body)
ck("11 旧 sufficient 断言清零", "sufficient explanation" not in full and "under both instruments" not in full)
ck("12 0.362 全稿 5 处", full.count("0.362") == 5, full.count("0.362"))
ck("13 Q=2.87", "Cochran Q = 2.87" in full and "Q = 2.97" not in full)
ck("14 可解释零=三", "three provide interpretable null estimates" in full)
ck("15 主稿页眉=new", all(sec.header.paragraphs[0].text == "Pleiotropy at the FTO locus in the coffee\u2013AF signal" for sec in m.sections))
ck("16 Short title 同步", any("Short title: Pleiotropy at the FTO locus" in p for p in ps))
def_s = {int(x) for x in re.findall(r"Table S(\d+)\.", sfull)}
used = {int(x) for x in re.findall(r"Table S(\d+)", full)}
ck("17 S1-S31 闭合", min(def_s) == 1 and max(def_s) == 31 and used <= def_s)
ck("18 核心属性新题", docx.Document(os.path.join(B, "Manuscript.docx")).core_properties.title.startswith("Pleiotropy at the FTO Locus"))

print()
print("=" * 86)
print("C. 全投稿包旧叙事残留扫描")
print("=" * 86)
texts = {}
for f in ["Manuscript.docx", "Supplement.docx", "Cover_Letter.docx", "Highlights.docx"]:
    d = docx.Document(os.path.join(B, f))
    t = "\n".join(p.text for p in d.paragraphs)
    for tb in d.tables:
        for r in tb.rows:
            for c in r.cells: t += "\n" + c.text
    texts[f] = t
# 注意：主稿 P127 是参考文献原题名，属正常
for f, t in texts.items():
    hits = [k for k in ["Coffee, adiposity loci", "Genetically Proxied Sweetened Beverage",
                        "Adiposity-Linked Pleiotropy", "OLD_HDR"] if k in t]
    # 主稿允许参考文献中含 "Sweetened beverages and atrial fibrillation"
    ck("19 %-20s 旧串=%s" % (f, len(hits)), len(hits) == 0)

print("\n%d/%d PASS" % (sum(1 for x in res if x), len(res)))
