# -*- coding: utf-8 -*-
import csv,os,math,json,hashlib
from collections import Counter,defaultdict
from scipy.stats import chi2
W=r"C:\Users\64915\WorkBuddy\2026-10-30-20-42-58"
D=os.path.join(W,"_review3_fix")
A=r"C:\a3work"
old=list(csv.DictReader(open(os.path.join(W,"TableS30_per_variant.csv"),encoding="utf-8-sig")))
non=[r for r in old if r["Outcome source"]!="Yuan 2025"]
order=[]
for r in old:
    if r["Exposure"] not in order: order.append(r["Exposure"])
E={
 "Artificial_sweetener_added_to_tea":"Artificial sweetener added to tea",
 "Coffee_intake":"Coffee intake",
 "Fizzy_drink_intake_SSB":"Fizzy drink intake (SSB)",
 "Low_calorie_drink_intake_ASB":"Low-calorie drink intake (ASB)",
 "Sugar_added_to_coffee":"Sugar added to coffee",
 "Sugar_added_to_tea":"Sugar added to tea",
 "Tea_intake":"Tea intake"}
new=[]
for tag,label in E.items():
    p=os.path.join(A,"yuan2025_corrected","dat_%s_yuan.csv"%tag)
    rs=list(csv.DictReader(open(p,encoding="utf-8")))
    rs=[r for r in rs if str(r.get("mr_keep","TRUE")).upper()!="FALSE"]
    for r in rs:
        bx=float(r["beta.exposure"]); sx=float(r["se.exposure"])
        by=float(r["beta.outcome"]); sy=float(r["se.outcome"])
        b=by/bx; se=sy/abs(bx)
        new.append({"Exposure":label,"Outcome source":"Yuan 2025","SNP":r["SNP"],
          "EA>OA":r["effect_allele.exposure"]+">"+r["other_allele.exposure"],
          "EAF":f'{float(r["eaf.exposure"]):.6f}',"beta_exposure":f"{bx:.6f}","SE_exposure":f"{sx:.6f}",
          "F":f"{bx*bx/(sx*sx):.2f}","beta_outcome":f"{by:.5f}","SE_outcome":f"{sy:.5f}",
          "Wald OR":f"{math.exp(b):.2f}","95% CI lower":f"{math.exp(b-1.96*se):.2f}","95% CI upper":f"{math.exp(b+1.96*se):.2f}"})
allrows=non+new
fields=list(old[0].keys())
out=os.path.join(D,"TableS30_per_variant_corrected.csv")
with open(out,"w",encoding="utf-8-sig",newline="") as f:
    w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(allrows)
# 全精度 IVW/Q 由 harmonized 文件计算，不从显示值反推
qrows=[]
for tag,label in E.items():
    rs=[r for r in csv.DictReader(open(os.path.join(A,"yuan2025_corrected","dat_%s_yuan.csv"%tag),encoding="utf-8")) if str(r.get("mr_keep","TRUE")).upper()!="FALSE"]
    th=[float(r["beta.outcome"])/float(r["beta.exposure"]) for r in rs]
    w=[float(r["beta.exposure"])**2/float(r["se.outcome"])**2 for r in rs]
    b=sum(a*x for a,x in zip(w,th))/sum(w)
    Q=sum(a*(x-b)**2 for a,x in zip(w,th)); df=len(rs)-1
    qrows.append({"exposure":label,"n":len(rs),"Q":Q,"df":df,"Q_P":chi2.sf(Q,df),"I2":max(0,(Q-df)/Q)*100})
with open(os.path.join(D,"yuan2025_q_corrected.csv"),"w",encoding="utf-8",newline="") as f:
    w=csv.DictWriter(f,fieldnames=list(qrows[0])); w.writeheader(); w.writerows(qrows)
# 极值与权重
weights=defaultdict(float)
for r in allrows:
    weights[(r["Exposure"],r["Outcome source"])]+=float(r["beta_exposure"])**2/float(r["SE_outcome"])**2
ext=[]
for r in allrows:
    OR=float(r["Wald OR"])
    if OR<0.1 or OR>10:
        w=float(r["beta_exposure"])**2/float(r["SE_outcome"])**2
        ext.append({"exposure":r["Exposure"],"source":r["Outcome source"],"SNP":r["SNP"],"OR":OR,"F":float(r["F"]),"weight_pct":100*w/weights[(r["Exposure"],r["Outcome source"])]})
summary={"rows":len(allrows),"source_counts":Counter(r["Outcome source"] for r in allrows),"yuan_counts":Counter(r["Exposure"] for r in new),"extreme_n":len(ext),"extremes":ext,"weight_range":[min(x["weight_pct"] for x in ext),max(x["weight_pct"] for x in ext)],"F_range":[min(x["F"] for x in ext),max(x["F"] for x in ext)],"csv":out,"sha256":hashlib.sha256(open(out,'rb').read()).hexdigest()}
json.dump(summary,open(os.path.join(D,"s30_corrected_summary.json"),"w",encoding="utf-8"),ensure_ascii=False,indent=2,default=dict)
print("rows",len(allrows),summary["source_counts"])
print("Yuan",summary["yuan_counts"])
print("extreme",len(ext),"weight",summary["weight_range"],"F",summary["F_range"])
for q in qrows: print(q["exposure"],q["n"],"Q P",q["Q_P"],"I2",q["I2"])
