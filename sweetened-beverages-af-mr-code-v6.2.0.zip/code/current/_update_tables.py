import docx, math

SUP = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\Supplement.docx"
doc = docx.Document(SUP)

def cell_set(c, text, size=8):
    c.text = ""
    p = c.paragraphs[0]
    run = p.add_run(text)
    run.font.size = docx.shared.Pt(size)

def show(tb, n=3):
    for r in tb.rows[:n]:
        print("   ", " | ".join(c.text.strip()[:22] for c in r.cells))

# ---- Table S1 ----
t1 = doc.tables[0]
print("Table S1 header:", [c.text.strip() for c in t1.rows[0].cells])
hit1 = 0
for r in t1.rows:
    if r.cells[0].text.strip() == "Tea intake":
        old = r.cells[4].text.strip()
        cell_set(r.cells[4], "32 / 32 / 32 / 29")
        print("  S1 tea retained:", old, "-> 32 / 32 / 32 / 29")
        hit1 += 1

# ---- Table S2 ----
t2 = doc.tables[1]
print("\nTable S2 header:", [c.text.strip() for c in t2.rows[0].cells])
newvals = {
    "Inverse variance weighted": ("29", "1.13 (0.54-2.34)", "0.753"),
    "MR Egger":                  ("29", "2.86 (0.39-20.86)", "0.310"),
    "Weighted median":           ("29", "1.44 (0.63-3.28)", "0.383"),
    "Weighted mode":             ("29", "1.56 (0.67-3.62)", "0.309"),
}
hit2 = 0
for r in t2.rows:
    if r.cells[0].text.strip() == "Tea intake" and "BioBank" in r.cells[1].text:
        meth = r.cells[2].text.strip()
        if meth in newvals:
            n, orci, p = newvals[meth]
            old = " | ".join(c.text.strip() for c in r.cells[3:6])
            cell_set(r.cells[3], n)
            cell_set(r.cells[4], orci)
            cell_set(r.cells[5], p)
            print("  S2 tea/BBJ %-26s %s -> %s | %s | %s" % (meth, old, n, orci, p))
            hit2 += 1

# ---- Table S3 ----
t3 = doc.tables[2]
print("\nTable S3 header:", [c.text.strip() for c in t3.rows[0].cells])
hit3 = 0
for r in t3.rows:
    if r.cells[0].text.strip() == "Tea intake" and "BioBank" in r.cells[1].text:
        old = " | ".join(c.text.strip() for c in r.cells[2:6])
        cell_set(r.cells[2], "53.7 (28)")
        cell_set(r.cells[3], "0.0024")
        cell_set(r.cells[4], "-0.0185 (0.0187)")
        cell_set(r.cells[5], "0.332")
        print("  S3 tea/BBJ:", old, "-> 53.7 (28) | 0.0024 | -0.0185 (0.0187) | 0.332")
        hit3 += 1

doc.save(SUP)
print("\nrows updated: S1=%d S2=%d S3=%d" % (hit1, hit2, hit3))

d2 = docx.Document(SUP)
print("\n--- verify ---")
show(d2.tables[0], 8)
print()
for r in d2.tables[1].rows:
    if r.cells[0].text.strip() == "Tea intake" and "BioBank" in r.cells[1].text:
        print("  ", " | ".join(c.text.strip() for c in r.cells))
print()
for r in d2.tables[2].rows:
    if r.cells[0].text.strip() == "Tea intake" and "BioBank" in r.cells[1].text:
        print("  ", " | ".join(c.text.strip() for c in r.cells))
