# -*- coding: utf-8 -*-
"""修 S4 脚注与 Methods 的 PRESSO 描述（新增两处后须同步）。"""
import docx, os

B = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013"


def set_text(p, t):
    p.runs[0].text = t
    for r in p.runs[1:]:
        r.text = ""


# 1) Methods
MS = os.path.join(B, "Manuscript.docx")
d = docx.Document(MS)
old = ("For exposures showing a nominal IVW association (P < 0.05) against the primary outcome, MR-PRESSO was "
       "applied to detect horizontal pleiotropy and outlier instruments.")
new = ("MR-PRESSO was applied to detect horizontal pleiotropy and outlier instruments for exposures showing a "
       "nominal IVW association (P < 0.05): coffee intake against the primary outcome, and, in the source concerned, "
       "sugar added to tea against FinnGen R13 and sugar added to coffee against AFGen 2018 (Table S4).")
hit = 0
for p in d.paragraphs:
    if old in p.text:
        set_text(p, p.text.replace(old, new))
        hit += 1
print("Methods matched:", hit)
assert hit == 1
d.save(MS)

# 2) S4 脚注
SUP = os.path.join(B, "Supplement.docx")
s = docx.Document(SUP)
old2 = ("MVMR, multivariable Mendelian randomization (IVW); outcome is atrial fibrillation (Nielsen 2018, European "
        "ancestry). MR-PRESSO was applied to coffee intake, the only exposure with a nominal IVW association "
        "against the primary outcome.")
new2 = ("MVMR, multivariable Mendelian randomization (IVW); outcome is atrial fibrillation (Nielsen 2018, European "
        "ancestry). MR-PRESSO was applied to coffee intake, the only exposure with a nominal IVW association against "
        "the primary outcome, and to the two exposures with nominal associations in other sources (sugar added to tea "
        "against FinnGen R13; sugar added to coffee against AFGen 2018). Where no variant exceeded the outlier "
        "threshold, only the raw estimate is reported and the outlier-corrected estimate is not estimable.")
hit = 0
for p in s.paragraphs:
    if old2 in p.text:
        set_text(p, p.text.replace(old2, new2))
        hit += 1
print("S4 note matched:", hit)
assert hit == 1
s.save(SUP)

# 3) 验证
d2 = docx.Document(MS)
for p in d2.paragraphs:
    if "MR-PRESSO was applied to detect" in p.text:
        i = p.text.find("MR-PRESSO was applied")
        print("\nMethods:", p.text[i:i + 300])
s2 = docx.Document(SUP)
for p in s2.paragraphs:
    if "MVMR, multivariable" in p.text:
        print("\nS4 note:", p.text[:430])
