import csv, json, math, os, re, urllib.request

TOKEN = None
for line in open(os.path.expanduser("~/.Renviron"), encoding="utf-8", errors="replace"):
    m = re.match(r"\s*OPENGWAS_JWT\s*=\s*['\"]?([^'\"\s]+)", line)
    if m:
        TOKEN = m.group(1)

def fetch(gwas_id, variants):
    body = json.dumps({"id": [gwas_id], "variant": variants}).encode()
    req = urllib.request.Request("https://api.opengwas.io/api/associations", data=body,
                                 headers={"Authorization": "Bearer " + TOKEN,
                                          "Content-Type": "application/json"})
    return json.loads(urllib.request.urlopen(req, timeout=120).read().decode())

def ivw(bx, sx, by, sy):
    w = [(b / s) ** 2 for b, s in zip(bx, sx)]
    # ratio estimate per variant (first-order weights)
    num = sum(wi * (b / s) ** 2 * 0 for wi, b, s in zip(w, bx, sx))
    # use standard IVW on Wald ratios
    wr = [b_o / b_e for b_e, b_o in zip(bx, by)]
    sw = [s_o / abs(b_e) for b_e, s_o in zip(bx, sy)]
    W = [1 / s ** 2 for s in sw]
    mu = sum(x * y for x, y in zip(wr, W)) / sum(W)
    se = math.sqrt(1 / sum(W))
    Q = sum(wv * (x - mu) ** 2 for x, wv in zip(wr, W))
    return mu, se, Q, len(wr)

rows = list(csv.DictReader(open(r"C:\a3work\dat_Tea_intake_ebi_a_GCST006414.csv",
                               encoding="utf-8", errors="replace")))
print("index SNPs:", len(rows))
rs = [r["SNP"] for r in rows]
got = {x["rsid"]: x for x in fetch("bbj-a-71", rs)}
print("recovered in bbj-a-71:", len(got))

COMP = {"A": "T", "T": "A", "C": "G", "G": "C"}
bx, sx, by, sy, used, drop = [], [], [], [], [], []
for r in rows:
    s = r["SNP"]
    if s not in got:
        drop.append((s, "absent"))
        continue
    o = got[s]
    ea_e = r["effect_allele.exposure"].upper()
    oa_e = r["other_allele.exposure"].upper()
    ea_o = (o.get("ea") or "").upper()
    oa_o = (o.get("nea") or "").upper()
    be = float(r["beta.exposure"]); se_e = float(r["se.exposure"])
    bo = float(o["beta"]); so = float(o["se"])
    if ea_o == ea_e and oa_o == oa_e:
        pass
    elif ea_o == oa_e and oa_o == ea_e:
        bo = -bo
    elif COMP.get(ea_o) == ea_e and COMP.get(oa_o) == oa_e:
        pass
    elif COMP.get(ea_o) == oa_e and COMP.get(oa_o) == ea_e:
        bo = -bo
    else:
        drop.append((s, f"allele mismatch {ea_e}/{oa_e} vs {ea_o}/{oa_o}"))
        continue
    if ea_e in "AT" and oa_e in "AT" and ea_e != oa_e:
        drop.append((s, "palindromic"))
        continue
    if ea_e in "CG" and oa_e in "CG" and ea_e != oa_e:
        drop.append((s, "palindromic"))
        continue
    bx.append(be); sx.append(se_e); by.append(bo); sy.append(so); used.append(s)

mu, se, Q, n = ivw(bx, sx, by, sy)
print("usable SNPs:", n)
print("dropped:", len(drop), drop[:8])
print("IVW OR = %.3f (%.3f-%.3f), P = %.4f, Q = %.2f (df %d), I2 = %.1f%%"
      % (math.exp(mu), math.exp(mu - 1.96 * se), math.exp(mu + 1.96 * se),
         2 * (1 - 0.5 * (1 + math.erf(abs(mu / se) / math.sqrt(2)))), Q, n - 1,
         max(0, (Q - (n - 1)) / Q) * 100))
print("\npaper (Table S2) BioBank Japan tea intake: OR 1.06 (0.52-2.14), P = 0.875, n = 36")
