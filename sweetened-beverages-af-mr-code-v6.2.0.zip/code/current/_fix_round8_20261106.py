# -*- coding: utf-8 -*-
"""第八轮：收口三处论证口径残留（两次独立复核一致后执行）"""
import docx, os

MS = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\Manuscript.docx"
d = docx.Document(MS)

# (段落锚点, 原文子串, 新文子串) —— 只在包含子串的单个 run 内替换，保留 run 结构与格式
PATCHES = [
    (
        "Beyond previous single-beverage",
        "Neither modelled adiposity at locus level, and under both instruments the variants "
        "we examined converge on FTO rather than on caffeine metabolism, so a shared adiposity "
        "pathway is a sufficient explanation for their positivity as well as for our own.",
        "Neither modelled adiposity at locus level. In our own instruments, the strongest "
        "coffee variants converge on FTO rather than on caffeine-metabolism loci, so "
        "adiposity-linked pleiotropy is a plausible and more parsimonious explanation for "
        "positive coffee estimates, including our own; we did not re-analyse the instruments "
        "used in those two studies.",
    ),
    (
        "Colocalization reinforced",
        "but shared a causal variant with AF at FTO (PP.H4 = 0.894; FinnGen R13 0.906)",
        "but shared a causal variant with AF at FTO in the two larger panels (PP.H4 = 0.894; "
        "FinnGen R13 0.906) and was inconclusive in the smaller AFGen 2018 panel (0.362)",
    ),
    (
        "As the locus-level component",
        ", the larger outcome GWAS yielded strong evidence of a shared causal variant "
        "(PP.H4 = 0.894; FinnGen R13 0.906), compatible with adiposity-linked pleiotropy",
        ", the two larger outcome GWAS yielded strong evidence of a shared causal variant "
        "(PP.H4 = 0.894; FinnGen R13 0.906), whereas the smaller AFGen 2018 panel was "
        "inconclusive (0.362); this pattern is compatible with adiposity-linked pleiotropy",
    ),
]

for anchor, old, new in PATCHES:
    para = next((p for p in d.paragraphs if anchor in p.text), None)
    assert para is not None, "anchor not found: " + anchor[:40]
    assert old in para.text, "old text not found: " + old[:50]
    # 定位包含完整 old 的单个 run（P070 的 old 落在 run6 内）
    hit = [r for r in para.runs if old in r.text]
    assert len(hit) == 1, "expected exactly 1 run containing old, got %d" % len(hit)
    hit[0].text = hit[0].text.replace(old, new)
    print("ok  patched:", anchor[:42])

d.save(MS)

# ---------------- 回读验证 ----------------
d2 = docx.Document(MS)
ps = [p.text for p in d2.paragraphs]
full = "\n".join(ps)

print()
print("=" * 84)
print("回读验证")
print("=" * 84)
assert "sufficient explanation" not in full, "M1 residue"
assert "under both instruments" not in full, "M1b residue"
assert "we did not re-analyse the instruments used in those two studies" in full, "M1 new missing"
assert "a plausible and more parsimonious explanation" in full, "M1 hedge missing"
assert "inconclusive in the smaller AFGen 2018 panel (0.362)" in full, "M2 new missing"
assert "whereas the smaller AFGen 2018 panel was inconclusive (0.362)" in full, "M3 new missing"
print("  三处替换全部到位，旧断言清零")
print("  0.362 出现次数:", full.count("0.362"))
print("  inconclusive 出现次数:", full.count("inconclusive"))
print("  more parsimonious 出现次数:", full.count("more parsimonious"))

def idx(s):
    return next(i for i, t in enumerate(ps) if t.strip() == s)
abst = len(" ".join(ps[6:9]).split())
body = sum(len(ps[k].split()) for k in range(idx("Introduction"), idx("Declarations")))
print("  摘要:", abst, "词 | 正文:", body, "词 | 段落:", len(ps))

i_ref = idx("References")
refs = [t.strip() for t in ps[i_ref + 1:] if t.strip()]
print("  参考文献:", len(refs), "条")

for anchor, _, _ in PATCHES:
    t = next(p for p in ps if anchor in p)
    j = t.find("Neither modelled") if anchor.startswith("Beyond") else (t.find("but shared a causal") if anchor.startswith("Colocalization") else t.find(", the two larger outcome"))
    print()
    print("  --- %s ---" % anchor[:38])
    print("  " + t[max(0, j - 40):j + 330].replace("\n", " "))
print("\nDONE")
