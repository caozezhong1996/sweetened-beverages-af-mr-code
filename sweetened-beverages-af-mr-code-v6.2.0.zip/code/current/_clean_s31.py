import docx
from docx.shared import Pt

SUP = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\Supplement.docx"
doc = docx.Document(SUP)

t31 = doc.tables[-1]
hdr = [c.text.strip() for c in t31.rows[0].cells]
print("S31 header:", hdr)

# 茶行：BAJ proxy 10 -> 3, unavailable — -> 3, retained 29
fixed = 0
for r in t31.rows:
    if r.cells[0].text.strip() == "Tea intake":
        vals = [c.text.strip() for c in r.cells]
        print("before:", " | ".join(vals))
        # 列序: Exposure, Index, AFGen rec, AFGen proxied, AFGen unavail, BBJ rec, BBJ proxied, BBJ unavail, BBJ retained
        for idx, new in ((6, "3"), (7, "3"), (8, "29 \u2020")):
            c = r.cells[idx]
            c.text = ""
            run = c.paragraphs[0].add_run(new)
            run.font.size = Pt(7.5)
        fixed += 1
print("rows fixed:", fixed)

NEW_NOTE = ("\u2020 BioBank Japan tea panel: 26 of the 32 index variants were recovered directly and three "
            "further variants were retained through proxy search at the package default "
            "(TwoSampleMR::extract_outcome_data, proxies = TRUE, rsq \u2265 0.8), giving 29 variants in total; "
            "three index variants could not be recovered.")

hit = 0
for p in doc.paragraphs:
    if p.text.startswith("\u2020 The BioBank Japan tea panel") or p.text.startswith("\u2020 BioBank Japan tea panel"):
        if p.runs:
            p.runs[0].text = NEW_NOTE
            for r in p.runs[1:]:
                r.text = ""
        hit += 1
print("footnote rewritten:", hit)

doc.save(SUP)

d2 = docx.Document(SUP)
for r in d2.tables[-1].rows:
    if r.cells[0].text.strip() == "Tea intake":
        v = [c.text.strip() for c in r.cells]
        print("\nS31 tea row:", " | ".join(v))
        n_idx = int(v[1]); rec = int(v[5]); px = int(v[6]); un = int(v[7]); ret = int(v[8].replace("\u2020", "").strip())
        print("  check: rec+proxy = %d, retained = %d -> %s" % (rec + px, ret, "OK" if rec + px == ret else "MISMATCH"))
        print("  check: idx-retained = %d, unavailable = %d -> %s" % (n_idx - ret, un, "OK" if n_idx - ret == un else "MISMATCH"))
for p in d2.paragraphs:
    if p.text.startswith("\u2020"):
        print("\nfootnote:", p.text)
