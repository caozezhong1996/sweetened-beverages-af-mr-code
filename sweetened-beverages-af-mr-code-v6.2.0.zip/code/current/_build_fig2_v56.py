# -*- coding: utf-8 -*-
"""Figure 2 (v53): forest plot rebuilt at AHA print width.

Canvas = exact final print size (17.4 cm), so every font size below IS the
printed point size. Layout: 2 rows x 3 columns of small multiples, one panel
per outcome source, shared exposure axis, labels only on the left column.
Margins and title sizes are derived from measured text extents, not guessed.
"""
import csv
import io
import math
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from matplotlib.textpath import TextPath
from matplotlib.ticker import FixedFormatter, NullLocator

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

M = r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
NEW = os.path.join(M, "06_升级分析_v4", "results")
OLD = os.path.join(M, "03_结果数据_mr_results")
OUTDIR = r"C:\Users\64915\WorkBuddy\2026-10-30-20-42-58"
A3 = r"C:\a3work"

CM = 1 / 2.54
W_IN, H_IN = 17.4 * CM, 15.6 * CM
DPI = 600


def text_w(text, size, weight="normal"):
    """Width in inches of the widest line."""
    fp = FontProperties(family="DejaVu Sans", size=size, weight=weight)
    return max(TextPath((0, 0), ln, prop=fp).get_extents().width
               for ln in text.split("\n")) / 72.0


def fit_size(text, size, max_w, weight="normal"):
    s = size
    while s > 5 and text_w(text, s, weight) > max_w:
        s -= 0.1
    return round(s, 1)


EXPO = [
    ("Sugar_added_to_tea", "Sugar added to tea"),
    ("Sugar_added_to_coffee", "Sugar added to coffee"),
    ("Fizzy_drink_intake_SSB", "Fizzy drinks (SSB)"),
    ("Low_calorie_drink_intake_ASB", "Low-calorie drinks (ASB)"),
    ("Artificial_sweetener_added_to_tea", "Sweetener added to tea"),
    ("Coffee_intake", "Coffee intake"),
    ("Tea_intake", "Tea intake"),
]
META = [("caffeine", "Plasma caffeine"), ("paraxanthine", "Plasma paraxanthine"),
        ("theobromine", "Plasma theobromine")]


def ivw(path):
    if not os.path.exists(path):
        return None
    for r in csv.DictReader(open(path, encoding="utf-8")):
        if r["method"] == "Inverse variance weighted":
            return dict(b=float(r["b"]), se=float(r["se"]), p=float(r["pval"]))
    return None


def bio_est(path):
    """Return IVW when available, otherwise the single-instrument Wald ratio."""
    if not os.path.exists(path):
        return None
    rows = list(csv.DictReader(open(path, encoding="utf-8")))
    for method in ("Inverse variance weighted", "Wald ratio"):
        for r in rows:
            if r["method"] == method:
                return dict(b=float(r["b"]), se=float(r["se"]), p=float(r["pval"]))
    return None


yuan = {}
for r in csv.DictReader(open(os.path.join(A3, "yuan2025_mr.csv"), encoding="utf-8")):
    if r["method"] == "Inverse variance weighted":
        yuan[r["exposure"]] = r
YUAN_KEY = {"Sugar_added_to_tea": "Sugar added to tea",
            "Sugar_added_to_coffee": "Sugar added to coffee",
            "Fizzy_drink_intake_SSB": "Fizzy drinks (SSB)",
            "Low_calorie_drink_intake_ASB": "Low-calorie drinks (ASB)",
            "Artificial_sweetener_added_to_tea": "Sweetener added to tea",
            "Coffee_intake": "Coffee intake", "Tea_intake": "Tea intake"}


def get_yuan(t):
    k = YUAN_KEY.get(t)
    if not k or k not in yuan:
        return None
    lo, hi = float(yuan[k]["lo"]), float(yuan[k]["hi"])
    return dict(b=math.log(float(yuan[k]["OR"])),
                se=(math.log(hi) - math.log(lo)) / (2 * 1.96), p=float(yuan[k]["p"]))


SOURCES = {
    "nielsen": ("Nielsen 2018 (EUR)\nprimary", "#B33A3A", "o", True,
                lambda t: ivw(os.path.join(NEW, f"mr_{t}_ebi_a_GCST006414.csv"))),
    "finn": ("FinnGen R13 (EUR)\nreplication", "#1A5276", "s", True,
             lambda t: ivw(os.path.join(NEW, f"mr_{t}_finngen_R13.csv"))),
    "yuan": ("Yuan 2025 (EUR)\nreplication, UKB-free", "#145A86", "D", True, get_yuan),
    "meta": ("EUR meta-analysis\nNielsen + FinnGen R13", "#0E6655", "P", True, None),
    "afgen": ("AFGen 2018 (EUR)\nsensitivity", "#8C8C8C", "^", False,
              lambda t: (ivw(os.path.join(OLD, f"mr_{t}_ebi_a_GCST006061.csv"))
                         or ivw(os.path.join(OLD, f"mr_{t}.csv")))),
    "bbj": ("BioBank Japan (EAS)\ncontext", "#7A4E7E", "v", False,
            lambda t: ivw(os.path.join(OLD, f"mr_{t}_bbj_a_71.csv"))),
}

data = {k: {} for k in SOURCES}
for tag, _ in EXPO:
    for key in ("nielsen", "finn", "afgen", "bbj"):
        r = SOURCES[key][4](tag)
        if r:
            data[key][tag] = r
    a, b = data["nielsen"].get(tag), data["finn"].get(tag)
    if a and b:
        w1, w2 = 1 / a["se"] ** 2, 1 / b["se"] ** 2
        bb = (a["b"] * w1 + b["b"] * w2) / (w1 + w2)
        se = math.sqrt(1 / (w1 + w2))
        data["meta"][tag] = dict(b=bb, se=se, p=math.erfc(abs(bb / se) / math.sqrt(2)))
    r = get_yuan(tag)
    if r:
        data["yuan"][tag] = r

for row in csv.DictReader(open(os.path.join(NEW, "biomarker_meta_summary.csv"), encoding="utf-8")):
    data["meta"]["bio_" + row["exposure"]] = dict(
        b=math.log(float(row["or"])),
        se=(math.log(float(row["hi"])) - math.log(float(row["lo"]))) / (2 * 1.96),
        p=float(row["p"]))

# Source-specific biomarker estimates already reported in Table S25.
for key, _ in META:
    for source, stem in (("nielsen", "nielsen"), ("finn", "finngen")):
        r = bio_est(os.path.join(NEW, f"mr_biomarker_{key}_{stem}.csv"))
        if r:
            data[source]["bio_" + key] = r

# ---------- y layout ----------
BAR, GAP = 1.0, 0.85
ys, ylabels = {}, []
y = 0.0
for tag, lab in EXPO:
    ys[tag] = y
    ylabels.append((y, lab))
    y += BAR
y += GAP
sep_y = y - GAP / 2
for key, lab in META:
    ys["bio_" + key] = y
    ylabels.append((y, lab))
    y += BAR
Y_MIN, Y_MAX = -0.62, y - BAR + 0.62

# ---------- measured margins ----------
LBL_SIZE = 9.4
lbl_w = max(text_w(l, LBL_SIZE) for _, l in ylabels)
RIGHT_IN = 0.06
LEFT_IN = lbl_w + 0.16                     # label + tick pad + half marker
LEFT = LEFT_IN / W_IN
RIGHT = 1 - RIGHT_IN / W_IN

GAPX_IN, GAPY_IN = 0.26, 0.95
TOP_IN, BOTTOM_IN = 0.66, 0.70             # room for titles / x label
colw = (RIGHT - LEFT) - 2 * GAPX_IN / W_IN
colw = colw / 3
rowh = (1 - TOP_IN / H_IN - BOTTOM_IN / H_IN) - GAPY_IN / H_IN
rowh = rowh / 2
TOP = 1 - TOP_IN / H_IN
BOTTOM = BOTTOM_IN / H_IN

# ---------- figure ----------
plt.rcParams.update({"font.family": "DejaVu Sans", "axes.linewidth": 0.6})
fig = plt.figure(figsize=(W_IN, H_IN), dpi=DPI)

ORDER = [["nielsen", "finn", "yuan"], ["meta", "afgen", "bbj"]]
XLIM = (0.18, 4.2)

for ri, rowkeys in enumerate(ORDER):
    for ci, key in enumerate(rowkeys):
        title, col, mk, bold, _ = SOURCES[key]
        x0 = LEFT + ci * (colw + GAPX_IN / W_IN)
        y0 = TOP - (ri + 1) * rowh - ri * GAPY_IN / H_IN
        ax = fig.add_axes([x0, y0, colw, rowh])
        ax.set_xscale("log")
        ax.set_xlim(*XLIM)
        ax.set_ylim(Y_MAX, Y_MIN)

        ax.axvline(1, color="#555555", lw=0.7, ls=(0, (3, 2)), zorder=1)
        ax.axhline(sep_y, color="#cccccc", lw=0.6, ls=":", zorder=1)

        for tag, yv in ys.items():
            r = data[key].get(tag)
            if r is None:
                if tag.startswith("bio_"):
                    ax.text(0.315, yv, "n.e.", fontsize=7.4, color="#b0b0b0",
                            va="center", ha="left")
                continue
            or_ = math.exp(r["b"])
            lo_raw = math.exp(r["b"] - 1.96 * r["se"])
            hi_raw = math.exp(r["b"] + 1.96 * r["se"])
            lo, hi = max(lo_raw, XLIM[0] * 1.004), min(hi_raw, XLIM[1] * 0.996)
            sig = r["p"] < 0.05
            ax.plot([lo, hi], [yv, yv], color=col, lw=1.1,
                    solid_capstyle="butt", zorder=2)
            if hi_raw > XLIM[1]:                       # truncated upper limit
                ax.plot([hi], [yv], marker=">", ms=2.6, mfc=col, mec=col, ls="", zorder=2)
            if lo_raw < XLIM[0]:
                ax.plot([lo], [yv], marker="<", ms=2.6, mfc=col, mec=col, ls="", zorder=2)
            ax.plot([or_], [yv], marker=mk, ms=4.2, ls="", zorder=3,
                    mfc=col if sig else "white", mec=col, mew=0.9)

        ax.set_xticks([0.2, 0.5, 1, 2, 4])
        ax.xaxis.set_major_formatter(FixedFormatter(["0.2", "0.5", "1", "2", "4"]))
        ax.xaxis.set_minor_locator(NullLocator())
        ax.tick_params(axis="x", labelsize=9, length=2.2, pad=1.4)
        ax.set_yticks([v for v, _ in ylabels])
        if ci == 0:
            ax.set_yticklabels([l for _, l in ylabels], fontsize=LBL_SIZE)
            ax.tick_params(axis="y", length=0, pad=2.5)
        else:
            ax.set_yticklabels([])
            ax.tick_params(axis="y", length=0)
        for side in ("top", "right"):
            ax.spines[side].set_visible(False)
        ax.spines["left"].set_visible(ci == 0)
        tsz = fit_size(title, 9.0, colw * W_IN - 0.04, "bold" if bold else "normal")
        ax.set_title(title, fontsize=tsz, color=col, pad=3.5, linespacing=1.25,
                     fontweight="bold" if bold else "normal", loc="left")

CTR = 0.5 * (LEFT + RIGHT)
note1 = ("Filled marker: P < 0.05.  Whiskers: 95% CI; arrows = truncated.  "
         "Metabolites shown where estimated; n.e. = not estimated.")
note_sz = fit_size(note1, 8.2, W_IN - 0.12)
fig.text(0.5, 0.972, note1, ha="center", va="center", color="#555555", fontsize=note_sz)
xl = "Odds ratio per unit higher beverage intake or per SD higher plasma metabolite (IVW, log scale)"
xl_sz = max(9.0, fit_size(xl, 9.6, W_IN - 0.12))
fig.text(0.5, 0.028, xl, ha="center", va="center", fontsize=xl_sz)

out = os.path.join(OUTDIR, "Figure2_Forest_v56_300dpi.png")
fig.savefig(out, dpi=DPI, facecolor="white")
plt.close(fig)

print(f"saved: {out}")
print(f"canvas {W_IN*2.54:.2f} x {H_IN*2.54:.2f} cm @{DPI} dpi ({os.path.getsize(out)/1024:.0f} KB)")
print(f"left margin {LEFT_IN:.2f} in (label {lbl_w:.2f} in)   panel {colw*W_IN:.2f} in wide")
for name, s, mx in [("note", note1, W_IN - 0.12), ("axis title", xl, W_IN - 0.12)]:
    print(f"  {name}: {text_w(s, note_sz if 'note' in name else xl_sz):.2f} in needed, "
          f"{mx:.2f} in available -> {'fits' if text_w(s, note_sz if 'note' in name else xl_sz) <= mx else 'OVERFLOW'}")
