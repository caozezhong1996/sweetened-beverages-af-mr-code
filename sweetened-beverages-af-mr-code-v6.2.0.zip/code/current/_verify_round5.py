# -*- coding: utf-8 -*-
import docx, re
B = r'C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013'
TITLE = 'Adiposity-Linked Pleiotropy in the Coffee–Atrial Fibrillation Signal: A Two-Sample Mendelian Randomization Study'
m=docx.Document(B+r'\Manuscript.docx'); s=docx.Document(B+r'\Supplement.docx')
c=docx.Document(B+r'\Cover_Letter.docx'); h=docx.Document(B+r'\Highlights.docx')
mp=[p.text for p in m.paragraphs]; sp=[p.text for p in s.paragraphs]
full='\n'.join(mp); sfull='\n'.join(sp); cfull='\n'.join(p.text for p in c.paragraphs); hfull='\n'.join(p.text for p in h.paragraphs)
for tb in m.tables:
    for r in tb.rows:
        for cell in r.cells: full+='\n'+cell.text
for tb in s.tables:
    for r in tb.rows:
        for cell in r.cells: sfull+='\n'+cell.text
checks=[]
def ck(label,cond,detail=''): checks.append((label,bool(cond),detail))
def idx(x): return next(i for i,t in enumerate(mp) if t.strip()==x)

ck('主稿标题',mp[0]==TITLE)
ck('补充标题',sp[1]==TITLE)
ck('投稿信标题',TITLE in cfull)
ck('摘要249词',len(' '.join(mp[6:9]).split())==249,len(' '.join(mp[6:9]).split()))
ck('正文9384词',sum(len(mp[k].split()) for k in range(idx('Introduction'),idx('Declarations')))==9383)
ck('摘要结论仍未过度','more compatible with adiposity-linked pleiotropy' in mp[8] and 'although neither was excluded' in mp[8])
ck('摘要FTO不确定','0.362' in mp[7] and 'AFGen was inconclusive' in mp[7])
ck('摘要失败口径','did not meet the pre-specified consistency criteria' in mp[7])
ck('摘要无every失败','failed every' not in full)
ck('P103 FTO不确定',any('smaller AFGen 2018 panel inconclusive' in t for t in mp))
ck('CP含0.362','inconclusive in AFGen' in full and '0.362' in full)
ck('投稿信含0.362','0.362' in cfull)
ck('方向计数10/15',full.count('Ten of the fifteen')==1 and 'ten moved toward the null and five moved away' in full)
ck('方向旧句清零','all moved toward the null' not in full and 'all of which moved toward' not in full)
ck('abolished清零','abolished' not in full)
ck('亚组差异限定','between-subgroup difference was not statistically significant' in full)
ck('路线排序新表述','statistically significant exposure-wide MR estimate' in full and 'These lines are ordered by how little they depend on statistical power' not in full)
ck('共定位仍依赖区域功效','remains dependent on regional association strength' in full)
ck('茶零口径','uninformative rather than confirmatory' in full and 'extend that literature causally' not in full)
ck('Highlights 最多两簇','at most two independent clusters' in hfull and 'two independent outcome clusters' not in hfull)
ck('Highlights FTO不确定','inconclusive in AFGen' in hfull)
ck('P095两条主线','rests on two primary lines' in full and 'rests on three lines' not in full)
ck('P105计数','Further observations are consistent' in full and 'Three further observations' not in full)
ck('ASB限定','to our knowledge' in mp[6] and 'specifically' in mp[6])
ck('CL ASB限定','to our knowledge, no Mendelian randomization study has estimated intake specifically' in cfull)
ck('S30表题七暴露','Table S30. Per-variant instrument-level estimates for all seven exposures' in sfull)
ck('S9 249词','249 words' in sfull and '247 words' not in sfull and '231 words' not in sfull)
ck('S9软件版本','R 4.6.1, TwoSampleMR 0.7.9, MRPRESSO 1.0, coloc 5.2.3' in sfull)
ck('S9范围','Tables S12–S31' in sfull)
ck('S9旧标题清零','Two-Sample and Multivariable' not in sfull)
ck('补充目录S30S31','Table S30 per-variant' in sp[2] and 'Table S31 recovery' in sp[2])
ck('Figure1不再F>20','per-variant F met the selection-implied' in open('_build_fig1_v56.py',encoding='utf-8').read() and 'per-variant F > 20' not in open('_build_fig1_v56.py',encoding='utf-8').read())
ck('Figure2尺度说明','per SD higher plasma metabolite' in open('_build_fig2_v56.py',encoding='utf-8').read())
ck('主稿元数据',m.core_properties.title==TITLE)
ck('补充元数据',s.core_properties.title=='Supplemental material: '+TITLE)
ck('无占位符','{{' not in full+sfull)
# refs
i=next(i for i,t in enumerate(mp) if t.strip()=='References')
refs=[t.strip() for t in mp[i+1:] if t.strip()]
BL=re.compile(r'\[([0-9,\s\u2013-]+)\]'); order=[]
for t in mp[:i]:
    for match in BL.finditer(t):
        for part in re.split(r'[,\s]+',match.group(1)):
            if not part: continue
            if re.search(r'[\u2013-]',part):
                a,b=re.split(r'[\u2013-]',part)
                if a.isdigit() and b.isdigit():
                    for n in range(int(a),int(b)+1):
                        if n not in order: order.append(n)
            elif part.isdigit():
                n=int(part)
                if n not in order: order.append(n)
ck('57条严格递增',len(refs)==57 and order==list(range(1,58)),'%d/%d'%(len(refs),len(order)))
ck('新增Kim文献','56. Kim M' in refs[55] and '42266723' not in refs[55])
ck('新增Yang文献','57. Yang M' in refs[56])
ck('新段引用56-57',any('These bounds are consistent' in t and '[56]' in t and '[57]' in t for t in mp))
used={int(x) for x in re.findall(r'Table S(\d+)',full)}
defined={int(x) for x in re.findall(r'Table S(\d+)\.',sfull)}
ck('S1-S31闭合',used==defined==set(range(1,32)),'%d/%d'%(len(used),len(defined)))
expected=[('The contamination-mixture estimator','manuscript ref 31'),('CAUSE (Morrison et al.','manuscript ref 33'),('Network (two-step) mediation MR','manuscript ref 28'),('MRlap (Mounier & Kutalik','manuscript ref 34'),('Early-onset AF (onset before age 66)','manuscript ref 54'),('MR-RAPS (Zhao et al.','manuscript ref 32'),('Conditional F statistics quantify','manuscript ref 27'),('Exposures were plasma caffeine','manuscript ref 25'),('Exposures were plasma caffeine','manuscript ref 42')]
for anchor,ref in expected:
    ps=[p for p in sp if anchor in p]
    ck('表注 '+ref, len(ps)==1 and ref in ps[0])

fails=[x for x in checks if not x[1]]
for label,ok,detail in checks: print(('PASS' if ok else 'FAIL'),label,detail)
print('\nSUMMARY',len(checks)-len(fails),'/',len(checks),'PASS')
if fails: raise SystemExit(1)
