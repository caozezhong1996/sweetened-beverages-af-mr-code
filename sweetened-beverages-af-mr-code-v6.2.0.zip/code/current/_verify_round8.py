# -*- coding: utf-8 -*-
"""第八轮改后终检：三处收口 + 周边叙事同步 + 未破坏项"""
import docx, os, re, zipfile

B = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013"
res = []
def ck(name, cond, note=""):
    res.append(cond)
    print(("PASS " if cond else "FAIL ") + name + (("  [" + str(note) + "]") if note != "" else ""))

m = docx.Document(os.path.join(B, "Manuscript.docx"))
ps = [p.text for p in m.paragraphs]
full = "\n".join(ps)
for tb in m.tables:
    for r in tb.rows:
        for c in r.cells: full += "\n" + c.text

s = docx.Document(os.path.join(B, "Supplement.docx"))
sfull = "\n".join(p.text for p in s.paragraphs)
for tb in s.tables:
    for r in tb.rows:
        for c in r.cells: sfull += "\n" + c.text

texts = {}
for f in ["Manuscript.docx", "Supplement.docx", "Cover_Letter.docx", "Highlights.docx"]:
    d = docx.Document(os.path.join(B, f))
    t = "\n".join(p.text for p in d.paragraphs)
    for tb in d.tables:
        for r in tb.rows:
            for c in r.cells: t += "\n" + c.text
    texts[f] = t
texts["README_投稿包.md"] = open(os.path.join(B, "README_投稿包.md"), encoding="utf-8").read()

print("=" * 86)
print("A. 本轮三处收口")
print("=" * 86)
ck("1 旧 sufficient explanation 清零", all("sufficient explanation" not in t for t in texts.values()))
ck("2 旧 under both instruments 清零", all("under both instruments" not in t for t in texts.values()))
ck("3 新增未重分析别人工具的披露", "we did not re-analyse the instruments used in those two studies" in full)
ck("4 新增更简约解释限定", "a plausible and more parsimonious explanation" in full)
ck("5 P100 补 AFGen 0.362", "inconclusive in the smaller AFGen 2018 panel (0.362)" in full)
ck("6 P070 补 AFGen 0.362", "whereas the smaller AFGen 2018 panel was inconclusive (0.362)" in full)
ck("7 0.362 出现次数>=5", full.count("0.362") >= 5, full.count("0.362"))
ck("8 无 sufficient 强断言残留", full.count("sufficient") == 0, full.count("sufficient"))

print()
print("=" * 86)
print("B. 未破坏既有结论")
print("=" * 86)
def idx(x): return next(i for i, t in enumerate(ps) if t.strip() == x)
i_ref = idx("References")
refs = [t.strip() for t in ps[i_ref + 1:] if t.strip()]
order, first = [], {}
for pi, t in enumerate(ps[:i_ref]):
    for mt in re.finditer(r"\[([0-9,\s\u2013-]+)\]", t):
        for part in re.split(r"[,\s]+", mt.group(1)):
            if not part: continue
            if re.search(r"[\u2013-]", part):
                a, b = re.split(r"[\u2013-]", part)
                if not (a.isdigit() and b.isdigit()): continue
                nums = range(int(a), int(b) + 1)
            elif part.isdigit(): nums = [int(part)]
            else: continue
            for n in nums:
                if n not in first: first[n] = pi; order.append(n)
ck("9 57 条严格 1-57", len(refs) == 57 and order == list(range(1, 58)), "%d/%d" % (len(refs), len(order)))
abst = len(" ".join(ps[6:9]).split())
body = sum(len(ps[k].split()) for k in range(idx("Introduction"), idx("Declarations")))
ck("10 摘要 249 词", abst == 249, abst)
ck("11 正文 >9400 词", body > 9400, body)
ck("12 摘要仍含 AFGen inconclusive", "inconclusive in AFGen (0.362)" in ps[7])
ck("13 摘要仍含 13-47%", "13\u201347%" in ps[7])
ck("14 摘要仍含 1.21-1.38", "1.21\u20131.38" in ps[7])
ck("15 Q=2.87 全精度", "Cochran Q = 2.87" in full and "Q = 2.97" not in full)
ck("16 可解释零=三", "three provide interpretable null estimates" in full and "four provide interpretable" not in full)
ck("17 标题未变", ps[0].strip().startswith("Pleiotropy at the FTO Locus"))
ck("18 无占位符", full.count("{{") == 0)

# 补充表闭合
def_s = {int(x) for x in re.findall(r"Table S(\d+)\.", sfull)}
used = {int(x) for x in re.findall(r"Table S(\d+)", full)}
ck("19 S1-S31 闭合", min(def_s) == 1 and max(def_s) == 31 and used <= def_s, "def %d used %d" % (len(def_s), len(used)))

print()
print("=" * 86)
print("C. 核心属性 / 页眉 / 短题")
print("=" * 86)
ck("20 核心属性新题", docx.Document(os.path.join(B, "Manuscript.docx")).core_properties.title.startswith("Pleiotropy at the FTO Locus"))
z = zipfile.ZipFile(os.path.join(B, "Manuscript.docx"))
hdr = ""
for n in z.namelist():
    if n.startswith("word/header"):
        hdr += z.read(n).decode("utf-8", "replace")
ck("21 页眉无旧 adiposity loci", "adiposity loci" not in hdr)
ck("22 Short title 已同步", any("Short title: Pleiotropy at the FTO locus" in p for p in ps))

print()
print("=" * 86)
print("D. 周边叙事同步（改正文后必扫）")
print("=" * 86)
for f, t in texts.items():
    hits = sum(t.count(k) for k in ["sufficient explanation", "under both instruments", "Largely Account", "carried by adiposity"])
    ck("23 %-22s 强断言残留=%d" % (f, hits), hits == 0)

print("\n%d/%d PASS" % (sum(1 for x in res if x), len(res)))
