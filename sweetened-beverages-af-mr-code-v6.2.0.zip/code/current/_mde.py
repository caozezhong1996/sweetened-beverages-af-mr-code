# -*- coding: utf-8 -*-
"""从 CI 反推 SE，计算 MDE（80% power, 双侧 α=0.05）。"""
import csv, math, os
import docx

Z = 1.959963985
ZB = 0.8416212336
K = Z + ZB  # 2.801585

A3 = r"C:\a3work"
B = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013"


def se_from_ci(lo, hi, log=True):
    if log:
        return (math.log(hi) - math.log(lo)) / (2 * Z)
    return (hi - lo) / (2 * Z)


print("=" * 84)
print("A. 脂肪剔除后的 MDE —— adiposity_sensitivity_all_cohorts.csv")
print("=" * 84)
p = os.path.join(A3, "adiposity_sensitivity_all_cohorts.csv")
rows = list(csv.DictReader(open(p, encoding="utf-8-sig")))
print("%-12s %-38s %5s %8s %8s %8s %8s" % ("source", "exposure", "n", "OR", "MDE_all", "n_clean", "MDE_clean"))
out = []
for r in rows:
    try:
        orall = float(r["OR"]); lo = float(r["lo"]); hi = float(r["hi"])
        orc = float(r["OR_clean"]); loc = float(r["lo_clean"]); hic = float(r["hi_clean"])
    except Exception:
        continue
    se_all = se_from_ci(lo, hi)
    se_cln = se_from_ci(loc, hic)
    mde_all = math.exp(K * se_all)
    mde_cln = math.exp(K * se_cln)
    out.append((r["outcome"], r["exposure"], r["n"], orall, mde_all, r["n_clean"], orc, mde_cln))
    print("%-12s %-38s %5s %8.3f %8.3f %8s %8.3f" % (r["outcome"], r["exposure"][:38], r["n"], orall, mde_all,
                                                     r["n_clean"], mde_cln))

print()
print("咖啡三源的 MDE 变化：")
for o in out:
    if "Coffee intake" in o[1]:
        print("  %-10s all %s: MDE %.2f → clean %s: MDE %.2f  (OR %.3f → %.3f)" %
              (o[0], o[2], o[4], o[5], o[7], o[3], o[6]))

print()
print("=" * 84)
print("B. 反向 MR 的 MDE —— 表 S7（beta 尺度）")
print("=" * 84)
s = docx.Document(B + r"\Supplement.docx")
tb = None
for t in s.tables:
    hdr = [c.text.strip() for c in t.rows[0].cells]
    if any("Reverse" in h for h in hdr):
        tb = t
        break
print("  header:", [c.text.strip() for c in tb.rows[0].cells])
import re
for r in tb.rows[1:]:
    v = [c.text.strip() for c in r.cells]
    m = re.search(r"\(([-\d.]+) to ([-\d.]+)\)", v[3])
    if not m:
        continue
    lo, hi = float(m.group(1)), float(m.group(2))
    se = se_from_ci(lo, hi, log=False)
    mde = math.exp(K * se) if se > 0 else float("nan")
    print("  %-38s beta CI [%+.4f, %+.4f]  SE %.4f  MDE OR %.2f" % (v[0][:38], lo, hi, se, mde))
