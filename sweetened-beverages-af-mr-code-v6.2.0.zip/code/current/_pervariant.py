import csv, math, os, glob

BASE = r"C:\a3work"
OUTDIR = r"C:\Users\64915\WorkBuddy\2026-10-30-20-42-58"

EXPO = {
    "Sugar added to tea": "Sugar added to tea",
    "Sugar added to coffee": "Sugar added to coffee",
    "Fizzy drink intake (SSB)": "Fizzy drink intake (SSB)",
    "Low-calorie drink intake (ASB)": "Low-calorie drink intake (ASB)",
    "Artificial sweetener added to tea": "Artificial sweetener added to tea",
    "Coffee intake": "Coffee intake",
    "Tea intake": "Tea intake",
}
S1 = {  # Table S1 retained counts: Nielsen/AFGen/FinnGenR13/BBJ
    "Sugar added to tea": (17, 17, 16, 11),
    "Sugar added to coffee": (15, 15, 15, 11),
    "Fizzy drink intake (SSB)": (8, 8, 8, 4),
    "Low-calorie drink intake (ASB)": (17, 17, 16, 8),
    "Artificial sweetener added to tea": (14, 14, 14, 6),
    "Coffee intake": (34, 34, 34, 32),
    "Tea intake": (32, 32, 32, 36),
}

# 主暴露（ukb-b-5237 咖啡）用于补齐 Yuan 缺失的 se/pos/等位基因
main = {}
for r in csv.DictReader(open(os.path.join(BASE, "dat_Coffee_intake_ebi_a_GCST006414.csv"),
                             encoding="utf-8", errors="replace")):
    main[r["SNP"]] = r

rows_out = []
counts = {}
files = sorted(glob.glob(os.path.join(BASE, "dat_*.csv")))
for f in files:
    bn = os.path.basename(f)
    body = bn[4:-4]
    if body.endswith("_ebi_a_GCST006414"):
        expo_raw, src = body[:-len("_ebi_a_GCST006414")], "Nielsen 2018"
    elif body.endswith("_finngen_R13"):
        expo_raw, src = body[:-len("_finngen_R13")], "FinnGen R13"
    elif body.endswith("_yuan"):
        expo_raw, src = body[:-len("_yuan")], "Yuan 2025"
    else:
        continue
    expo_raw = expo_raw.replace("_", " ")
    # 还原为论文用名
    mapping = {
        "Sugar added to tea": "Sugar added to tea",
        "Sugar added to coffee": "Sugar added to coffee",
        "Fizzy drink intake SSB": "Fizzy drink intake (SSB)",
        "Low calorie drink intake ASB": "Low-calorie drink intake (ASB)",
        "Artificial sweetener added to tea": "Artificial sweetener added to tea",
        "Coffee intake": "Coffee intake",
        "Tea intake": "Tea intake",
    }
    expo = mapping.get(expo_raw, expo_raw)

    recs = list(csv.DictReader(open(f, encoding="utf-8", errors="replace")))
    counts[(expo, src)] = len(recs)
    for r in recs:
        snp = r["SNP"]
        m = main.get(snp, {})
        bx = float(r["beta.exposure"])
        sx = float(r["se.exposure"]) if r.get("se.exposure") else float(m.get("se.exposure", "nan"))
        F = float(r["F_stat"]) if r.get("F_stat") else (bx / sx) ** 2
        by = float(r["beta.outcome"])
        sy = float(r["se.outcome"])
        ea = r.get("effect_allele.exposure") or m.get("effect_allele.exposure", "")
        oa = r.get("other_allele.exposure") or m.get("other_allele.exposure", "")
        eaf = r.get("eaf.exposure") or m.get("eaf.exposure", "")
        chrom = r.get("chr") or m.get("chr", "")
        pos = r.get("pos") or m.get("pos", "")
        wr = by / bx
        sewr = sy / abs(bx)
        rows_out.append(dict(exposure=expo, source=src, snp=snp,
                             loc=f"{chrom}:{pos}" if chrom else "",
                             alleles=f"{ea}>{oa}" if ea else "",
                             eaf=eaf, bx=bx, sx=sx, F=F, by=by, sy=sy,
                             or_=math.exp(wr),
                             lo=math.exp(wr - 1.96 * sewr),
                             hi=math.exp(wr + 1.96 * sewr)))

# --- 交叉核对 S1 retained ---
print("%-38s %-14s %-8s %-8s %s" % ("exposure", "source", "dat_n", "S1_n", "match"))
for expo, (n1, n2, n3, n4) in S1.items():
    for src, ref in (("Nielsen 2018", n1), ("FinnGen R13", n3), ("Yuan 2025", None)):
        got = counts.get((expo, src))
        if got is None and src == "Yuan 2025":
            got = counts.get((expo, "Yuan 2025"))
            if got is None:
                continue
        if got is None:
            continue
        if ref is None:
            print("%-38s %-14s %-8d %-8s -" % (expo, src, got, "n/a"))
        else:
            print("%-38s %-14s %-8d %-8d %s" % (expo, src, got, ref, "OK" if got == ref else "DIFF"))

# --- 写出 CSV ---
out_csv = os.path.join(OUTDIR, "TableS30_per_variant.csv")
with open(out_csv, "w", newline="", encoding="utf-8-sig") as fh:
    w = csv.writer(fh)
    w.writerow(["Exposure", "Outcome source", "SNP", "chr:pos (GRCh37)", "EA>OA", "EAF",
                "beta_exposure", "SE_exposure", "F", "beta_outcome", "SE_outcome",
                "Wald OR", "95% CI lower", "95% CI upper"])
    for r in rows_out:
        w.writerow([r["exposure"], r["source"], r["snp"], r["loc"], r["alleles"],
                    r["eaf"], "%.6f" % r["bx"], "%.6f" % r["sx"], "%.2f" % r["F"],
                    "%.5f" % r["by"], "%.5f" % r["sy"], "%.2f" % r["or_"],
                    "%.2f" % r["lo"], "%.2f" % r["hi"]])
print("\nrows:", len(rows_out), "->", out_csv)
