import docx
from docx.shared import Pt

SUP = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\Supplement.docx"
doc = docx.Document(SUP)

# 1) S31 表最后一行最后一列 36† -> 29†
t31 = doc.tables[-1]
fixed = 0
for r in t31.rows:
    if r.cells[0].text.strip() == "Tea intake" and r.cells[-1].text.strip().startswith("36"):
        c = r.cells[-1]
        c.text = ""
        run = c.paragraphs[0].add_run("29 \u2020")
        run.font.size = Pt(7.5)
        fixed += 1
print("S31 table cell 36 -> 29:", fixed)

# 2) 重写脚注 4
NEW = ("\u2020 The BioBank Japan tea panel was originally recorded as containing 36 variants, four more than "
       "the 32-variant European index set. This count could not be reproduced and has been replaced. The row "
       "was re-derived on 30 October 2026 with the original procedure (TwoSampleMR::extract_outcome_data "
       "followed by harmonise_data, action = 2) against the released bbj-a-71 statistics, using proxy search at "
       "the package default (proxies = TRUE, rsq \u2265 0.8): six index variants were substituted and 29 "
       "variants were retained, giving an IVW OR of 1.13 (0.54\u20132.34; P = 0.75). Without proxy search, "
       "26 variants are retained and the estimate is 0.98 (0.46\u20132.11; P = 0.96). The revised counts and "
       "estimates for tea intake in the BioBank Japan panel have been applied to Table S1, Table S2, "
       "Table S3 and Figure 2. Both reconstructions include the null, and the composition of this panel does "
       "not affect any conclusion in the paper.")

hit = 0
for p in doc.paragraphs:
    if p.text.startswith("\u2020 The BioBank Japan tea panel"):
        if p.runs:
            p.runs[0].text = NEW
            for r in p.runs[1:]:
                r.text = ""
        hit += 1
print("footnote rewritten:", hit)

doc.save(SUP)

d2 = docx.Document(SUP)
for r in d2.tables[-1].rows:
    if r.cells[0].text.strip() == "Tea intake":
        print("\nS31 tea row:", " | ".join(c.text.strip() for c in r.cells))
for p in d2.paragraphs:
    if p.text.startswith("\u2020 The BioBank Japan tea panel"):
        print("\nfootnote:", p.text[:200], "...")
