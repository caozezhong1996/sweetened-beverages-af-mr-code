import csv, json, os, re, time, urllib.request, glob

TOKEN = None
rp = os.path.expanduser("~/.Renviron")
for line in open(rp, encoding="utf-8", errors="replace"):
    m = re.match(r"\s*OPENGWAS_JWT\s*=\s*['\"]?([^'\"\s]+)", line)
    if m:
        TOKEN = m.group(1)
print("token loaded:", bool(TOKEN))

API = "https://api.opengwas.io/api/associations"

def query(variants, gwas_id):
    body = json.dumps({"id": [gwas_id], "variant": variants}).encode()
    req = urllib.request.Request(API, data=body,
                                 headers={"Authorization": "Bearer " + TOKEN,
                                          "Content-Type": "application/json"})
    for attempt in range(4):
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                data = json.loads(r.read().decode())
            return {x["rsid"] for x in data if x.get("rsid")}
        except Exception as e:
            print("   retry", attempt, gwas_id, repr(e)[:90])
            time.sleep(3 + attempt * 3)
    return set()

KEY = {
    "Artificial_sweetener_added_to_tea": "Artificial sweetener added to tea",
    "Coffee_intake": "Coffee intake",
    "Fizzy_drink_intake_SSB": "Fizzy drink intake (SSB)",
    "Low_calorie_drink_intake_ASB": "Low-calorie drink intake (ASB)",
    "Sugar_added_to_coffee": "Sugar added to coffee",
    "Sugar_added_to_tea": "Sugar added to tea",
    "Tea_intake": "Tea intake",
}
S1 = {
    "Artificial sweetener added to tea": (14, 6),
    "Coffee intake": (34, 32),
    "Fizzy drink intake (SSB)": (8, 4),
    "Low-calorie drink intake (ASB)": (17, 8),
    "Sugar added to coffee": (15, 11),
    "Sugar added to tea": (17, 11),
    "Tea intake": (32, 36),
}
SOURCES = [("ebi-a-GCST006061", "AFGen 2018", 0), ("bbj-a-71", "BioBank Japan", 1)]

out = []
for f in sorted(glob.glob(r"C:\a3work\dat_*_ebi_a_GCST006414.csv")):
    stem = os.path.basename(f)[4:-len("_ebi_a_GCST006414.csv")]
    expo = KEY[stem]
    rs = sorted({r["SNP"] for r in csv.DictReader(open(f, encoding="utf-8", errors="replace"))})
    for gid, label, idx in SOURCES:
        got = query(rs, gid)
        direct = len(got & set(rs))
        retained = S1[expo][idx]
        proxy = retained - direct
        missing = len(rs) - retained
        out.append([expo, label, len(rs), direct, proxy, missing, retained])
        print("%-38s %-15s idx=%2d direct=%2d proxy=%2d missing=%2d retained=%2d"
              % (expo, label, len(rs), direct, proxy, missing, retained))
        time.sleep(1.5)

with open(r"C:\a3work\s1_proxy_rebuild.csv", "w", newline="", encoding="utf-8-sig") as fh:
    w = csv.writer(fh)
    w.writerow(["Exposure", "Outcome source", "Index SNPs", "Recovered directly",
                "Proxy substituted", "Unavailable (no proxy)", "Retained (Table S1)"])
    w.writerows(out)
print("\ntotal proxy:", sum(r[4] for r in out), "| total unavailable:", sum(r[5] for r in out))
