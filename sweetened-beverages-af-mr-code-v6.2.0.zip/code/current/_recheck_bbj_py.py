import csv, math

def load(p):
    return list(csv.DictReader(open(p, encoding="utf-8-sig")))

def ivw(rows):
    """TwoSampleMR::mr_ivw default (first-order weights 1/se_out^2)"""
    bx = [float(r["beta.exposure"]) for r in rows]
    sx = [float(r["se.exposure"]) for r in rows]
    by = [float(r["beta.outcome"]) for r in rows]
    sy = [float(r["se.outcome"]) for r in rows]
    w = [1 / s ** 2 for s in sy]
    b = sum(wi * bxi * byi for wi, bxi, byi in zip(w, bx, by)) / sum(wi * bxi ** 2 for wi, bxi in zip(w, bx))
    se = math.sqrt(1 / sum(wi * bxi ** 2 for wi, bxi in zip(w, bx)))
    Q = sum(wi * (byi - b * bxi) ** 2 for wi, bxi, byi in zip(w, bx, by))
    z = b / se
    p = math.erfc(abs(z) / math.sqrt(2))
    return b, se, Q, p, len(rows)

def egger(rows):
    """weighted least squares of b_out on b_exp, weights 1/se_out^2 -> intercept"""
    bx = [float(r["beta.exposure"]) for r in rows]
    by = [float(r["beta.outcome"]) for r in rows]
    sy = [float(r["se.outcome"]) for r in rows]
    w = [1 / s ** 2 for s in sy]
    sw = sum(w)
    xbar = sum(wi * xi for wi, xi in zip(w, bx)) / sw
    ybar = sum(wi * yi for wi, yi in zip(w, by)) / sw
    sxx = sum(wi * (xi - xbar) ** 2 for wi, xi in zip(w, bx))
    sxy = sum(wi * (xi - xbar) * (yi - ybar) for wi, xi, yi in zip(w, bx, by))
    slope = sxy / sxx
    intercept = ybar - slope * xbar
    # SE of intercept
    resid = [yi - intercept - slope * xi for xi, yi in zip(bx, by)]
    sigma2 = sum(wi * r ** 2 for wi, r in zip(w, resid)) / (len(bx) - 2)
    se_int = math.sqrt(sigma2 * (1 / sw + xbar ** 2 / sxx))
    p = math.erfc(abs(intercept / se_int) / math.sqrt(2))
    return intercept, se_int, p

for tag in ("FALSE", "TRUE"):
    rows = load(rf"C:\a3work\bbj_tea_harmonised_proxies_{tag}.csv")
    b, se, Q, p, n = ivw(rows)
    ei, ese, ep = egger(rows)
    print(f"--- proxies={tag}  n={n} ---")
    print(f"  IVW  beta={b:+.4f}  se={se:.4f}  OR={math.exp(b):.3f} "
          f"({math.exp(b-1.96*se):.3f}-{math.exp(b+1.96*se):.3f})  P={p:.4f}")
    print(f"  Q    ={Q:.2f}  df={n-1}  I2={max(0,(Q-(n-1))/Q)*100:.1f}%")
    print(f"  Egger intercept={ei:+.5f} (SE {ese:.5f})  P={ep:.4f}")

print("\nR reference:")
print("  proxies=FALSE: IVW b=-0.0187 se=0.3900 OR 0.981 (0.457-2.108) P=0.9618 | Q=46.78 (df25) | int -0.01759 (0.01881) P=0.3592")
print("  proxies=TRUE : IVW b=+0.1177 se=0.3742 OR 1.125 (0.540-2.342) P=0.7532 | Q=53.74 (df28) | int -0.01847 (0.01870) P=0.3320")
