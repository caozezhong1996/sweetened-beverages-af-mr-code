/* Independent local-candidate audit: manual ZIP parser, CRC32, SHA256 and MANIFEST. */
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');
const ROOT = 'C:/Users/64915/WorkBuddy/2026-10-30-20-42-58';
const BASE = ROOT + '/_targeted_fix_20261124';
const Z = ROOT + '/Zenodo_更新候选_20261124_定向修订.zip';
const SUB = 'C:/Users/64915/Desktop/JAHA投稿包_奶茶房颤MR_20261013';
const RENDER = BASE + '/render';
const OUT = BASE + '/review/candidate_node.json';
const EXPECTED_DOCS = {
  'Manuscript.docx': 'df2b92489432e9e247d23c1869da2a7b9ad767be7765e7aef854e447679d4722',
  'Cover_Letter.docx': '6910ad46cb7bd01b26c722ea79d0dafa37931589616ce701d5db93dcf83bf0cc',
  'Highlights.docx': '2bf1e7be1362c4b5eb2d6fe3e444182eb4bcf6ac65b96298c3099b4fc7811e7f',
  'Supplement.docx': '7b264eef245abaa6712d1f4c1fbafff6d9f286943704dd4107b257bec60fc882'
};
const CURRENT_CODE = [
  'revision_texts_20261124.json','apply_targeted_fix_20261124.py','audit_targeted_fix_20261124.py',
  'round_B_node_audit_20261124.js','round_C_render_audit_20261124.py','finalize_local_candidate_20261124.py',
  'verify_local_candidate_node_20261124.js'
];
const b = fs.readFileSync(Z);
function sha(x) { return crypto.createHash('sha256').update(x).digest('hex'); }
const crcTable = new Uint32Array(256);
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
  crcTable[n] = c >>> 0;
}
function crc32(x) {
  let c = 0xFFFFFFFF;
  for (const byte of x) c = crcTable[(c ^ byte) & 0xFF] ^ (c >>> 8);
  return (c ^ 0xFFFFFFFF) >>> 0;
}
let eocd = -1;
for (let i = b.length - 22; i >= Math.max(0, b.length - 65558); i--) {
  if (b.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
}
if (eocd < 0) throw new Error('EOCD not found');
const declared = b.readUInt16LE(eocd + 10);
const cdOff = b.readUInt32LE(eocd + 16);
const entries = {};
const badCrc = [];
let p = cdOff, count = 0, manifestText = null;
while (p < b.length && b.readUInt32LE(p) === 0x02014b50 && count < declared) {
  const expectedCrc = b.readUInt32LE(p + 16);
  const method = b.readUInt16LE(p + 10), csize = b.readUInt32LE(p + 20), usize = b.readUInt32LE(p + 24);
  const fnLen = b.readUInt16LE(p + 28), exLen = b.readUInt16LE(p + 30), cmLen = b.readUInt16LE(p + 32);
  const lhOff = b.readUInt32LE(p + 42);
  const name = b.toString('utf8', p + 46, p + 46 + fnLen);
  if (b.readUInt32LE(lhOff) !== 0x04034b50) throw new Error('Bad local header: ' + name);
  const start = lhOff + 30 + b.readUInt16LE(lhOff + 26) + b.readUInt16LE(lhOff + 28);
  const raw = b.subarray(start, start + csize);
  const data = method === 0 ? raw : method === 8 ? zlib.inflateRawSync(raw) : null;
  if (!data || data.length !== usize) throw new Error('Decode/size mismatch: ' + name);
  const actualCrc = crc32(data);
  if (actualCrc !== expectedCrc) badCrc.push(name);
  entries[name] = { bytes: data.length, sha256: sha(data), crc32: actualCrc, data };
  if (name === 'MANIFEST.csv') manifestText = data.toString('utf8').replace(/^\uFEFF/, '');
  p += 46 + fnLen + exLen + cmLen;
  count++;
}
if (!manifestText) throw new Error('MANIFEST.csv missing');
const lines = manifestText.trim().split(/\r?\n/);
const manifestBad = [];
const manifestNames = new Set();
for (const line of lines.slice(1)) {
  const cols = line.split(',');
  if (cols.length < 3) { manifestBad.push(line + ':INVALID_ROW'); continue; }
  const name = cols[0].replace(/\\/g, '/');
  manifestNames.add(name);
  const rec = entries[name];
  if (!rec) manifestBad.push(name + ':MISSING');
  else if (rec.bytes !== parseInt(cols[1], 10) || rec.sha256 !== cols[2].trim()) manifestBad.push(name + ':MISMATCH');
}
const fileNames = Object.keys(entries);
const missingFromManifest = fileNames.filter(n => n !== 'MANIFEST.csv' && !manifestNames.has(n));
const extraInManifest = [...manifestNames].filter(n => !entries[n]);
function walk(dir, prefix = '') {
  const out = [];
  for (const item of fs.readdirSync(dir, { withFileTypes: true })) {
    const rel = prefix ? prefix + '/' + item.name : item.name;
    if (item.isDirectory()) out.push(...walk(path.join(dir, item.name), rel));
    else if (item.isFile()) out.push(rel);
  }
  return out;
}
const localFiles = walk(SUB);
const archiveSubmission = fileNames.filter(n => n.startsWith('submission/') && !n.endsWith('/')).map(n => n.slice(11));
const submissionDiff = [];
for (const rel of [...new Set([...localFiles, ...archiveSubmission])]) {
  const localPath = path.join(SUB, ...rel.split('/'));
  const rec = entries['submission/' + rel];
  if (!rec || !fs.existsSync(localPath)) { submissionDiff.push({ path: rel, error: 'missing_on_one_side' }); continue; }
  const data = fs.readFileSync(localPath);
  if (data.length !== rec.bytes || sha(data) !== rec.sha256) submissionDiff.push({ path: rel, error: 'bytes_or_sha256' });
}
const docHashes = {}, docHashDiff = [];
for (const [name, expected] of Object.entries(EXPECTED_DOCS)) {
  const rec = entries['submission/' + name];
  docHashes[name] = rec ? rec.sha256 : null;
  if (!rec || rec.sha256 !== expected) docHashDiff.push(name);
}
const verificationPdfEqualsFresh = {};
for (const stem of ['Manuscript', 'Supplement']) {
  const rec = entries['verification/' + stem + '_rendered.pdf'];
  const fresh = fs.readFileSync(path.join(RENDER, stem + '.pdf'));
  verificationPdfEqualsFresh[stem] = !!rec && rec.bytes === fresh.length && rec.sha256 === sha(fresh);
}
const nmrMatches = {};
for (const name of Object.keys(EXPECTED_DOCS)) {
  const stem = name.replace(/\.docx$/, '');
  const rec = entries['data/derived/nmr/' + stem + '.txt'];
  nmrMatches[name] = !!rec && rec.data.equals(fs.readFileSync(BASE + '/package/data/derived/nmr/' + stem + '.txt'));
}
const currentCode = {};
for (const name of CURRENT_CODE) currentCode[name] = !!entries['code/current/' + name];
const result = {
  candidate_path: Z, candidate_bytes: b.length, candidate_sha256: sha(b),
  entries_parsed: count, declared_entries: declared, bad_crc: badCrc,
  manifest_rows: lines.length - 1, manifest_mismatches: manifestBad,
  missing_from_manifest: missingFromManifest, extra_in_manifest: extraInManifest,
  local_submission_files: localFiles.length, archive_submission_files: archiveSubmission.length,
  submission_differences: submissionDiff, archived_docx_sha256: docHashes,
  docx_hash_mismatches: docHashDiff,
  verification_pdf_equals_fresh_render: verificationPdfEqualsFresh,
  nmr_exports_match: nmrMatches, current_revision_code_present: currentCode,
  old_revision_script_retired: !entries['code/current/apply_revision_20261115.py'] && !!entries['code/history/apply_revision_20261115.py'],
  graphical_abstract_source_present: !!entries['code/current/_gabs_v66.py']
};
result.all_pass = count === declared && declared === lines.length && badCrc.length === 0 &&
  manifestBad.length === 0 && missingFromManifest.length === 0 && extraInManifest.length === 0 &&
  localFiles.length === 10 && archiveSubmission.length === 10 && submissionDiff.length === 0 &&
  docHashDiff.length === 0 && Object.values(verificationPdfEqualsFresh).every(Boolean) &&
  Object.values(nmrMatches).every(Boolean) && Object.values(currentCode).every(Boolean) &&
  result.old_revision_script_retired && result.graphical_abstract_source_present;
fs.writeFileSync(OUT, JSON.stringify(result, null, 2));
console.log(JSON.stringify(result, null, 2));
if (!result.all_pass) process.exit(1);
