# -*- coding: utf-8 -*-
"""Figure S2 (v54): LDSC cross-trait genetic correlations, rebuilt at print width.
v54 (2026-11-12): legend wording clarified (solid/dashed LINE, not circle);
control-row rg labels now use three decimals to match the caption and
Table S11 (0.923 / 0.005). Main-trait rows stay at two decimals.
Figure S2 (v53): LDSC cross-trait genetic correlations, rebuilt at print width.

Canvas is the exact print size (15.92 cm), so fontsize == printed point size.
One axis, two markers per exposure row (Nielsen 2018 / FinnGen R13), values in
a right-hand column, validation controls below a separator.
"""
import csv
import io
import math
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from matplotlib.textpath import TextPath

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

M = r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
RES = os.path.join(M, "06_升级分析_v4", "results")
OUTDIR = r"C:\Users\64915\WorkBuddy\2026-10-30-20-42-58\_review3_fix\figures_new"

CM = 1 / 2.54
W_IN, H_IN = 17.40 * CM, 7.6 * CM
DPI = 600

rows = list(csv.DictReader(open(os.path.join(RES, "ldsc_rg_v44.csv"), encoding="utf-8")))
by = {(r["exposure"], r["outcome"]): r for r in rows}

EXP = [("Fizzy_drink_intake_SSB", "Fizzy_drink_intake_SSB"),
       ("Low_calorie_drink_intake_ASB", "Low_calorie_drink_intake_ASB")]
LAB = {"fizzy": "Fizzy drinks (SSB)", "lowcal": "Low-calorie drinks (ASB)",
       "sugarCof": "Sugar added to coffee", "coffee": "Coffee intake",
       "tea": "Tea intake"}
ORDER = ["coffee", "tea", "sugarCof", "fizzy", "lowcal"]     # top to bottom

C_N, C_R = "#37474F", "#B33A3A"
C_CTRL = "#78909C"


def tp_w(text, size, weight="normal"):
    fp = FontProperties(family="DejaVu Sans", size=size, weight=weight)
    return max(TextPath((0, 0), ln, prop=fp).get_extents().width
               for ln in text.split("\n")) / 72.0


LBL = 8.6
lbl_w = max(tp_w(LAB[k], LBL) for k in ORDER)

# y layout
BAR, GAP = 1.0, 0.85
ys, ticks, labels = {}, [], []
y = 0.0
for k in ORDER:
    ys[k] = y
    ticks.append(y)
    labels.append(LAB[k])
    y += BAR
y += GAP
ctrl_y = {}
for key, lab, step in [("same", "Same-trait control\n(Nielsen × R13)", 1.55),
                       ("over", "Overlap control\n(coffee × tea)", BAR)]:
    ctrl_y[key] = y
    ticks.append(y)
    labels.append(lab)
    y += step
Y_MIN, Y_MAX = -0.7, y - BAR + 0.5

VAL_W = tp_w("+0.005  (int -0.318)", 8.0) + 0.08  # widest control label plus padding
lbl_w = max(lbl_w, max(tp_w(l, LBL) for l in labels))
LEFT_IN = lbl_w + 0.17
RIGHT_IN = VAL_W + 0.12

LEFT = LEFT_IN / W_IN
RIGHT = 1 - RIGHT_IN / W_IN
TOP_IN, BOT_IN = 0.42, 0.52
TOP = 1 - TOP_IN / H_IN
BOTTOM = BOT_IN / H_IN

plt.rcParams.update({"font.family": "DejaVu Sans", "axes.linewidth": 0.6})
fig = plt.figure(figsize=(W_IN, H_IN), dpi=DPI)
ax = fig.add_axes([LEFT, BOTTOM, RIGHT - LEFT, TOP - BOTTOM])

XL = (-0.55, 1.15)
ax.set_xlim(*XL)
ax.set_ylim(Y_MAX, Y_MIN)
ax.axvline(0, color="#263238", lw=0.8, ls=(0, (3, 2)), zorder=1)
ax.axhspan(ctrl_y["same"] - 0.55, ctrl_y["over"] + 0.55, color="#F2F5F7", zorder=0)

OFF = 0.19
for k in ORDER:
    for oc, col, mk, dy in [("Nielsen", C_N, "o", -OFF), ("R13", C_R, "o", +OFF)]:
        r = by[(k, oc)]
        rg, se = float(r["rg"]), float(r["rg_se"])
        lo, hi = rg - 1.96 * se, rg + 1.96 * se
        sig = r["rg_fdr"] not in ("", None) and float(r["rg_fdr"]) < 0.05
        yv = ys[k] + dy
        ax.plot([max(lo, XL[0] + 0.01), min(hi, XL[1] - 0.01)], [yv, yv],
                color=col, lw=0.9, zorder=2, ls="-" if oc == "Nielsen" else (0, (2, 1.4)))
        if hi > XL[1]:
            ax.plot([XL[1] - 0.01], [yv], marker=">", ms=2.4, color=col, ls="", zorder=2)
        if lo < XL[0]:
            ax.plot([XL[0] + 0.01], [yv], marker="<", ms=2.4, color=col, ls="", zorder=2)
        ax.plot([rg], [yv], marker=mk, ms=3.6, ls="", zorder=3,
                mfc=col if sig else "white", mec=col, mew=0.9)
        ax.text(1.02, yv, f"{rg:+.2f}", transform=ax.get_yaxis_transform(),
                va="center", ha="left", fontsize=8.0, color=col,
                fontweight="bold" if sig else "normal")

# controls
for key, (expo, outc) in [("same", ("Nielsen", "R13")), ("over", ("coffee", "tea"))]:
    r = by[(expo, outc)]
    rg, se = float(r["rg"]), float(r["rg_se"])
    lo, hi = rg - 1.96 * se, rg + 1.96 * se
    yv = ctrl_y[key]
    ax.plot([max(lo, XL[0] + 0.01), min(hi, XL[1] - 0.01)], [yv, yv],
            color=C_CTRL, lw=0.9, zorder=2)
    if hi > XL[1]:
        ax.plot([XL[1] - 0.01], [yv], marker=">", ms=2.4, color=C_CTRL, ls="", zorder=2)
    ax.plot([rg], [yv], marker="s", ms=3.4, ls="", zorder=3, color=C_CTRL)
    intercepts = {"same": 0.0418, "over": -0.3182}
    ax.text(1.02, yv, f"{rg:+.3f}  (int {intercepts[key]:+.3f})", transform=ax.get_yaxis_transform(),
            va="center", ha="left", fontsize=8.0, color=C_CTRL)

ax.set_yticks(ticks)
ax.set_yticklabels(labels, fontsize=LBL)
ax.tick_params(axis="y", length=0, pad=2)
ax.set_xticks([-0.5, 0, 0.5, 1.0])
ax.tick_params(axis="x", labelsize=8.4, length=2.2, pad=1.6)
ax.set_xlabel("Cross-trait genetic correlation, rg", fontsize=8.8)
for s in ("top", "right", "left"):
    ax.spines[s].set_visible(False)
ax.set_title("Solid line, Nielsen 2018;  dashed line, FinnGen R13;  "
             "\nfilled circles, FDR q < 0.05; gray squares, controls", fontsize=7.8, color="#555555", loc="left", pad=3)

out = os.path.join(OUTDIR, "FigureS2_LDSC_rg_v55.png")
fig.savefig(out, dpi=DPI, facecolor="white")
plt.close(fig)
print(f"saved: {out}")
print(f"canvas {W_IN*2.54:.2f} x {H_IN*2.54:.2f} cm @{DPI} dpi ({os.path.getsize(out)/1024:.0f} KB)")
print(f"label {lbl_w:.2f} in, value col {VAL_W:.2f} in")
