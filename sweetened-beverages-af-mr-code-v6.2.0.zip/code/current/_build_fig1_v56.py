# -*- coding: utf-8 -*-
"""Figure 1 (v54). Study-design flowchart rebuilt at print width.

The v53 layout needed a 29 cm canvas to hold three columns of 9 pt text, so it
printed at ~5 pt once scaled to the 15.9 cm column. Here the same content is
re-flowed into two columns and the canvas IS the print size (15.92 cm wide),
so every font size below is the printed point size.
"""
import io
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.textpath import TextPath
from matplotlib.font_manager import FontProperties

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

OUT = r"C:\Users\64915\WorkBuddy\2026-10-30-20-42-58\Figure1_Study_Design_v56.png"

W_IN, H_IN, DPI = 17.40 / 2.54, 7.10, 600
XMAX = 100.0
YMAX = 100.0 * H_IN / W_IN
MARGIN_TOP, MARGIN_BOT = 1.1, 1.5
PT_PER_UNIT = W_IN * 72.0 / XMAX

C_DATA, C_INST, C_ANA, C_ROB = "#2A6F7F", "#C08329", "#4A6FA5", "#7A4E7E"
INK, ARROW = "#263238", "#7a8b93"

fig = plt.figure(figsize=(W_IN, H_IN), dpi=DPI)
ax = fig.add_axes([0, 0, 1, 1])
ax.set_xlim(0, XMAX)
ax.set_ylim(0, YMAX)
ax.axis("off")

LS = 1.28
BUS_FRAC = 0.34
STRIP = 3.3
PAD_TOP, PAD_BOT = 1.75, 1.6
BODY_SIZE, TITLE_SIZE = 8.6, 9.6
_FP = {w: FontProperties(family="DejaVu Sans", weight=w) for w in ("normal", "bold")}


def width_units(text, size, weight="normal"):
    return max(TextPath((0, 0), ln, size=size, prop=_FP[weight]).get_extents().width
               for ln in text.split("\n")) * 1.10 / PT_PER_UNIT


def fit_size(text, size, max_w, weight="normal", floor=5.8):
    while size > floor and width_units(text, size, weight) > max_w:
        size -= 0.1
    return round(size, 1)


def line_h(n, size, ls=LS):
    return n * ls * size / PT_PER_UNIT


class Box:
    def __init__(self, x, w, title, body, color, pad_x=2.2):
        self.x, self.w, self.title, self.body, self.color = x, w, title, body, color
        self.pad_x = pad_x
        self.n = body.count("\n") + 1
        self.y = self.h = self.title_fs = self.body_fs = None

    def height(self):
        return STRIP + PAD_TOP + line_h(self.n, self.body_fs) + PAD_BOT

    @property
    def cx(self):
        return self.x + self.w / 2

    def draw(self):
        ax.add_patch(FancyBboxPatch((self.x, self.y - self.h), self.w, self.h,
                                    boxstyle="round,pad=0,rounding_size=0.9",
                                    facecolor="white", edgecolor=self.color,
                                    linewidth=1.15, zorder=2))
        ax.add_patch(FancyBboxPatch((self.x, self.y - STRIP), self.w, STRIP,
                                    boxstyle="round,pad=0,rounding_size=0.9",
                                    facecolor=self.color, edgecolor="none",
                                    alpha=0.13, zorder=2))
        ax.text(self.cx, self.y - STRIP / 2, self.title, ha="center", va="center",
                fontsize=self.title_fs, fontweight="bold", color=self.color, zorder=4)
        ax.text(self.cx, self.y - STRIP - PAD_TOP, self.body, ha="center", va="top",
                fontsize=self.body_fs, color=INK, zorder=4, linespacing=LS)


# ------------------------------------------------------------------ content
MAIN_TITLE = "Study design: genetically proxied sweetened beverage intake\nand atrial fibrillation"
assert width_units(MAIN_TITLE, 10.2, "bold") < 94
ax.text(XMAX / 2, YMAX - 0.10, MAIN_TITLE,
        ha="center", va="top", fontsize=10.2, fontweight="bold", color=INK,
        linespacing=1.15)

WB, X1, X2 = 46.6, 1.6, 51.8          # two-column geometry

B1 = [
    Box(X1, WB, "Exposure GWAS",
        "UK Biobank, 7 beverage phenotypes\n"
        "2 at P < $5\\times10^{-8}$, 5 at $P < 5\\times10^{-6}$\n"
        "N = 64,949–447,485 (EUR)\n"
        "Plasma metabolites (Chen 2023):\n"
        "caffeine · paraxanthine · theobromine\n"
        "N ≈ 8,000 (EUR)", C_DATA),
    Box(X2, WB, "Outcome GWAS: atrial fibrillation",
        "Nielsen 2018 (primary): 60,620\n"
        "FinnGen R13 (replication): 67,783\n"
        "Yuan 2025 (replication, UKB-free):\n"
        "192,851 cases\n"
        "AFGen 2018 (sensitivity): 55,114\n"
        "BioBank Japan (EAS): 8,180", C_DATA),
]
B3 = [Box(1.6, 96.8, "Instrument selection and harmonisation",
          "Independent SNPs (r² < 0.001 within 10,000 kb); P < $5\\times10^{-8}$ for coffee and tea intake,\n"
          "$P < 5\\times10^{-6}$ for the five sub-phenotypes; locus-lead variants for plasma metabolites\n"
          "Palindromic variants excluded; index variants harmonised to each panel where available\n"
          "(BioBank Japan: proxy substitution, Table S1); per-variant F met the selection-implied\n"
          "floor for beverages and was 29.8–48.7 for metabolites", C_INST, pad_x=2.6)]
B4 = [
    Box(X1, WB, "Univariable and multivariable MR",
        "Random-effects IVW (7 beverages,\n"
        "3 metabolites); MR-Egger, weighted\n"
        "median, weighted mode, MR-PRESSO,\n"
        "Wald ratio; MVMR with BMI\n"
        "(conditional F reported)\n"
        "Covariate: BMI (GIANT, N = 681,275)\n"
        "Positive controls: alcohol (GSCAN)\n"
        "and intake frequency (UKB)", C_ANA),
    Box(X2, WB, "Meta-analysis and contextual arm",
        "Fixed-effect European meta-analysis\n"
        "(Nielsen 2018 + FinnGen R13);\n"
        "Benjamini–Hochberg FDR across the\n"
        "7 primary tests; BioBank Japan (EAS)\n"
        "contextual arm\n"
        "Yuan 2025 shown separately, not pooled\n"
        "Adiposity-locus sensitivity (Table S27)\n"
        "Placebo exclusion test (2,000 replicates)", C_ANA),
]
B5 = [
    Box(X1, WB, "Robustness and pleiotropy",
        "Cochran's Q · MR-Egger intercept\n"
        "MR-PRESSO · radial IVW · MR-RAPS\n"
        "CAUSE · MRlap · contamination mixture\n"
        "LDSC rg · Steiger · reverse MR\n"
        "alcohol positive lifestyle control", C_ROB),
    Box(X2, WB, "Probes of the nominal coffee signal",
        "Colocalization at CYP1A1–CYP1A2, AHR\n"
        "and FTO; two-step BMI mediation MR\n"
        "Adiposity-locus sensitivity: variants\n"
        "within 500 kb of 724 BMI loci removed\n"
        "(Table S27)", C_ROB),
]
BANDS = [B1, B3, B4, B5]

# ------------------------------------------------------------------ typography
body_fs = min(fit_size(b.body, BODY_SIZE, b.w - 2 * b.pad_x) for b in sum(BANDS, []))
for b in sum(BANDS, []):
    b.body_fs = body_fs
for row in BANDS:
    tfs = min(fit_size(b.title, TITLE_SIZE, b.w - 2.6, "bold") for b in row)
    for b in row:
        b.title_fs = tfs
print(f"body {body_fs} pt, band titles " +
      " / ".join(f"{r[0].title_fs}" for r in BANDS))

# ------------------------------------------------------------------ rhythm
heights = [max(b.height() for b in row) for row in BANDS]
title_h = 2.50 * 10.2 / PT_PER_UNIT
avail = YMAX - MARGIN_TOP - MARGIN_BOT
gap = (avail - title_h - sum(heights)) / len(BANDS)
print("band heights", [f"{h:.1f}" for h in heights],
      f"gap {gap:.2f} units = {gap * PT_PER_UNIT:.1f} pt")
assert gap > 3.0, f"vertical gap too small ({gap:.2f})"

y = YMAX - MARGIN_TOP - title_h
tops = []
for row, h in zip(BANDS, heights):
    y -= gap
    tops.append(y)
    for b in row:
        b.y, b.h = y, h
        b.draw()
    y -= h
print(f"stack bottom {y:.2f} vs margin {MARGIN_BOT}")


def bus(src_bottom, dst_top, xs_src, xs_dst):
    mid = src_bottom - BUS_FRAC * (src_bottom - dst_top)
    for x in xs_src:
        ax.plot([x, x], [src_bottom, mid], color=ARROW, lw=1.0, zorder=1,
                solid_capstyle="butt")
    ax.plot([min(xs_src + xs_dst), max(xs_src + xs_dst)], [mid, mid],
            color=ARROW, lw=1.0, zorder=1, solid_capstyle="butt")
    for x in xs_dst:
        ax.add_patch(FancyArrowPatch((x, mid), (x, dst_top), arrowstyle="-|>",
                                     mutation_scale=7.5, linewidth=1.05,
                                     color=ARROW, zorder=1, shrinkA=0, shrinkB=0))


bus(tops[0] - heights[0], tops[1], [b.cx for b in B1], [B3[0].cx])
bus(tops[1] - heights[1], tops[2], [B3[0].cx], [b.cx for b in B4])
bus(tops[2] - heights[2], tops[3], [b.cx for b in B4], [b.cx for b in B5])

# ------------------------------------------------------------------ verify
fig.canvas.draw()
r = fig.canvas.get_renderer()
inv = ax.transData.inverted()
problems = []


def bb(t):
    b = t.get_window_extent(renderer=r)
    (x0, y0), (x1, y1) = inv.transform([[b.x0, b.y0], [b.x1, b.y1]])
    return x0, y0, x1, y1


pairs = []
for b in sum(BANDS, []):
    pairs += [(b.title, b, "title"), (b.body, b, "body")]
for t, (src, b, kind) in zip(list(ax.texts)[1:], pairs):
    x0, y0, x1, y1 = bb(t)
    if x0 < b.x + 0.05 or x1 > b.x + b.w - 0.05:
        problems.append(f"{kind} wider than box: {src[:34]!r} "
                        f"({x0:.1f}-{x1:.1f} vs {b.x:.1f}-{b.x + b.w:.1f})")
    if y0 < b.y - b.h + 0.08:
        problems.append(f"{kind} below box: {src[:34]!r} ({y0:.2f} vs {b.y - b.h:.2f})")
    if kind == "title" and (y0 < b.y - STRIP or y1 > b.y):
        problems.append(f"title outside strip: {src[:30]!r}")

for row, ytop in zip(BANDS, tops):
    counts = {b.n for b in row}
    if len(counts) > 1:
        problems.append(f"unequal line counts at y={ytop:.1f}: {sorted(counts)}")
if y < MARGIN_BOT - 0.1:
    problems.append(f"stack overflows bottom margin ({y:.2f} < {MARGIN_BOT})")

print("VERIFY:", "PASS — text inside boxes, uniform sizes, balanced rows"
      if not problems else f"{len(problems)} problem(s)")
for p in problems:
    print("  -", p)

fig.savefig(OUT, dpi=DPI, facecolor="white")
plt.close(fig)
import os
print(f"saved: {OUT}")
print(f"canvas {W_IN*2.54:.2f} x {H_IN*2.54:.2f} cm @{DPI} dpi ({os.path.getsize(OUT)/1024:.0f} KB)")
