import csv, docx
from copy import deepcopy
from docx.shared import Pt, Cm
from docx.oxml.ns import qn

SUP = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\Supplement.docx"
CSV = r"C:\a3work\s1_proxy_rebuild.csv"

raw = list(csv.DictReader(open(CSV, encoding="utf-8-sig")))
doc = docx.Document(SUP)

# 1) S1 脚注加一句指引（段落 4）
target = None
for p in doc.paragraphs:
    if p.text.startswith("F statistics are per-variant") and "Table S31" not in p.text:
        target = p
        break
if target is not None:
    add = (" Variant-level recovery in the two non-European-accessible panels is itemised in Table S31.")
    target.runs[-1].text = target.runs[-1].text + add
    print("S1 footnote appended")

# 2) 追加 Table S31
src_tblPr = deepcopy(doc.tables[0]._tbl.tblPr)

h = doc.add_paragraph()
r = h.add_run("Table S31. Recovery of European index variants in the AFGen 2018 and BioBank Japan outcome panels")
r.bold = True
r.font.size = Pt(9)
r.font.name = "Calibri"
r._element.rPr.rFonts.set(qn("w:eastAsia"), "\u5fae\u8f6f\u96c5\u9ed1")

head = ["Exposure", "Index SNPs", "AFGen recovered", "AFGen proxied",
        "AFGen unavailable", "BBJ recovered", "BBJ proxied", "BBJ unavailable", "BBJ retained"]
rows = []
for x in raw:
    expo = x["Exposure"]
    idx = int(x["Index SNPs"])
    direct = int(x["Recovered directly"])
    proxy = int(x["Proxy substituted"])
    missing = int(x["Unavailable (no proxy)"])
    retained = int(x["Retained (Table S1)"])
    if "BioBank" in x["Outcome source"]:
        rows.append((expo, idx, "", "", "", direct, proxy,
                     "\u2014" if missing < 0 else missing, f"{retained}" + ("\u2020" if missing < 0 else "")))
rows = []
for expo in ["Sugar added to tea", "Sugar added to coffee", "Fizzy drink intake (SSB)",
             "Low-calorie drink intake (ASB)", "Artificial sweetener added to tea",
             "Coffee intake", "Tea intake"]:
    af = next((x for x in raw if x["Exposure"] == expo and "AFGen" in x["Outcome source"]), None)
    bb = next((x for x in raw if x["Exposure"] == expo and "BioBank" in x["Outcome source"]), None)
    if not af or not bb:
        continue
    idx = int(af["Index SNPs"])
    ad, ap, am = int(af["Recovered directly"]), int(af["Proxy substituted"]), int(af["Unavailable (no proxy)"])
    bd, bp, bm, br = (int(bb["Recovered directly"]), int(bb["Proxy substituted"]),
                      int(bb["Unavailable (no proxy)"]), int(bb["Retained (Table S1)"]))
    special = " \u2020" if bm < 0 else ""
    rows.append([expo, str(idx), str(ad), str(ap), str(am), str(bd), str(bp),
                 ("\u2014" if bm < 0 else str(bm)), str(br) + special])

tb = doc.add_table(rows=1, cols=len(head))
_t = tb._tbl
_t.remove(_t.tblPr)
_t.insert(0, deepcopy(src_tblPr))
widths = [3.9, 1.5, 1.9, 1.7, 2.0, 1.9, 1.7, 2.0, 1.7]
for i, hh in enumerate(head):
    c = tb.rows[0].cells[i]
    c.text = ""
    par = c.paragraphs[0]
    par.paragraph_format.space_after = Pt(0)
    run = par.add_run(hh)
    run.bold = True
    run.font.size = Pt(7.5)
    c.width = Cm(widths[i])
for rec in rows:
    cells = tb.add_row().cells
    for i, v in enumerate(rec):
        cells[i].text = ""
        par = cells[i].paragraphs[0]
        par.paragraph_format.space_after = Pt(0)
        run = par.add_run(v)
        run.font.size = Pt(7.5)
        cells[i].width = Cm(widths[i])

notes = [
    "Counts were re-derived on 30 October 2026 by querying the released AFGen 2018 (ebi-a-GCST006061) and "
    "BioBank Japan (bbj-a-71) summary statistics against the European index set for each exposure, using the "
    "OpenGWAS association endpoint. Recovered directly = index variants present in the outcome panel; "
    "proxied = variants retained in Table S1 that are not present as index variants and were therefore carried "
    "by a substitute variant; unavailable = index variants for which neither the index variant nor a substitute "
    "was retained.",
    "AFGen 2018 recovered every index variant for all seven exposures: there was no proxy substitution and no "
    "unavailable variant in that panel, and the counts in Table S1 are identical to the index-set sizes.",
    "BioBank Japan totals: 15 proxy substitutions across the six exposures other than tea intake, and 29 index "
    "variants for which no variant was retained.",
    "\u2020 The BioBank Japan tea panel contains 36 variants, four more than the 32-variant European index set. "
    "Proxy substitution cannot increase a variant count, so this panel cannot have been derived by substituting "
    "variants into the European index set alone: 26 index variants were recovered, and 10 further variants are "
    "neither index variants nor substitutes for them. A plausible explanation is that the panel was clumped "
    "against an East Asian linkage-disequilibrium reference or that additional variants crossed the selection "
    "threshold in that cohort, but the present record does not identify which. This row should be re-derived "
    "from the original harmonisation script, or described explicitly in the Methods, before submission.",
]
for n in notes:
    par = doc.add_paragraph()
    par.paragraph_format.space_after = Pt(2)
    run = par.add_run(n)
    run.font.size = Pt(7.5)

doc.save(SUP)
print("tables:", len(doc.tables))
d2 = docx.Document(SUP)
print("S31 present:", any(p.text.startswith("Table S31.") for p in d2.paragraphs))
print("S1 footnote has pointer:", any("itemised in Table S31" in p.text for p in d2.paragraphs))
