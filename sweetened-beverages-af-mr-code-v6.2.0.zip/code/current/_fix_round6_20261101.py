# -*- coding: utf-8 -*-
import docx
from docx.shared import Pt
B=r'C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013'
def set_para(p,text):
    if not p.runs: p.add_run(text)
    else:
        p.runs[0].text=text
        for r in p.runs[1:]: r.text=''
def rep(d,old,new,expected=1,label=''):
    n=0
    for p in d.paragraphs:
        if old in p.text:
            set_para(p,p.text.replace(old,new)); n+=1
    for tb in d.tables:
        for row in tb.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    if old in p.text:
                        set_para(p,p.text.replace(old,new)); n+=1
    assert n==expected,'%s expected %d got %d'%(label,expected,n)
    print('OK',label,n)

m=docx.Document(B+r'\Manuscript.docx')
reps=[
('artificially sweetened beverage (ASB) intake has not been examined by Mendelian randomization','artificially sweetened beverage (ASB) intake has, to our knowledge, not been examined by Mendelian randomization specifically'),
('the only signal surviving correction in the pre-specified family of seven','the only signal surviving correction in the seven-test family'),
('supported a shared variant with Nielsen (0.894) and FinnGen (0.906), not AFGen (0.362)','supported a shared variant with Nielsen (0.894) and FinnGen (0.906); AFGen was inconclusive (0.362)'),
('No sweetened-beverage exposure was causally associated','No sweetened-beverage exposure satisfied the causal criteria'),
('Nielsen 2018 (primary)','Nielsen 2018'),
('only Nielsen 2018 retained a nominal association','only Nielsen retained a nominal association'),
('(PP.H4 0.894 in Nielsen and 0.906 in FinnGen; 0.362 in AFGen)','(PP.H4 0.894 in Nielsen and 0.906 in FinnGen; inconclusive in AFGen, 0.362)'),
('Three further observations are consistent with this localisation but carry less weight.','Further observations are consistent with this localisation but carry less weight.'),
]
for a,b in reps: rep(m,a,b,label='main: '+a[:38]) if a!='only Nielsen 2018 retained a nominal association' else rep(m,a,b,expected=2,label='main: '+a[:38])
old=('The evidence for an adiposity-linked origin therefore rests on three lines: colocalization, which places the shared coffee–AF signal at FTO while excluding the caffeine-metabolism loci; the instrument-level pattern, in which the two largest single-variant estimates come from adiposity loci whose magnitudes are not biologically credible as coffee-specific effects; and the adiposity-locus exclusion, which narrows the between-source range. These lines are ordered by how little they depend on a statistically significant exposure-wide MR estimate: the first carries most weight, the second is descriptive, and the third is post hoc and precision-limited.')
new=('The evidence for an adiposity-linked origin therefore rests on two primary lines: colocalization, which localized the shared signal to FTO in the two larger panels while showing no shared counterpart at the caffeine-metabolism loci; and the instrument-level pattern, in which the two largest single-variant estimates come from adiposity loci whose magnitudes are not biologically credible as coffee-specific effects. The adiposity-locus exclusion provides a post hoc consistency check rather than independent evidence: it narrows the between-source range, but no heterogeneity was detectable before exclusion. These lines are ordered by how little they depend on a statistically significant exposure-wide MR estimate: colocalization carries most weight, and the instrument-level pattern is descriptive.')
rep(m,old,new,label='P095 two lines plus consistency check')
m.save(B+r'\Manuscript.docx')

c=docx.Document(B+r'\Cover_Letter.docx')
rep(c,'for which no Mendelian randomization estimate has previously been published','for which, to our knowledge, no Mendelian randomization study has estimated intake specifically',label='CL ASB')
rep(c,'0.362 in the smaller AFGen panel','inconclusive in the smaller AFGen panel, 0.362',label='CL AFGen')
rep(c,'and instruments restricted to the caffeine-metabolism windows are null while the remainder of the instrument set carries the signal.','and instruments restricted to the caffeine-metabolism windows were null whereas the remainder carried the signal, although the between-subgroup difference was not statistically significant.',label='CL subgroup')
c.save(B+r'\Cover_Letter.docx')

h=docx.Document(B+r'\Highlights.docx')
rep(h,"Coffee's AF signal colocalized at FTO in two panels (PP.H4 0.894/0.906; 0.362 in AFGen), not at caffeine loci.","Coffee's signal colocalized at FTO in two panels (PP.H4 0.894/0.906; inconclusive in AFGen), not at caffeine loci.",label='HL FTO')
rep(h,'No sweetened-beverage exposure was causally associated with AF; sources spanned at most two independent clusters.','No sweetened-beverage exposure met the pre-specified causal criteria; sources spanned at most two independent clusters.',label='HL null')
h.save(B+r'\Highlights.docx')

s=docx.Document(B+r'\Supplement.docx')
rep(s,'247 words','249 words',label='S9 word count')
s.save(B+r'\Supplement.docx')

# verify counts
m2=docx.Document(B+r'\Manuscript.docx'); ps=[p.text for p in m2.paragraphs]
def idx(x): return next(i for i,t in enumerate(ps) if t.strip()==x)
print('ABSTRACT',len(' '.join(ps[6:9]).split()))
print('BODY',sum(len(ps[k].split()) for k in range(idx('Introduction'),idx('Declarations'))))
