from pathlib import Path
import hashlib
import json
import re
import pymupdf
from PIL import Image, ImageDraw

BASE = Path(r"C:\Users\64915\WorkBuddy\2026-10-30-20-42-58\_targeted_fix_20261124")
NEW = BASE / "render"
CONTACT = BASE / "render" / "contact"
CONTACT.mkdir(exist_ok=True)
OLD = {
    "Manuscript": BASE / "package" / "verification" / "Manuscript_rendered.pdf",
    "Supplement": BASE / "package" / "verification" / "Supplement_rendered.pdf",
    "Cover_Letter": Path(r"C:\Users\64915\WorkBuddy\2026-10-30-20-42-58\_narrative_adjust_20261122\render_clean\Cover_Letter.pdf"),
    "Highlights": Path(r"C:\Users\64915\WorkBuddy\2026-10-30-20-42-58\_narrative_adjust_20261122\render_clean\Highlights.pdf"),
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def compact(s):
    return re.sub(r"\s+", " ", s).strip()


results = {}
for stem, old_path in OLD.items():
    new_path = NEW / f"{stem}.pdf"
    old = pymupdf.open(old_path)
    new = pymupdf.open(new_path)
    page_results = []
    images = []
    for i in range(max(len(old), len(new))):
        if i >= len(old) or i >= len(new):
            page_results.append({"page": i + 1, "missing_on_one_side": True})
            continue
        a, b = old[i], new[i]
        ta, tb = a.get_text("text"), b.get_text("text")
        pa = a.get_pixmap(dpi=110, alpha=False)
        pb = b.get_pixmap(dpi=110, alpha=False)
        pixels_equal = pa.width == pb.width and pa.height == pb.height and pa.samples == pb.samples
        rect = b.rect
        outside = []
        for block in b.get_text("dict")["blocks"]:
            for line in block.get("lines", []):
                for span in line.get("spans", []):
                    x0, y0, x1, y1 = span["bbox"]
                    if x0 < rect.x0 - 1 or y0 < rect.y0 - 1 or x1 > rect.x1 + 1 or y1 > rect.y1 + 1:
                        outside.append({"text": span["text"], "bbox": span["bbox"]})
        page_results.append({
            "page": i + 1,
            "text_equal_baseline": ta == tb,
            "pixels_equal_baseline_110dpi": pixels_equal,
            "text_sha256": sha(tb.encode("utf-8")),
            "characters": len(tb),
            "outside_page_spans": outside,
            "start": compact(tb)[:280],
            "end": compact(tb)[-280:],
        })
        pix = b.get_pixmap(dpi=120, alpha=False)
        im = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
        im.thumbnail((590, 780))
        tile = Image.new("RGB", (610, 820), "white")
        tile.paste(im, ((610 - im.width) // 2, 30))
        ImageDraw.Draw(tile).text((10, 8), f"{stem} p{i + 1}", fill="black")
        images.append(tile)
    if len(new) > len(old):
        for i in range(len(old), len(new)):
            b = new[i]
            pix = b.get_pixmap(dpi=120, alpha=False)
            im = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
            im.thumbnail((590, 780))
            tile = Image.new("RGB", (610, 820), "white")
            tile.paste(im, ((610 - im.width) // 2, 30))
            ImageDraw.Draw(tile).text((10, 8), f"{stem} p{i + 1}", fill="black")
            images.append(tile)
    contact_files = []
    for start in range(0, len(images), 6):
        group = images[start:start + 6]
        sheet = Image.new("RGB", (1220, 2460), "#d9d9d9")
        for j, im in enumerate(group):
            sheet.paste(im, ((j % 2) * 610, (j // 2) * 820))
        target = CONTACT / f"{stem}_{start + 1:02d}-{start + len(group):02d}.png"
        sheet.save(target)
        contact_files.append(str(target))
    full_text = "\n".join(p.get_text("text") for p in new)
    results[stem] = {
        "new_pdf": str(new_path),
        "new_pdf_sha256": sha(new_path.read_bytes()),
        "old_pages": len(old),
        "new_pages": len(new),
        "text_changed_pages": [p["page"] for p in page_results if not p.get("text_equal_baseline", False)],
        "pixel_changed_pages": [p["page"] for p in page_results if not p.get("pixels_equal_baseline_110dpi", False)],
        "pages_with_outside_spans": [p["page"] for p in page_results if p.get("outside_page_spans")],
        "blank_pages": [p["page"] for p in page_results if p.get("characters", 1) == 0],
        "replacement_character_pages": [i + 1 for i, p in enumerate(new) if "\ufffd" in p.get_text("text")],
        "unresolved_placeholders": [x for x in ("__TOTAL__", "__ABSTRACT__") if x in full_text],
        "contact_files": contact_files,
        "pages": page_results,
    }

all_ms = compact(" ".join(p.get_text("text") for p in pymupdf.open(NEW / "Manuscript.pdf")))
all_sp = compact(" ".join(p.get_text("text") for p in pymupdf.open(NEW / "Supplement.pdf")))
results["cross_checks"] = {
    "manuscript_mde": "from 1.37–1.70 to 1.52–1.73" in all_ms,
    "manuscript_yuan": "OR 0.95, 95% CI 0.71–1.28; P = 0.732; Cochran Q P = 0.010" in all_ms,
    "supplement_strobe_234": "Abstract (Background / Methods and Results / Conclusions), 234 words" in all_sp,
    "supplement_s29_q": "Cochran Q = 9.156 (df = 2), Q P = 0.0103" in all_sp,
    "supplement_s29_or": "0.95 (0.71–1.28)" in all_sp,
    "supplement_s29_recovered": "3 / 3" in all_sp,
}
results["all_pass"] = all(
    not r["blank_pages"] and not r["replacement_character_pages"] and not r["unresolved_placeholders"]
    and not r["pages_with_outside_spans"]
    for k, r in results.items() if k in OLD
) and all(results["cross_checks"].values())
out = BASE / "review" / "round_C_render.json"
out.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8")
summary = {k: {x: y for x, y in v.items() if x not in {"pages", "contact_files"}} for k, v in results.items() if k in OLD}
summary["cross_checks"] = results["cross_checks"]
summary["all_pass"] = results["all_pass"]
print(json.dumps(summary, ensure_ascii=False, indent=2))
if not results["all_pass"]:
    raise SystemExit(1)
