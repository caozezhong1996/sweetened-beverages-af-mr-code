# Adiposity-locus sensitivity across all three ancestral-matched outcome datasets.
# For every exposure x outcome: RE-IVW with all instruments, and with instruments
# lying within 500 kb of a genome-wide-significant BMI locus removed.
suppressMessages({library(data.table); library(TwoSampleMR)})
RES <- "C:/a3work"

re_ivw <- function(bx, by, sy) {
  w <- 1 / sy^2
  b <- sum(w * bx * by) / sum(w * bx^2)
  se_fe <- sqrt(1 / sum(w * bx^2))
  q <- sum(w * (by - b * bx)^2)
  df <- length(bx) - 1
  infl <- max(1, sqrt(q / df))
  se <- se_fe * infl
  c(b = b, se = se, lo = b - 1.96 * se, hi = b + 1.96 * se,
    p = 2 * pnorm(-abs(b / se)), Q = q, Qp = pchisq(q, df, lower.tail = FALSE), infl = infl)
}

bmi <- fread(file.path(RES, "tmp_bmi_instruments_v46.csv"))
bmi <- bmi[!is.na(chr) & !is.na(pos)]
WIN <- 500000

EXPO <- c("Sugar_added_to_tea", "Sugar_added_to_coffee", "Fizzy_drink_intake_SSB",
          "Low_calorie_drink_intake_ASB", "Artificial_sweetener_added_to_tea",
          "Coffee_intake", "Tea_intake")
LAB <- c("Sugar added to tea", "Sugar added to coffee", "Fizzy drinks (SSB)",
         "Low-calorie drinks (ASB)", "Sweetener added to tea", "Coffee intake", "Tea intake")
OUTS <- c(Nielsen = "ebi_a_GCST006414", `FinnGen R13` = "finngen_R13",
          `Yuan 2025` = "yuan")

get_d <- function(e, src) {
  if (src == "yuan") {
    expo <- fread(file.path(RES, sprintf("dat_%s_ebi_a_GCST006414.csv", e)))
    expo <- expo[mr_keep %in% c(TRUE, "TRUE")]
    ex <- format_data(as.data.frame(expo), type = "exposure", snp_col = "SNP",
                      beta_col = "beta.exposure", se_col = "se.exposure",
                      effect_allele_col = "effect_allele.exposure",
                      other_allele_col = "other_allele.exposure",
                      eaf_col = "eaf.exposure", pval_col = "pval.exposure")
    yo <- fread(file.path(RES, "yuan2025_instruments.tsv"))[SNP %in% ex$SNP]  # keep shared SNPs in every exposure
    out <- format_data(as.data.frame(yo), type = "outcome", snp_col = "SNP",
                       beta_col = "beta.out", se_col = "se.out",
                       effect_allele_col = "ea.out", other_allele_col = "oa.out",
                       eaf_col = "eaf.out", pval_col = "pval.out")
  } else {
    f <- file.path(RES, sprintf("dat_%s_%s.csv", e, src))
    if (!file.exists(f)) return(NULL)
    d0 <- fread(f)
    if ("mr_keep" %in% names(d0)) d0 <- d0[mr_keep %in% c(TRUE, "TRUE")]
    ex <- format_data(as.data.frame(d0), type = "exposure", snp_col = "SNP",
                      beta_col = "beta.exposure", se_col = "se.exposure",
                      effect_allele_col = "effect_allele.exposure",
                      other_allele_col = "other_allele.exposure",
                      eaf_col = "eaf.exposure", pval_col = "pval.exposure")
    out <- format_data(as.data.frame(d0), type = "outcome", snp_col = "SNP",
                       beta_col = "beta.outcome", se_col = "se.outcome",
                       effect_allele_col = "effect_allele.outcome",
                       other_allele_col = "other_allele.outcome",
                       eaf_col = "eaf.outcome", pval_col = "pval.outcome")
  }
  d <- harmonise_data(ex, out, action = 2)
  d[d$mr_keep %in% c(TRUE, "TRUE"), ]
}

pos_of <- function(e) {
  s <- fread(file.path(RES, sprintf("dat_%s_ebi_a_GCST006414.csv", e)))
  s[, .(SNP, chr = as.integer(chr), pos = as.integer(pos))]
}

rows <- list()
for (oi in seq_along(OUTS)) {
  oname <- names(OUTS)[oi]; src <- OUTS[oi]
  for (i in seq_along(EXPO)) {
    d <- tryCatch(get_d(EXPO[i], src), error = function(x) { cat("   ERR:", conditionMessage(x), "
"); NULL })
    if (is.null(d) || nrow(d) < 3) { cat("!!", oname, LAB[i], "\n"); next }
    d <- merge(as.data.table(d), pos_of(EXPO[i]), by = "SNP", all.x = TRUE)
    nb <- integer(0)
    for (k in seq_len(nrow(d))) {
      if (is.na(d$chr[k])) next
      if (any(bmi$chr == d$chr[k] & abs(bmi$pos - d$pos[k]) <= WIN)) nb <- c(nb, k)
    }
    m1 <- re_ivw(d$beta.exposure, d$beta.outcome, d$se.outcome)
    keep <- if (length(nb)) d[-nb, ] else d
    m2 <- if (nrow(keep) >= 3) re_ivw(keep$beta.exposure, keep$beta.outcome, keep$se.outcome)
          else c(b = NA, se = NA, lo = NA, hi = NA, p = NA, Q = NA, Qp = NA, infl = NA)
    cat(sprintf("%-14s %-24s n=%2d OR=%.2f (%.2f-%.2f) P=%.4f | drop%2d -> n=%2d OR=%.2f (%.2f-%.2f) P=%.4f\n",
                oname, LAB[i], nrow(d), exp(m1["b"]), exp(m1["lo"]), exp(m1["hi"]), m1["p"],
                length(nb), nrow(keep), exp(m2["b"]), exp(m2["lo"]), exp(m2["hi"]), m2["p"]))
    rows[[length(rows) + 1]] <- data.table(
      outcome = oname, exposure = LAB[i],
      n = nrow(d), OR = exp(m1["b"]), lo = exp(m1["lo"]), hi = exp(m1["hi"]),
      p = m1["p"], Qp = m1["Qp"],
      n_adipo = length(nb), n_clean = nrow(keep),
      OR_clean = exp(m2["b"]), lo_clean = exp(m2["lo"]), hi_clean = exp(m2["hi"]),
      p_clean = m2["p"])
  }
}
dt <- rbindlist(rows)
fwrite(dt, file.path(RES, "adiposity_sensitivity_all_cohorts_corrected.csv"))
cat("\nwrote adiposity_sensitivity_all_cohorts.csv  rows:", nrow(dt), "\n")

p <- dt[!is.na(p_clean)]
p[, `:=`(attenuation = round((OR - OR_clean) / (OR - 1) * 100, 0))]
print(p[order(outcome, -abs(OR - 1)), .(outcome, exposure, OR = round(OR, 2), p = signif(p, 3),
          OR_clean = round(OR_clean, 2), p_clean = signif(p_clean, 3), attenuation)])
