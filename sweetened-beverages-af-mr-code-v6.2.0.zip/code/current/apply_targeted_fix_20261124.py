from pathlib import Path
import argparse
import hashlib
import io
import json
import re
import zipfile
import xml.etree.ElementTree as ET

BASE = Path(r"C:\Users\64915\WorkBuddy\2026-10-30-20-42-58\_targeted_fix_20261124")
BACKUP = BASE / "backup"
OUTPUT = BASE / "output"
REVIEW = BASE / "review"
CONFIG = json.loads((BASE / "revision_texts.json").read_text(encoding="utf-8"))
W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
XML = "http://www.w3.org/XML/1998/namespace"
NS = {"w": W}
EXPECTED_BASE_SHA = {
    "Manuscript": "b482045b0ceef744b7c595f2a7fcca2aa80c2581cf870d994565f8eee8e24a0a",
    "Supplement": "61409b00d745a0a7da4ecd0d2ed7c5741d96c45af0d39497f278c35ec05969d1",
    "Cover_Letter": "55fee2b99028f8039611026e46abe76a76a682b11521212a8ee9d0b1f3e5de41",
}
EXPECTED_CHANGES = {"Manuscript": 17, "Supplement": 19, "Cover_Letter": 3}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ptext(p):
    return "".join(node.text or "" for node in p.findall(".//w:t", NS))


def read_source(name):
    path = BACKUP / f"{name}.docx"
    actual_sha = sha(path.read_bytes())
    if actual_sha != EXPECTED_BASE_SHA[name]:
        raise RuntimeError(f"{name}: unexpected base SHA256 {actual_sha}")
    with zipfile.ZipFile(path) as zin:
        if zin.testzip() is not None:
            raise RuntimeError(f"{name}: base CRC failure")
        infos = [i for i in zin.infolist() if not i.is_dir()]
        parts = {i.filename: zin.read(i.filename) for i in infos}
    for _, (prefix, uri) in ET.iterparse(
        io.BytesIO(parts["word/document.xml"]), events=("start-ns",)
    ):
        ET.register_namespace(prefix, uri)
    root = ET.fromstring(parts["word/document.xml"])
    paragraphs = root.findall(".//w:p", NS)
    return path, infos, parts, root, paragraphs


def build_candidate_texts(name, paragraphs):
    before = [ptext(p) for p in paragraphs]
    after = before.copy()
    changes = []
    job = CONFIG[name]
    full = {int(k): v for k, v in job.get("full", {}).items()}
    edits = {int(k): v for k, v in job.get("edits", {}).items()}
    overlap = set(full) & set(edits)
    if overlap:
        raise RuntimeError(f"{name}: full/edit index overlap {sorted(overlap)}")
    targets = sorted(set(full) | set(edits))
    if len(targets) != EXPECTED_CHANGES[name]:
        raise RuntimeError(f"{name}: expected {EXPECTED_CHANGES[name]} targets, got {len(targets)}")
    for idx in targets:
        if idx < 0 or idx >= len(before):
            raise RuntimeError(f"{name}: paragraph index {idx} out of range")
        old = before[idx]
        if not old:
            raise RuntimeError(f"{name}: paragraph {idx} is empty")
        new = full.get(idx, old)
        for old_fragment, new_fragment in edits.get(idx, []):
            count = new.count(old_fragment)
            if count != 1:
                raise RuntimeError(
                    f"{name}: paragraph {idx} fragment {old_fragment!r} matched {count} times"
                )
            new = new.replace(old_fragment, new_fragment, 1)
        if new == old:
            raise RuntimeError(f"{name}: paragraph {idx} would not change")
        after[idx] = new
        changes.append({"paragraph": idx, "old": old, "new": new})
    return before, after, changes


def resolve_dynamic_counts(texts):
    manuscript = texts["Manuscript"]["after"].copy()
    if manuscript[5] != "Total word count: __TOTAL__":
        raise RuntimeError(f"Manuscript: unresolved total placeholder in {manuscript[5]!r}")
    total = sum(len(x.split()) for x in manuscript)
    manuscript[5] = f"Total word count: {total:,}"
    total_check = sum(len(x.split()) for x in manuscript)
    if total_check != total:
        raise RuntimeError(f"Manuscript: total word count fixed point failed {total} != {total_check}")
    abstract = sum(len(x.split()) for x in manuscript[7:10])
    clinical = sum(len(x.split()) for x in manuscript[13:21])
    body = sum(len(x.split()) for x in manuscript[21:102])
    texts["Manuscript"]["after"] = manuscript
    for change in texts["Manuscript"]["changes"]:
        if change["paragraph"] == 5:
            change["new"] = manuscript[5]
    supplement = texts["Supplement"]["after"].copy()
    expected = "Abstract (Background / Methods and Results / Conclusions), __ABSTRACT__ words"
    if supplement[1230] != expected:
        raise RuntimeError(f"Supplement: unresolved abstract placeholder in {supplement[1230]!r}")
    supplement[1230] = (
        "Abstract (Background / Methods and Results / Conclusions), "
        f"{abstract} words"
    )
    texts["Supplement"]["after"] = supplement
    for change in texts["Supplement"]["changes"]:
        if change["paragraph"] == 1230:
            change["new"] = supplement[1230]
    return {
        "abstract": abstract,
        "clinical_perspective_including_headings": clinical,
        "introduction_through_conclusions": body,
        "total": total,
        "title_page": manuscript[5],
        "strobe_abstract_line": supplement[1230],
    }


def write_candidate(name, source, before, after, changes):
    _, infos, parts, root, paragraphs = source
    by_index = {c["paragraph"]: c for c in changes}
    for idx, change in by_index.items():
        nodes = paragraphs[idx].findall(".//w:t", NS)
        if not nodes:
            raise RuntimeError(f"{name}: paragraph {idx} has no text nodes")
        nodes[0].text = after[idx]
        nodes[0].set(f"{{{XML}}}space", "preserve")
        for node in nodes[1:]:
            node.text = ""
    new_document = ET.tostring(root, encoding="utf-8", xml_declaration=True)
    new_parts = dict(parts)
    new_parts["word/document.xml"] = new_document
    out_path = OUTPUT / f"{name}.docx"
    temp_path = OUTPUT / f".{name}.tmp.docx"
    with zipfile.ZipFile(temp_path, "w") as zout:
        for info in infos:
            zout.writestr(info, new_parts[info.filename])
    temp_path.replace(out_path)
    with zipfile.ZipFile(out_path) as zf:
        bad_crc = zf.testzip()
        check_parts = {n: zf.read(n) for n in zf.namelist() if not n.endswith("/")}
    check_root = ET.fromstring(check_parts["word/document.xml"])
    check_texts = [ptext(p) for p in check_root.findall(".//w:p", NS)]
    non_doc_diffs = sorted(
        n for n in parts
        if n != "word/document.xml" and sha(parts[n]) != sha(check_parts.get(n, b""))
    )
    actual_diffs = [i for i, (a, b) in enumerate(zip(before, check_texts)) if a != b]
    expected_diffs = sorted(by_index)
    result = {
        "file": out_path.name,
        "base_sha256": sha((BACKUP / out_path.name).read_bytes()),
        "output_sha256": sha(out_path.read_bytes()),
        "paragraph_count": len(check_texts),
        "changed_paragraphs": actual_diffs,
        "expected_changed_paragraphs": expected_diffs,
        "all_paragraphs_as_expected": check_texts == after,
        "only_expected_paragraphs_changed": actual_diffs == expected_diffs,
        "unchanged_non_document_parts": (
            not non_doc_diffs and set(parts) == set(check_parts)
        ),
        "non_document_differences": non_doc_diffs,
        "crc": bad_crc,
    }
    if not all([
        result["all_paragraphs_as_expected"],
        result["only_expected_paragraphs_changed"],
        result["unchanged_non_document_parts"],
        result["crc"] is None,
    ]):
        raise RuntimeError(f"{name}: candidate verification failed: {result}")
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--write", action="store_true", help="write candidate DOCX files after dry-run checks")
    args = parser.parse_args()
    sources = {}
    texts = {}
    for name in ("Manuscript", "Cover_Letter", "Supplement"):
        source = read_source(name)
        sources[name] = source
        before, after, changes = build_candidate_texts(name, source[4])
        texts[name] = {"before": before, "after": after, "changes": changes}
    counts = resolve_dynamic_counts(texts)
    dry_report = {
        "mode": "write" if args.write else "dry-run",
        "base_sha256": EXPECTED_BASE_SHA,
        "expected_changed_paragraphs": {
            name: sorted(c["paragraph"] for c in item["changes"])
            for name, item in texts.items()
        },
        "word_counts": counts,
        "changes": {name: item["changes"] for name, item in texts.items()},
    }
    (REVIEW / "dry_run.json").write_text(
        json.dumps(dry_report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    write_results = []
    if args.write:
        for name in ("Manuscript", "Cover_Letter", "Supplement"):
            write_results.append(write_candidate(
                name,
                sources[name],
                texts[name]["before"],
                texts[name]["after"],
                texts[name]["changes"],
            ))
        (REVIEW / "apply_report.json").write_text(
            json.dumps({"word_counts": counts, "files": write_results}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    summary = {
        "mode": dry_report["mode"],
        "changed_paragraph_counts": {name: len(item["changes"]) for name, item in texts.items()},
        "word_counts": counts,
        "candidate_files": write_results,
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
