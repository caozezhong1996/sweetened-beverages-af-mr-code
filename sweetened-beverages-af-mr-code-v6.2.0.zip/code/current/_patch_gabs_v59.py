# -*- coding: utf-8 -*-
p = "_gabs_v59.py"
s = open(p, encoding="utf-8").read()

old = r'''txt(74, 60.6, "Colocalizes with AF at FTO (0.894)\nreplication 0.906; no AF signal\nat CYP1A1–CYP1A2 or AHR (PP.H4 ≤ 0.008)",
    size=6.4)'''
new = r'''txt(74, 60.6, "FTO 0.894/0.906 (2 panels); AFGen\ninconclusive (0.362); no AF signal\nat CYP1A1–CYP1A2 or AHR (≤ 0.008)",
    size=6.2)'''
assert old in s, "anchor not found"
s = s.replace(old, new)
s = s.replace("Graphical abstract v57 — 证据校准版（脂肪相关多效性为更简约解释）。",
              "Graphical abstract v59 — 右框同步 AFGen 2018 不确定结果 (PP.H4 0.362)。")
s = s.replace("Graphical_Abstract_v58.png", "Graphical_Abstract_v59.png")
open(p, "w", encoding="utf-8").write(s)
print("patched")
for line in s.splitlines():
    if "FTO 0.894" in line or "inconclusive (0.362)" in line or "Graphical_Abstract_v59" in line:
        print("  ", line.strip()[:110])
