# -*- coding: utf-8 -*-
p = r'C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\README_投稿包.md'
s = open(p, encoding='utf-8').read()
TITLE = 'Adiposity-Linked Pleiotropy in the Coffee–Atrial Fibrillation Signal: A Two-Sample Mendelian Randomization Study'
reps = [
('手稿（摘要 **246** 词；**55** 条参考文献；4 张表；正文 **8,952** 词）', '手稿（摘要 **248** 词；**55** 条参考文献；4 张表；正文 **9,233** 词）'),
('## 本稿要点（2026-10-31 定稿）', '## 本稿要点（2026-11-01 证据校准定稿）'),
('定位：**已发表的咖啡–房颤阳性遗传信号，其载体是体脂位点，不在咖啡或咖啡因本身**。', '定位：**已发表的咖啡–房颤阳性遗传信号，更兼容脂肪相关多效性，而非咖啡因特异通路；两种通路均未被完全排除**。'),
('- **标题（18 词，含副标题）**：`Adiposity Loci Largely Account for a Recurring Coffee–Atrial Fibrillation Signal: A Two-Sample Mendelian Randomization Study`', '- **标题（12 词，含副标题）**：`' + TITLE + '`'),
('这条不依赖统计功效，是全文最硬的一环。', '这条不要求全暴露 MR 估计显著，但仍受区域关联强度、SNP 覆盖、LD 对齐、模型假设和先验影响，是全文权重最高的一环。'),
('4. 脂肪位点剔除（最弱一环，已如实降级）：三源 1.26–1.39，两两不可区分（Q = 2.97，df 2，P = 0.23）。', '4. 脂肪位点剔除（最弱一环，已如实降级）：剔除前三源已两两不可区分（Q = 2.87，df 2，P = 0.24）；剔除后 1.26–1.39，仅点估计范围收窄，不作机制收敛证据。'),
('按首次出现顺序严格 1–54 递增', '按首次出现顺序严格 1–55 递增'),
('辩护要点：rs1421085 是内含子调控变异（调控 IRX3/IRX5），非催化结构域，故脂肪功能与 m6A 酶活在**该变异层面可分离**；且小鼠证据关乎心房组织内 Fto 剂量，非终生遗传变异。已写入 Discussion 新段。', '辩护要点：rs1421085 的脂肪效应已归因于 IRX3/IRX5 调控（Claussnitzer 2015），但 FTO 表达效应不能排除，也未做 FTO eQTL 共定位；故脂肪解释仅为**更简约的解释**，m6A 成分仍有可能。已写入 Discussion。'),
('本稿摘要 246 词。', '本稿摘要 248 词。'),
('- 标题：`Adiposity Loci Largely Account for a Recurring Coffee–Atrial Fibrillation Signal: A Two-Sample Mendelian Randomization Study`', '- 标题：`' + TITLE + '`'),
('- 数据与代码：概念 DOI 10.5281/zenodo.22099675（版本 DOI 10.5281/zenodo.23459526）。', '- 数据与代码：概念 DOI 10.5281/zenodo.22099675；当前公开版仍为 v5.2.4（版本 DOI 10.5281/zenodo.23450526），**上传本稿对应新版后方可投稿**。'),
('- [ ] 图文摘要用 2026-10-31 新版（标题与结论已随正文改写）', '- [ ] 图文摘要用 2026-11-01 证据校准版（标题与结论已随正文改写）\n- [ ] Zenodo 发布与当前 S1–S31、逐变异数据及代码一致的新版本'),
]
for old, new in reps:
    assert old in s, 'MISSING: ' + old[:90]
    s = s.replace(old, new)
open(p, 'w', encoding='utf-8').write(s)
print('updated', len(reps), 'items')
