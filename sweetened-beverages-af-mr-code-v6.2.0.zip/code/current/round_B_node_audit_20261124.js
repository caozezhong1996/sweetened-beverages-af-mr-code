/* Independent OOXML audit: manual ZIP parsing, CRC32, SHA256 and regex XML text extraction. */
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');
const BASE = 'C:/Users/64915/WorkBuddy/2026-10-30-20-42-58/_targeted_fix_20261124';
const SUB = 'C:/Users/64915/Desktop/JAHA投稿包_奶茶房颤MR_20261013';
const OUT = BASE + '/review/round_B_node.json';
const EXPECTED = {
  'Manuscript.docx': [5,9,23,24,25,59,71,82,86,87,92,94,95,97,98,99,101],
  'Cover_Letter.docx': [12,14,16],
  'Supplement.docx': [1230,1311,1740,1764,1836,1898,2347,2519,2537,2609,2984,2985,2986,2987,2988,2989,2990,3001,3003]
};
const EXPECTED_SHA = {
  'Manuscript.docx': 'df2b92489432e9e247d23c1869da2a7b9ad767be7765e7aef854e447679d4722',
  'Cover_Letter.docx': '6910ad46cb7bd01b26c722ea79d0dafa37931589616ce701d5db93dcf83bf0cc',
  'Supplement.docx': '7b264eef245abaa6712d1f4c1fbafff6d9f286943704dd4107b257bec60fc882',
  'Highlights.docx': '2bf1e7be1362c4b5eb2d6fe3e444182eb4bcf6ac65b96298c3099b4fc7811e7f'
};
function sha(x) { return crypto.createHash('sha256').update(x).digest('hex'); }
const crcTable = new Uint32Array(256);
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
  crcTable[n] = c >>> 0;
}
function crc32(x) {
  let c = 0xFFFFFFFF;
  for (const byte of x) c = crcTable[(c ^ byte) & 0xFF] ^ (c >>> 8);
  return (c ^ 0xFFFFFFFF) >>> 0;
}
function unzip(file) {
  const b = fs.readFileSync(file);
  let eocd = -1;
  for (let i = b.length - 22; i >= Math.max(0, b.length - 65558); i--) {
    if (b.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('EOCD not found: ' + file);
  const declared = b.readUInt16LE(eocd + 10);
  let p = b.readUInt32LE(eocd + 16), count = 0;
  const entries = {}, badCrc = [];
  while (p < b.length && b.readUInt32LE(p) === 0x02014b50 && count < declared) {
    const expectedCrc = b.readUInt32LE(p + 16);
    const method = b.readUInt16LE(p + 10), csize = b.readUInt32LE(p + 20), usize = b.readUInt32LE(p + 24);
    const fnLen = b.readUInt16LE(p + 28), exLen = b.readUInt16LE(p + 30), cmLen = b.readUInt16LE(p + 32);
    const lhOff = b.readUInt32LE(p + 42);
    const name = b.toString('utf8', p + 46, p + 46 + fnLen);
    if (b.readUInt32LE(lhOff) !== 0x04034b50) throw new Error('Bad local header: ' + name);
    const start = lhOff + 30 + b.readUInt16LE(lhOff + 26) + b.readUInt16LE(lhOff + 28);
    const raw = b.subarray(start, start + csize);
    const data = method === 0 ? raw : method === 8 ? zlib.inflateRawSync(raw) : null;
    if (!data || data.length !== usize) throw new Error('Decode/size mismatch: ' + name);
    if (crc32(data) !== expectedCrc) badCrc.push(name);
    entries[name] = data;
    p += 46 + fnLen + exLen + cmLen;
    count++;
  }
  if (count !== declared) throw new Error('Central directory count mismatch: ' + file);
  return { entries, badCrc, count, fileSha: sha(b) };
}
function decodeXml(s) {
  return s.replace(/&(#x[0-9a-fA-F]+|#[0-9]+|lt|gt|amp|quot|apos);/g, (_, e) => {
    if (e === 'lt') return '<'; if (e === 'gt') return '>'; if (e === 'amp') return '&';
    if (e === 'quot') return '"'; if (e === 'apos') return "'";
    return String.fromCodePoint(e.startsWith('#x') ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10));
  });
}
function paragraphTexts(xml) {
  const paras = xml.match(/<w:p\b[\s\S]*?<\/w:p>/g) || [];
  return paras.map(p => {
    let out = '';
    const re = /<w:t\b[^>]*>([\s\S]*?)<\/w:t>/g;
    let m;
    while ((m = re.exec(p)) !== null) out += decodeXml(m[1]);
    return out;
  });
}
function readDoc(file) {
  const z = unzip(file);
  const xml = z.entries['word/document.xml'].toString('utf8');
  const core = z.entries['docProps/core.xml'].toString('utf8');
  const titleMatch = core.match(/<dc:title\b[^>]*>([\s\S]*?)<\/dc:title>/);
  const tables = xml.match(/<w:tbl\b[\s\S]*?<\/w:tbl>/g) || [];
  return {
    z, xml, paras: paragraphTexts(xml), tables,
    title: titleMatch ? decodeXml(titleMatch[1]) : '',
    cantSplit: tables.map(t => (t.match(/<w:cantSplit\b/g) || []).length)
  };
}
const result = { files: {}, checks: {} };
const docs = {};
for (const name of Object.keys(EXPECTED)) {
  const oldDoc = readDoc(BASE + '/backup/' + name);
  const newDoc = readDoc(SUB + '/' + name);
  docs[name] = newDoc;
  const diffs = [];
  for (let i = 0; i < Math.max(oldDoc.paras.length, newDoc.paras.length); i++) {
    if (oldDoc.paras[i] !== newDoc.paras[i]) diffs.push(i);
  }
  const nonDocDiff = [];
  for (const namePart of Object.keys(oldDoc.z.entries)) {
    if (namePart === 'word/document.xml') continue;
    const a = oldDoc.z.entries[namePart], b = newDoc.z.entries[namePart];
    if (!b || sha(a) !== sha(b)) nonDocDiff.push(namePart);
  }
  for (const namePart of Object.keys(newDoc.z.entries)) {
    if (!oldDoc.z.entries[namePart]) nonDocDiff.push(namePart + ':NEW');
  }
  result.files[name] = {
    sha256: sha(fs.readFileSync(SUB + '/' + name)),
    zip_entries: newDoc.z.count,
    bad_crc: newDoc.z.badCrc,
    paragraphs: newDoc.paras.length,
    changed_paragraphs: diffs,
    expected_paragraphs: EXPECTED[name],
    non_document_differences: nonDocDiff,
    core_title_equal: oldDoc.title === newDoc.title && newDoc.title.length > 0,
    cant_split_equal: JSON.stringify(oldDoc.cantSplit) === JSON.stringify(newDoc.cantSplit),
    cant_split_by_table: newDoc.cantSplit
  };
}
const ms = docs['Manuscript.docx'].paras;
const wc = a => a.reduce((n, s) => n + (s.trim() ? s.trim().split(/\s+/).length : 0), 0);
result.checks.word_counts = {
  abstract: wc(ms.slice(7,10)), clinical_perspective: wc(ms.slice(13,21)),
  body: wc(ms.slice(21,102)), total: wc(ms), title_page: ms[5]
};
const refs = ms.filter(x => /^\d+\. /.test(x));
const oldRefs = readDoc(BASE + '/backup/Manuscript.docx').paras.filter(x => /^\d+\. /.test(x));
result.checks.references_61_identical = refs.length === 61 && JSON.stringify(refs) === JSON.stringify(oldRefs);
const sp = docs['Supplement.docx'].paras;
result.checks.s29_cells = {
  method: sp[2984], snps: sp[2985], r2: sp[2986], f: sp[2987], or: sp[2988],
  p: sp[2989], mde: sp[2990], recovered: sp[3001], note: sp[3003]
};
result.checks.s29_pass = sp[2984] === 'IVW' && sp[2985] === '3' && sp[2986] === '0.2850' &&
  sp[2987] === '31.6 / 545.5 / 408.0' && sp[2988] === '0.95 (0.71–1.28)' &&
  sp[2989] === '0.732' && sp[2990] === '1.53' && sp[3001] === '3 / 3' &&
  sp[3003].includes('Cochran Q = 9.156 (df = 2), Q P = 0.0103');
const allText = Object.values(docs).map(d => d.paras.join('\n')).join('\n');
const stale = ['from 1.37–1.53 to 1.52–1.73','only one was recovered in Yuan 2025',
  'most plausibly adiposity-linked','no conclusion here rests on the overlapping source',
  'four European European outcome files','__TOTAL__','__ABSTRACT__'];
result.checks.stale_found = stale.filter(x => allText.includes(x));
result.checks.required = {
  mde: ms[59].includes('from 1.37–1.70 to 1.52–1.73'),
  yuan: ms[71].includes('OR 0.95, 95% CI 0.71–1.28; P = 0.732; Cochran Q P = 0.010'),
  strobe_abstract: sp[1230] === 'Abstract (Background / Methods and Results / Conclusions), 234 words',
  strobe_clinical: sp[1311].includes('no sweetened-beverage exposure met the pre-specified causal criteria'),
  reference_map: sp[1740].includes('manuscript ref 34') && sp[1764].includes('manuscript ref 36') &&
    sp[1836].includes('manuscript ref 31') && sp[1898].includes('manuscript ref 37') &&
    sp[2347].includes('manuscript ref 58') && sp[2519].includes('manuscript ref 35') &&
    sp[2537].includes('manuscript ref 30') && sp[2609].includes('manuscript ref 28') &&
    sp[2609].includes('manuscript ref 46')
};
const hlBytes = fs.readFileSync(SUB + '/Highlights.docx');
result.checks.highlights_sha256 = sha(hlBytes);
result.checks.highlights_unchanged = sha(hlBytes) === EXPECTED_SHA['Highlights.docx'];
const figureDir = SUB + '/figures';
result.checks.figure_sha256 = {};
for (const name of fs.readdirSync(figureDir)) {
  result.checks.figure_sha256[name] = sha(fs.readFileSync(path.join(figureDir, name)));
}
result.all_pass = Object.entries(result.files).every(([name, r]) =>
  r.sha256 === EXPECTED_SHA[name] && r.bad_crc.length === 0 &&
  JSON.stringify(r.changed_paragraphs) === JSON.stringify(r.expected_paragraphs) &&
  r.non_document_differences.length === 0 && r.core_title_equal && r.cant_split_equal
) && result.checks.word_counts.abstract === 234 && result.checks.word_counts.clinical_perspective === 167 &&
  result.checks.word_counts.body === 7686 && result.checks.word_counts.total === 11979 &&
  ms[5] === 'Total word count: 11,979' && result.checks.references_61_identical &&
  result.checks.s29_pass && result.checks.stale_found.length === 0 &&
  Object.values(result.checks.required).every(Boolean) && result.checks.highlights_unchanged;
fs.writeFileSync(OUT, JSON.stringify(result, null, 2));
console.log(JSON.stringify(result, null, 2));
if (!result.all_pass) process.exit(1);
