# -*- coding: utf-8 -*-
import docx, re
B = r'C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013'
TITLE = 'Adiposity-Linked Pleiotropy in the Coffee–Atrial Fibrillation Signal: A Two-Sample Mendelian Randomization Study'

def set_para(p, text):
    if not p.runs:
        p.add_run(text)
    else:
        p.runs[0].text = text
        for r in p.runs[1:]: r.text = ''

def replace_in_doc(d, old, new, expected=1, label=''):
    n = 0
    for p in d.paragraphs:
        if old in p.text:
            set_para(p, p.text.replace(old, new))
            n += 1
    for tb in d.tables:
        for row in tb.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    if old in p.text:
                        set_para(p, p.text.replace(old, new))
                        n += 1
    assert n == expected, '%s: expected %d got %d' % (label, expected, n)
    print('OK', label, n)

# ---------- Manuscript ----------
MP = B + r'\Manuscript.docx'
m = docx.Document(MP)
replace_in_doc(m, 'Adiposity Loci Largely Account for a Recurring Coffee–Atrial Fibrillation Signal: A Two-Sample Mendelian Randomization Study', TITLE, label='main title')
replace_in_doc(m,
    'Conclusions: The recurring coffee signal was carried by adiposity-linked loci rather than by caffeine metabolism, and no sweetened-beverage exposure showed evidence of a causal association with AF; component-level nulls cannot certify composite milk-tea safety.',
    'Conclusions: The coffee signal was more compatible with adiposity-linked pleiotropy than with caffeine metabolism, although neither was excluded. No sweetened-beverage exposure showed evidence of a causal association with AF; component-level nulls cannot certify composite milk-tea safety.',
    label='abstract conclusion')
replace_in_doc(m,
    'The most consistent genetic signal, for coffee intake, was carried by adiposity-linked variation:',
    'The most consistent genetic signal, for coffee intake, was more compatible with adiposity-linked pleiotropy than with a caffeine-specific pathway:',
    label='principal findings')
replace_in_doc(m,
    'Tea is less studied: one Chinese cohort linked low-dose green tea to lower incident AF [47]; our null tea estimates extend that literature causally and concur with a previous null MR of tea intake against cardiovascular outcomes [37].',
    'Tea is less studied: one Chinese cohort linked low-dose green tea to lower incident AF [47]. Our tea estimates were compatible with a previous null MR of tea intake against cardiovascular outcomes [37], but pronounced within-source heterogeneity and nearly balanced opposite-direction variant estimates make them uninformative rather than confirmatory.',
    label='tea null interpretation')
old103 = next(p.text for p in m.paragraphs if p.text.startswith('Colocalization is the only line of evidence'))
new103 = ('Colocalization does not require the exposure-wide MR estimate to be statistically significant, but it remains dependent on regional association strength, variant coverage, linkage-disequilibrium alignment, model assumptions and prior choice. '
          'At FTO the default-prior analysis supported a shared coffee–AF variant (PP.H4 = 0.894 against Nielsen 2018 and 0.906 against FinnGen R13), compatible with adiposity-linked pleiotropy rather than proof of mediation. '
          'At CYP1A1–CYP1A2 and AHR — the two loci that encode caffeine metabolism and carry the strongest coffee instruments — the posterior mass lies instead on a coffee-specific signal with no AF counterpart (PP.H1 ≥ 0.93; PP.H4 ≤ 0.008). '
          'The dissociation is reproduced for tea at all three loci (Table S21), as would be expected if it reflected the biology of the beverage class rather than an idiosyncrasy of one phenotype. '
          'Two qualifications keep this at the locus level rather than the pathway level: the FTO result is prior-sensitive (PP.H4 0.457 at p12 = 10⁻⁶; Table S13), and BMI was not included in any colocalization model, so a shared variant at FTO is locus-level evidence, not evidence that adiposity mediates the effect.')
replace_in_doc(m, old103, new103, label='colocalization power and interpretation')
replace_in_doc(m,
    'The recurring coffee signal was carried by adiposity-linked loci rather than by caffeine metabolism, with a shared causal variant at FTO and no AF counterpart at the caffeine-metabolism loci, and it did not survive adiposity-locus exclusion consistently across sources.',
    'The recurring coffee signal was more compatible with adiposity-linked pleiotropy than with caffeine metabolism, although neither pathway was excluded and the association did not survive adiposity-locus exclusion consistently across sources.',
    label='main conclusions')
m.core_properties.title = TITLE
m.core_properties.author = 'Zezhong Cao'
m.core_properties.subject = 'Two-sample Mendelian randomization and locus-level colocalization'
m.save(MP)

# ---------- Cover letter ----------
CP = B + r'\Cover_Letter.docx'
c = docx.Document(CP)
replace_in_doc(c,
    'Adiposity Loci Largely Account for a Recurring Coffee–Atrial Fibrillation Signal: A Two-Sample Mendelian Randomization Study', TITLE,
    label='cover title')
oldcl = next(p.text for p in c.paragraphs if 'Using UK Biobank beverage GWAS and four European AF outcome files' in p.text)
newcl = ('Using UK Biobank beverage GWAS and four European AF outcome files—including the UK Biobank-free Yuan 2025 panel of 192,851 cases—we find no robust causal association for any sweetened-beverage phenotype, including artificially sweetened beverages, for which no Mendelian randomization estimate has previously been published, and show that the recurring coffee signal is more compatible with adiposity-linked pleiotropy than with a caffeine-specific pathway. '
         'The pivotal evidence is locus-level rather than dependent on a significant exposure-wide MR estimate: coffee and AF colocalize at FTO under the default prior (PP.H4 0.894; FinnGen R13 0.906) but not at CYP1A1–CYP1A2 or AHR, where the posterior mass lies on a coffee-specific signal with no AF counterpart (PP.H1 ≥ 0.93; PP.H4 ≤ 0.008). '
         'Tea shows the same dissociation, and instruments restricted to the caffeine-metabolism windows are null while the remainder of the instrument set carries the signal. These findings support adiposity-linked pleiotropy as a parsimonious explanation for the published positive estimates, without excluding caffeine-related or FTO-expression-mediated contributions.')
replace_in_doc(c, oldcl, newcl, label='cover evidence calibration')
c.core_properties.title = 'Cover Letter: ' + TITLE
c.core_properties.author = 'Zezhong Cao'
c.save(CP)

# ---------- Highlights ----------
HP = B + r'\Highlights.docx'
h = docx.Document(HP)
replace_in_doc(h, 'colocalised', 'colocalized', label='highlights US spelling')
replace_in_doc(h, '13-47%', '13–47%', label='highlights dash')
h.core_properties.title = 'Highlights: ' + TITLE
h.core_properties.author = 'Zezhong Cao'
h.save(HP)

# ---------- Supplement ----------
SP = B + r'\Supplement.docx'
s = docx.Document(SP)
replace_in_doc(s,
    'Genetically Proxied Sweetened Beverage Intake and Atrial Fibrillation: A Two-Sample and Multivariable Mendelian Randomization Study', TITLE,
    expected=1, label='supplement title')
replace_in_doc(s,
    'Table S29 caffeine-pathway instrument diagnostics; Figure S1',
    'Table S29 caffeine-pathway instrument diagnostics; Table S30 per-variant instrument-level estimates; Table S31 recovery of European index variants in the AFGen 2018 and BioBank Japan panels; Figure S1',
    label='supplement contents S30 S31')
replace_in_doc(s, 'Checklist condensed from Skrivankova et al.', 'Checklist based on Skrivankova et al.', label='S9 note')
replace_in_doc(s, 'A Two-Sample and Multivariable Mendelian Randomization Study', 'A Two-Sample Mendelian Randomization Study', expected=1, label='S9 title suffix')
# S9 cells
s9 = s.tables[8]
assert '231 words' in s9.rows[2].cells[2].text
s9.rows[2].cells[2].text = s9.rows[2].cells[2].text.replace('231 words', '246 words')
assert '[6]' in s9.rows[3].cells[3].text and '[5]' in s9.rows[3].cells[3].text
s9.rows[3].cells[3].text = s9.rows[3].cells[3].text.replace('[6]', '[8]').replace('[5]', '[7]')
assert 'R 4.6.0' in s9.rows[14].cells[3].text
s9.rows[14].cells[3].text = s9.rows[14].cells[3].text.replace('R 4.6.0, TwoSampleMR, MRPRESSO, coloc', 'R 4.6.1, TwoSampleMR 0.7.9, MRPRESSO 1.0, coloc 5.2.3')
assert 'Tables S12–S29' in s9.rows[15].cells[2].text
s9.rows[15].cells[2].text = s9.rows[15].cells[2].text.replace('Tables S12–S29', 'Tables S12–S31')
# 9 stale manuscript refs in notes
fixes = [
    ('The contamination-mixture estimator', 'manuscript ref 29', 'manuscript ref 31'),
    ('CAUSE (Morrison et al.', 'manuscript ref 31', 'manuscript ref 33'),
    ('Network (two-step) mediation MR', 'manuscript ref 26', 'manuscript ref 28'),
    ('MRlap (Mounier & Kutalik', 'manuscript ref 32', 'manuscript ref 34'),
    ('Early-onset AF (onset before age 66)', 'manuscript ref 46', 'manuscript ref 54'),
    ('MR-RAPS (Zhao et al.', 'manuscript ref 30', 'manuscript ref 32'),
    ('Conditional F statistics quantify', 'manuscript ref 25', 'manuscript ref 27'),
    ('Exposures were plasma caffeine', 'manuscript ref 23', 'manuscript ref 25'),
    ('Exposures were plasma caffeine', 'manuscript ref 37', 'manuscript ref 42'),
]
for anchor, old, new in fixes:
    hits = [p for p in s.paragraphs if anchor in p.text]
    assert len(hits) == 1, 'anchor %s -> %d' % (anchor, len(hits))
    p = hits[0]
    assert old in p.text, (anchor, old)
    set_para(p, p.text.replace(old, new))
    print('OK ref', anchor, old, '->', new)
s.core_properties.title = 'Supplemental material: ' + TITLE
s.core_properties.author = 'Zezhong Cao'
s.save(SP)

# verify key counts
m2 = docx.Document(MP)
abstract = ' '.join(p.text for p in m2.paragraphs[6:9])
print('ABSTRACT_WORDS', len(abstract.split()))
print('NEW_TITLE', m2.paragraphs[0].text)
print('DONE')
