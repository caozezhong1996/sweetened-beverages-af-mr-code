# -*- coding: utf-8 -*-
import docx, re
from copy import deepcopy
from docx.text.paragraph import Paragraph
from docx.shared import Pt
P = r'C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\Manuscript.docx'
m = docx.Document(P)
ps = m.paragraphs

def find(text):
    for i,p in enumerate(ps):
        if p.text.strip() == text:
            return i
    raise KeyError(text)

i_conc = find('Conclusions')
p_conc = ps[i_conc]
p_prev = ps[i_conc-1]
assert p_prev.text.startswith('A concern common to all behavioral-exposure instruments')

text = ('These bounds are consistent with recent observational syntheses. In a meta-analysis of 37 studies '
        '(3,625,613 participants), artificial sweetener intake—although not ASB beverages specifically—was not '
        'significantly associated with AF (HR 1.13, 95% CI 0.94–1.37), whereas higher risks were reported for '
        'several other cardiometabolic outcomes [56]. In a UK Biobank cohort of 131,247 coffee consumers, '
        'sugar-sweetened and artificially sweetened coffee were not associated with cardiovascular disease overall, '
        'with AF examined as a prespecified subtype [57]. Neither study isolates the combination of tea, sugar and '
        'milk that defines milk-tea-type beverages, but both are compatible with the absence of a robust '
        'beverage-specific genetic signal reported here.')
newp = p_conc.insert_paragraph_before('')
if p_prev._p.pPr is not None:
    newp._p.insert(0, deepcopy(p_prev._p.pPr))
run = newp.add_run(text)
run.font.name = 'Times New Roman'
run.font.size = Pt(12)

# Locate last reference paragraph (old ref 55) and append two entries preserving formatting
refs_start = next(i for i,p in enumerate(ps) if p.text.strip()=='References')
last = None
for p in ps[refs_start+1:]:
    if re.match(r'^55\.\s', p.text.strip()):
        last = p; break
assert last is not None
new_entries = [
    '56. Kim M, Kumar S, Chi G, Lee JJ. Artificial sweeteners and risk of cardiometabolic outcomes and mortality: a systematic review and meta-analysis. Nutr Res Pract. 2026;20(3):359-381. doi:10.4162/nrp.2026.20.3.359',
    '57. Yang M, Zhang L, Chen X, Lin Y, Lin J, Ni Z, et al. Association of unsweetened and sweetened coffee consumption with risk of cardiovascular disease: a prospective cohort study. Nutr Metab Cardiovasc Dis. 2026;36(6):104539. doi:10.1016/j.numecd.2026.104539',
]
for txt in new_entries:
    el = deepcopy(last._p)
    last._p.addnext(el)
    newp2 = Paragraph(el, last._parent)
    # set first run, clear rest
    if newp2.runs:
        newp2.runs[0].text = txt
        for r in newp2.runs[1:]: r.text = ''
    else:
        newp2.add_run(txt)
    last = newp2

m.save(P)
m2 = docx.Document(P)
ps2=[p.text for p in m2.paragraphs]
i_ref=next(i for i,t in enumerate(ps2) if t.strip()=='References')
refs=[t.strip() for t in ps2[i_ref+1:] if t.strip()]
print('refs',len(refs),'last two:',refs[-2][:80],'|',refs[-1][:80])
print('new para index',next(i for i,t in enumerate(ps2) if 'These bounds are consistent' in t))
print('word body',sum(len(ps2[k].split()) for k in range(next(i for i,t in enumerate(ps2) if t.strip()=='Introduction'),next(i for i,t in enumerate(ps2) if t.strip()=='Declarations'))))
print('abstract',len(' '.join(ps2[6:9]).split()))
