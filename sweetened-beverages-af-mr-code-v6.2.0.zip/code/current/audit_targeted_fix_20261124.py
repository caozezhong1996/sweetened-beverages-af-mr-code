from pathlib import Path
import argparse
import hashlib
import json
import re
import zipfile
import xml.etree.ElementTree as ET

BASE = Path(r"C:\Users\64915\WorkBuddy\2026-10-30-20-42-58\_targeted_fix_20261124")
W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NS = {"w": W}
DC = "http://purl.org/dc/elements/1.1/"
EXPECTED = {"Manuscript": 17, "Cover_Letter": 3, "Supplement": 19}
CONFIG = json.loads((BASE / "revision_texts.json").read_text(encoding="utf-8"))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def text(el):
    return "".join(t.text or "" for t in el.findall(".//w:t", NS))


def read(path):
    with zipfile.ZipFile(path) as zf:
        bad = zf.testzip()
        parts = {n: zf.read(n) for n in zf.namelist() if not n.endswith("/")}
    root = ET.fromstring(parts["word/document.xml"])
    paras = [text(p) for p in root.findall(".//w:p", NS)]
    tables = root.findall(".//w:body/w:tbl", NS)
    table_texts = [[text(p) for p in t.findall(".//w:p", NS)] for t in tables]
    cant_split = [[row.find("./w:trPr/w:cantSplit", NS) is not None for row in t.findall("./w:tr", NS)] for t in tables]
    core = ET.fromstring(parts["docProps/core.xml"])
    title_node = core.find(f"{{{DC}}}title")
    return {
        "parts": parts,
        "root": root,
        "paras": paras,
        "tables": table_texts,
        "cant_split": cant_split,
        "core_title": title_node.text if title_node is not None else "",
        "crc": bad,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", choices=["output", "submission"], default="output")
    args = parser.parse_args()
    target_dir = BASE / "output" if args.target == "output" else Path(r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013")
    result = {"target": str(target_dir), "files": {}, "stale_phrases": {}, "required_phrases": {}}
    docs = {}
    for name in EXPECTED:
        filename = f"{name}.docx"
        old = read(BASE / "backup" / filename)
        new = read(target_dir / filename)
        docs[name] = new
        diffs = [{"paragraph": i, "old": a, "new": b} for i, (a, b) in enumerate(zip(old["paras"], new["paras"])) if a != b]
        expected_indices = sorted(
            {int(i) for i in CONFIG[name].get("full", {})}
            | {int(i) for i in CONFIG[name].get("edits", {})}
        )
        table_diffs = [i + 1 for i, (a, b) in enumerate(zip(old["tables"], new["tables"])) if a != b]
        non_doc = sorted(n for n in old["parts"] if n != "word/document.xml" and sha(old["parts"][n]) != sha(new["parts"].get(n, b"")))
        result["files"][filename] = {
            "sha256": sha((target_dir / filename).read_bytes()),
            "crc": new["crc"],
            "paragraph_count": len(new["paras"]),
            "changed_paragraph_count": len(diffs),
            "expected_changed_paragraph_count": EXPECTED[name],
            "changed_paragraph_indices": [d["paragraph"] for d in diffs],
            "expected_changed_paragraph_indices": expected_indices,
            "changed_paragraphs": diffs,
            "table_count": len(new["tables"]),
            "table_text_changed_tables": table_diffs,
            "cant_split_equal": old["cant_split"] == new["cant_split"],
            "cant_split_rows": sum(sum(1 for x in table if x) for table in new["cant_split"]),
            "core_title": new["core_title"],
            "core_title_equal_base": old["core_title"] == new["core_title"] and bool(new["core_title"]),
            "non_document_parts_equal": not non_doc and set(old["parts"]) == set(new["parts"]),
            "non_document_differences": non_doc,
        }
    ms = docs["Manuscript"]
    p = ms["paras"]
    abstract = sum(len(x.split()) for x in p[7:10])
    cp = sum(len(x.split()) for x in p[13:21])
    body = sum(len(x.split()) for x in p[21:102])
    total = sum(len(x.split()) for x in p)
    references = [x for x in p if re.match(r"^\d+\. ", x)]
    old_ms = read(BASE / "backup" / "Manuscript.docx")
    old_references = [x for x in old_ms["paras"] if re.match(r"^\d+\. ", x)]
    result["word_counts"] = {
        "abstract": abstract,
        "clinical_perspective_including_headings": cp,
        "introduction_through_conclusions": body,
        "total": total,
        "title_page": p[5],
    }
    result["references"] = {"count": len(references), "identical_to_base": references == old_references}
    old_hl = (BASE / "backup" / "Highlights.docx").read_bytes()
    new_hl = (target_dir / "Highlights.docx").read_bytes() if (target_dir / "Highlights.docx").exists() else old_hl
    hl = read(target_dir / "Highlights.docx")["paras"][1:] if (target_dir / "Highlights.docx").exists() else read(BASE / "backup" / "Highlights.docx")["paras"][1:]
    result["highlights"] = {
        "byte_identical_to_base": old_hl == new_hl,
        "count": len(hl),
        "characters_without_bullet": [len(x) for x in hl],
        "all_le_120": all(len(x) <= 120 for x in hl),
        "texts": hl,
    }
    all_text = {name: "\n".join(doc["paras"]) for name, doc in docs.items()}
    stale = [
        "from 1.37–1.53 to 1.52–1.73",
        "only one was recovered in Yuan 2025",
        "most plausibly adiposity-linked",
        "no conclusion here rests on the overlapping source",
        "four European European outcome files",
        "__TOTAL__",
        "__ABSTRACT__",
    ]
    for phrase in stale:
        result["stale_phrases"][phrase] = [name for name, txt in all_text.items() if phrase in txt]
    required = {
        "abstract_word_count_234": ("Supplement", "Conclusions), 234 words"),
        "mde_range": ("Manuscript", "from 1.37–1.70 to 1.52–1.73"),
        "yuan_subgroup": ("Manuscript", "OR 0.95, 95% CI 0.71–1.28; P = 0.732; Cochran Q P = 0.010"),
        "yuan_all_three": ("Manuscript", "All three were recovered in Yuan 2025"),
        "s29_method": ("Supplement", "each three-SNP subset was analyzed using multiplicative random-effects IVW"),
        "s29_q": ("Supplement", "Cochran Q = 9.156 (df = 2), Q P = 0.0103"),
        "cover_yuan": ("Cover_Letter", "OR 1.32, 95% CI 0.99–1.76; P = 0.055"),
        "observational_coffee": ("Manuscript", "HR 0.83, 95% CI 0.74–0.94"),
        "sweetener_heterogeneity": ("Manuscript", "I² = 86.7%"),
    }
    for key, (name, phrase) in required.items():
        result["required_phrases"][key] = phrase in all_text[name]
    sp = docs["Supplement"]["paras"]
    result["supplement_reference_mappings"] = {
        str(i): sp[i] for i in (1740, 1764, 1836, 1898, 2347, 2519, 2537, 2609)
    }
    expected_ref_fragments = {
        1740: "manuscript ref 34", 1764: "manuscript ref 36",
        1836: "manuscript ref 31", 1898: "manuscript ref 37",
        2347: "manuscript ref 58", 2519: "manuscript ref 35",
        2537: "manuscript ref 30",
    }
    ref_map_pass = all(expected_ref_fragments[i] in sp[i] for i in expected_ref_fragments)
    ref_map_pass = ref_map_pass and "manuscript ref 28" in sp[2609] and "manuscript ref 46" in sp[2609]
    result["supplement_reference_mappings_pass"] = ref_map_pass
    result["s29_yuan_cells"] = {str(i): sp[i] for i in range(2984, 3004) if i in (2984,2985,2986,2987,2988,2989,2990,3001,3003)}
    expected_cells = {
        2984: "IVW", 2985: "3", 2986: "0.2850", 2987: "31.6 / 545.5 / 408.0",
        2988: "0.95 (0.71–1.28)", 2989: "0.732", 2990: "1.53", 3001: "3 / 3",
    }
    result["s29_yuan_cells_pass"] = all(sp[i] == v for i, v in expected_cells.items())
    file_pass = all(
        v["crc"] is None
        and v["changed_paragraph_indices"] == v["expected_changed_paragraph_indices"]
        and v["changed_paragraph_count"] == v["expected_changed_paragraph_count"]
        and v["cant_split_equal"]
        and v["core_title_equal_base"]
        and v["non_document_parts_equal"]
        for v in result["files"].values()
    )
    result["all_pass"] = all([
        file_pass,
        result["files"]["Manuscript.docx"]["table_text_changed_tables"] == [],
        abstract == 234,
        cp == 167,
        body == 7686,
        total == 11979,
        p[5] == "Total word count: 11,979",
        len(references) == 61,
        references == old_references,
        result["highlights"]["byte_identical_to_base"],
        len(hl) == 5,
        all(len(x) <= 120 for x in hl),
        not any(result["stale_phrases"].values()),
        all(result["required_phrases"].values()),
        ref_map_pass,
        result["s29_yuan_cells_pass"],
    ])
    out = BASE / "review" / f"candidate_audit_{args.target}.json"
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    summary = {k: v for k, v in result.items() if k not in {"files", "stale_phrases", "required_phrases", "supplement_reference_mappings", "s29_yuan_cells"}}
    summary["files"] = {n: {k: v for k, v in r.items() if k != "changed_paragraphs"} for n, r in result["files"].items()}
    summary["stale_phrases"] = result["stale_phrases"]
    summary["required_phrases"] = result["required_phrases"]
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if not result["all_pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
