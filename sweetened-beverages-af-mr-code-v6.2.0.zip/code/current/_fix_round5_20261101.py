# -*- coding: utf-8 -*-
import docx
B = r'C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013'

def set_para(p, text):
    if not p.runs:
        p.add_run(text)
    else:
        p.runs[0].text = text
        for r in p.runs[1:]: r.text = ''

def rep_doc(d, old, new, expected=1, label=''):
    n=0
    for p in d.paragraphs:
        if old in p.text:
            set_para(p, p.text.replace(old,new)); n+=1
    for tb in d.tables:
        for row in tb.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    if old in p.text:
                        set_para(p,p.text.replace(old,new)); n+=1
    assert n==expected, '%s expected %d got %d'%(label,expected,n)
    print('OK',label,n)

# ---------- Main ----------
MP=B+r'\Manuscript.docx'
m=docx.Document(MP); ps=[p.text for p in m.paragraphs]

# 1) S27 direction (Results)
old58=("Among the five sweetened-beverage exposures, all moved toward the null except two in Yuan 2025 that moved away from it and approached nominal significance: low-calorie drink intake (1.04 to 1.13, 0.99–1.28; P = 0.062) and artificial sweetener added to tea (1.03 to 1.33, 0.99–1.78; P = 0.057).")
new58=("Among the fifteen sweetened-beverage estimates (five exposures × three sources), ten moved toward the null and five moved away; of the latter, two in Yuan 2025 approached nominal significance: low-calorie drink intake (1.04 to 1.13, 0.99–1.28; P = 0.062) and artificial sweetener added to tea (1.03 to 1.33, 0.99–1.78; P = 0.057).")
rep_doc(m,old58,new58,label='S27 direction Results')

# 2) S27 direction (Discussion)
old105=("The adiposity-locus exclusion remains the only line that also covers the five sweetened-beverage phenotypes, all of which moved toward the null except two sweetener exposures in Yuan 2025 that moved away from it, a constraint on the adiposity explanation that we report rather than reconcile.")
new105=("The adiposity-locus exclusion remains the only line that also covers the five sweetened-beverage phenotypes. Ten of the fifteen estimates moved toward the null and five moved away, including two in Yuan 2025 that approached nominal significance; we report this as a constraint on the adiposity explanation rather than reconcile it.")
rep_doc(m,old105,new105,label='S27 direction Discussion')

# 3) Abstract: consolidate corrections and add AFGen source dependence
reps=[
('No sweetened-beverage exposure showed a causal association','No sweetened-beverage exposure was causally associated'),
('so observational-magnitude effects were not excluded','so observational-magnitude effects remained unexcluded'),
('Coffee was associated in all European sources','Coffee was associated across European sources'),
('yet failed every pre-specified robustness criterion','yet did not meet the pre-specified consistency criteria'),
('implying an upper bound of 1.21–1.38','implying a 1.21–1.38 upper bound'),
('At FTO, colocalization showed a shared causal variant (PP.H4 = 0.894; FinnGen R13 0.906);','At FTO, colocalization supported a shared variant with Nielsen (0.894) and FinnGen (0.906), not AFGen (0.362);'),
('After adiposity-locus exclusion the three coffee estimates','After adiposity-locus exclusion the coffee estimates'),
]
for a,b in reps: rep_doc(m,a,b,label='abstract: '+a[:35])

# 4) Clinical Perspective bullet
old15="• The only signal surviving multiplicity correction (coffee) failed every pre-specified robustness criterion and colocalized with AF at the adiposity locus FTO (PP.H4 0.894) rather than at the caffeine-metabolism loci CYP1A1–CYP1A2 and AHR (PP.H4 ≤ 0.008)."
new15="• The only signal surviving multiplicity correction (coffee) did not meet the pre-specified consistency criteria and colocalized with AF at the adiposity locus FTO (PP.H4 0.894 in Nielsen and 0.906 in FinnGen; 0.362 in AFGen) rather than at the caffeine-metabolism loci CYP1A1–CYP1A2 and AHR (PP.H4 ≤ 0.008)."
rep_doc(m,old15,new15,label='Clinical Perspective bullet')

# 5) Results failure wording
rep_doc(m,'The association nevertheless failed every pre-specified consistency criterion:','The association nevertheless did not satisfy the pre-specified set of consistency criteria:',label='Results failure wording')

# 6) Route map
rep_doc(m,'These lines are ordered by how little they depend on statistical power:','These lines are ordered by how little they depend on a statistically significant exposure-wide MR estimate:',label='route map ordering')

# 7) abolished vs subgroup test
rep_doc(m,'and restricting instruments to those loci abolished the signal while the remainder of the set retained it.','and instruments restricted to those loci did not reproduce the signal, whereas the remainder did, although the between-subgroup difference was not statistically significant.',label='subgroup wording')

# 8) P103 AFGen disclosure
rep_doc(m,'At FTO the default-prior analysis supported a shared coffee–AF variant (PP.H4 = 0.894 against Nielsen 2018 and 0.906 against FinnGen R13), compatible with adiposity-linked pleiotropy rather than proof of mediation.',
        'At FTO the default-prior analysis supported a shared coffee–AF variant against Nielsen 2018 (PP.H4 = 0.894) and FinnGen R13 (0.906), but not against the smaller AFGen 2018 panel (0.362), compatible with adiposity-linked pleiotropy rather than proof of mediation.',label='P103 AFGen')

m.save(MP)
m2=docx.Document(MP); ps2=[p.text for p in m2.paragraphs]
print('ABSTRACT_WORDS',len(' '.join(ps2[6:9]).split()))

# ---------- Highlights ----------
HP=B+r'\Highlights.docx'; h=docx.Document(HP)
rep_doc(h,"Coffee's genetic signal for AF colocalized at FTO (PP.H4 0.894), not at caffeine-metabolism loci.","Coffee's AF signal colocalized at FTO in two panels (PP.H4 0.894/0.906; 0.362 in AFGen), not at caffeine loci.",label='HL 1')
rep_doc(h,'Sweetened-beverage intake showed no causal association with AF across two independent outcome clusters.','No sweetened-beverage exposure was causally associated with AF; sources spanned at most two independent clusters.',label='HL 2')
h.save(HP)

# ---------- Cover Letter ----------
CP=B+r'\Cover_Letter.docx'; c=docx.Document(CP)
rep_doc(c,'coffee and AF colocalize at FTO under the default prior (PP.H4 0.894; FinnGen R13 0.906)','coffee and AF colocalize at FTO under the default prior (PP.H4 0.894 in Nielsen and 0.906 in FinnGen; 0.362 in the smaller AFGen panel)',label='CL AFGen')
c.save(CP)

# ---------- Supplement S30 title ----------
SP=B+r'\Supplement.docx'; s=docx.Document(SP)
rep_doc(s,'Table S30. Per-variant instrument-level estimates for coffee intake against atrial fibrillation (Nielsen 2018, FinnGen R13 and Yuan 2025)','Table S30. Per-variant instrument-level estimates for all seven exposures against atrial fibrillation (Nielsen 2018, FinnGen R13 and Yuan 2025)',label='S30 title')
s.save(SP)
print('DONE')
