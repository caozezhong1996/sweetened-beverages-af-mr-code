suppressMessages({library(TwoSampleMR)})
sink("C:/a3work/bbj_coffee_loo_data.txt", split = TRUE)

d <- read.csv("C:/a3work/dat_Coffee_intake_ebi_a_GCST006414.csv", stringsAsFactors = FALSE)
exp <- data.frame(SNP = d$SNP,
                  beta.exposure = as.numeric(d$beta.exposure),
                  se.exposure = as.numeric(d$se.exposure),
                  effect_allele.exposure = d$effect_allele.exposure,
                  other_allele.exposure = d$other_allele.exposure,
                  eaf.exposure = as.numeric(d$eaf.exposure),
                  pval.exposure = as.numeric(d$pval.exposure),
                  exposure = "Coffee intake", id.exposure = "ukb-b-5237",
                  stringsAsFactors = FALSE)

o <- extract_outcome_data(exp$SNP, "bbj-a-71", proxies = TRUE, rsq = 0.8)
h <- harmonise_data(exp, o, action = 2)
k <- h[h$mr_keep, ]
cat("index SNPs:", nrow(exp), "| outcome rows:", nrow(o), "| mr_keep:", nrow(k), "\n")

r <- mr_ivw(k$beta.exposure, k$beta.outcome, k$se.exposure, k$se.outcome)
cat(sprintf("IVW OR %.3f (%.3f-%.3f) P=%.4f  <-- paper reports 2.34 (1.17-4.68), P=0.016\n",
            exp(r$b), exp(r$b - 1.96*r$se), exp(r$b + 1.96*r$se), r$pval))

out <- k[, c("SNP", "beta.exposure", "se.exposure", "beta.outcome", "se.outcome")]
out$mr_keep <- "TRUE"
write.csv(out, "C:/a3work/dat_Coffee_intake_bbj_a_71.csv", row.names = FALSE)
cat("written C:/a3work/dat_Coffee_intake_bbj_a_71.csv rows:", nrow(out), "\n")
sink()
