suppressMessages({library(TwoSampleMR)})
options(width = 220)
LOG <- "C:/a3work/bbj_tea_rebuild.txt"
sink(LOG, split = TRUE)

d <- read.csv("C:/a3work/dat_Tea_intake_ebi_a_GCST006414.csv", stringsAsFactors = FALSE)
exp <- data.frame(SNP = d$SNP,
                  beta.exposure = as.numeric(d$beta.exposure),
                  se.exposure = as.numeric(d$se.exposure),
                  effect_allele.exposure = d$effect_allele.exposure,
                  other_allele.exposure = d$other_allele.exposure,
                  eaf.exposure = as.numeric(d$eaf.exposure),
                  pval.exposure = as.numeric(d$pval.exposure),
                  exposure = "Tea intake", id.exposure = "ukb-b-6066",
                  stringsAsFactors = FALSE)

for (px in c(FALSE, TRUE)) {
  cat("\n================ proxies =", px, "================\n")
  o <- extract_outcome_data(exp$SNP, "bbj-a-71", proxies = px, rsq = 0.8)
  cat("outcome rows:", nrow(o), "unique SNPs:", length(unique(o$SNP)), "\n")
  h <- harmonise_data(exp, o, action = 2)
  k <- h[h$mr_keep, ]
  cat("mr_keep rows:", nrow(k), "\n")
  res <- mr(k, method_list = c("mr_ivw", "mr_weighted_median", "mr_egger_regression", "mr_weighted_mode"))
  print(res[, c("method", "nsnp", "b", "se", "pval")], row.names = FALSE)
  cat("\nOR (IVW):", sprintf("%.3f (%.3f-%.3f)",
      exp(res$b[res$method == "Inverse variance weighted"]),
      exp(res$b[res$method == "Inverse variance weighted"] - 1.96 * res$se[res$method == "Inverse variance weighted"]),
      exp(res$b[res$method == "Inverse variance weighted"] + 1.96 * res$se[res$method == "Inverse variance weighted"])), "\n")
  het <- mr_heterogeneity(k)
  print(het[, c("method", "Q", "Q_df", "Q_pval")], row.names = FALSE)
  ple <- mr_pleiotropy_test(k)
  cat("Egger intercept:", sprintf("%.5f (SE %.5f), P = %.4f", ple$egger_intercept, ple$se, ple$pval), "\n")
  out_csv <- sprintf("C:/a3work/bbj_tea_harmonised_proxies_%s.csv", px)
  write.csv(k[, c("SNP", "beta.exposure", "se.exposure", "beta.outcome", "se.outcome",
                  "effect_allele.exposure", "other_allele.exposure",
                  "effect_allele.outcome", "other_allele.outcome")],
            out_csv, row.names = FALSE)
  cat("written:", out_csv, "\n")
}
sink()
