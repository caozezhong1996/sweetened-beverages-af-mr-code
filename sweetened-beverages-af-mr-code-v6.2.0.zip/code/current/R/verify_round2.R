R <- read.csv("C:/a3work/adiposity_sensitivity_all_cohorts.csv", stringsAsFactors = FALSE)
R <- R[R$exposure == "Coffee intake", ]
se_from <- function(lo, hi) (log(hi) - log(lo)) / (2 * qnorm(0.975))
qstat <- function(o, lo, hi) {
  y <- log(o); s <- se_from(lo, hi); w <- 1 / s^2
  mu <- sum(w * y) / sum(w)
  Q <- sum(w * (y - mu)^2); df <- length(y) - 1
  c(Q = Q, df = df, p = pchisq(Q, df, lower.tail = FALSE), mu = exp(mu))
}
cat("pre :", sprintf("%.4f", qstat(R$OR, R$lo, R$hi)), "\n")
cat("post:", sprintf("%.4f", qstat(R$OR_clean, R$lo_clean, R$hi_clean)), "\n")
cat("\npairwise (pre):\n")
y <- log(R$OR); s <- se_from(R$lo, R$hi)
for (i in 1:2) for (j in (i+1):3) {
  z <- (y[i] - y[j]) / sqrt(s[i]^2 + s[j]^2)
  cat(sprintf("  %d-%d z=%.3f P=%.3f\n", i, j, z, 2*pnorm(-abs(z))))
}
