suppressMessages(library(ieugwasr))
rs <- strsplit(readLines("C:/a3work/rsid_coffee.txt", warn = FALSE), ",")[[1]]
cat("n index SNPs:", length(rs), "\n")
cat("token available:", nchar(Sys.getenv("OPENGWAS_JWT")) > 0, "\n")
for (id in c("bbj-a-71", "ebi-a-GCST006061")) {
  res <- try(associations(rs, id), silent = TRUE)
  if (inherits(res, "try-error")) {
    cat(id, ": ERROR\n"); print(res); next
  }
  cat(sprintf("%-18s returned %d rows, unique SNPs %d\n", id, nrow(res), length(unique(res$rsid))))
  miss <- setdiff(rs, unique(res$rsid))
  cat("   missing:", if (length(miss)) paste(miss, collapse = ",") else "none", "\n")
}
