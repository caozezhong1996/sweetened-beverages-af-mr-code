suppressMessages({library(TwoSampleMR); library(MRPRESSO)})

A3 <- "C:/a3work"
exp_raw <- read.csv(file.path(A3, "dat_Sugar_added_to_coffee_ebi_a_GCST006414.csv"), stringsAsFactors = FALSE)
exp_raw <- exp_raw[exp_raw$mr_keep %in% c(TRUE, "TRUE", "true"), ]

exp_dat <- data.frame(
  SNP                    = exp_raw$SNP,
  beta.exposure          = as.numeric(exp_raw$beta.exposure),
  se.exposure            = as.numeric(exp_raw$se.exposure),
  effect_allele.exposure = exp_raw$effect_allele.exposure,
  other_allele.exposure  = exp_raw$other_allele.exposure,
  eaf.exposure           = as.numeric(exp_raw$eaf.exposure),
  pval.exposure          = as.numeric(exp_raw$pval.exposure),
  exposure               = "Sugar added to coffee",
  id.exposure            = "ukb-b-243",
  stringsAsFactors = FALSE
)

out_raw <- read.csv(file.path(A3, "afgen_sugar_coffee_raw.csv"), stringsAsFactors = FALSE)
out_dat <- data.frame(
  SNP                   = out_raw$rsid,
  beta.outcome          = as.numeric(out_raw$beta),
  se.outcome            = as.numeric(out_raw$se),
  effect_allele.outcome = toupper(out_raw$ea),
  other_allele.outcome  = toupper(out_raw$nea),
  eaf.outcome           = as.numeric(out_raw$eaf),
  pval.outcome          = as.numeric(out_raw$p),
  outcome               = "AFGen 2018",
  id.outcome            = "ebi-a-GCST006061",
  stringsAsFactors = FALSE
)

cat("exposure SNPs:", nrow(exp_dat), "| outcome SNPs:", nrow(out_dat), "\n")
h <- harmonise_data(exp_dat, out_dat, action = 2)
h <- h[h$mr_keep %in% c(TRUE, "TRUE", "true"), ]
cat("harmonised kept:", nrow(h), "\n")

ivw <- mr_ivw(h$beta.exposure, h$beta.outcome, h$se.exposure, h$se.outcome)
cat(sprintf("IVW: beta = %+.4f, SE = %.4f, P = %.4f, OR = %.3f (%.3f-%.3f)\n",
            ivw$b, ivw$se, ivw$pval, exp(ivw$b), exp(ivw$b - 1.96 * ivw$se), exp(ivw$b + 1.96 * ivw$se)))

Q <- mr_heterogeneity(h, method_list = "mr_ivw")
cat(sprintf("Cochran Q = %.2f (df %d), P = %.4f\n", Q$Q[1], Q$Q_df[1], Q$Q_pval[1]))

dat <- data.frame(beta.outcome = h$beta.outcome, beta.exposure = h$beta.exposure,
                  se.outcome = h$se.outcome, se.exposure = h$se.exposure, SNP = h$SNP)
res <- try(mr_presso(BetaOutcome = "beta.outcome", BetaExposure = "beta.exposure",
                     SdOutcome = "se.outcome", SdExposure = "se.exposure",
                     data = dat, NbDistribution = 1000, SignifThreshold = 0.05,
                     seed = 20261031), silent = TRUE)
if (inherits(res, "try-error")) {
  cat("PRESSO ERROR:", as.character(res), "\n")
} else {
  m <- res$`Main MR results`
  for (i in seq_len(nrow(m))) {
    cat(sprintf("PRESSO %-18s beta = %+.4f  SE = %s  P = %s\n", m$`MR Analysis`[i],
                m$`Causal Estimate`[i],
                ifelse(is.na(m$Sd[i]), "NA", sprintf("%.4f", m$Sd[i])),
                ifelse(is.na(m$`P-value`[i]), "NA", sprintf("%.4f", m$`P-value`[i]))))
  }
  gl <- res$`MR-PRESSO results`$`Global Test`
  cat(sprintf("PRESSO global: RSSobs = %.3f, P = %s\n", gl$RSSobs, format(gl$Pvalue)))
  ot <- res$`MR-PRESSO results`$`Outlier Test`
  if (is.data.frame(ot) && "Pvalue" %in% names(ot)) {
    cat("outliers at P<0.05:", sum(ot$Pvalue < 0.05, na.rm = TRUE), "of", nrow(ot), "\n")
    print(head(ot[order(ot$Pvalue), ], 4))
  } else {
    cat("no outlier table; outliers at P<0.05: 0\n")
  }
}

write.csv(h, file.path(A3, "harmonised_sugar_coffee_afgen.csv"), row.names = FALSE)
