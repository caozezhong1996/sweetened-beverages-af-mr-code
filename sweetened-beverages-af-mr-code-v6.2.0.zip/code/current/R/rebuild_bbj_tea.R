suppressMessages({library(TwoSampleMR)})
options(width = 200)

d <- read.csv("C:/a3work/dat_Tea_intake_ebi_a_GCST006414.csv", stringsAsFactors = FALSE)
cat("index SNPs in exposure file:", nrow(d), "\n")

exp <- data.frame(
  SNP              = d$SNP,
  beta.exposure    = as.numeric(d$beta.exposure),
  se.exposure      = as.numeric(d$se.exposure),
  effect_allele.exposure = d$effect_allele.exposure,
  other_allele.exposure  = d$other_allele.exposure,
  eaf.exposure     = as.numeric(d$eaf.exposure),
  pval.exposure    = as.numeric(d$pval.exposure),
  exposure         = "Tea intake",
  id.exposure      = "ukb-b-6066",
  stringsAsFactors = FALSE
)

cat("\n--- A. proxies = FALSE ---\n")
o1 <- tryCatch(extract_outcome_data(exp$SNP, "bbj-a-71", proxies = FALSE),
               error = function(e) {cat("ERR:", conditionMessage(e), "\n"); NULL})
if (!is.null(o1)) {
  cat("outcome rows:", nrow(o1), " unique SNPs:", length(unique(o1$SNP)), "\n")
  h1 <- harmonise_data(exp, o1, action = 2)
  k1 <- h1[h1$mr_keep, ]
  cat("harmonised, mr_keep rows:", nrow(k1), "\n")
  r1 <- mr_ivw(k1$beta.exposure, k1$beta.outcome, k1$se.exposure, k1$se.outcome)
  cat(sprintf("IVW OR %.3f (%.3f-%.3f) P=%.4f\n", exp(r1$b), exp(r1$b - 1.96*r1$se),
              exp(r1$b + 1.96*r1$se), r1$pval))
}

cat("\n--- B. proxies = TRUE (TwoSampleMR default) ---\n")
o2 <- tryCatch(extract_outcome_data(exp$SNP, "bbj-a-71", proxies = TRUE, rsq = 0.8),
               error = function(e) {cat("ERR:", conditionMessage(e), "\n"); NULL})
if (!is.null(o2)) {
  cat("outcome rows:", nrow(o2), " unique SNPs:", length(unique(o2$SNP)), "\n")
  cat("target SNP column present:", "target_snp" %in% names(o2), "\n")
  if ("target_snp" %in% names(o2)) {
    n_proxy <- sum(o2$target_snp != o2$SNP, na.rm = TRUE)
    cat("rows that are proxy substitutions:", n_proxy, "\n")
    tb <- table(o2$target_snp[o2$target_snp != o2$SNP])
    cat("proxy counts per target:\n"); print(tb)
  }
  h2 <- harmonise_data(exp, o2, action = 2)
  k2 <- h2[h2$mr_keep, ]
  cat("harmonised, mr_keep rows:", nrow(k2), "\n")
  r2 <- mr_ivw(k2$beta.exposure, k2$beta.outcome, k2$se.exposure, k2$se.outcome)
  cat(sprintf("IVW OR %.3f (%.3f-%.3f) P=%.4f\n", exp(r2$b), exp(r2$b - 1.96*r2$se),
              exp(r2$b + 1.96*r2$se), r2$pval))
}
cat("\npaper reports: n = 36, OR 1.06 (0.52-2.14), P = 0.875\n")
