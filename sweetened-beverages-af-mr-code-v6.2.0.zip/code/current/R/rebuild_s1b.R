suppressMessages(library(ieugwasr))
LOGF <- "C:/a3work/step.log"
writeLines("start", LOGF)

files <- list.files("C:/a3work", pattern = "^dat_.*_ebi_a_GCST006414\\.csv$", full.names = TRUE)
files <- sort(files)
writeLines(paste("files", length(files)), LOGF)

s1 <- data.frame(
  exposure = c("Artificial sweetener added to tea", "Coffee intake", "Fizzy drink intake (SSB)",
               "Low-calorie drink intake (ASB)", "Sugar added to coffee", "Sugar added to tea", "Tea intake"),
  afgen = c(14, 34, 8, 17, 15, 17, 32),
  bbj   = c(6, 32, 4, 8, 11, 11, 36),
  stringsAsFactors = FALSE
)

keymap <- c("Artificial sweetener added to tea" = "Artificial sweetener added to tea",
            "Coffee intake" = "Coffee intake",
            "Fizzy drink intake SSB" = "Fizzy drink intake (SSB)",
            "Low calorie drink intake ASB" = "Low-calorie drink intake (ASB)",
            "Sugar added to coffee" = "Sugar added to coffee",
            "Sugar added to tea" = "Sugar added to tea",
            "Tea intake" = "Tea intake")

rows <- list()
for (f in files) {
  nm <- sub("_ebi_a_GCST006414\\.csv$", "", sub("^dat_", "", basename(f)))
  nm <- keymap[[gsub("_", " ", nm)]]
  d <- read.csv(f, stringsAsFactors = FALSE)
  rs <- unique(d$SNP)
  for (src in c("ebi-a-GCST006061", "bbj-a-71")) {
    res <- tryCatch(associations(rs, src), error = function(e) NULL)
    direct <- if (is.null(res)) NA_integer_ else length(unique(res$rsid))
    writeLines(sprintf("%s|%s|idx=%d|direct=%s", nm, src, length(rs), as.character(direct)), LOGF)
    rows[[length(rows) + 1]] <- data.frame(exposure = nm, source = src,
                                           n_index = length(rs), direct = direct,
                                           stringsAsFactors = FALSE)
  }
}
out <- do.call(rbind, rows)
out$retained <- ifelse(out$source == "ebi-a-GCST006061",
                       s1$afgen[match(out$exposure, s1$exposure)],
                       s1$bbj[match(out$exposure, s1$exposure)])
out$proxy   <- out$retained - out$direct
out$missing <- out$n_index - out$retained
write.csv(out, "C:/a3work/s1_proxy_rebuild.csv", row.names = FALSE)
writeLines("done", LOGF)
