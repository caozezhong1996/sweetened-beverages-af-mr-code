suppressMessages(library(MRPRESSO))

run_presso <- function(file, label, nboot = 1000, out_txt = NULL) {
  d <- read.csv(file, stringsAsFactors = FALSE)
  lines <- c()
  add <- function(...) { s <- paste0(...); lines <<- c(lines, s); cat(s, "\n") }

  add("\n=== ", label, " ===")
  if ("mr_keep" %in% names(d)) d <- d[d$mr_keep %in% c(TRUE, "TRUE", "true"), ]
  add("kept SNPs: ", nrow(d), " | outcome: ", paste(unique(d$id.outcome), collapse = ","))

  dat <- data.frame(beta.outcome = as.numeric(d$beta.outcome),
                    beta.exposure = as.numeric(d$beta.exposure),
                    se.outcome = as.numeric(d$se.outcome),
                    se.exposure = as.numeric(d$se.exposure),
                    SNP = d$SNP, row.names = NULL)
  res <- try(mr_presso(BetaOutcome = "beta.outcome", BetaExposure = "beta.exposure",
                       SdOutcome = "se.outcome", SdExposure = "se.exposure",
                       data = dat, NbDistribution = nboot, SignifThreshold = 0.05,
                       seed = 20261031), silent = TRUE)
  if (inherits(res, "try-error")) { add("PRESSO ERROR: ", as.character(res)); return(invisible(NULL)) }

  main <- res$`Main MR results`
  add("\n-- Main MR --")
  for (i in seq_len(nrow(main))) {
    add(sprintf("  %-18s beta = %+.4f  SE = %.4f  P = %.4f  OR = %.3f",
                main$`MR Analysis`[i], main$`Causal Estimate`[i], main$Sd[i], main$`P-value`[i],
                exp(main$`Causal Estimate`[i])))
  }
  gl <- res$`MR-PRESSO results`$`Global Test`
  add(sprintf("\n-- Global test: RSSobs = %.3f, P = %s --", gl$RSSobs, format(gl$Pvalue)))

  out <- res$`MR-PRESSO results`$`Outlier Test`
  if (is.data.frame(out) && nrow(out) > 0 && "Pvalue" %in% names(out)) {
    add("-- outlier test available for ", nrow(out), " SNPs --")
    o <- out[order(out$Pvalue), ]
    for (i in seq_len(min(5, nrow(o)))) {
      add(sprintf("  %-14s beta = %+.4f  P = %.4f", o$`SNP`[i] %||% rownames(o)[i], o$`Beta`[i] %||% NA, o$Pvalue[i]))
    }
    add("  outliers at P<0.05: ", sum(o$Pvalue < 0.05, na.rm = TRUE))
  } else {
    add("-- no outlier table returned; outliers at P<0.05: 0 --")
  }
  if (!is.null(out_txt)) writeLines(lines, out_txt)
  invisible(res)
}

`%||%` <- function(a, b) if (is.null(a)) b else a

r1 <- run_presso("C:/a3work/dat_Sugar_added_to_tea_finngen_R13.csv",
                 "Sugar added to tea x FinnGen R13", out_txt = "C:/a3work/presso_tea_finngen.txt")
