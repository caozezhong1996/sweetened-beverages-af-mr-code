suppressMessages({library(TwoSampleMR)})
options(width = 200)
sink("C:/a3work/bbj_ivw_diag.txt", split = TRUE)

for (tag in c("FALSE", "TRUE")) {
  k <- read.csv(sprintf("C:/a3work/bbj_tea_harmonised_proxies_%s.csv", tag), stringsAsFactors = FALSE)
  cat("\n=========== proxies =", tag, " n =", nrow(k), "===========\n")

  # 1) TwoSampleMR 三种 model
  for (md in c("default", "fixed", "random")) {
    r <- mr_ivw(k$beta.exposure, k$beta.outcome, k$se.exposure, k$se.outcome, model = md)
    cat(sprintf("mr_ivw model=%-8s b=%+.5f se=%.5f  OR=%.3f (%.3f-%.3f) P=%.4f\n",
                md, r$b, r$se, exp(r$b), exp(r$b - 1.96*r$se), exp(r$b + 1.96*r$se), r$pval))
  }

  # 2) 手算 fixed-effect IVW
  w <- 1 / k$se.outcome^2
  b_fe <- sum(w * k$beta.exposure * k$beta.outcome) / sum(w * k$beta.exposure^2)
  se_fe <- sqrt(1 / sum(w * k$beta.exposure^2))
  cat(sprintf("hand fixed-effect      b=%+.5f se=%.5f\n", b_fe, se_fe))

  # 3) 手算 DL 随机效应 IVW（对 Wald 比）
  wr <- k$beta.outcome / k$beta.exposure
  sw <- k$se.outcome / abs(k$beta.exposure)
  ww <- 1 / sw^2
  mu <- sum(ww * wr) / sum(ww)
  Q <- sum(ww * (wr - mu)^2)
  df <- length(wr) - 1
  C <- sum(ww) - sum(ww^2) / sum(ww)
  tau2 <- max(0, (Q - df) / C)
  se_re <- sqrt(1 / sum(1 / (sw^2 + tau2)))
  cat(sprintf("hand DL random-effect  b=%+.5f se=%.5f tau2=%.5f Q=%.2f df=%d\n", mu, se_re, tau2, Q, df))

  # 4) Egger：TwoSampleMR vs 直接 lm
  eg <- mr_egger_regression(k$beta.exposure, k$beta.outcome, k$se.exposure, k$se.outcome)
  cat(sprintf("mr_egger_regression    intercept=%+.5f (SE %.5f) P=%.4f\n",
              eg$b_i, eg$se_i, eg$pval_i))
  m <- lm(k$beta.outcome ~ k$beta.exposure, weights = 1 / k$se.outcome^2)
  cat(sprintf("lm(weights=1/se_out^2) intercept=%+.5f (SE %.5f)\n",
              coef(m)[1], summary(m)$coefficients[1, 2]))
  m2 <- lm(k$beta.outcome ~ k$beta.exposure)
  cat(sprintf("lm(unweighted)         intercept=%+.5f (SE %.5f)\n",
              coef(m2)[1], summary(m2)$coefficients[1, 2]))
  pl <- mr_pleiotropy_test(k)
  cat(sprintf("mr_pleiotropy_test     intercept=%+.5f (SE %.5f) P=%.4f\n",
              pl$egger_intercept, pl$se, pl$pval))
}
sink()
