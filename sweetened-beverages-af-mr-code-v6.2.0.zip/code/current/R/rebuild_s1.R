suppressMessages(library(ieugwasr))

files <- list.files("C:/a3work", pattern = "^dat_.*_ebi_a_GCST006414\\.csv$", full.names = TRUE)
s1 <- data.frame(
  exposure = c("Artificial sweetener added to tea", "Coffee intake", "Fizzy drink intake (SSB)",
               "Low-calorie drink intake (ASB)", "Sugar added to coffee", "Sugar added to tea", "Tea intake"),
  n_index  = c(14, 34, 8, 17, 15, 17, 32),
  afgen    = c(14, 34, 8, 17, 15, 17, 32),
  bbj      = c(6, 32, 4, 8, 11, 11, 36),
  stringsAsFactors = FALSE
)

out <- data.frame()
for (f in files) {
  nm <- sub("^dat_", "", basename(f))
  nm <- sub("_ebi_a_GCST006414\\.csv$", "", nm)
  nm <- gsub("_", " ", nm)
  nm <- c("Artificial sweetener added to tea" = "Artificial sweetener added to tea",
          "Coffee intake" = "Coffee intake",
          "Fizzy drink intake SSB" = "Fizzy drink intake (SSB)",
          "Low calorie drink intake ASB" = "Low-calorie drink intake (ASB)",
          "Sugar added to coffee" = "Sugar added to coffee",
          "Sugar added to tea" = "Sugar added to tea",
          "Tea intake" = "Tea intake")[nm]
  d <- read.csv(f, stringsAsFactors = FALSE)
  rs <- unique(d$SNP)
  for (src in c("ebi-a-GCST006061", "bbj-a-71")) {
    res <- try(associations(rs, src), silent = TRUE)
    direct <- if (inherits(res, "try-error")) NA_integer_ else length(unique(res$rsid))
    out <- rbind(out, data.frame(exposure = nm, source = src, n_index = length(rs),
                                 direct = direct))
  }
}
out$retained <- ifelse(out$source == "ebi-a-GCST006061",
                       s1$afgen[match(out$exposure, s1$exposure)],
                       s1$bbj[match(out$exposure, s1$exposure)])
out$proxy   <- out$retained - out$direct
out$missing <- out$n_index - out$retained
write.csv(out, "C:/a3work/s1_proxy_rebuild.csv", row.names = FALSE)
writeLines(capture.output(print(out, row.names = FALSE)), "C:/a3work/s1_proxy_table.txt")
writeLines(paste("proxy", sum(out$proxy, na.rm = TRUE), "missing", sum(out$missing, na.rm = TRUE)), "C:/a3work/s1_totals.txt")
cat("\nproxy 合计:", sum(out$proxy, na.rm = TRUE), "\n")
cat("missing 合计:", sum(out$missing, na.rm = TRUE), "\n")
