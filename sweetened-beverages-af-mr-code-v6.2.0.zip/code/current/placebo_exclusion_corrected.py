# -*- coding: utf-8 -*-
"""Placebo exclusion test for M2: is the 'convergence' after removing
adiposity-locus instruments just regression to the mean?"""
import csv
import io
import math
import os
import sys

import numpy as np

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
D = r"C:\a3work"
RES = r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822\06_升级分析_v4\results"

LOCI = np.array([(int(x["chr"]), int(x["pos"]))
                 for x in csv.DictReader(open(os.path.join(D, "tmp_bmi_instruments_v46.csv"), encoding="utf-8"))])


def load(src):
    rows = []
    if src == "yuan":
        # Join Yuan AF effects to exposure-side GRCh37 coordinates.
        exp = {r["SNP"]: r for r in csv.DictReader(
            open(os.path.join(D, "dat_Coffee_intake_ebi_a_GCST006414.csv"), encoding="utf-8"))}
        comp = lambda a: a.translate(str.maketrans("ACGT", "TGCA"))
        for r in csv.DictReader(open(os.path.join(D, "yuan2025_instruments.tsv"), encoding="utf-8"), delimiter="\t"):
            if r["SNP"] not in exp:  # shared variants remain eligible for coffee
                continue
            e = exp[r["SNP"]]
            bx = float(e["beta.exposure"])
            ea, oa = e["effect_allele.exposure"], e["other_allele.exposure"]
            if r["ea.out"] == ea and r["oa.out"] == oa:
                by = float(r["beta.out"])
            elif r["ea.out"] == oa and r["oa.out"] == ea:
                by = -float(r["beta.out"])
            elif r["ea.out"] == comp(ea) and r["oa.out"] == comp(oa):
                by = float(r["beta.out"])
            elif r["ea.out"] == comp(oa) and r["oa.out"] == comp(ea):
                by = -float(r["beta.out"])
            else:
                continue
            rows.append((r["SNP"], int(e["chr"]), int(e["pos"]), bx, by, float(r["se.out"])))
    else:
        f = os.path.join(D, f"dat_Coffee_intake_{src}.csv")
        # FinnGen dat has no coordinates: borrow them from the Nielsen harmonised file
        coord = {r["SNP"]: (int(r["chr"]), int(r["pos"]))
                 for r in csv.DictReader(open(os.path.join(D, "dat_Coffee_intake_ebi_a_GCST006414.csv"), encoding="utf-8"))}
        for r in csv.DictReader(open(f, encoding="utf-8")):
            c, p = coord[r["SNP"]]
            rows.append((r["SNP"], c, p,
                         float(r["beta.exposure"]), float(r["beta.outcome"]), float(r["se.outcome"])))
    return rows


def ivw(rows):
    if len(rows) < 3:
        return np.nan, np.nan
    a = np.array([[r[3], r[4], r[5]] for r in rows])
    bx, by, se = a[:, 0], a[:, 1], a[:, 2]
    w = 1 / se ** 2
    den = (w * bx ** 2).sum()
    b = (w * bx * by).sum() / den
    se_fe = math.sqrt(1 / den)
    q = float((w * (by - b * bx) ** 2).sum())
    infl = max(1.0, math.sqrt(q / (len(rows) - 1)))
    return b, se_fe * infl


def adiposity_mask(rows):
    keep = []
    for snp, c, p, *_ in rows:
        near = ((LOCI[:, 0] == c) & (np.abs(LOCI[:, 1] - p) <= 500000)).any()
        keep.append(not near)
    return np.array(keep)


sources = {"Nielsen": load("ebi_a_GCST006414"),
           "FinnGen": load("finngen_R13"),
           "Yuan": load("yuan")}

base, post, drop_n = {}, {}, {}
for name, rows in sources.items():
    mask = adiposity_mask(rows)
    base[name] = ivw(rows)[0]
    post[name] = ivw([r for r, k in zip(rows, mask) if k])[0]
    drop_n[name] = int((~mask).sum())
    print(f"{name:<10} n={len(rows):>2} 剔除 {drop_n[name]:>2}  "
          f"OR {math.exp(base[name]):.2f} → {math.exp(post[name]):.2f}")

spread_pre = max(base.values()) - min(base.values())
spread_post = max(post.values()) - min(post.values())
print(f"\n观测：log-OR 全距 剔除前 {spread_pre:.4f} → 剔除后 {spread_post:.4f}")

# No pooled estimate is computed: the outcome sources are not mutually independent.

# ---------------- placebo ----------------
rng = np.random.default_rng(20261028)
NREP = 2000
spreads = []
for _ in range(NREP):
    ests = []
    for name, rows in sources.items():
        k = drop_n[name]
        idx = rng.choice(len(rows), size=len(rows) - k, replace=False)
        sub = [rows[i] for i in idx]
        ests.append(ivw(sub)[0])
    spreads.append(max(ests) - min(ests))

spreads = np.array(spreads)
print(f"\n安慰剂剔除（{NREP} 次，每次随机删除与肥胖剔除相同数量的工具）：")
print(f"  全距中位数 {np.median(spreads):.4f}（IQR {np.percentile(spreads,25):.4f}–{np.percentile(spreads,75):.4f}）")
print(f"  全距 ≤ 观测剔除后全距的比例 = {(spreads <= spread_post).mean():.3f}")
print(f"  全距 ≤ 观测剔除后全距的 5% 分位 = {np.percentile(spreads,5):.4f}")
print(f"  观测剔除后全距在随机分布中的位置 = {(spreads < spread_post).mean()*100:.1f}% 的随机剔除全距更小")

with open(os.path.join(D, "placebo_spread_distribution_corrected.csv"), "w", encoding="utf-8", newline="") as f:
    w = csv.writer(f)
    w.writerow(["replicate", "spread_log_or"])
    for i, s in enumerate(spreads, 1):
        w.writerow([i, f"{s:.6f}"])

print("\n判读：")
frac = (spreads <= spread_post).mean()
if frac > 0.5:
    print(f"  随机剔除有 {frac:.2%} 的情形产生同等或更小的全距 → '收敛'不能作为机制证据，应删去该因果化表述。")
elif frac > 0.05:
    print(f"  随机剔除仅 {frac:.2%} 达到同等收敛 → 收敛方向不寻常，但机制解释仍需其他证据。")
else:
    print(f"  随机剔除几乎不产生同等收敛（{frac:.2%}）→ 肥胖剔除的收敛并非回归到均值的假象。")
