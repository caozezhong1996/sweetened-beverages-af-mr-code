# -*- coding: utf-8 -*-
"""S4 加 2 行 PRESSO；S27 加 MDE 列；S7 加反向 MR MDE 列。"""
import docx, os, shutil, re, math, csv
from copy import deepcopy
from docx.shared import Pt

SUP = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\Supplement.docx"
ARCH = r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版\JAHA_v20261031_复核修改前备份"
shutil.copy(SUP, os.path.join(ARCH, "Supplement_加PRESSO与MDE前.docx"))
print("backup ok")

Z = 1.959963985
K = Z + 0.8416212336


def grid(tb):
    return [[c.text.strip() for c in r.cells] for r in tb.rows]


def rebuild(doc, tb, rows, font=7.5):
    """用 rows 重建 tb（保留表属性与列宽）。"""
    old_el = tb._tbl
    parent = old_el.getparent()
    idx = list(parent).index(old_el)
    tblPr_src = deepcopy(old_el.tblPr)
    widths = [c.width for c in tb.columns]
    ncol = len(rows[0])

    new_tb = doc.add_table(rows=len(rows), cols=ncol)
    new_tb._tbl.remove(new_tb._tbl.tblPr)
    new_tb._tbl.insert(0, tblPr_src)
    for i, row in enumerate(rows):
        for j in range(ncol):
            cell = new_tb.cell(i, j)
            cell.text = ""
            run = cell.paragraphs[0].add_run(row[j] if j < len(row) else "")
            run.font.size = Pt(font)
            if i == 0:
                run.bold = True
    for j in range(min(len(widths), ncol)):
        for r in new_tb.rows:
            r.cells[j].width = widths[j]
    new_el = new_tb._tbl
    parent.remove(new_el)
    parent.insert(idx, new_el)
    parent.remove(old_el)


d = docx.Document(SUP)

# ---------- S4：加两行 PRESSO ----------
tb4 = d.tables[3]
r4 = grid(tb4)
print("S4:", len(r4), "x", len(r4[0]))
print("  header:", r4[0])
new_rows4 = []
inserted = False
for r in r4:
    new_rows4.append(r)
    if r[0].startswith("MR-PRESSO: coffee intake → AF (FinnGen"):
        new_rows4.append([
            "MR-PRESSO: sugar added to tea → AF (FinnGen R13)",
            "raw beta −0.506; outlier-corrected not estimable",
            "raw 0.027; global <0.001",
            "16",
            "Global test significant but no variant identified as an outlier at P<0.05: heterogeneity is dispersed rather than driven by a few variants",
        ])
        new_rows4.append([
            "MR-PRESSO: sugar added to coffee → AF (AFGen 2018)",
            "raw beta −0.217; outlier-corrected not estimable",
            "raw 0.030; global 0.358",
            "15",
            "Global test non-significant with no outlier: horizontal pleiotropy does not explain this nominal estimate",
        ])
        inserted = True
assert inserted, "S4 anchor not found"
rebuild(d, tb4, new_rows4, font=7.5)
print("  S4 ->", len(new_rows4), "rows")

# ---------- S27：加 MDE 列 ----------
tb27 = d.tables[28]
r27 = grid(tb27)
print("\nS27:", len(r27), "x", len(r27[0]))
print("  header:", r27[0])
hdr = ["Outcome source", "Exposure", "SNPs (all)", "OR (95% CI), all", "MDE OR, all", "P",
       "SNPs (kept)", "OR (95% CI), adiposity loci removed", "MDE OR, kept", "P"]
def se_log(lo, hi):
    return (math.log(hi) - math.log(lo)) / (2 * Z)
out27 = [hdr]
for r in r27[1:]:
    if len(r) < 8:
        continue
    try:
        lo, hi = [float(x) for x in re.findall(r"[-\d.]+", r[3])[-2:]]
        lo2, hi2 = [float(x) for x in re.findall(r"[-\d.]+", r[6])[-2:]]
        mde1 = "%.2f" % math.exp(K * se_log(lo, hi))
        mde2 = "%.2f" % math.exp(K * se_log(lo2, hi2))
    except Exception:
        mde1 = mde2 = ""
    out27.append([r[0], r[1], r[2], r[3], mde1, r[4], r[5], r[6], mde2, r[7]])
rebuild(d, tb27, out27, font=6.5)
print("  S27 ->", len(out27), "rows x", len(hdr))

# ---------- S7：加反向 MR MDE ----------
tb7 = d.tables[6]
r7 = grid(tb7)
print("\nS7:", len(r7), "x", len(r7[0]))
print("  header:", r7[0])
out7 = [r7[0] + ["Reverse MR MDE (SD)"]]
for r in r7[1:]:
    if len(r) < 6:
        continue
    m = re.search(r"\(([-\d.]+) to ([-\d.]+)\)", r[3])
    if m:
        lo, hi = float(m.group(1)), float(m.group(2))
        mde = "%.3f" % (K * (hi - lo) / (2 * Z))
    else:
        mde = ""
    out7.append(r[:6] + [mde])
rebuild(d, tb7, out7, font=7.5)
print("  S7 ->", len(out7), "rows x", len(out7[0]))

d.save(SUP)
print("\nsaved")

# 验证
d2 = docx.Document(SUP)
print("tables:", len(d2.tables))
for i in (3, 6, 28):
    t = d2.tables[i]
    print("  idx%02d: %d x %d | %s" % (i, len(t.rows), len(t.columns),
                                       [c.text.strip()[:20] for c in t.rows[0].cells]))
print("\nS27 咖啡行：")
for r in d2.tables[28].rows:
    v = [c.text.strip() for c in r.cells]
    if v[0] and "Coffee" in v[1]:
        print("  ", " | ".join(v))
print("\nS4 新增行：")
for r in d2.tables[3].rows:
    v = [c.text.strip() for c in r.cells]
    if "sugar added" in v[0]:
        print("  ", " | ".join(x[:46] for x in v))
