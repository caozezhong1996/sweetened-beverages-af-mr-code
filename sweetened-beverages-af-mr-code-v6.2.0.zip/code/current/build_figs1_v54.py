# -*- coding: utf-8 -*-
"""Figure S1 (v54): leave-one-out and funnel diagnostics, rebuilt at print width.
v54 (2026-11-12): RIGHT_IN 0.06 -> 0.08 in, the smallest margin that keeps
the rightmost A2 x tick label (2.5) fully inside the canvas. Larger values
(>=0.10) make matplotlib re-select ticks and drop 2.5 altogether, which
would replace a clipped label with a missing one. No data, limits or fonts
changed; only the right margin and therefore the axes width."""
import csv
import io
import math
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.textpath import TextPath
from matplotlib.font_manager import FontProperties
import numpy as np

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

M = r"C:\Users\64915\Documents\kimi\workspace\奶茶房颤MR_迁移包_20260822"
NEW = os.path.join(M, "06_升级分析_v4", "results")
OLD = os.path.join(M, "03_结果数据_mr_results")
OUTDIR = r"C:\Users\64915\WorkBuddy\2026-10-30-20-42-58\_fig_fix\new"
A3 = r"C:\a3work"

CM = 1 / 2.54
W_IN, H_IN = 17.40 * CM, 23.0 * CM
DPI = 600

COMBOS = [
    ("A", "Coffee_intake", "ebi_a_GCST006414", NEW, "Coffee intake × Nielsen 2018", "#B33A3A"),
    ("B", "Coffee_intake", "finngen_R13", NEW, "Coffee intake × FinnGen R13", "#1A5276"),
    ("C", "Sugar_added_to_tea", "finngen_R13", NEW, "Sugar added to tea × FinnGen R13", "#0E6655"),
    ("D", "Sugar_added_to_coffee", "ebi_a_GCST006061", OLD, "Sugar added to coffee × AFGen", "#8C5A11"),
    ("E", "Coffee_intake", "yuan", A3, "Coffee intake × Yuan 2025", "#145A86"),
]


def tp_w(text, size, weight="normal"):
    fp = FontProperties(family="DejaVu Sans", size=size, weight=weight)
    return max(TextPath((0, 0), ln, prop=fp).get_extents().width
               for ln in text.split("\n")) / 72.0


def load(path):
    rows = []
    for r in csv.DictReader(open(path, encoding="utf-8")):
        if str(r.get("mr_keep", "TRUE")).upper() == "FALSE":
            continue
        try:
            bx, by = float(r["beta.exposure"]), float(r["beta.outcome"])
            sy = float(r["se.outcome"])
        except (KeyError, ValueError):
            continue
        if not all(map(math.isfinite, (bx, by, sy))) or sy <= 0 or bx == 0:
            continue
        rows.append(dict(snp=r["SNP"], bx=bx, by=by, sy=sy))
    return rows


def ivw(rows):
    w = np.array([1 / r["sy"] ** 2 for r in rows])
    bx = np.array([r["bx"] for r in rows])
    by = np.array([r["by"] for r in rows])
    den = float((w * bx ** 2).sum())
    b = float((w * bx * by).sum() / den)
    se_fe = math.sqrt(1 / den)
    q = float((w * (by - b * bx) ** 2).sum())
    df = len(rows) - 1
    infl = max(1.0, math.sqrt(q / df)) if df > 0 else 1.0
    return b, se_fe * infl, infl


LBL = 8.2
plt.rcParams.update({"font.family": "DejaVu Sans", "axes.linewidth": 0.6})
fig = plt.figure(figsize=(W_IN, H_IN), dpi=DPI)

LEFT_IN, RIGHT_IN = 0.10, 0.08
LEFT, RIGHT = LEFT_IN / W_IN, 1 - RIGHT_IN / W_IN
TOP_IN, BOT_IN = 0.26, 1.00
GAPX_IN, GAPY_IN = 0.52, 0.56
colw = ((RIGHT - LEFT) * W_IN - GAPX_IN) / 2 / W_IN
rowh = ((1 - TOP_IN / H_IN - BOT_IN / H_IN) * H_IN - (len(COMBOS) - 1) * GAPY_IN) / len(COMBOS) / H_IN
TOP = 1 - TOP_IN / H_IN
BOT = BOT_IN / H_IN

for i, (letter, tag, stem, d, label, col) in enumerate(COMBOS):
    rows = load(os.path.join(d, f"dat_{tag}_{stem}.csv"))
    b, se, infl = ivw(rows)
    y0 = TOP - (i + 1) * rowh - i * GAPY_IN / H_IN

    # ---------------- leave-one-out ----------------
    ax = fig.add_axes([LEFT, y0, colw, rowh])
    loo = []
    for k in range(len(rows)):
        bb, ss, _ = ivw(rows[:k] + rows[k + 1:])
        loo.append((bb, ss))
    loo.sort(key=lambda t: t[0])
    ax.errorbar([t[0] for t in loo], np.arange(len(loo)),
                xerr=[1.96 * t[1] for t in loo], fmt="o", ms=2.2, lw=0.0,
                elinewidth=0.55, color=col, alpha=0.75, zorder=2)
    ax.axvline(b, color="#B33A3A", lw=0.9, ls=(0, (4, 2)), zorder=3)
    ax.axvline(0, color="#AAAAAA", lw=0.6, zorder=1)
    ax.set_yticks([])
    ax.set_ylim(-1.4, len(loo) + 0.4)
    ax.set_xlabel("Leave-one-out IVW log OR", fontsize=LBL, labelpad=1.5)
    ax.set_title(f"{letter}1  {label}  ({len(rows)} SNPs)", fontsize=8.3, color=col,
                 loc="left", pad=3)
    ax.tick_params(axis="x", labelsize=LBL, length=2.0, pad=1.4)
    for s in ("top", "right", "left"):
        ax.spines[s].set_visible(False)

    # ---------------- funnel ----------------
    ax = fig.add_axes([LEFT + colw + GAPX_IN / W_IN, y0, colw, rowh])
    wr = np.array([r["by"] / r["bx"] for r in rows])
    prec = np.array([abs(r["bx"]) / r["sy"] for r in rows])
    ax.scatter(wr, prec, s=7, color=col, alpha=0.85, zorder=2, linewidths=0)
    ax.axvline(b, color="#B33A3A", lw=0.9, ls=(0, (4, 2)), zorder=3)
    ax.axvline(0, color="#AAAAAA", lw=0.6, zorder=1)
    ymax = float(prec.max()) * 1.12
    ys = np.linspace(max(ymax * 0.03, 0.35), ymax, 200)
    for s in (1, -1):
        ax.plot(b + s * 1.96 / ys, ys, color="#999999", lw=0.7, ls=":", zorder=1)
    ax.set_xlim(min(wr.min(), b) - 0.3, max(wr.max(), b) + 0.3)
    ax.set_ylim(0, ymax)
    ax.set_xlabel("Per-SNP Wald ratio (log OR)", fontsize=LBL, labelpad=1.5)
    ax.set_title(f"{letter}2  funnel plot, overdispersion {infl:.2f}×", fontsize=8.3,
                 color=col, loc="left", pad=3)
    ax.set_ylabel("Precision (1/SE)", fontsize=LBL, labelpad=1.5)
    ax.tick_params(axis="both", labelsize=LBL, length=2.0, pad=1.4)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)

note = ("Red dashed line, random-effects IVW estimate.  Funnel panels: dotted curves, pseudo-95% confidence region;\n"
        "grey line, null.  Leave-one-out panels: one estimate per omitted variant.")
note_sz = 7.8 if tp_w(note, 7.8) <= W_IN - 0.12 else 7.4
fig.text(0.5, 0.018, note, ha="center", va="center", fontsize=note_sz,
         color="#555555", linespacing=1.45)

out = os.path.join(OUTDIR, "FigureS1_LOO_Funnel_v54.png")
fig.savefig(out, dpi=DPI, facecolor="white")
plt.close(fig)
print(f"saved: {out}")
print(f"canvas {W_IN*2.54:.2f} x {H_IN*2.54:.2f} cm @{DPI} dpi ({os.path.getsize(out)/1024:.0f} KB)")
print(f"note needs {tp_w(note, note_sz):.2f} in / {W_IN-0.12:.2f} in available")
for letter, tag, stem, d, label, col in COMBOS:
    rows = load(os.path.join(d, f"dat_{tag}_{stem}.csv"))
    b, se, infl = ivw(rows)
    print(f"  {letter} {label:<44} n={len(rows):>2}  b={b:+.4f}  OR={math.exp(b):.2f}  "
          f"CI={math.exp(b-1.96*se):.2f}-{math.exp(b+1.96*se):.2f}")
