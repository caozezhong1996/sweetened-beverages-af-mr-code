# -*- coding: utf-8 -*-
"""给 Table S3 增加 I² 列（重建表，保留样式）。"""
import docx, os, shutil, re
from copy import deepcopy
from docx.shared import Pt

SUP = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\Supplement.docx"
ARCH = r"C:\Users\64915\Desktop\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版\JAHA_v20261031_复核修改前备份"
shutil.copy(SUP, os.path.join(ARCH, "Supplement_S3加I2前.docx"))
print("backup ok")

d = docx.Document(SUP)
tb = d.tables[2]
old = [[c.text.strip() for c in r.cells] for r in tb.rows]
print("S3 shape:", len(old), "x", len(old[0]))
print("header:", old[0])

# 解析 Q 与 df，计算 I²
def i2(q, df):
    if q <= 0:
        return 0.0
    v = (q - df) / q * 100
    return max(0.0, v)

new_rows = []
drop = 0
for r in old:
    if r[0] == "Exposure" and r[2] == "Cochran Q (df)":
        new_rows.append(["Exposure", "Outcome source", "Cochran Q (df)", "Q P value", "I² (%)",
                         "Egger intercept (SE)", "Intercept P value"])
        continue
    m = re.match(r"([\d.]+)\s*\((\d+)\)", r[2])
    if not m:
        new_rows.append(r[:3] + [r[3]] + [""] + r[4:])
        drop += 1
        continue
    q, df = float(m.group(1)), int(m.group(2))
    val = "%.1f" % i2(q, df)
    new_rows.append([r[0], r[1], r[2], r[3], val, r[4], r[5]])

print("rows without parsable Q:", drop)
print("sample:", new_rows[1], new_rows[25])

# 校验茶与糖加茶
for r in new_rows:
    if r[0] == "Tea intake" and "Nielsen" in r[1]:
        print("  tea x Nielsen  ->", r)
    if r[0] == "Tea intake" and "FinnGen" in r[1]:
        print("  tea x FinnGen  ->", r)
    if r[0] == "Sugar added to tea" and "Nielsen" in r[1]:
        print("  sugar tea x Nielsen ->", r)

# 重建：在原位置插入新表
tbl_el = tb._tbl
parent = tbl_el.getparent()
idx = list(parent).index(tbl_el)
tblPr_src = deepcopy(tbl_el.tblPr)
widths = [c.width for c in tb.columns]

new_tb = d.add_table(rows=len(new_rows), cols=7)
# 样式继承
new_tb._tbl.remove(new_tb._tbl.tblPr)
new_tb._tbl.insert(0, tblPr_src)
for i, row in enumerate(new_rows):
    for j, val in enumerate(row):
        cell = new_tb.cell(i, j)
        cell.text = ""
        run = cell.paragraphs[0].add_run(val)
        run.font.size = Pt(7.5)
        if i == 0:
            run.bold = True
for j, w in enumerate(widths[:6]):
    for row in new_tb.rows:
        row.cells[j].width = w

# 移到原位置
new_el = new_tb._tbl
parent.remove(new_el)
parent.insert(idx, new_el)
# 删除旧表
parent.remove(tbl_el)

d.save(SUP)
print("\nsaved")

# 验证
d2 = docx.Document(SUP)
t2 = d2.tables[2]
print("new shape:", len(t2.rows), "x", len(t2.columns))
print("header:", [c.text.strip() for c in t2.rows[0].cells])
for r in t2.rows:
    v = [c.text.strip() for c in r.cells]
    if v[0] == "Tea intake" and ("Nielsen" in v[1] or "FinnGen" in v[1]):
        print("  ", v)
print("total tables:", len(d2.tables))
