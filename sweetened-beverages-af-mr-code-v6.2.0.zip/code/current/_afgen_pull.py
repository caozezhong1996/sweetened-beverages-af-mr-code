# -*- coding: utf-8 -*-
"""从 OpenGWAS 提取 AFGen 2018 上糖加咖啡 15 个工具位点的关联。"""
import csv, json, os, re, urllib.request

A3 = r"C:\a3work"
EXPO = os.path.join(A3, "dat_Sugar_added_to_coffee_ebi_a_GCST006414.csv")
AFGEN = "ebi-a-GCST006061"

TOKEN = None
for line in open(os.path.expanduser("~/.Renviron"), encoding="utf-8", errors="replace"):
    m = re.match(r"\s*OPENGWAS_JWT\s*=\s*['\"]?([^'\"\s]+)", line)
    if m:
        TOKEN = m.group(1)
assert TOKEN, "token not found"
print("token ok, len", len(TOKEN))

rows = list(csv.DictReader(open(EXPO, encoding="utf-8", errors="replace")))
keep = [r for r in rows if str(r.get("mr_keep", "")).lower() in ("true", "1")]
print("exposure instruments:", len(keep), "of", len(rows))
snps = [r["SNP"] for r in keep]
print("snps:", snps)

body = json.dumps({"id": [AFGEN], "variant": snps}).encode()
req = urllib.request.Request(
    "https://api.opengwas.io/api/associations",
    data=body,
    headers={"Authorization": "Bearer " + TOKEN, "Content-Type": "application/json"},
)
raw = json.loads(urllib.request.urlopen(req, timeout=180).read().decode())
print("returned rows:", len(raw))
if raw:
    print("fields:", sorted(raw[0].keys()))

out = os.path.join(A3, "afgen_sugar_coffee_raw.csv")
if raw:
    keys = ["rsid", "beta", "se", "p", "ea", "nea", "eaf", "n", "id"]
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys, extrasaction="ignore")
        w.writeheader()
        for r in raw:
            w.writerow({k: r.get(k) for k in keys})
    print("written:", out)
    got = {r["rsid"] for r in raw}
    print("missing:", [s for s in snps if s not in got] or "none")
else:
    print("NO DATA RETURNED")
