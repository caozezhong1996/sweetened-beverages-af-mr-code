# -*- coding: utf-8 -*-
"""第七轮：按三位模拟审稿人的共同阻断项与自查发现降格/纠正"""
import docx, os, sys

B = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013"
OLD_T = "Adiposity-Linked Pleiotropy in the Coffee\u2013Atrial Fibrillation Signal: A Two-Sample Mendelian Randomization Study"
NEW_T = "Pleiotropy at the FTO Locus in the Coffee\u2013Atrial Fibrillation Signal: A Two-Sample Mendelian Randomization Study"

log = []

def set_text(p, new):
    p.runs[0].text = new
    for r in p.runs[1:]:
        r.text = ""

def rep_para(doc, old, new, expected=1, label=""):
    n = 0
    for p in doc.paragraphs:
        if old in p.text:
            set_text(p, p.text.replace(old, new))
            n += 1
    if n != expected:
        print("FAIL[%s] matched=%d expected=%d" % (label, n, expected))
        log.append(("FAIL", label, n))
    else:
        print("ok  [%s]" % label)
        log.append(("ok", label, n))
    return n

# ---------------- Manuscript ----------------
mp = os.path.join(B, "Manuscript.docx")
m = docx.Document(mp)

# M1 标题降格
assert m.paragraphs[0].text.strip() == OLD_T, m.paragraphs[0].text[:80]
set_text(m.paragraphs[0], NEW_T)
print("ok  [M1 title]")

# M2 摘要三处
rep_para(m, "Coffee was associated across European sources",
         "Coffee intake showed a nominal association across European sources", 1, "M2a nominal")
rep_para(m, "Seven phenotypes were instrumented in UK Biobank (N = 64,949\u2013447,485) and defined",
         "Seven phenotypes were instrumented in UK Biobank and defined", 1, "M2b drop N")
rep_para(m, "yet did not meet the pre-specified consistency criteria",
         "but did not meet pre-specified consistency criteria", 1, "M2c criteria")
rep_para(m, "At FTO, colocalization supported a shared variant with Nielsen (0.894) and FinnGen (0.906); AFGen was inconclusive (0.362)",
         "Colocalization supported a shared FTO variant with Nielsen (0.894) and FinnGen (0.906), but was inconclusive in AFGen (0.362)",
         1, "M2d coloc")

# M3 可解释零：四改三
rep_para(m,
    "Across the seven phenotypes, four provide interpretable null estimates (fizzy drink, low-calorie drink, "
    "artificial sweetener added to tea and sugar added to coffee); two do not, for the reasons given above and in "
    "the heterogeneity analysis (sugar added to tea and tea intake); and coffee intake is not a null estimate.",
    "Across the seven phenotypes, three provide interpretable null estimates (fizzy drink, low-calorie drink and "
    "artificial sweetener added to tea), in that within-source heterogeneity was not significant in any of their "
    "four outcome panels (Table S3). Three are qualified rather than interpretable: sugar added to coffee showed "
    "significant within-source heterogeneity in three of its four panels (Q P = 0.018, 4.1 \u00d7 10\u207b\u2077 and 0.007); "
    "sugar added to tea showed the same and also failed the negative control; and tea intake showed both "
    "heterogeneity and a near-even split in variant direction (Results; Table S3). Coffee intake is not a null estimate.",
    1, "M3 null count")

# M4 Q 精度：两位小数反推改为全精度
rep_para(m, "between-source Cochran Q = 2.97, df = 2, P = 0.23, I\u00b2 = 33%",
         "between-source Cochran Q = 2.87, df = 2, P = 0.24, I\u00b2 = 30%", 1, "M4 Q precision")

# M5 咖啡因位点仅 Nielsen 可评估
rep_para(m,
    "the posterior mass lies instead on a coffee-specific signal with no AF counterpart (PP.H1 \u2265 0.93; PP.H4 \u2264 0.008)",
    "the posterior mass lies instead on a coffee-specific signal with no AF counterpart (PP.H1 \u2265 0.93; PP.H4 \u2264 0.008); "
    "these two loci could be assessed against Nielsen 2018 only (Table S8)", 1, "M5 locus symmetry")

# M6 结论不依赖重叠来源
rep_para(m,
    "whereas the diagnostic detected known coffee\u2013tea overlap (\u22120.318).",
    "whereas the diagnostic detected known coffee\u2013tea overlap (\u22120.318). Every beverage null and the coffee "
    "association were nevertheless reproduced in the UK Biobank-free Yuan 2025 panel, so no conclusion here rests "
    "on the overlapping source.", 1, "M6 overlap independence")

m.save(mp)

# 词数
m2 = docx.Document(mp)
ps = [p.text for p in m2.paragraphs]
def idx(s):
    return next(i for i, t in enumerate(ps) if t.strip() == s)
abst = len(" ".join(ps[6:9]).split())
body = sum(len(ps[k].split()) for k in range(idx("Introduction"), idx("Declarations")))
print("abstract words =", abst, "| body words =", body)

# ---------------- Cover Letter ----------------
cpath = os.path.join(B, "Cover_Letter.docx")
c = docx.Document(cpath)
rep_para(c, OLD_T, NEW_T, 1, "CL title")
c.save(cpath)

# ---------------- Supplement ----------------
spath = os.path.join(B, "Supplement.docx")
s = docx.Document(spath)
rep_para(s, OLD_T, NEW_T, 1, "SUP title")
# 摘要词数声明
for tb in s.tables:
    for r in tb.rows:
        for cell in r.cells:
            if "249 words" in cell.text:
                for para in cell.paragraphs:
                    if "249 words" in para.text:
                        for run in para.runs:
                            if "249 words" in run.text:
                                run.text = run.text.replace("249 words", "%d words" % abst)
                                print("ok  [SUP S9 abstract count -> %d]" % abst)
s.save(spath)

# ---------------- core properties ----------------
for fn in ("Manuscript.docx", "Supplement.docx"):
    p = os.path.join(B, fn)
    d = docx.Document(p)
    cp = d.core_properties
    if cp.title:
        cp.title = cp.title.replace(OLD_T, NEW_T)
        d.save(p)
        print("ok  [core props]", fn, "->", cp.title[:60])

# ---------------- README ----------------
rpath = os.path.join(B, "README_投稿包.md")
txt = open(rpath, encoding="utf-8").read()
if OLD_T in txt:
    txt = txt.replace(OLD_T, NEW_T)
    print("ok  [README title]")
txt = txt.replace("\u6458\u8981 **249** \u8bcd", "\u6458\u8981 **%d** \u8bcd" % abst)
txt = txt.replace("\u672c\u7a3f\u6458\u8981 249 \u8bcd", "\u672c\u7a3f\u6458\u8981 %d \u8bcd" % abst)
import re
txt = re.sub(r"\u6b63\u6587 \*\*9,\d{3}\*\* \u8bcd", "\u6b63\u6587 **{:,}** \u8bcd".format(body), txt)
open(rpath, "w", encoding="utf-8").write(txt)
print("ok  [README counts]")

print("\nDONE")
