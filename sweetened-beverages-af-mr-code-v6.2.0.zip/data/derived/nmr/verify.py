# -*- coding: utf-8 -*-
import math, re

def se_from_ci(lo, hi):
    return (math.log(hi) - math.log(lo)) / (2*1.959964)

def fe_meta(ests, ses):
    w = [1/s**2 for s in ses]
    y = sum(wi*e for wi, e in zip(w, ests)) / sum(w)
    se = math.sqrt(1/sum(w))
    return y, se

def ivw_het(ests, ses):
    w = [1/s**2 for s in ses]
    y = sum(wi*e for wi, e in zip(w, ests)) / sum(w)
    Q = sum(wi*(e-y)**2 for wi, e in zip(w, ests))
    df = len(ests)-1
    I2 = max(0.0, (Q-df)/Q) if Q > 0 else 0.0
    from math import erfc, sqrt
    # chi2 sf via series for df=1
    p = erfc(sqrt(Q/2)) if df == 1 else None
    return y, Q, df, I2, p

print("="*70)
print("闸门A: 表2 各暴露 Nielsen vs FinnGen 的 I2（稿件称 0-3%，糖茶 67%）")
tab2 = {
 # exposure: (Nielsen OR, lo, hi, FinnGen OR, lo, hi)
 "sugar_tea": (0.91,0.72,1.17, 0.60,0.40,0.90),
 "sugar_coffee": (0.89,0.70,1.13, 0.88,0.59,1.31),
 "fizzy_SSB": (0.91,0.67,1.22, 0.98,0.70,1.37),
 "lowcal_ASB": (0.99,0.86,1.13, 0.94,0.81,1.09),
 "artsw_tea": (0.91,0.72,1.14, 0.96,0.72,1.28),
 "coffee": (1.26,1.02,1.57, 1.58,1.09,2.29),
 "tea": (0.90,0.72,1.14, 0.88,0.60,1.28),
}
for k,(o1,l1,h1,o2,l2,h2) in tab2.items():
    e1, e2 = math.log(o1), math.log(o2)
    s1, s2 = se_from_ci(l1,h1), se_from_ci(l2,h2)
    y,Q,df,I2,p = ivw_het([e1,e2],[s1,s2])
    m, mse = fe_meta([e1,e2],[s1,s2])
    # DerSimonian-Laird random effects
    s2tau = max(0.0, (Q-df)/ (sum(1/x**2 for x in [s1,s2]) - sum(1/x**4 for x in [s1,s2])/sum(1/x**2 for x in [s1,s2])))
    wr=[1/(x**2+s2tau) for x in [s1,s2]]
    yr = sum(wi*e for wi,e in zip(wr,[e1,e2]))/sum(wr)
    ser = math.sqrt(1/sum(wr))
    print(f"{k:14s} FE OR={math.exp(m):.4f} ({math.exp(m-1.96*mse):.3f}-{math.exp(m+1.96*mse):.3f})  Q={Q:.2f} I2={I2*100:5.1f}%  RE OR={math.exp(yr):.3f} ({math.exp(yr-1.96*ser):.3f}-{math.exp(yr+1.96*ser):.3f})")

print()
print("="*70)
print("闸门B: P<5e-6 对应的最小 F")
z = 4.564647
print(f"z(5e-6, two-sided) = {z:.4f}, F = z^2 = {z**2:.2f}")

print()
print("="*70)
print("闸门C: 咖啡因窗口 vs 其余工具的差值检验（审稿人B称不显著）")
for name,(oA,lA,hA,oB,lB,hB) in {
  "Nielsen": (1.03,0.76,1.38, 1.50,1.12,2.01),
  "FinnGen": (1.23,0.73,2.07, 1.96,1.18,3.24)}.items():
    eA,eB = math.log(oA), math.log(oB)
    sA,sB = se_from_ci(lA,hA), se_from_ci(lB,hB)
    d = eB-eA; sd = math.sqrt(sA**2+sB**2); zz = d/sd
    from math import erfc, sqrt
    p = erfc(abs(zz)/sqrt(2))
    print(f"{name}: diff logOR={d:.4f} SE={sd:.4f} z={zz:.3f} P={p:.4f}")

print()
print("="*70)
print("闸门D: BH 校正，7 检验族 vs 28 检验族")
p7 = [0.060,0.246,0.563,0.499,0.407,0.002,0.285]
for n,ps in ((7,p7),(28,p7)):
    srt = sorted(ps)
    th = [0.05*(i+1)/n for i in range(len(srt))]
    sig = [ (p,t) for p,t in zip(srt,th) if p<=t]
    print(f"n={n}: 排序P={['%.3f'%x for x in srt]}")
    print(f"      BH阈值={['%.4f'%x for x in th]}")
    print(f"      通过={[(round(p,3),round(t,4)) for p,t in sig]}")
    print(f"      最大通过P={max([p for p,t in sig]) if sig else None}")

print()
print("="*70)
print("闸门E: 阳性对照酒精 meta 1.19 (1.01-1.40) 复算")
print("  单项 1.16/1.12/1.29 (Nielsen/AFGen/FinnGen) — 稿件只合并 Nielsen+FinnGen")
e=[math.log(1.16),math.log(1.29)]; s=[se_from_ci(0.96,1.40),se_from_ci(0.94,1.78)]
y,se_=fe_meta(e,s)
print(f"  FE = {math.exp(y):.3f} ({math.exp(y-1.96*se_):.3f}-{math.exp(y+1.96*se_):.3f})  [稿件 1.19 (1.01-1.40)]")

print()
print("="*70)
print("闸门F: 代谢物表 S25 vs 图2 是否 n.e.")
print("  S25 明确给出 Nielsen 与 FinnGen 两列估计: 咖啡因5/1, 副黄嘌呤7/2, 可可碱2/2 个工具")
