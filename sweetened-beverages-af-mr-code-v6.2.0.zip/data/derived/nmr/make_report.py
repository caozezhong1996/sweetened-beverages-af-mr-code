# -*- coding: utf-8 -*-
import os
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn

from docx.oxml import OxmlElement

def _ea_style(style, ea):
    rPr = style.element.get_or_add_rPr()
    rFonts = rPr.find(qn("w:rFonts"))
    if rFonts is None:
        rFonts = OxmlElement("w:rFonts"); rPr.append(rFonts)
    rFonts.set(qn("w:eastAsia"), ea)

def _ea(run, ea):
    rPr = run._element.get_or_add_rPr()
    rFonts = rPr.find(qn("w:rFonts"))
    if rFonts is None:
        rFonts = OxmlElement("w:rFonts"); rPr.append(rFonts)
    rFonts.set(qn("w:eastAsia"), ea)


OUT = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013\审稿与编辑评估_20261029.docx"

doc = Document()

# 基础样式
st = doc.styles["Normal"]
st.font.name = "Times New Roman"
st.font.size = Pt(10.5)
_ea_style(st, "宋体")
st.paragraph_format.space_after = Pt(4)
st.paragraph_format.line_spacing = 1.25

sec = doc.sections[0]
sec.top_margin = Cm(2.2); sec.bottom_margin = Cm(2.2)
sec.left_margin = Cm(2.4); sec.right_margin = Cm(2.4)

def H(txt, lvl=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(12 if lvl == 1 else 8)
    p.paragraph_format.space_after = Pt(4)
    r = p.add_run(txt)
    r.bold = True
    r.font.size = Pt(14 if lvl == 1 else 11.5)
    r.font.name = "Times New Roman"
    _ea(r, "黑体")
    r.font.color.rgb = RGBColor(0x11, 0x11, 0x11)
    return p

def P(txt, bold_prefix=None, indent=0, size=10.5):
    p = doc.add_paragraph()
    if indent:
        p.paragraph_format.left_indent = Cm(indent)
    if bold_prefix:
        r = p.add_run(bold_prefix); r.bold = True; r.font.size = Pt(size)
        _ea(r, "黑体")
    r = p.add_run(txt); r.font.size = Pt(size)
    _ea(r, "宋体")
    return p

def B(txt, size=10.5):
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.space_after = Pt(2)
    r = p.add_run(txt); r.font.size = Pt(size)
    _ea(r, "宋体")
    return p

def T(rows, widths=None, header=True):
    t = doc.add_table(rows=len(rows), cols=len(rows[0]))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    tblPr = t._tbl.tblPr
    layout = OxmlElement("w:tblLayout"); layout.set(qn("w:type"), "fixed"); tblPr.append(layout)
    for i, row in enumerate(rows):
        for j, cell in enumerate(row):
            c = t.cell(i, j)
            c.text = ""
            p = c.paragraphs[0]
            p.paragraph_format.space_after = Pt(1)
            r = p.add_run(str(cell)); r.font.size = Pt(9)
            r.font.name = "Times New Roman"
            _ea(r, "宋体")
            if header and i == 0:
                r.bold = True
    if widths:
        for j, w in enumerate(widths):
            for row in t.rows:
                row.cells[j].width = Cm(w)
            t.columns[j].width = Cm(w)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return t

# ============ 标题 ============
tp = doc.add_paragraph(); tp.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = tp.add_run("审稿与编辑评估报告"); r.bold = True; r.font.size = Pt(18)
_ea(r, "黑体")

sp = doc.add_paragraph(); sp.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = sp.add_run("Genetically Proxied Sweetened Beverage Intake and Atrial Fibrillation:\nA Two-Sample and Multivariable Mendelian Randomization Study")
r.italic = True; r.font.size = Pt(10)

info = doc.add_paragraph(); info.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = info.add_run("目标期刊：Journal of the American Heart Association　|　审读日期：2026-10-29　|　版本：投稿包 20261013")
r.font.size = Pt(9); r.font.color.rgb = RGBColor(0x55,0x55,0x55)

doc.add_paragraph()
P("本报告基于对主稿、补充材料（表 S1–S29）、Highlights、Cover Letter 与四张图的逐页通读，"
  "并对全部关键估计做了独立复算；另以三份互盲审稿意见交叉比对，凡审稿人提出的数值指控均重新验算，"
  "确认成立才写入。期刊规则与参考文献均做了一手核实。",
  bold_prefix="方法与边界　")

# ============ 0 ============
H("0　结论先行")
P("建议处置：Major revision。现在这个状态投出去，会在 JAHA 的统计审稿环节被挡下，"
  "但缺陷几乎全在表述层与文献层，数据层是干净的。", bold_prefix="")

rows = [
 ["判断项", "结论", "依据"],
 ["数据可复现性", "通过", "独立重算 7 个欧洲 meta、I²、BH、阳性对照，全部落在报告值上；Table 2 与 Table S2 抽查 30 余格无一处不符"],
 ["主结果可信度", "中等偏上", "五个甜味饮料表型在无 UKB 重叠的 192,851 例结局中同样为零，这是全文最硬的一环"],
 ["表述校准", "不合格", "摘要把方向写错、把东亚提升为独立人群证据、阴性对照失败未披露"],
 ["文献完整性", "不合格", "漏引一篇 2026 年 3 月发表的同题 MR，且该文结论与本文咖啡信号方向一致"],
 ["图表准确性", "不合格", "图 2 把 6 个确实存在的估计标成 n.e.；图 1 的代理数写错一个数量级；图 S1 图注承诺的穷举不成立"],
 ["JAHA 格式", "合规", "摘要 181 词、Clinical Perspective 188 词、必备声明齐；原创研究无正文字数上限"],
]
T(rows, widths=[3.0, 2.2, 10.2])

P("最需要立刻处理的三件事：",
  bold_prefix="")
B("补引 You 等 2026 年 Eur J Nutr 那篇（咖啡 OR 1.281，95% CI 1.036–1.583，P = 0.022）。它比本文早七个多月发表，"
  "同一暴露、同一结局、同一方法，方向与本文的咖啡信号一致。不引会被审稿人当成文献检索不全。")
B("摘要里 \"attenuated estimates to 1.26–1.39\" 的方向是错的。Nielsen 2018 是 1.26 升到 1.39，不是衰减。")
B("阴性对照失败（糖加茶对房室阻滞 OR 0.51，P = 0.0012，Bonferroni 后仍显著）在摘要、Highlights、结论三处全部缺席。"
  "这是全稿唯一一个通过校正的对照失败，藏不住。")

P("还有一个战略判断，比上述三条都重要：这篇稿子的真实卖点不是奶茶，是「已经发表的两个阳性 MR 结果"
  "（Xie 2024 的 1.023、You 2026 的 1.281）可以被脂肪量位点的多效性解释掉」。"
  "现在的稿子把这条最值钱的发现写成了自我否定（\"我们的结果不足以推翻共识\"），等于把弹药扔了。",
  bold_prefix="")

# ============ 1 ============
H("1　稿件实际在做什么")
P("先把账对齐，后面所有判断都建立在这张表上。")
rows = [
 ["层", "内容", "关键数字"],
 ["暴露", "UK Biobank 七个饮料表型（非奶茶）", "五个亚表型 N = 64,949；咖啡 428,860；茶 447,485"],
 ["工具阈值", "咖啡与茶 P < 5×10⁻⁸；五个亚表型 P < 5×10⁻⁶", "F 最小 20.8–21.7；累计 R² 0.126%–0.568%"],
 ["主结局", "Nielsen 2018（含 UKB）", "60,620 例"],
 ["复制结局", "FinnGen R13 / Yuan 2025（无 UKB）", "67,783 / 192,851 例"],
 ["敏感与情境", "AFGen 2018 / BioBank Japan", "55,114 / 8,180 例"],
 ["核心结论", "五个甜味饮料表型对 AF 无因果证据", "欧洲 meta OR 0.82–0.97，P ≥ 0.06"],
 ["唯一通过 BH 的信号", "咖啡", "meta OR 1.34（1.11–1.62），P = 0.002"],
 ["信号的去脂解构", "剔除 724 个 BMI 位点 ±500 kb 内工具", "来源间跨度 1.26–1.79 → 1.26–1.39"],
 ["对照", "阳性：酒精；阴性：房室阻滞", "阳性仅 meta P = 0.035；阴性在糖加茶上失败"],
]
T(rows, widths=[2.6, 6.6, 6.2])

P("需要看清的一点：标题写「Sweetened Beverage Intake」，实际做的是英国中老年欧洲裔人群的加糖行为。"
  "奶茶在全文出现 12 次，Introduction 3 次、Discussion 3 次、摘要 1 次、结论 1 次，Results 零次。"
  "也就是说，稿子自己知道做不了奶茶，却把奶茶放在标题动机、摘要首句和 Cover Letter 的第一卖点上。")

# ============ 2 ============
H("2　审稿人视角")

H("2.1　A 类：必须改的事实性错误", 2)
P("A1　摘要把「升高」写成了「衰减」", bold_prefix="")
P("摘要原句：\"Coffee was associated in primary analyses, but excluding adiposity-locus instruments attenuated estimates to 1.26–1.39\"。"
  "查 Table S27：Nielsen 2018 由 1.26（1.02–1.57）升到 1.39（1.04–1.86），P = 0.028；FinnGen R13 由 1.58 降到 1.39；"
  "Yuan 2025 由 1.79 降到 1.26。三个来源里两个下降、一个上升，而且上升的那个恰恰是唯一保持名义显著的主结局。"
  "用 attenuated 概括三个数，方向错了。这是全文关于核心敏感性分析唯一的定量陈述，多数读者只读摘要。", indent=0.5)
P("改法：\"narrowed the between-source range from 1.26–1.79 to 1.26–1.39; only Nielsen 2018 retained a nominal association "
  "(1.39, 1.04–1.86; P = 0.028)\"。", indent=0.5)

H("2.2　B 类：可验证的客观缺陷", 2)
P("以下每一条都能被本稿自己的表格或图片直接证伪，不需要新数据。")

B("B1　图 2 把 6 个确实存在的代谢物估计标成 n.e.。图 2 的 Nielsen 2018 与 FinnGen R13 两个面板，"
  "血浆咖啡因、副黄嘌呤、可可碱三行全部标「n.e.」，图顶横条还写着 \"Metabolites: EUR meta-analysis panel only\"。"
  "但 Table S25 明确给出这 6 个估计：咖啡因 Nielsen 5 个工具 0.99（0.91–1.06）、FinnGen 单工具 1.10（0.82–1.48）；"
  "副黄嘌呤 7 个工具 0.98、2 个工具 0.90；可可碱 0.85、0.84。九次代谢物估计里六次存在却被画成不存在。"
  "后果不只是图注错：把分量藏起来，读者就看不到「咖啡因合并估计 0.99（0.92–1.07）」的精度几乎全靠 Nielsen 的 5 个工具，"
  "而 FinnGen 的单工具区间宽到 0.82–1.48。")
B("B2　正文称 \"AFGen 2018 estimates were likewise null for all exposures except sugar added to coffee\"。"
  "但 Table S2 第 103 行：咖啡对 AFGen 为 1.26（1.02–1.55），P = 0.031，是名义显著；图 2 的 AFGen 面板里咖啡那个三角也是实心的。"
  "同一段往后三句，作者自己又写 \"concordant in AFGen 2018 (OR 1.26; P = 0.031)\"。同一页内自相矛盾。")
B("B3　图 S1 图注承诺穷举，实际漏了两个。图注写 \"every exposure–source combination with a nominal IVW association "
  "in any current or legacy source\"，随后只列了四组。按本稿数据，咖啡对 Yuan 2025（1.79，P = 0.0022，全部 21 个配对里最强）"
  "与咖啡对 BioBank Japan（2.34，P = 0.016）都是名义显著，都没有留一法也没有漏斗图。"
  "要命的是作者随后正是用「去掉 FTO 与 TMEM18 后信号塌陷」来解释咖啡——这恰恰是留一法该先暴露的东西，"
  "而最强的、且来自无重叠来源的那个估计完全没做影响力诊断。")
B("B4　Table 4 的「No. SNPs」列混装了两种量。MVMR-IVW 一次拟合只有一个联合工具集，"
  "不可能同时用 467 个 SNP 估 BMI、用 14 个估咖啡。Table S24 说联合集 471 个（BMI 项用 467），"
  "S4 又说糖加茶的条件估计只有 1 个工具。表题列了三个暴露，表体只有两行，糖加茶整行缺失。"
  "读者无法从表里判断 467 与 14 是什么关系，而 467 支撑的 BMI 效应（OR 1.47，P = 2.0×10⁻²⁷）是全文阳性对照的唯一定量依据。")
B("B5　图 1 的「四个代理」与 Table S1 差一个数量级。图 1 写 \"the same index variants harmonised to every outcome panel "
  "(four proxies substituted for BioBank Japan)\"。实际 Table S1 的 BBJ 列相对欧洲索引集为 11/17、11/15、4/8、8/17、6/14、32/34、36/32，"
  "即五个亚表型缺 6、4、4、9、8 个，咖啡缺 2 个，合计 29 个配对缺失；而茶是 36 个，比欧洲侧的 32 个还多 4 个。"
  "单靠「替换代理」在算术上不可能变多。茶这一行需要作者说明，否则就是计数错误。")
B("B6　Table S19 有一个名义显著的合并估计没进结果段。跨两个 UKB 咖啡 GWAS 的固定效应合并是 1.23（1.04–1.44），P = 0.013，"
  "方向与咖啡正相关一致。正文只引了仅用 Neale 1498 的 1.18、P = 0.166。表注说该合并「仅供完整性、不作独立证据解读」，"
  "这一点可以接受；但「不作证据解读」和「完全不进正文」是两回事。一个与主结论同方向的名义显著估计只存在于补充材料，属于报告不完整。")
B("B7　图 S2 右侧标注被画布裁掉。可读到 \"+0.92 (int +0.0\" 与 \"+0.00 (int -0.31\"，标准误与右括号丢失。"
  "图注虽在文字里补了 −0.318（SE 0.011），但图面本身不完整，须重排留白。")
B("B8　Table S8 脚注印了本地目录路径，如 \"03_结果数据_mr_results/upgrade_coloc_*.csv\"、\"06_升级分析_v4/results/...\"。"
  "投稿版补充材料里出现作者硬盘结构，属不该出现的内容，改为 Zenodo 归档路径。")
B("B9　Table S27 脚注称「removed 3–19 variants per exposure」。实际最小是 2（气泡饮料 8→6），应为 2–19。")

H("2.3　C 类：表述校准（不改数据，改说法）", 2)
P("C1　「F > 20 所以工具够强」是循环论证，这一条最要紧", bold_prefix="")
P("方法学审稿人会一眼看出：双侧 P = 5×10⁻⁶ 对应 z = 4.5646，单变异 F = z² = 20.84。"
  "Table S22 报告的最小 F 是 20.8、20.9、20.9、21.0、21.7，全部紧贴这条由选择阈值本身决定的地板。"
  "换句话说，「所有 F 都超过 20」在这个阈值下不可能失败，它不含任何独立信息，只是把 P 阈值换了个写法。"
  "真正有信息量的是累计 R²：0.126%（气泡饮料）到 0.568%（低热量饮料）。"
  "这个数字配上 Table S12 的 MDE 1.21–1.53，说明这组工具对 OR 1.10 量级的功效只有 9%–29%。"
  "稿件在局限性里已经承认 \"F captures neither winner's curse nor correlated pleiotropy\"，但正文与摘要没把后果带出来。", indent=0.5)
P("改法：删掉 \"indicating strong instruments and limited weak-instrument bias\" 的因果措辞，"
  "改为「选择阈值决定的最小 F 为 20.8」，并直接报告累计 R² 与它对 NOME 假设的含义。", indent=0.5)

P("C2　阴性对照失败被处理成脚注，但它否掉的是主结果本身", bold_prefix="")
P("糖加茶对房室阻滞 β = −0.676（SE 0.209），OR 0.51，P = 0.0012，在九个检验的 Bonferroni 阈值 0.0056 下仍显著；"
  "加权中位数 −0.634（P = 0.024）、MR-Egger −1.369（P = 0.054）方向一致，所以不是离群位点造成的。"
  "更关键的是 Table S18 的表注自己承认：\"The coffee and sugar-in-tea estimates mirrored the direction and magnitude "
  "of their AF associations\"。糖加茶对 AF 的 β 是 −0.506，对房室阻滞是 −0.676，两个不同结局、同一套 16 个位点、几乎同一量级。"
  "这是非特异工具变量的典型指纹。", indent=0.5)
P("作者的处置只是加一句免责，然后照旧在摘要与 Highlights 里写 \"No genetic evidence that sweetened-beverage intake causes "
  "atrial fibrillation\"。这个不对称要被点破：如果糖加茶那 16 个位点不携带暴露特异信息，那么这一行对 AF 的零估计同样不携带信息，"
  "它既不能支持「无效应」，也不该与另外四行一起被数成五个零结果之一。建议的做法是把它标记为「工具变量非特异，估计不可解释」"
  "并从主结果计数中移出，同时在摘要与结论里写明。", indent=0.5)

P("C3　咖啡因亚组与脂肪剔除共享同一批位点，两条「互相印证」的证据线其实是一条", bold_prefix="")
P("Table S29 自己写明：三个咖啡因窗口位点全部落在 BMI 位点 500 kb 内，而剔除时这 3 个也一并被删。"
  "具体是 34 个咖啡工具 = 3 个咖啡因窗口 + 31 个其余，剔除 17 个 = 3（咖啡因）+ 14（其余）。"
  "于是「咖啡因通路工具为零、其余工具承载信号」与「去掉脂肪位点后信号收窄」不是两条独立证据，是同一批位点的两种切法。", indent=0.5)
P("而且「其余 31 个工具承载信号」这句没有做过差异检验。用 Table S4 报告的区间反推，Nielsen 两个亚组之差 z = 1.764、P = 0.078；"
  "FinnGen z = 1.258、P = 0.208。两个来源都不显著（我复算过）。所以这句应当降级为"
  "「三个咖啡因窗口位点在本次样本量下不足以检出 OR 1.53 以下的效应」，而不是「未检出咖啡因处理效应」。", indent=0.5)

P("C4　上界 1.01–1.17 与「不可换算」两句互相抵消", bold_prefix="")
P("摘要与结论各自承担了一半：「上界 1.01–1.17」暗示排除了较大效应，「观察性量级未被排除」又暗示没排除。"
  "逻辑上，若 per-category 增量与 high-vs-low 的 HR 不可换算，那么 1.17 这个数对 HR 1.10 就不构成任何约束，"
  "两句不能同时做功。更实质的问题是：这个上界不是设计属性，而是点估计恰好落在 1 以下的产物——"
  "糖加茶的 meta 点估计 0.82，上界自然是 1.01；若真值为 1.10，按 Table S12 的 MDE（meta 列 1.29–1.38），该研究的上界应在 1.35 附近。", indent=0.5)
P("改法二选一：删掉区间，改为「若真实 OR 为 1.10，本设计的 95% 上界约为 1.35」；或保留区间但明确写出它只在点估计低于 1 时成立。", indent=0.5)

P("C5　BMI 的条件 F = 7.46 被称「稳健」，与否定咖啡的 5.25 双标", bold_prefix="")
P("正文写 \"BMI retained a robust direct effect on AF (OR 1.47 per SD …), serving as a positive control\"，"
  "紧接着用「条件 F 低于 10、弱工具使多变量估计偏向零」否定咖啡的 0.82。两个判断用了同一套诊断，方向相反。"
  "BMI 的条件 F 是 7.46，同样低于 10。若 7.5 足以让咖啡不可信，它同样削弱 BMI 那一项；若不足以，就不能拿 5.2 否定咖啡。"
  "另需注意「弱工具使 MVMR 偏向零」这句在这批数据上不能直接套用：弱工具下 MVMR 偏向的是混杂的观察性关联，不是无条件偏向零。", indent=0.5)

P("C6　多重比较的族边界决定了结论", bold_prefix="")
P("咖啡在 7 检验族里以 P = 0.002 存活（阈值 0.0071）。若把四个欧洲结局 × 七个暴露 = 28 个 IVW 检验算作一族，"
  "咖啡 meta 的 P = 0.002 对阈值 0.0018 也不再存活（我复算过：28 检验族下没有任何一个检验通过）。"
  "反过来，房室阻滞的 P = 0.0012 被放进 9 检验族并宣布「通过校正」，而它所在的整体检验数远超 9。"
  "同一篇稿子里，P = 0.0012 被当作显著的对照失败，P = 0.014 被当作可忽略的噪声，判定依据不是统一阈值。", indent=0.5)
P("改法：为每张表指定所属族与校正方法并说明理由，附一张全部检验清单（原始 P、所属族、族内检验数、校正后 P），"
  "至少把 28 检验族作为敏感性分析报告一次。这不是要求改结论，是要求让读者看到边界在哪。", indent=0.5)

P("C7　阳性对照只到「边缘」，不能支撑「流程对目标量级有效」", bold_prefix="")
P("GSCAN 每周饮酒量在四个队列里单项全部不显著（1.16、1.12、1.29、2.25），只有把 Nielsen 与 FinnGen 固定效应合并才得到 "
  "1.19（1.01–1.40），P = 0.035，且未做多重比较校正（我复算得 1.192，1.014–1.403，与稿件一致）。"
  "换成位点更多、样本更大的摄入频率（97 个位点，N = 462,346）后，四个队列与合并估计全部为零（1.07，0.99–1.16）。"
  "换成更强的工具后已知的因果暴露反而测不出来，这提示问题可能在位点集而非样本量。", indent=0.5)
P("这篇稿子要否定的是 OR 1.10–1.20 量级的观察性关联，而阳性对照的校准结论恰恰是「该流程处于检出边缘」。"
  "这个结论应当进摘要，而不是留在补充材料。", indent=0.5)

P("C8　结论把东亚从「情境」提升为「人群证据」", bold_prefix="")
P("结论原句 \"showed no evidence of a causal association with atrial fibrillation in European or East Asian populations\"。"
  "但 Results 自己写 \"Given European-ancestry instruments, these estimates are context, not independent evidence\"；"
  "Clinical Perspective 也只写 \"an East Asian contextual analysis\"。"
  "8,180 例、欧洲来源工具、置信区间跨四倍（糖加茶 0.66，0.21–2.11；气泡饮料只有 4 个工具，0.35，0.06–2.05），"
  "用它支撑「在东亚人群中无因果」是明显外推。", indent=0.5)

P("C9　两处小数字", bold_prefix="")
P("(1) 正文称 \"Between-source heterogeneity was negligible except for sugar added to tea (I² = 67%; 0–3% for others)\"。"
  "我按 Table 2 反推复算，咖啡是 6.3%，不是 0–3%；其余五个确为 0%。糖加茶我算得 66.5%，与 67% 相符。"
  "(2) 正文两处称 Nielsen 比 AFGen \"nearly twice-larger\"。按病例数 60,620/55,114 = 1.10，只大 10%；"
  "按总样本 1,030,836/537,409 = 1.92 才接近两倍。对 AF 而言有信息量的是病例数，"
  "用总样本来支撑「信号在更大的结局中未复制」是偏乐观的表述，应写明是总样本。", indent=0.5)

# ============ 3 ============
H("3　编辑视角")

P("3.1　scope 与栏目", bold_prefix="")
P("JAHA 是 AHA 金色开源刊，收心血管流行病学与营养，本文落点没问题。真正贴合的入口有两个："
  "该刊 2025 年发过含糖饮料心血管负担的 APC 建模（ref 44，JAHA 2025;14(9):e035978），本文可定位为对该负担估计的因果检验；"
  "2026 年 AHA 咖啡因科学声明（ref 12）明确呼吁「区分咖啡因与共摄入成分」，本文的血浆代谢物臂正是对这一呼吁的直接回应。"
  "这两个入口都比奶茶硬。")

P("3.2　novelty 的实数", bold_prefix="")
P("桌面拒稿的主要风险不在方法，在「又是含糖饮料 + MR」。已有三篇正面撞车："
  "Xie 2024（ref 5，SSB→AF，OR 1.023）、Yuan & Larsson 2019（ref 4，咖啡→AF，null）、Li & Xu 2025（ref 6）。"
  "再加一篇本稿未引的 You 2026（Eur J Nutr，咖啡 OR 1.281）。", bold_prefix="")
P("真实的增量有三个：(1) Yuan 2025 这个无 UKB 的 192,851 例结局，是同期同类工作里唯一能甩开样本重叠的；"
  "(2) 脂肪量位点剔除把来源间跨度从 1.26–1.79 收到 1.26–1.39，并配了 2,000 次随机剔除的安慰剂检验（2.1%）；"
  "(3) FTO 共定位 PP.H4 = 0.894 而 CYP1A1–CYP1A2 / AHR 的 PP.H1 ≥ 0.93、PP.H4 ≤ 0.008，这个分离很干净。"
  "这三条合起来是一个方法学增量，不是结论增量。")

P("3.3　格式与硬性要求（已核实一手规则）", bold_prefix="")
rows = [
 ["项目", "JAHA 要求", "本稿", "判定"],
 ["原创研究正文字数", "无上限（文章类型表 Words 一栏为「—」）", "8,612 词（Introduction→Conclusions）", "合规，但约为常规两倍，会被要求压缩"],
 ["摘要", "≤250 词，须结构化 Background / Methods / Results / Conclusions", "181 词，三段式（Methods and Results 合并）", "合规"],
 ["Clinical Perspective", "≤250 词，每节不超过三条单句要点", "188 词，5 条要点", "合规，第二条含两句，可拆"],
 ["图表数量", "无上限", "主文 4 表 2 图", "合规"],
 ["初投稿格式", "明确允许「不完全按期刊标准格式」的初投", "—", "不构成拒稿理由"],
 ["必备声明", "Nonstandard Abbreviations、Author Contributions、Funding、Disclosures、Data Availability", "齐备", "合规"],
]
T(rows, widths=[2.8, 6.0, 4.2, 2.4])

P("这里要纠正一个常见误判：有意见认为「正文 7,000 余词超出 5,000 词上限约四成」。JAHA 对原创研究不设正文字数上限，"
  "5,000 词是 JACC 系刊的口径。但 8,612 词确实约为同类稿件两倍，讨论（1,776 词）与结果（4,146 词）几乎等长，"
  "同一组数字在后文重复三处，编辑大概率会要求压缩三成。这是「会被要求改」，不是「违规」。", bold_prefix="")

P("3.4　会在编辑手上被点名的五处", bold_prefix="")
B("标题 over-claim。标题写 \"A Two-Sample and Multivariable Mendelian Randomization Study\"，但 MVMR 三个暴露的条件 F 全部低于 10，"
  "糖加茶只有 1 个联合工具，作者自己把这一节定为「探索性」。以 Multivariable 入题却不在摘要给任何多变量结果，"
  "编辑会要求么改标题、么在摘要补一句 0.82（0.65–1.04）并注明条件 F < 10。")
B("署名顺序。作者行是 \"Cao Zezhong¹, Chen Rongrong¹\"，姓名顺序反了。西方刊应为 Zezhong Cao、Rongrong Chen，"
  "否则 PubMed 会索引成 \"Cao Z\"，后续引用与 ORCID 匹配都会出问题。通讯作者行、Cover Letter 落款同样要改。"
  "EM 系统的 Given / Family 分栏 README 已经提醒过，但手稿正文这一层漏了。")
B("伦理声明。稿件引《中国涉及人的生命科学和医学研究伦理审查办法》第三十二条作为豁免依据。"
  "这是中国法规，AHA 系统不认这条依据，审稿人会直接标红。改为「本研究仅使用公开去标识化的汇总统计，"
  "经所属机构伦理委员会判定无需审批」并给出机构名称或正式豁免编号。")
B("回避审稿人 Larsson 的理由要写清。她是 ref 4（咖啡→AF 的 MR）、ref 35、ref 36 的作者，"
  "同时是 ref 12 这篇 AHA 科学声明的第 7 作者。回避本身站得住（同题竞争者 + 既有相反结论），"
  "但她恰好是这篇稿子最内行的读者，编辑可能反过来问「你回避的是不是最该审你的人」。"
  "建议在投稿信里主动写明理由，并说明补引 You 2026 后不回避该组。")
B("统计审稿。JAHA 对 MR 与观察性研究会加送统计审稿。C1（F > 20 循环论证）与 C2（阴性对照失败）会被抓，"
  "与其等第二轮，不如第一轮就改掉。")

P("3.5　成本", bold_prefix="")
P("APC 约 3,810 美元，AHA/ASA 会员 2,200 美元；无投稿费；外审单盲。按 2025–2026 年数据，"
  "接收率约 28.5%、首次决定中位 18.5 天。这个周期对本文有利——它需要的是一次高质量修复，不是重做。")

# ============ 4 ============
H("4　与指南、共识、研究热点的对齐")

rows = [
 ["文件", "与本稿的关系", "建议用法"],
 ["2024 ESC 房颤指南（ref 1）", "把酒精、肥胖、血压列为可干预因素，未把含糖饮料列为危险因素",
  "可用作「含糖饮料尚未进入指南证据链」的论据，比用作「公共卫生优先事项」的背景更准确"],
 ["2023 ACC/AHA/ACCP/HRS 房颤指南（ref 42）", "对咖啡因给出 Class 3（不劝患者为防复发而戒咖啡）",
  "与本文咖啡无稳健效应的结论互补；注意本文是 incident AF，指南是复发，估计量不同，稿件已写明，保持"],
 ["2026 AHA 咖啡因科学声明（ref 12）", "已独立核实：Circulation 2026;154(9):e345–e355，2026-07-20 上线，Marcus 任主席，Larsson 为第 7 作者",
  "声明明确呼吁「区分咖啡因与共摄入成分」。这是本稿最好的 Introduction 锚点，现在被埋在讨论里"],
 ["SSB 归因心血管负担（ref 44，JAHA 2025）", "同刊前作，给的是归因负担而非因果",
  "可在 Cover Letter 里做成「同刊对话」，比强调奶茶更有说服力"],
]
T(rows, widths=[3.9, 6.3, 5.4])

P("关于「没人做过奶茶」这个前提，我做了检索，结论是好消息：",
  bold_prefix="")
P("截至 2026 年 10 月，没有检索到以奶茶/珍珠奶茶为暴露、房颤为结局的前瞻队列，也没有把奶茶单独工具化的 GWAS。"
  "2026 年 4 月有一篇 Ayurveda 视角的奶茶综述（Int J Drug Deliv Technol），2026 年 Medscape 有一篇珍珠奶茶与 MASLD 的评论，"
  "两者都明确写着「奶茶本身尚未在大型前瞻队列中被单独研究」。所以稿件「no prospective cohort that directly measured milk tea "
  "consumption in relation to AF」这句目前站得住。", indent=0.5)
P("但窗口在收窄。这个空白正在被公开讨论，一旦有人做出奶茶的 GWAS 或队列，这条前提就没了。"
  "这也意味着：把稿件的价值押在「第一个提奶茶」上是脆的，押在「脂肪量多效性可以解释已发表的阳性 MR」上是稳的。", indent=0.5)

# ============ 5 ============
H("5　文献核验")

P("机械核验（脚本跑全文，含表格）：46 条参考文献，正文引用编号覆盖 1–46，无悬空、无越界。这一点是干净的。", bold_prefix="")
P("抽验出版信息：ref 12 我独立核实（DOI 10.1161/CIR.0000000000001454，Circulation 2026;154(9):e345–e355，卷期页与作者序均对）；"
  "ref 11（DECAF，JAMA 2026;335(4):317-325，DOI 10.1001/jama.2025.21056）、ref 17（Nat Commun 2025;16:6426）、"
  "ref 39（Eur Heart J 2025;46(36):3546-3554）、ref 44（JAHA 2025;14(9):e035978）经 DOI 核对存在且卷页相符。"
  "ref 5 的 AF 结局 3,818 例（333,381 对照）已核实，稿件转述准确。", bold_prefix="")

P("缺一条关键文献（必须补）", bold_prefix="")
P("You X, Guo W, Huang K, Zhong C, Yang L, Jiang Q. Association between genetically predicted dietary patterns and "
  "atrial fibrillation: a two sample Mendelian randomization study. Eur J Nutr. 2026;65:95. "
  "doi:10.1007/s00394-026-03944-6（2026-03-17 上线，苏州大学附属第三医院心内科）。", indent=0.5)
P("该文测了 20 种膳食习惯对 AF 的因果效应，咖啡 OR 1.281（95% CI 1.036–1.583），P = 0.022，并在 UKB 中做了重复。"
  "这与本稿 Nielsen 的 1.26（1.02–1.57）几乎重合。它带来两个后果：", indent=0.5)
P("一，本稿「遗传证据一致指向无害」的框架已经过时。现在有两篇 MR 给出正向估计，不是「我们的结果不足以推翻共识」，"
  "而是「共识正在移动，而我们能解释它为什么移动」。", indent=0.5)
P("二，补引之后这篇稿子反而变强。因为 You 等只报了阳性估计、没有做脂肪量解构；本稿的 FTO 共定位（PP.H4 = 0.894）、"
  "TMEM18 与 FTO 两个最大 Wald 比的移除、以及剔除后来源间跨度收窄，正好给那个阳性估计提供了机制解释。"
  "这是一条现成的、更强的叙事线。", indent=0.5)

P("两条待作者自查（我未能证实，不作断言）", bold_prefix="")
P("(1) Table S10 脚注称「sugar added to tea 与 artificial sweetener added to tea 的全量统计未公开，故无法做 LDSC」。"
  "Neale lab UKB round-2 发布覆盖约 4,000 个表型，含多个 PHESANT 膳食字段。请核实这两个字段是否确实不在其中。"
  "若在，这两个表型的 LDSC 是可以做的，而审稿人一定会问「为什么七个表型只做了五个」。", indent=0.5)
P("(2) 正文称 FTO rs1421085 与 TMEM18 rs13387939 是「对 Yuan 2025 的 AF 单个 Wald 比最大的两个变异（OR 9.95 与 10.67）」。"
  "补充材料里没有任何一张表支撑这两个数。这句不可核验，建议补一张逐变异 Wald 比表，或删掉具体数值。", indent=0.5)

# ============ 6 ============
H("6　修改优先级")

P("第一步：不补任何数据，1–2 天可完成，全部是改文本与图", bold_prefix="")
B("改 A1 摘要方向；改 C8 删掉东亚的人群断言；把阴性对照失败写进摘要 Conclusions 与 Highlights（C2）。")
B("补引 You 2026，并把 Discussion 的咖啡段从「不足以推翻共识」改写为「解释已发表的正向估计」（第 5 节）。")
B("修 B1（图 2 的 n.e.）、B2（AFGen 那句）、B7（图 S2 裁切）、B8（本地路径）、B9（2–19）。")
B("改作者姓名顺序、伦理声明口径、标题是否保留 Multivariable。")

P("第二步：有现成数据，重跑一次即可", bold_prefix="")
B("B3 补咖啡对 Yuan 2025 的留一法与漏斗图（数据在手，这是全稿最强估计，没有影响力诊断说不过去）。")
B("C3 给两个咖啡因亚组做正式的差值检验并报告（我算得 P = 0.078 / 0.208，两个来源都不显著，作者自己算一遍写进去，比被审稿人算出来好）。")
B("B4 把 Table 4 的 SNP 列拆成「联合集 471 / 暴露特异 n」两列，补糖加茶一行并标注「仅 1 个联合工具，不可解释」，或把表题改成两暴露模型。")
B("B5 按暴露逐一给 BBJ 的保留、缺失、代理数，并解释茶为何是 36。")

P("第三步：需要新分析，但都在现有管线上", bold_prefix="")
B("C1 把「F > 20」改成对累计 R² 的如实描述，并补一个定量偏倚陈述（winner's curse 下的期望膨胀）。")
B("C6 附一张全部检验清单与族划分，把 28 检验族作为敏感性分析报告一次。")
B("C5 用 coffee + BMI 的两暴露 MVMR 重估（这个模型可识别），替代现在的三暴露模型。")
B("补一张逐 SNP 工具变量表（rsID、最近基因、EAF、β、SE、P、F、是否落在 BMI 位点 500 kb 内）。"
  "现在全文只出现过 6 个 rsID。把「五个亚表型能否被工具化」当核心问题的稿件，不给工具清单是无法核查的状态。")

P("明确不必做的事", bold_prefix="")
B("不要为了「合规」砍到 5,000 词。JAHA 没有这条上限。要砍是为了可读性，砍讨论里的重复段，不是为了凑数。")
B("不要把 Table 4 整表删掉。它是标题的一部分，删了就坐实标题 over-claim；改成可识别的两暴露模型更好。")
B("不要放弃奶茶这个动机。前提目前仍然成立，只是别把它放在标题与摘要首句的位置，改成「成分替代设计的方法学界限」的例证。")

# ============ 7 ============
H("7　复核为无误，不要动")

P("以下是我独立验过、确认正确的地方。改稿时不要顺手把它们改坏——补丁式改稿最常见的损伤就是把对的地方一起动了。")
rows = [
 ["项目", "我的复算", "判定"],
 ["欧洲 meta（七个暴露）", "由 Table 2 的 OR 与 CI 反推 SE 后重算，0.82/0.88/0.94/0.97/0.93/1.34/0.90，逐格相符", "无误"],
 ["糖加茶 I²", "66.5%，随机效应 0.764（0.510–1.143）", "与 67%、0.77（0.51–1.15）相符"],
 ["咖啡 I²", "6.3%", "稿件写的 0–3% 偏低，见 C9"],
 ["BH（7 检验族）", "阈值 0.0071，仅咖啡 P = 0.002 通过", "无误"],
 ["酒精阳性对照", "固定效应 1.192（1.014–1.403）", "与 1.19（1.01–1.40）相符"],
 ["摘要词数", "181 词（去栏目标签 176）", "合规"],
 ["Clinical Perspective", "188 词，5 条要点", "合规"],
 ["参考文献闭合", "46 条，覆盖 1–46，无悬空无越界", "无误"],
 ["SNP 计数闭环", "Table 2 的 17/15/8/17/14/34/32 与 S1、S22、S26 对齐；137 配对 / 133 唯一 / Yuan 128（96%）", "无误"],
 ["糖加茶在 FinnGen 的 0.60", "Table S2 与图 2 一致，实心方框", "无误"],
 ["Yuan 咖啡 1.79", "Table S2 与图 2 一致，实心菱形", "无误"],
 ["剔除后三个估计", "1.39（1.04–1.86）、1.39（0.94–2.04）、1.26（0.90–1.75）", "正文、摘要、S27 三处一致"],
]
T(rows, widths=[3.4, 7.8, 4.4])

# ============ 8 ============
H("8　一个必须处理的不利判断")

P("这篇稿子目前最大的问题不是缺陷数量，是叙事重心错位。"
  "它花了大量篇幅证明自己「没做什么」——没做奶茶、成分替代不能外推、MVMR 是探索性的、中介不可解释、阴性对照失败、"
  "重叠没校正、工具变量阈值宽松。这些披露本身是诚实的，值得肯定。但累积起来给编辑的印象是：作者自己也不确定这些数据能说什么。")

P("而数据其实能说一件很清楚的事：", bold_prefix="")
P("含糖饮料与咖啡的行为学工具变量，其与房颤的关联主要由脂肪量位点承载。"
  "证据是三条互相独立的线：(1) 剔除 724 个 BMI 位点 ±500 kb 内的工具后，七个暴露的点估计几乎全部向 1 收缩"
  "（气泡饮料 0.91→1.01、糖加咖啡 0.89→0.98、糖加茶 0.91→1.03、低热量 0.99→1.00），咖啡在三个来源里两个向 1 收缩；"
  "(2) FTO 共定位 PP.H4 = 0.894（FinnGen 0.906），而两个咖啡因代谢位点 PP.H1 ≥ 0.93、PP.H4 ≤ 0.008；"
  "(3) FTO rs1421085 与 TMEM18 rs13387939 是单个效应最大的两个变异。"
  "第 (1) 条我在 Table S27 里逐行核过，方向是一致的，而稿件只把它当作「稳健性检验」，没有把它当作结论。", indent=0.5)

P("这个重构会同时解决三件事：把标题与摘要从「我们没做奶茶」变成「我们解释了别人为什么做出阳性」；"
  "让 8,612 词的篇幅有落点；也让 JAHA 有一个明确的、可被引用的方法学贡献，而不只是一份校准良好的阴性报告。"
  "代价是 Discussion 要重写三分之二，Introduction 要换掉奶茶的框架。这是改稿里最费力的一步，也是最值的一步。")

doc.add_paragraph()
foot = doc.add_paragraph()
r = foot.add_run("本报告的复算脚本与中间结果存放于 C:\\a3work\\nmr\\（verify.py、verify2.py、long_paras.txt）。"
                 "凡标注「已独立核实」的条目为本人复算或一手核对；标注「待作者自查」的为未能证实，不作断言。")
r.font.size = Pt(8.5); r.italic = True; r.font.color.rgb = RGBColor(0x66,0x66,0x66)

doc.save(OUT)
print("saved", OUT, os.path.getsize(OUT))
