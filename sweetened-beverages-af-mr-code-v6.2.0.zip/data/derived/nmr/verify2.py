# -*- coding: utf-8 -*-
import re, sys, os
import docx

SRC = r"C:\Users\64915\Desktop\JAHA投稿包_奶茶房颤MR_20261013"

def flat(path):
    d = docx.Document(path)
    from docx.table import Table
    from docx.text.paragraph import Paragraph
    out=[]
    for child in d.element.body.iterchildren():
        if child.tag.endswith('}p'):
            out.append(Paragraph(child,d).text)
        elif child.tag.endswith('}tbl'):
            tb=Table(child,d)
            for row in tb.rows:
                seen=set(); cs=[]
                for c in row.cells:
                    if id(c._tc) in seen: continue
                    seen.add(id(c._tc)); cs.append(c.text)
                out.append(" | ".join(cs))
    return out, d

paras, doc = flat(os.path.join(SRC,"Manuscript.docx"))
text = "\n".join(paras)

print("="*72)
print("1. 主稿词数（分段）")
# locate section boundaries
idx = {}
for i,p in enumerate(paras):
    s = p.strip()
    for k in ["Abstract","Introduction","Methods","Results","Discussion","Conclusions","References","Tables","Figure legends","Declarations"]:
        if s == k and k not in idx:
            idx[k]=i
print("   段落数:", len(paras), " 章节定位:", idx)

def wc(a,b):
    return len(re.findall(r"\S+", " ".join(paras[a:b])))

if "Introduction" in idx and "References" in idx:
    print("   Introduction→Conclusions 词数:", wc(idx["Introduction"], idx["References"]))
    for k in ["Introduction","Methods","Results","Discussion"]:
        nxt = {"Introduction":"Methods","Methods":"Results","Results":"Discussion","Discussion":"Conclusions"}[k]
        print(f"   {k:14s}: {wc(idx[k], idx[nxt])}")

print()
print("="*72)
print("2. 摘要词数")
a0 = idx.get("Abstract",0)+1
a1 = idx.get("Introduction",10)
ab = " ".join(paras[a0:a1])
print("   含栏目标签:", len(re.findall(r"\S+", ab)))
ab2 = re.sub(r"^(Background|Methods and Results|Conclusions)\s*:\s*", "", ab, flags=re.M)
print("   不含栏目标签:", len(re.findall(r"\S+", ab2)))

print()
print("="*72)
print("3. Clinical Perspective 词数（JAHA 限 250）")
try:
    c0 = next(i for i,p in enumerate(paras) if p.strip()=="Clinical Perspective")
    c1 = next(i for i,p in enumerate(paras) if p.strip()=="Introduction")
    cp = [p for p in paras[c0:c1] if p.strip()]
    print("   总词数:", len(re.findall(r"\S+"," ".join(cp))))
    print("   条目数:", sum(1 for p in cp if p.strip().startswith("•")))
    for p in cp:
        print("     -", p[:70], "...", len(re.findall(r"\S+",p)), "词")
except StopIteration:
    print("   未定位")

print()
print("="*72)
print("4. 'milk tea' / 'bubble tea' 分布")
for term in ["milk tea","bubble tea","Milk tea"]:
    print(f"   {term}: 主稿 {len(re.findall(term, text))} 次")
# 按章节
sect=[]
cur="Title"
for p in paras:
    if p.strip() in ("Introduction","Methods","Results","Discussion","Conclusions","Abstract"):
        cur=p.strip()
    if "milk tea" in p or "bubble" in p:
        sect.append(cur)
from collections import Counter
print("   出现章节:", Counter(sect))

print()
print("="*72)
print("5. 参考文献引用闭合")
body = "\n".join(paras[:idx["References"]])
cited = set()
for m in re.finditer(r"\[([0-9,\s\-–]+)\]", body):
    s=m.group(1)
    for part in re.split(r",", s):
        part=part.strip()
        if re.match(r"^\d+\s*[–\-]\s*\d+$", part):
            a,bp = re.split(r"[–\-]", part)
            for k in range(int(a), int(bp)+1): cited.add(k)
        elif part.isdigit():
            cited.add(int(part))
refs = [p for p in paras[idx["References"]:] if re.match(r"^\d+\.\s", p.strip())]
nref = len(refs)
print("   参考文献条数:", nref)
print("   正文引用编号范围:", min(cited), "-", max(cited), " 共", len(cited), "个不同编号")
missing = [k for k in range(1,nref+1) if k not in cited]
extra = sorted(k for k in cited if k>nref or k<1)
print("   未被引用的编号:", missing)
print("   越界引用:", extra)

print()
print("="*72)
print("6. docx 核心属性（闸门12）")
for f in ["Manuscript.docx","Supplement.docx","Highlights.docx","Cover_Letter.docx"]:
    d=docx.Document(os.path.join(SRC,f)); cp=d.core_properties
    print(f"   {f}: author={cp.author!r} last_modified_by={cp.last_modified_by!r}")
    print(f"       title={cp.title!r} subject={cp.subject!r} comments={cp.comments!r} keywords={cp.keywords!r}")

print()
print("="*72)
print("7. 页眉页脚")
import zipfile
for f in ["Manuscript.docx","Supplement.docx"]:
    z=zipfile.ZipFile(os.path.join(SRC,f))
    hf=[n for n in z.namelist() if re.search(r"word/(header|footer)\d*\.xml", n)]
    print(f"   {f}: {hf if hf else '无'}")

print()
print("="*72)
print("8. 作者行与姓名顺序")
for p in paras[:12]:
    if p.strip(): print("   |", p.strip()[:120])

print()
print("="*72)
print("9. 关键数字多处一致性抽查")
checks = {
 "1.26 (0.90–1.75)": "coffee Yuan after exclusion",
 "1.39 (1.04–1.86)": "coffee Nielsen after exclusion",
 "1.39 (0.94–2.04)": "coffee FinnGen after exclusion",
 "0.82–0.97": "abstract meta range",
 "1.01 to 1.17": "upper bounds",
 "192,851": "Yuan cases",
 "60,620": "Nielsen cases",
 "67,783": "FinnGen cases",
 "8,180": "BBJ cases",
}
for k,v in checks.items():
    print(f"   {k!r} ({v}): 主稿 {text.count(k)} 次")
