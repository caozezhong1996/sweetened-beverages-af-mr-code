# -*- coding: utf-8 -*-
"""验算：正文所称 between-source I²=67%（糖加茶）是否成立。"""
import math

# 表 2 的 Nielsen 与 FinnGen 列（OR, lo, hi）
tab2 = {
    "Sugar added to tea":      ((0.91, 0.72, 1.17), (0.60, 0.40, 0.90)),
    "Sugar added to coffee":   ((0.89, 0.70, 1.13), (0.88, 0.59, 1.31)),
    "Fizzy drink (SSB)":       ((0.91, 0.67, 1.22), (0.98, 0.70, 1.37)),
    "Low-calorie (ASB)":       ((0.99, 0.86, 1.13), (0.94, 0.81, 1.09)),
    "Sweetener added to tea":  ((0.91, 0.72, 1.14), (0.96, 0.72, 1.28)),
    "Coffee intake":           ((1.26, 1.02, 1.57), (1.58, 1.09, 2.29)),
    "Tea intake":              ((0.90, 0.72, 1.14), (0.88, 0.60, 1.28)),
}

Z = 1.959963985


def se_from_ci(lo, hi):
    return (math.log(hi) - math.log(lo)) / (2 * Z)


print("%-24s %9s %9s %8s %7s %8s" % ("exposure", "Q(df=1)", "I2(%)", "tau2", "P", "同向?"))
print("-" * 70)
for name, (a, b) in tab2.items():
    l1, s1 = math.log(a[0]), se_from_ci(a[1], a[2])
    l2, s2 = math.log(b[0]), se_from_ci(b[1], b[2])
    w1, w2 = 1 / s1 ** 2, 1 / s2 ** 2
    mu = (w1 * l1 + w2 * l2) / (w1 + w2)
    Q = w1 * (l1 - mu) ** 2 + w2 * (l2 - mu) ** 2
    df = 1
    I2_dl = max(0.0, (Q - df) / Q) * 100 if Q > 0 else 0.0
    # DerSimonian-Laird tau^2
    C = w1 + w2 - (w1 ** 2 + w2 ** 2) / (w1 + w2)
    tau2 = max(0.0, (Q - df) / C)
    # 反向 chi2(1) 的 p
    from math import erfc, sqrt
    p = erfc(sqrt(Q / 2)) if Q > 0 else 1.0
    same = "是" if l1 * l2 > 0 else "否"
    print("%-24s %9.4f %9.1f %8.4f %7.3f %8s" % (name, Q, I2_dl, tau2, p, same))

print()
print("正文 P052 与表 2 脚注均称：between-source I² 在糖加茶为 67%，其余 0–6%。")
print("上表显示：所有暴露的 between-source Q 均 < 1（df=1），I² 按定义应为 0。")
print()
print("对照：within-source（between-instrument）I² —— 由原始 dat_*.csv 重算")
print("  Tea intake × Nielsen    Q=93.47 df=31 → I² = %.1f%%" % ((93.47 - 31) / 93.47 * 100))
print("  Tea intake × FinnGen    Q=149.83 df=31 → I² = %.1f%%" % ((149.83 - 31) / 149.83 * 100))
print("  Sugar tea × Nielsen     Q=31.5  df=16 → I² = %.1f%%" % ((31.5 - 16) / 31.5 * 100))
print("  Sugar tea × FinnGen     Q=51.1  df=15 → I² = %.1f%%" % ((51.1 - 15) / 51.1 * 100))
