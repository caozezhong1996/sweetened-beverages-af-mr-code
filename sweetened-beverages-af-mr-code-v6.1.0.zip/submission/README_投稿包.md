# 投稿包 · 奶茶房颤 MR（JAHA）

目标期刊：**Journal of the American Heart Association (JAHA)** — AHA 金色开源刊
投稿系统：https://jaha-submit.aha-journals.org

本文件夹只放要上传的文件。版本沿革、旧版图件与校验记录在归档夹：
`桌面\投稿归档_奶茶房颤MR_EJPC+EHJOpen_旧版\`

## 文件与上传类目

| 文件 | 内容 | 上传类目（EM 系统） |
|---|---|---|
| `Cover_Letter.docx` | 投稿信 | Cover Letter |
| `Manuscript.docx` | 手稿（摘要 **235** 词；Clinical Perspective **167** 词（含标题）；**61** 条参考文献；4 张表；正文 **8,092** 词；总词数 **12,386**） | Manuscript |
| `Supplement.docx` | 在线补充材料（表 S1–S31，34 个表对象；含完整 STROBE-MR 与 404 行逐变异表） | Supplemental Material |
| `Highlights.docx` | Highlights（5 条） | Highlights / Other |
| `figures/Figure1_Study_Design.png` | 图 1 · 研究设计 v59（17.40 × 18.03 cm，600 dpi） | Figure 1 |
| `figures/Figure2_Forest.png` | 图 2 · 主结果森林图 v57，6 面板（17.40 × 15.60 cm，600 dpi） | Figure 2 |
| `figures/FigureS1_LOO_Funnel.png` | 补充图 S1 · LOO + 漏斗 v55（17.40 × 23.00 cm，600 dpi） | Supplemental Figure |
| `figures/FigureS2_LDSC_rg.png` | 补充图 S2 · LDSC 森林 v55（17.40 × 7.60 cm，600 dpi） | Supplemental Figure |
| `figures/Graphical_Abstract.png` | 图文摘要 v66（12.50 × 17.99 cm，300 dpi） | Graphical Abstract |

Figure 1/2 与两张补充图统一按 **17.40 cm 宽**设计（= AHA 双栏上限 7 in），按双栏全宽插入 k≈1.02。
脚本实际最小字号为 GA 6.2 pt、Figure 2 7.4 pt、Figure S2 7.8 pt；低于 AHA Figure Guidelines
建议的 8–10 pt，需在录用阶段按版面重绘（初投稿允许不按期刊格式）。

Table 2 为 **6 列**（primary + 两个 replication + meta + SNPs）；AFGen 与 BioBank Japan 的完整估计在 Table S2。
主图与表已用 LibreOffice 渲染成 PDF 逐页目检。2026-11-22 补材分页修复后，36 页 Supplement 中 STROBE-MR 与 Table S30 的全部行均已禁止跨页断行，原 6 处断行均消除；三遍复核未见内容越界、乱码、孤立续句或新增跨页断行。

## 本稿要点（2026-11-01 证据校准定稿）

定位：**已发表的咖啡–房颤阳性遗传信号，更兼容脂肪相关多效性，而非咖啡因特异通路；两种通路均未被完全排除**。
昵称「奶茶」只作动机，不作暴露；真实暴露是 UK Biobank 的甜味饮料消费表型。

- **标题（15 词，含副标题；短题 Short title：FTO pleiotropy in the coffee–AF signal（38 字符））**：`Pleiotropy at the FTO Locus in the Coffee–Atrial Fibrillation Signal: A Two-Sample Mendelian Randomization Study`
  （2026-10-31 已删去 "and Multivariable"：摘要无 MVMR 数字，条件 F 全 < 10，标题不宜承诺 MVMR 为主方法。
  2026-11-01 又由 "Adiposity-Linked Pleiotropy in the…" 改为 "Pleiotropy at the FTO Locus in the…"：三位模拟审稿人一致指出 FTO 共定位仅单一位点、严格先验 PP.H4 降至 0.457/0.491、未做 BMI 条件化共定位、MVMR 条件 F < 10，不足以把机制钉在脂肪上；题目改为「FTO 位点的多效性」，机制归属留在摘要与讨论作解释性表述。）
- **主证据排序（按对功效的依赖程度降序）**：
  1. **FTO 共定位 PP.H4 = 0.894（Nielsen）、0.906（FinnGen R13），但较小的 AFGen 面板仅 0.362**；CYP1A1–CYP1A2 与 AHR 的 PP.H1 ≥ 0.93、PP.H4 ≤ 0.008；茶在同样三位点重复出同一分离（S21）。这条不要求全暴露 MR 估计显著，但仍受区域关联强度、SNP 覆盖、LD 对齐、模型假设和先验影响，是全文权重最高的一环。
  2. 单变异层面：FTO rs1421085 与 TMEM18 rs13387939 的 Wald 比跨源为 4.86–19.66 与 9.23–32.06（per-SNP F 127.2 / 59.9，是强工具）——比值精度不低而量级生物学上不可能，指向排他性假设在这两个位点失效（S30）。
  3. 咖啡因窗口工具为零、其余工具承载信号。
  4. 脂肪位点剔除（最弱一环，已如实降级）：剔除前三源在零协方差近似下两两不可区分（Q = 1.03，df 2，P = 0.60）；剔除后 1.26–1.39，仅点估计范围收窄，不作机制收敛证据。
- **ASB 定位（2026-10-31 新增；2026-11-22 校准为 beverage-wide 辅助贡献，不改变其预设检验地位）**：低热量饮料是本文唯一「观察性有关联、遗传学无估计」的暴露。编辑主线仍为咖啡–AF 信号的 FTO 位点级拆解。
  - 事实：PubMed（宽式 / 全 tiab 严格式）与 Europe PMC（含 preprint）三轮检索一致——**SSB–AF 的 MR 共 1 篇，ASB–AF 的 MR 共 0 篇**；奶茶–AF 为 0 篇。
  - 四条支撑：累积 R² 0.568%（七个暴露中最高）、MDE 1.15（最小）、rg 0.313（十对中最强）、观察性 HR 1.20（强于 SSB 的 1.10）。
  - 措辞纪律：一律写 `ASB intake has not been examined by Mendelian randomization`，**不写 "ASB 未被遗传学检验"**——Kong 2025（*Toxicol Appl Pharmacol* 505:117580）用 MR 检验的是阿斯巴甜靶点 OXTR 蛋白，不是 ASB 摄入。
- **如实披露，不藏**：
  - 三源咖啡在零协方差近似下的两两差异 P = 0.31–0.81，故「跨度收窄」是点估计变化，不是向共同值收敛。
  - 剔除脂肪位点后 Yuan 中 ASB 1.04→**1.13（0.99–1.28，P = 0.062）**、代糖加茶 1.03→1.33（0.99–1.78，P = 0.057），方向与「脂肪量解释一切」相反，正文与投稿信均正面写出。
- **上界陈述**：若真值 OR 1.10，按观测 SE 的 95% 上界应 1.21–1.38；观测到的 1.01–1.17 只因点估计 ≤ 1。摘要、Clinical Perspective、Results、Discussion、Conclusions 五处统一。
- **F 值陈述**：P<5×10⁻⁶ → F 地板 20.84，P<5×10⁻⁸ → 29.71；观测最小 F 正贴地板，故「F>20 说明工具强」改为「由阈值决定，不含独立证据」，强度改用累计 R² 0.126%–0.568%。
- **阴性对照**：糖加茶对房室阻滞 β = −0.676 对其 AF 的 β = −0.506，同一批 16 个位点、量级相仿，故该暴露的 AF 零估计判为「不可解释」；四源面板中气泡饮、低热量饮、代糖加茶无显著异质性；纳入 Yuan 后，气泡饮与代糖加茶仍有显著异质性（Q P = 0.026、<0.001），故五源口径下只有低热量饮保留该性质；糖加茶另因阴性对照失败而不可解释。
- **参考文献**：**61** 条；最终已按 AHA 要求依首次出现顺序编号，并对多作者文献采用前 10 位作者后 et al.。关键最终编号：ref 14=2026 咖啡–AF meta，15=2026 UKB 咖啡/茶前瞻队列，22=Yuan 原文，23=Yuan Author Correction，44=JAHA 左房指标与 BMI–AF。61 条均完成 PubMed/DOI 元数据核验，无 Critical/Major 问题。
- **茶的异质性（2026-10-31 补）**：between-source 异质性仅糖加茶较高（I² = 67%，Q = 2.98，df 1，P = 0.084），其余 0–6%；但 **within-source 异质性对茶极大**（Nielsen Q P = 3.5×10⁻⁸、I² 66.8%；FinnGen 1.6×10⁻¹⁷、I² 79.3%），单变异 Wald 比方向几乎对半（15 正/17 负、14 正/18 负）。故茶的零是**方向抵消**而非精确的零，已明确不计入"可解释的零"。糖加茶与糖加咖啡也有轻度 within-source 异质（Q P = 0.011、0.018），已在 Limitations 一并说明。
- **FTO 的双重身份（2026-10-31 补）**：FTO 亦是 m6A 去甲基化酶，小鼠证据显示 Fto 经 Kcne1、Lox 去甲基化影响房颤（Aging Cell 2025;24(12):e70263；Europace 2026;28(4):euag047）。辩护要点：rs1421085 的脂肪效应已归因于 IRX3/IRX5 调控（Claussnitzer 2015），但 FTO 表达效应不能排除，也未做 FTO eQTL 共定位；故脂肪解释仅为**更简约的解释**，m6A 成分仍有可能。已写入 Discussion。
- **Yuan 2025 的 Author Correction（2026-10-31 查清）**：2025-10-03 的更正把欧洲病例数 **117,905 → 192,851**、跨人群病例数 **168,007 → 252,438**（DOI 10.1038/s41467-025-64765-5）。本稿用的 192,851 是**更正后**数值，正文已写明这一沿革——这也解释了此前 192,851 / 252,438 / 168,007 / 117,905 四个数字的关系。
- **数据版本**：Yuan 2025 用 GCST90624413（8 个发现队列，192,851 例，排除 UKB）；含 UKB 的欧洲 meta 为 GCST90624412（228,926 例），因暴露–结局重叠未使用。
- **作者姓名与学位**：Zezhong Cao, MD；Rongrong Chen, MD（正文、通讯行、Cover Letter、Author Contributions 一致）。

## JAHA 政策要点

- **原创研究无正文字数硬上限**（官方文章类型表里 Words 一栏为 "—"），**摘要硬上限 250 词且须结构化**。本稿摘要 235 词。
- **初投稿不要求格式合规**：可传单个 PDF 或分散文件，系统自动合并；格式细节在修回/录用阶段执行。
- **必备结构已内置**：结构化摘要、Nonstandard Abbreviations and Acronyms、Clinical Perspective（What Is New? / What Are the Clinical Implications?）、Author Contributions、Sources of Funding、Disclosures、Data Availability。
- **APC**：约 $3,700–3,810（AHA 会员约 $2,200），以投稿时官网为准。
- 可建议/回避审稿人。**建议**将 Susanna C. Larsson 列入 excluded reviewers（理由须在信中写明，现 Cover Letter 已写）。
- Clinical Trial Registration：不适用（公开汇总数据 MR）。
- **伦理**：采用 "not applicable" 版（数据为公开去标识化汇总统计，无个体记录、无受试者接触），不引中国法规条文。

## 填写提醒

- EM 系统通讯作者：**Given name = Zezhong，Family name = Cao**（上次 Elsevier 系统把名重复成 "Cao Zezhong Zezhong"，逐栏核对）。
- 标题：`Pleiotropy at the FTO Locus in the Coffee–Atrial Fibrillation Signal: A Two-Sample Mendelian Randomization Study`
- ORCID：0000-0002-8949-6078；共同作者 Chen Rongrong（chenrrxh@126.com）。
- 数据与代码：概念 DOI 10.5281/zenodo.22099675；**当前公开版 v6.0.0**（版本 DOI **10.5281/zenodo.24347377**，2026-11-19 发布，已确认概念 DOI 指向新版且 v6.0.0 标签源归档包含发布时候选 ZIP）。**2026-11-22 补材分页修复版尚未公开发布**；公开 v6.0.0 的 Supplement 仍含本轮已修复的 6 处跨页断行。

## 上传前检查

- [ ] EM 里作者姓名栏逐项核对（Given / Family 分开）
- [ ] 填写 excluded reviewer（Larsson）
- [ ] 投稿类型选 Original Research，4 张图按 Figure 1/2 + Supplemental Figure 1/2 分派
- [ ] 图文摘要用 v66（2026-11-22）：候选 FTO 共定位框移至左侧第一发现位，甜饮料框移至右侧；v65 原源码基线复现与旧成品差异为 0 像素，v66 的文字、数字、字体、各框配色、布局和画布均不变
- [ ] 图 1 用 v59（2026-11-15）：结局病例数标注不变，主标题加入 locus-level pleiotropy，精简方法清单；数据、阈值、布局、配色与画布尺寸不变
- [x] Zenodo 已发布 **v6.0.0 / 10.5281/zenodo.24347377**（2026-11-19）；其科学内容、S1–S31、逐变异数据及代码与当前稿一致，但 Supplement 为分页修复前版本
- [ ] 将 2026-11-22 分页修复＋叙事层级校准版发布为新 GitHub Release / Zenodo 版本；概念 DOI 不变，主稿、投稿信与补材无需写入新版本 DOI
- [ ] 第二轮模拟审稿修订（2026-11-14）：补材 STROBE-MR 清单改为转述当前三分法（原引号引述的 four of the five 与正文 three 冲突）；ref 30 删去非原题名的 (MR-PRESSO)；Methods Multiplicity 补族划分与 Table S28 独立簇的连接；S31 表注 totals 明确六非茶口径并给出七行合计；Highlights 第 1 条消除 caffeine loci 歧义、第 4 条补 FinnGen R13 与 FDR 限定；Figure S2 图注并列说明两图实心标记的不同阈值
- [ ] 补充图 S1 用 v55（2026-11-15）：Yuan 咖啡修正为 32 工具并重绘，保留 0.08 in 右侧留白；补充图 S2 用 v55：轴题改为通用 rg，图例明确实心圆为 FDR 显著、灰方块为验证控制
- [ ] Highlights 5 条，逐条 ≤ 120 字符（当前 116/115/113/111/85；已去除双项目符号）
- [ ] 第三轮修订（2026-11-15）：修正 Yuan 抽取对共享 SNP 的单一暴露分配，132/137 暴露–工具对可用；Yuan 咖啡 IVW 改为 OR 1.32（0.99–1.76），P=0.055；Table S26/S27/S30、Figure 2/S1、摘要/CP/Highlights/GA/STROBE 与候选包同步；ref 9 恢复原题名，当时新增 ref 58 为 Yuan 更正（最终 ref 23）
- [ ] 编辑聚焦修订（2026-11-15）：摘要改为 230 词并从遗传证据冲突切入；Discussion 净减 849 词；PubMed 更新至 2026-11-15，当时新增 ref 59–61（最终 ref 14、15、44）；投稿信补 Yuan 咖啡非显著；Figure 1 v59 与 GA v64 仅做呈现精简，不改估计
- [ ] 最终细节收尾（2026-11-17）：摘要展开缩写后 240 词，CP 207 词，正文 8,103 词、总词数 12,442；215 处语言/数学/格式统一；61 条引用按首现顺序重排，37 条文献按 AHA 前 10 作者规则修正；短题 38 字符、作者 MD、标题页总词数、页码、References→Figure legends→Tables 顺序和全部表格重复表头已补齐
- [ ] S27 与机制措辞闭环（2026-11-17）：主文和 S27 表注统一为剔除前 1.26–1.58、剔除后 1.26–1.39、随机删除 3.85%（全精度复算 77/2,000）；引言及 STROBE-MR 引述的 `determine` 改为 `interrogate`；GA v65 改为候选共定位表述。未改任何 MR 估计、引用或显著性判定
- [ ] 叙事层级校准（2026-11-22）：两遍独立复审一致后，将摘要、Clinical Perspective、引言目标句、Principal findings、Conclusions 与投稿信统一为「咖啡阳性信号→FTO/咖啡因位点拆解→有边界的甜饮料结果→奶茶外推限制」；甜饮料预设检验地位不变。STROBE-MR Item 1a/1b/3/17 改为当前正文转述，既有的 249 词和旧 Item 17 引述同步纠正；Highlights 保留功效与失败对照；GA v66 仅交换两个发现框位置。当前摘要 235 词、CP 167 词（含标题）、正文 8,092 词、总词数 12,386；未改任何 MR 估计、参考文献、表格数据或显著性判定

详细清单见归档夹 `审读意见_20261026\投稿前自检清单_20261027.md`。
