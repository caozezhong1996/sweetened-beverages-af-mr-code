v4.5.4 enhancement package (25 Aug 2026)
=========================================
Two independent-data-source consistency analyses for the nominal coffee signal:

1. Independent coffee-exposure GWAS replication (Neale lab UKB round-2 field 1498;
   n = 334,659; effects per ALT allele). Instruments: 3,147 variants at P < 5e-8
   (low-confidence excluded), 27 loci after 1-Mb window pruning, 24 recovered in the
   harmonized Nielsen 2018 statistics by chr:pos + exact ref/alt matching. IVW OR
   1.18 (0.93-1.50), P = 0.166; cross-GWAS fixed-effect meta-analysis OR 1.23
   (1.04-1.44), P = 0.013. Files: mr_/het_/pleio_/dat_Neale1498_*_v47, summary txt,
   cross-GWAS meta csv; script run_v47_neale1498_sensitivity.R. Table S19.

2. Full-coverage BMI mediation sensitivity (Neale lab field 21001, raw kg/m2;
   n = 359,983): 33 of 34 coffee instruments recovered (only rs117810762 missing);
   beta_XM = 3.587 kg/m2 = 0.747 SD (vs 0.820 SD Yengo primary); mediated
   proportion 109% (95% CI -9% to 227%). Units verified at the FTO anchor
   (beta = 0.359 kg/m2). Files: mediation_*21001_v47; script
   run_v47_mediation_neale21001.R. Table S16 sensitivity rows.

Source sumstats downloaded from the Neale lab S3 mirror (pdl.sh parallel range
requests; gzip integrity verified). All headline numbers appear in manuscript
Tables S16 and S19.
