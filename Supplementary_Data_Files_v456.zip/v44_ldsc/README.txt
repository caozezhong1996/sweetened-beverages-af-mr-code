v4.4 (LDSC revision) — 2026-08-23

New analysis: cross-trait LD score regression (LDSC; Bulik-Sullivan et al., 2015)
between five beverage traits (Neale lab UK Biobank round-2 full summary statistics,
pre-munged LDSC format) and atrial fibrillation (harmonized Nielsen 2018,
GWAS Catalog GCST006414; FinnGen release R13, I9_AF), using 1000 Genomes EUR
HapMap 3 LD scores (eur_w_ld_chr; Zenodo record 8182036, copy of the Alkes Group
reference; M = 1,290,027 SNPs). Two-step weighted least squares with 200-block
jackknife standard errors; effect alleles aligned across sources, palindromic
variants excluded; Benjamini-Hochberg FDR across the ten beverage-AF rg tests.

Validation: same-trait positive control Nielsen 2018 x FinnGen R13 returned
rg = 0.923 (SE 0.101); overlap positive control coffee x tea (both UK Biobank)
returned cross-trait intercept -0.318 (SE 0.011), confirming diagnostic
sensitivity, whereas all ten beverage-AF intercepts were ~0 (|int| <= 0.018),
quantitatively excluding material sample-overlap bias.

Note: full per-variant summary statistics for sugar added to tea (ukb-b-8442)
and artificial sweetener added to tea (ukb-b-5867) are not publicly distributed
(IEU PHESANT pipeline subsets, N = 64,949); LDSC therefore covers 5 of 7
exposures.

Files:
- ldsc_h2_v44.csv    single-trait observed-scale SNP heritability and intercepts (7 traits)
- ldsc_rg_v44.csv    cross-trait rg, SE, P, FDR q, cross-trait intercepts (10 tests + 2 controls)
- ldsc_v44_log.txt   console log of the analysis run
- run_v44_ldsc.R     LDSC analysis code (R)
- munge_for_ldsc.py  munging of Nielsen 2018 / FinnGen R13 to LDSC format (python)

Manuscript changes: new Methods subsection (Genetic correlation and overlap
diagnostics), new Results subsection (Genetic correlation with AF), Discussion
and limitation no. 6 updated with the quantitative overlap diagnostic,
references 21-22 added (Bulik-Sullivan 2015a/b). Supplement: Tables S10-S11
added. Cover letter updated.
