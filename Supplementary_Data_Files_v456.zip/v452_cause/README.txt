v4.5.2 CAUSE analysis (24 Aug 2026): genome-wide causal vs correlated-pleiotropy model
 for coffee intake vs AF (Nielsen 2018), on the same munged HM3 inputs as the LDSC analysis.
 Causal model not better than sharing (P = 0.534); posterior causal gamma = 0.01 (-0.01 to 0.04).
