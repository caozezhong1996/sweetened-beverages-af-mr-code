v4.5.3 enhancement package (25 Aug 2026)
=========================================
Three revision-stage robustness analyses for the sole nominal signal (coffee intake):

1. Two-step (network) mediation MR, coffee -> BMI -> AF (Nielsen 2018):
   mediation_bmi_v46.tsv (headline numbers), step1/step2 MR tables and harmonised
   datasets, and the 701 window-pruned BMI instruments. BMI source: Yengo 2018
   (GCST006900; same GWAS as the MVMR). Scripts: run_v46_mediation_bmi_{A,A2,C}.R

2. MRlap sample-overlap / winner's-curse / weak-instrument correction
   (coffee Neale-1498 x AF Nielsen-2018): mrlap_coffee_v46.txt; script run_v46_mrlap.R.
   GenomicSEM was loaded from source (devtools::load_all); install_genomicsem_deps.R
   lists its CRAN dependencies. Mounier & Kutalik 2023, Genet Epidemiol 47:314-331.

3. Negative outcome control vs atrioventricular block (FinnGen R13 I9_AVBLOCK):
   mr_avblock_v46.csv (9 exposures x IVW/WM/Egger); script run_v46_avblock.R.

All headline numbers appear in manuscript Tables S16-S18.
