v4.5.1 reviewer-driven enhancement analyses (24 Aug 2026):
 - coloc_priorscan_v45.tsv: coloc.abf prior p12 sensitivity scan at FTO (Nielsen 2018 + FinnGen R13)
 - conmix_coffee_v45.tsv: contamination-mixture estimates for coffee -> AF (34 instruments)
 - coloc_FTO_Nielsen_region_v45.tsv: Nielsen 2018 FTO regional dataset rebuilt from local full summary statistics (1,744 rows)
 - run_v45_coloc_priorscan.R / run_v45_conmix.R: analysis scripts
