# Release candidate — Pleiotropy at the FTO Locus in the Coffee–Atrial Fibrillation Signal

Date: 2026-11-08. Local candidate for a new Zenodo version; NOT yet published.

This build supersedes the 2026-11-07 candidate. Changes in this build:
- Table captions in the manuscript and supplement now use keep-with-next, so no caption is
  separated from its table across a page break (verified by two independent rendered checks);
- submission/, data/derived/nmr/ text exports and verification/ PDFs are regenerated from the
  current DOCX; MANIFEST.csv is recomputed.
- No manuscript text was changed in this build.

## 2026-11-17 S27 and wording closure

- Main text and Table S27 now consistently report the unrestricted coffee range as 1.26-1.58, the post-exclusion range as 1.26-1.39 and the random-deletion fraction as 3.85% (77/2,000).
- The objective wording and its STROBE-MR quotation use 'interrogate' rather than 'determine'.
- Graphical Abstract v65 uses 'Candidate FTO colocalization'. No estimate, reference, significance decision, layout or canvas changed.
- The current placebo script prints the fraction to two decimals; its isolated rerun reproduced the archived distribution byte for byte.

## Contents

- `submission/`: current manuscript, supplement, cover letter, highlights, README and figures.
- `code/current/` and `code/history/`: analysis and revision code.
- `data/harmonized/`, `data/derived/`: harmonized datasets and derived results.
- `verification/`: rendered PDFs of the current manuscript and supplement.

Publishing is the authors' external action. The manuscript, cover letter and
supplement cite the concept DOI 10.5281/zenodo.22099675, which always resolves
to the latest version, so no DOI text needs editing after upload. Only the
submission README status lines need updating.

## Data package mapping (added 2026-11-08)

- `Supplementary_Data_Files.zip`: 21 current-manuscript per-SNP harmonized CSVs
  plus `TableS30_per_variant_estimates.csv` (404 rows), matching the Supplement
  statement on per-SNP harmonized datasets.
- `data/derived/coloc_caf_v59/`: colocalization region summary statistics
  (the 'colocalization results directory' referred to in the Supplement).
- The deprecated `Supplementary_Data_Files_v456.zip` from the previous public
  release is intentionally NOT carried over: it contains historical v31-v456
  directories with deprecated outcome endpoints.

## Figure 1 spelling unification (added 2026-11-09)

- `submission/figures/Figure1_Study_Design.png` is v59; the current source script is
  `code/current/_build_fig1_v59.py`. Earlier v53-v58 scripts remain for reproducibility.
- Only two in-figure spellings changed (harmonisation->harmonization,
  harmonised->harmonized). A baseline re-render of v56 matched the previous PNG
  pixel-for-pixel; computed font sizes, band heights, gap, colours and canvas size
  are unchanged. No manuscript text, numbers or references changed.

## Current figure source scripts (added 2026-11-09)

Every figure in `submission/figures/` can be regenerated from a script in this archive:

| Figure | Current source script |
|---|---|
| `Figure1_Study_Design.png` (v59) | `code/current/_build_fig1_v59.py` |
| `Figure2_Forest.png` | `code/current/_build_fig2_v57.py` |
| `FigureS1_LOO_Funnel.png` (v55) | `code/current/build_figs1_v55.py` |
| `FigureS2_LDSC_rg.png` (v55) | `code/current/build_figs2_v55.py` |
| `Graphical_Abstract.png` (v65) | `code/current/_gabs_v65.py` |

Earlier Figure 1 v53-v58 and graphical-abstract v57-v63 scripts remain in
`code/current/` and `code/history/` for reproducibility of prior versions.
Figure 1 v59 simplifies the method lists and title; GA v64 removes a literature-search
statement from the findings panel. Neither changes data, estimates or canvas size. The v60 graphical-abstract source was added in this build: the
2026-11-09 layout fix had replaced the figure without archiving its script.

Note: the v53 supplemental scripts wrote files named `*_300dpi.png`, but their
`DPI` constant is 600 and they call `savefig(..., dpi=DPI)`. Re-running them on 2026-11-09
reproduced the current 600-dpi submission figures pixel-for-pixel. The suffix is historical.

## Revision of 2026-11-11 (post-mock-review)

- Corrected Supplement Table S31 caption: 29 -> 33 index variants with no retained
  variant across the six non-tea exposures (36 across all seven); the tea-panel
  29 retained variants remain in the dagger footnote.
- Aligned abstract, Clinical Perspective, limitations, Highlights wording and the
  graphical abstract with the three-tier null interpretation; added colocalization
  evidence boundaries to Strengths and limitations; restated the two sample-size
  comparisons by effective sample size; normalized four counts to thousands separators.
- Graphical abstract v60 -> v61 (two figure strings only; layout and canvas unchanged).
- The concept DOI still resolves to v5.2.4; publishing this build is the authors' action.

Also on 2026-11-11: the core document properties of Cover_Letter.docx and
Highlights.docx still carried the superseded title. Both were updated to the
current title; body text, headers and the Re line were already correct.

Legacy verifier retirement (2026-11-11): `verification/_verify_release.py` carried
v52-era assertions (superseded title, 248-word abstract, 55 references, 9,233-word
body, `_gabs_v57.py`). Running it against the current build would fail on stale
assertions rather than real defects. It was moved to `code/history/` for provenance.
Current verification is MANIFEST.csv plus the figure-to-source mapping above.

## 2026-11-12 figure-accuracy revision

- Figure S1 v53 -> v54: right margin 0.06 -> 0.08 in. This is the smallest value
  that keeps the rightmost A2 x tick label (2.5) inside the canvas; >= 0.10 in
  makes matplotlib re-select ticks and drop 2.5 entirely. No data, axis limits
  or font sizes changed.
- Figure 1 v57 -> v58 and Graphical Abstract v61 -> v62: outcome box titles now
  state that the listed numbers are case counts. The GA rg line names R13 as the
  single outcome source behind the two FDR-significant correlations. The GA left
  findings box keeps its v61 wording because the full three-way null
  classification needs 156.2 pt in a 155.9 pt box; it remains in manuscript P078.
- Figure S2 v53 -> v54: legend says solid/dashed LINE rather than circle; the two
  control-row rg labels use three decimals (0.923 / 0.005) to match the caption
  and Table S11. Main-trait rows stay at two decimals.
- Manuscript Figure S2 caption now states that only the five beverage traits with
  public full summary statistics were estimable and that the control rows are
  validation diagnostics rather than beverage-AF estimates.
- All four baseline scripts were re-rendered unchanged and matched the previous
  PNGs pixel-for-pixel before any edit was applied.

## 2026-11-14 second-round peer-review revision

Text-only changes after a second independent mock review. No figure, estimate,
confidence interval, P value or significance judgement changed.

- Supplement Table S9 (STROBE-MR checklist), item 16: replaced two quoted
  fragments that no longer exist in the Results. The second quoted sentence
  claimed 'four of the five' interpretable nulls, whereas the current text
  reports three interpretable, three qualified and coffee as a non-null.
  The cell now paraphrases the current three-way classification.
- Manuscript reference 30: removed the appended '(MR-PRESSO)' so the title
  matches the published record (Europe PMC PMID 29686387).
- Methods Multiplicity: added one sentence connecting the seven-test primary
  family to the pre-specified two-source meta-analysis and to the at-most-two
  independent clusters documented in Table S28.
- Supplement Table S31 caption: moved the six-non-tea qualifier in front of
  the totals and gave the seven-row sums (18 and 36) explicitly.
- Highlights: item 1 now says the caffeine-metabolism loci had no AF
  counterpart (rather than implying no coffee signal at those loci); item 4
  names FinnGen R13 as the single FDR-significant source.
- Manuscript Figure S2 caption: states that filled markers in this figure
  denote FDR q < 0.05 whereas those in Figure 2 denote nominal P < 0.05.
- Body text 9,601 -> 9,669 words; abstract 249, Clinical Perspective 187 and
  five Highlights bullets unchanged. submission README and MANIFEST updated.

## 2026-11-15 shared-instrument correction
- Yuan extraction originally allocated each shared SNP to only one exposure. The corrected join retains shared SNPs for every eligible exposure, giving 132 of 137 exposure-instrument pairs (128 of 133 unique variants).
- Yuan coffee IVW is OR 1.32 (0.99-1.76), P=0.054889; sugar added to coffee is OR 0.82 (0.59-1.14), P=0.243892. Table S26/S27/S30, main text, abstract, Clinical Perspective, Highlights, graphical abstract and Figures 2/S1 were regenerated.
- Table S30 now contains 404 rows: Nielsen 137, FinnGen 135 and Yuan 132. FTO API-based and locally rebuilt inputs plus full-prior outputs are included under data/derived/coloc_fto/.

The nmr PNGs are visual diagnostics; fig2_yuan.png and p_yuan.png were regenerated on 2026-11-15. The older S30 document builders are retained only under code/history/ and must not be run against the current Supplement.

## Final language, reference and layout sweep (2026-11-17)

The current manuscript has a 240-word abstract, 207-word Clinical Perspective,
8,103-word main text and 12,442 total words. References are numbered by first
appearance and use the AHA first-10-author rule. The final reference positions
include 14/15 for the 2026 coffee meta-analysis and UKB cohort, 22/23 for Yuan
and its Author Correction, and 44 for the JAHA left-atrial study. Main-text
section order is Introduction, Methods, Results, Discussion, Conclusions,
Declarations, References, Figure legends and Tables. Title-page metadata,
running title and page numbering were completed; all table header rows repeat
across pages. The sweep changed wording, notation, reference formatting and
layout properties only, not any effect estimate or significance decision.
